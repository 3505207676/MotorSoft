<?php
require_once __DIR__ . '/../../bootstrap.php';
agenda_controller()->listarHorarios();
