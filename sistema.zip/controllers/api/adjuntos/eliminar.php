<?php
require_once __DIR__ . '/../../bootstrap.php';
adjuntos_controller()->eliminar();
