<?php

require_once __DIR__ . '/../../models/Seguridad/Permiso.php';

class PermisoRepository
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /** @return Permiso[] */
    public function listarTodos(): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Permisos ORDER BY modulo, nombre'
        );
        return $this->mapMany($stmt->fetchAll());
    }

    /** @return Permiso[] */
    public function listarPorModulo(string $modulo): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Permisos WHERE modulo = :modulo ORDER BY nombre',
            [':modulo' => $modulo]
        );
        return $this->mapMany($stmt->fetchAll());
    }

    /** @return Permiso[] */
    public function listarPorRol(int $idRol): array
    {
        $sql = 'SELECT p.*
                FROM Permisos p
                INNER JOIN Permisos_Rol pr ON pr.id_permiso = p.id_permiso
                WHERE pr.id_rol = :id_rol
                  AND pr.deleted_at IS NULL
                ORDER BY p.modulo, p.nombre';
        $stmt = $this->db->query($sql, [':id_rol' => $idRol]);
        return $this->mapMany($stmt->fetchAll());
    }

    public function buscarPorId(int $id): ?Permiso
    {
        $stmt = $this->db->query(
            'SELECT * FROM Permisos WHERE id_permiso = :id LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        return $fila ? Permiso::fromArray($fila) : null;
    }

    /** @param array $filas
     *  @return Permiso[]
     */
    private function mapMany(array $filas): array
    {
        $lista = [];
        foreach ($filas as $fila) {
            $lista[] = Permiso::fromArray($fila);
        }
        return $lista;
    }
}
