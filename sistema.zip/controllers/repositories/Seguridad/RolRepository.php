<?php

require_once __DIR__ . '/../../models/Seguridad/Rol.php';
require_once __DIR__ . '/PermisoRepository.php';

class RolRepository
{
    private Database $db;
    private PermisoRepository $permisos;

    public function __construct(Database $db, ?PermisoRepository $permisos = null)
    {
        $this->db       = $db;
        $this->permisos = $permisos ?: new PermisoRepository($db);
    }

    public function buscarPorId(int $id, bool $conPermisos = true): ?Rol
    {
        $stmt = $this->db->query(
            'SELECT * FROM Roles WHERE id_rol = :id AND deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        if (!$fila) {
            return null;
        }
        $rol = Rol::fromArray($fila);
        if ($conPermisos) {
            $rol->setPermisos($this->permisos->listarPorRol((int) $rol->getIdRol()));
        }
        return $rol;
    }

    public function buscarPorNombre(string $nombre): ?Rol
    {
        $stmt = $this->db->query(
            'SELECT * FROM Roles WHERE nombre = :n AND deleted_at IS NULL LIMIT 1',
            [':n' => trim($nombre)]
        );
        $fila = $stmt->fetch();
        return $fila ? Rol::fromArray($fila) : null;
    }

    /** @return Rol[] */
    public function listar(bool $conPermisos = false): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Roles WHERE deleted_at IS NULL ORDER BY nombre'
        );
        $roles = [];
        foreach ($stmt->fetchAll() as $fila) {
            $rol = Rol::fromArray($fila);
            if ($conPermisos && $rol->getIdRol()) {
                $rol->setPermisos($this->permisos->listarPorRol((int) $rol->getIdRol()));
            }
            $roles[] = $rol;
        }
        return $roles;
    }

    /** @return Permiso[] */
    public function listarPermisos(): array
    {
        return $this->permisos->listarTodos();
    }
}
