<?php

require_once __DIR__ . '/../../models/Seguridad/LogAuditoria.php';

class LogAuditoriaRepository
{
    private const LIMITE_MAX = 1000;

    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function guardar(LogAuditoria $log): LogAuditoria
    {
        $sql = 'INSERT INTO Logs_Actoria (
                    id_usuario, id_sesiones, accion, tabla_afectada, registro_id,
                    valores_anteriores, valores_nuevos, ip_address, user_agent, fecha
                ) VALUES (
                    :id_usuario, :id_sesiones, :accion, :tabla_afectada, :registro_id,
                    :valores_anteriores, :valores_nuevos, :ip_address, :user_agent, :fecha
                )';
        $this->db->query($sql, [
            ':id_usuario'          => $log->getIdUsuario(),
            ':id_sesiones'         => $log->getIdSesion(),
            ':accion'              => $log->getAccion(),
            ':tabla_afectada'      => $log->getTablaAfectada(),
            ':registro_id'         => $log->getRegistroId(),
            ':valores_anteriores'  => $log->getValoresAnterioresJson(),
            ':valores_nuevos'      => $log->getValoresNuevosJson(),
            ':ip_address'          => $log->getIpAddress(),
            ':user_agent'          => $log->getUserAgent(),
            ':fecha'               => $log->getFecha()->format('Y-m-d H:i:s'),
        ]);
        $log->assignId((int) $this->db->lastInsertId());
        return $log;
    }

    public function buscarPorId(int $id): ?LogAuditoria
    {
        $stmt = $this->db->query(
            'SELECT l.*, u.nombre AS usuario_nombre
             FROM Logs_Actoria l
             LEFT JOIN Usuarios u ON u.id_usuario = l.id_usuario
             WHERE l.id_log = :id
             LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        return $fila ? LogAuditoria::fromArray($fila) : null;
    }

    /** @return LogAuditoria[] */
    public function listar(array $filtros = []): array
    {
        [$where, $params] = $this->armarWhere($filtros);
        $limite = (int) ($filtros['limite'] ?? 500);
        if ($limite < 1) {
            $limite = 500;
        }
        if ($limite > self::LIMITE_MAX) {
            $limite = self::LIMITE_MAX;
        }
        $sql = 'SELECT l.*, u.nombre AS usuario_nombre
                FROM Logs_Actoria l
                LEFT JOIN Usuarios u ON u.id_usuario = l.id_usuario
                WHERE ' . $where . '
                ORDER BY l.fecha DESC, l.id_log DESC
                LIMIT ' . $limite;
        return $this->mapMany($this->db->query($sql, $params)->fetchAll());
    }

    public function contar(array $filtros = []): int
    {
        [$where, $params] = $this->armarWhere($filtros);
        $fila = $this->db->query(
            'SELECT COUNT(*) AS total
             FROM Logs_Actoria l
             LEFT JOIN Usuarios u ON u.id_usuario = l.id_usuario
             WHERE ' . $where,
            $params
        )->fetch();
        return (int) ($fila['total'] ?? 0);
    }

    public function contarHoy(): int
    {
        $fila = $this->db->query(
            'SELECT COUNT(*) AS total FROM Logs_Actoria WHERE DATE(fecha) = CURDATE()'
        )->fetch();
        return (int) ($fila['total'] ?? 0);
    }

    /** @return string[] */
    public function listarTablas(): array
    {
        $stmt = $this->db->query(
            'SELECT DISTINCT tabla_afectada FROM Logs_Actoria ORDER BY tabla_afectada'
        );
        $out = [];
        foreach ($stmt->fetchAll() as $fila) {
            if (!empty($fila['tabla_afectada'])) {
                $out[] = $fila['tabla_afectada'];
            }
        }
        return $out;
    }

    /** @return LogAuditoria[] */
    public function listarPorTabla(string $tabla): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Logs_Actoria WHERE tabla_afectada = :tabla ORDER BY fecha DESC',
            [':tabla' => $tabla]
        );
        return $this->mapMany($stmt->fetchAll());
    }

    /** @return LogAuditoria[] */
    public function listarPorUsuario(int $idUsuario): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Logs_Actoria WHERE id_usuario = :id ORDER BY fecha DESC',
            [':id' => $idUsuario]
        );
        return $this->mapMany($stmt->fetchAll());
    }

    /**
     * @param array<string,mixed> $filtros
     * @return array{0:string,1:array<string,mixed>}
     */
    private function armarWhere(array $filtros): array
    {
        $sql = '1 = 1';
        $params = [];
        if (!empty($filtros['accion'])) {
            $sql .= ' AND l.accion = :accion';
            $params[':accion'] = $filtros['accion'];
        }
        if (!empty($filtros['tabla'])) {
            $sql .= ' AND l.tabla_afectada = :tabla';
            $params[':tabla'] = $filtros['tabla'];
        }
        if (!empty($filtros['id_usuario'])) {
            $sql .= ' AND l.id_usuario = :uid';
            $params[':uid'] = (int) $filtros['id_usuario'];
        }
        if (!empty($filtros['desde'])) {
            $sql .= ' AND l.fecha >= :desde';
            $params[':desde'] = $filtros['desde'];
        }
        if (!empty($filtros['hasta'])) {
            $sql .= ' AND l.fecha < DATE_ADD(:hasta, INTERVAL 1 DAY)';
            $params[':hasta'] = $filtros['hasta'];
        }
        if (!empty($filtros['tablas']) && is_array($filtros['tablas'])) {
            $keys = [];
            foreach (array_values($filtros['tablas']) as $i => $tabla) {
                $key = ':tab' . $i;
                $keys[] = $key;
                $params[$key] = $tabla;
            }
            if ($keys) {
                $sql .= ' AND LOWER(l.tabla_afectada) IN (' . implode(', ', $keys) . ')';
            }
        }
        if (!empty($filtros['excluir_tablas']) && is_array($filtros['excluir_tablas'])) {
            $keys = [];
            foreach (array_values($filtros['excluir_tablas']) as $i => $tabla) {
                $key = ':xtab' . $i;
                $keys[] = $key;
                $params[$key] = $tabla;
            }
            if ($keys) {
                $sql .= ' AND (l.tabla_afectada IS NULL OR l.tabla_afectada = \'\' OR LOWER(l.tabla_afectada) NOT IN ('
                    . implode(', ', $keys) . '))';
            }
        }
        $q = trim((string) ($filtros['q'] ?? $filtros['busqueda'] ?? ''));
        if ($q !== '') {
            $sql .= ' AND (
                u.nombre LIKE :q
                OR l.accion LIKE :q
                OR l.tabla_afectada LIKE :q
                OR CAST(l.registro_id AS CHAR) LIKE :q
                OR l.ip_address LIKE :q
            )';
            $params[':q'] = '%' . $q . '%';
        }
        return [$sql, $params];
    }

    /** @return LogAuditoria[] */
    private function mapMany(array $filas): array
    {
        $logs = [];
        foreach ($filas as $fila) {
            $logs[] = LogAuditoria::fromArray($fila);
        }
        return $logs;
    }
}
