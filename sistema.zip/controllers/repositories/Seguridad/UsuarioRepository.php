<?php

require_once __DIR__ . '/../../models/Seguridad/Usuario.php';
require_once __DIR__ . '/RolRepository.php';

class UsuarioRepository
{
    private Database $db;
    private RolRepository $roles;

    public function __construct(Database $db, ?RolRepository $roles = null)
    {
        $this->db    = $db;
        $this->roles = $roles ?: new RolRepository($db);
    }

    public function buscarPorId(int $id, bool $conRol = true): ?Usuario
    {
        $stmt = $this->db->query(
            'SELECT * FROM Usuarios WHERE id_usuario = :id AND deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        );
        return $this->hydrate($stmt->fetch() ?: null, $conRol);
    }

    public function buscarPorCorreo(string $correo, bool $conRol = true): ?Usuario
    {
        $stmt = $this->db->query(
            'SELECT * FROM Usuarios WHERE correo = :correo AND deleted_at IS NULL LIMIT 1',
            [':correo' => strtolower(trim($correo))]
        );
        return $this->hydrate($stmt->fetch() ?: null, $conRol);
    }

    public function buscarPorDocumento(string $documento, bool $conRol = true): ?Usuario
    {
        $stmt = $this->db->query(
            'SELECT * FROM Usuarios WHERE documento = :documento AND deleted_at IS NULL LIMIT 1',
            [':documento' => trim($documento)]
        );
        return $this->hydrate($stmt->fetch() ?: null, $conRol);
    }

    public function buscarPorTelefono(string $digitos, bool $conRol = false): ?Usuario
    {
        $solo = preg_replace('/\D+/', '', $digitos) ?? '';
        $sufijo = $solo === '' ? '' : substr($solo, -10);
        if ($sufijo === '') {
            return null;
        }
        $stmt = $this->db->query(
            'SELECT * FROM Usuarios
             WHERE deleted_at IS NULL
               AND telefono IS NOT NULL
               AND REPLACE(REPLACE(REPLACE(REPLACE(telefono, \' \', \'\'), \'-\', \'\'), \'+\', \'\'), \'.\', \'\') LIKE :s
             LIMIT 1',
            [':s' => '%' . $sufijo]
        );
        return $this->hydrate($stmt->fetch() ?: null, $conRol);
    }

    public function buscarPorTokenRecuperacion(string $token): ?Usuario
    {
        $hash = Usuario::hashToken($token);
        $fila = $this->db->query(
            'SELECT * FROM Usuarios
             WHERE token_recuperacion = :token
               AND deleted_at IS NULL
             LIMIT 1',
            [':token' => $hash]
        )->fetch();
        if (!$fila) {
            $fila = $this->db->query(
                'SELECT * FROM Usuarios
                 WHERE token_recuperacion = :token
                   AND deleted_at IS NULL
                 LIMIT 1',
                [':token' => $token]
            )->fetch();
        }
        return $this->hydrate($fila ?: null, true);
    }

    public function correoExiste(string $correo, ?int $exceptoId = null): bool
    {
        $sql = 'SELECT COUNT(*) AS total FROM Usuarios
                WHERE correo = :correo AND deleted_at IS NULL';
        $params = [':correo' => strtolower(trim($correo))];
        if ($exceptoId !== null) {
            $sql .= ' AND id_usuario <> :id';
            $params[':id'] = $exceptoId;
        }
        $fila = $this->db->query($sql, $params)->fetch();
        return (int) $fila['total'] > 0;
    }

    public function documentoExiste(string $documento, ?int $exceptoId = null): bool
    {
        $sql = 'SELECT COUNT(*) AS total FROM Usuarios
                WHERE documento = :documento AND deleted_at IS NULL';
        $params = [':documento' => $documento];
        if ($exceptoId !== null) {
            $sql .= ' AND id_usuario <> :id';
            $params[':id'] = $exceptoId;
        }
        $fila = $this->db->query($sql, $params)->fetch();
        return (int) $fila['total'] > 0;
    }

    /** @return Usuario[] */
    public function listar(): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Usuarios WHERE deleted_at IS NULL ORDER BY nombre'
        );
        $usuarios = [];
        foreach ($stmt->fetchAll() as $fila) {
            $usuarios[] = $this->hydrate($fila, true);
        }
        return $usuarios;
    }

    public function guardar(Usuario $usuario): Usuario
    {
        $rol = $usuario->getRol();
        if ($rol === null || $rol->getIdRol() === null) {
            throw new AppException('El usuario debe tener un rol válido', HTTP_BAD_REQUEST);
        }

        $params = [
            ':id_rol'             => $rol->getIdRol(),
            ':nombre'             => $usuario->getNombre(),
            ':correo'             => $usuario->getCorreo(),
            ':telefono'           => $usuario->getTelefono(),
            ':documento'          => $usuario->getDocumento(),
            ':estado'             => $usuario->getEstado(),
            ':password_hash'      => $usuario->getPasswordHash(),
            ':intentos_login'     => $usuario->getIntentosLogin(),
            ':token_recuperacion' => $usuario->getTokenRecuperacion(),
            ':token_expiracion'   => $usuario->getTokenExpiracion()
                ? $usuario->getTokenExpiracion()->format('Y-m-d H:i:s')
                : null,
            ':updated_at'         => $usuario->getUpdatedAt()
                ? $usuario->getUpdatedAt()->format('Y-m-d H:i:s')
                : null,
            ':updated_by'         => $usuario->getUpdatedBy(),
            ':deleted_at'         => $usuario->getDeletedAt()
                ? $usuario->getDeletedAt()->format('Y-m-d H:i:s')
                : null,
        ];

        if ($usuario->getIdUsuario() === null) {
            $sql = 'INSERT INTO Usuarios (
                        id_rol, nombre, correo, telefono, documento, estado,
                        password_hash, intentos_login, token_recuperacion, token_expiracion,
                        created_at, created_by
                    ) VALUES (
                        :id_rol, :nombre, :correo, :telefono, :documento, :estado,
                        :password_hash, :intentos_login, :token_recuperacion, :token_expiracion,
                        :created_at, :created_by
                    )';
            $params[':created_at'] = $usuario->getCreatedAt()->format('Y-m-d H:i:s');
            $params[':created_by'] = $usuario->getCreatedBy();
            unset($params[':updated_at'], $params[':updated_by'], $params[':deleted_at']);
            $this->db->query($sql, $params);
            $usuario->assignId((int) $this->db->lastInsertId());
            return $usuario;
        }

        $sql = 'UPDATE Usuarios SET
                    id_rol = :id_rol,
                    nombre = :nombre,
                    correo = :correo,
                    telefono = :telefono,
                    documento = :documento,
                    estado = :estado,
                    password_hash = :password_hash,
                    intentos_login = :intentos_login,
                    token_recuperacion = :token_recuperacion,
                    token_expiracion = :token_expiracion,
                    updated_at = :updated_at,
                    updated_by = :updated_by,
                    deleted_at = :deleted_at
                WHERE id_usuario = :id_usuario';
        $params[':id_usuario'] = $usuario->getIdUsuario();
        $this->db->query($sql, $params);
        return $usuario;
    }

    private function hydrate(?array $fila, bool $conRol): ?Usuario
    {
        if (!$fila) {
            return null;
        }
        $rol = null;
        if ($conRol && !empty($fila['id_rol'])) {
            $rol = $this->roles->buscarPorId((int) $fila['id_rol'], true);
        }
        return Usuario::fromArray($fila, $rol);
    }
}
