<?php

require_once __DIR__ . '/../../models/Seguridad/Sesion.php';
require_once __DIR__ . '/UsuarioRepository.php';

class SesionRepository
{
    private Database $db;
    private UsuarioRepository $usuarios;

    public function __construct(Database $db, ?UsuarioRepository $usuarios = null)
    {
        $this->db       = $db;
        $this->usuarios = $usuarios ?: new UsuarioRepository($db);
    }

    public function buscarPorToken(string $token, bool $conUsuario = true): ?Sesion
    {
        $stmt = $this->db->query(
            'SELECT * FROM Sesiones WHERE token = :token LIMIT 1',
            [':token' => $token]
        );
        $fila = $stmt->fetch();
        if (!$fila) {
            return null;
        }
        $usuario = null;
        if ($conUsuario) {
            $usuario = $this->usuarios->buscarPorId((int) $fila['id_usuario'], true);
        }
        return Sesion::fromArray($fila, $usuario);
    }

    public function buscarPorId(int $id): ?Sesion
    {
        $stmt = $this->db->query(
            'SELECT * FROM Sesiones WHERE id_sesiones = :id LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        return $fila ? Sesion::fromArray($fila) : null;
    }

    public function guardar(Sesion $sesion): Sesion
    {
        if ($sesion->getIdSesion() === null) {
            $sql = 'INSERT INTO Sesiones (
                        id_usuario, token, fecha_inicio, fecha_expiracion, ip_address, deleted_at
                    ) VALUES (
                        :id_usuario, :token, :fecha_inicio, :fecha_expiracion, :ip_address, :deleted_at
                    )';
            $this->db->query($sql, $this->params($sesion));
            $sesion->assignId((int) $this->db->lastInsertId());
            return $sesion;
        }

        $sql = 'UPDATE Sesiones SET
                    id_usuario = :id_usuario,
                    token = :token,
                    fecha_inicio = :fecha_inicio,
                    fecha_expiracion = :fecha_expiracion,
                    ip_address = :ip_address,
                    deleted_at = :deleted_at
                WHERE id_sesiones = :id_sesiones';
        $params = $this->params($sesion);
        $params[':id_sesiones'] = $sesion->getIdSesion();
        $this->db->query($sql, $params);
        return $sesion;
    }

    private function params(Sesion $sesion): array
    {
        return [
            ':id_usuario'       => $sesion->getIdUsuario(),
            ':token'            => $sesion->getToken(),
            ':fecha_inicio'     => $sesion->getFechaInicio()->format('Y-m-d H:i:s'),
            ':fecha_expiracion' => $sesion->getFechaExpiracion()->format('Y-m-d H:i:s'),
            ':ip_address'       => $sesion->getIpAddress(),
            ':deleted_at'       => $sesion->getDeletedAt()
                ? $sesion->getDeletedAt()->format('Y-m-d H:i:s')
                : null,
        ];
    }
}
