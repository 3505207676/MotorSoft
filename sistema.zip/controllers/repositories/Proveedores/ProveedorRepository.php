<?php

require_once __DIR__ . '/../../models/Proveedores/Proveedor.php';

class ProveedorRepository
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function buscarPorId(int $id): ?Proveedor
    {
        $fila = $this->db->query(
            'SELECT * FROM Proveedores WHERE id_proveedor = :id AND deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        )->fetch();
        return $fila ? Proveedor::fromArray($fila) : null;
    }

    public function buscarPorTelefono(string $digitos): ?Proveedor
    {
        $sufijo = $this->sufijoTelefono($digitos);
        if ($sufijo === '') {
            return null;
        }
        $fila = $this->db->query(
            'SELECT * FROM Proveedores
             WHERE deleted_at IS NULL
               AND REPLACE(REPLACE(REPLACE(REPLACE(telefono, \' \', \'\'), \'-\', \'\'), \'+\', \'\'), \'.\', \'\') LIKE :s
             LIMIT 1',
            [':s' => '%' . $sufijo]
        )->fetch();
        return $fila ? Proveedor::fromArray($fila) : null;
    }

    /** @return Proveedor[] */
    public function listar(array $filtros = []): array
    {
        $sql = 'SELECT * FROM Proveedores WHERE deleted_at IS NULL';
        $params = [];
        if (!empty($filtros['estado'])) {
            $sql .= ' AND estado = :est';
            $params[':est'] = $filtros['estado'];
        }
        if (!empty($filtros['busqueda'])) {
            $like = '%' . $filtros['busqueda'] . '%';
            $sql .= ' AND (nombre LIKE :q1 OR nit LIKE :q2 OR telefono LIKE :q3 OR email LIKE :q4)';
            $params[':q1'] = $like;
            $params[':q2'] = $like;
            $params[':q3'] = $like;
            $params[':q4'] = $like;
        }
        $sql .= ' ORDER BY nombre ASC';
        $lista = [];
        foreach ($this->db->query($sql, $params)->fetchAll() as $fila) {
            $lista[] = Proveedor::fromArray($fila);
        }
        return $lista;
    }

    public function guardar(Proveedor $proveedor): Proveedor
    {
        if ($proveedor->getIdProveedor() === null) {
            $this->db->query(
                'INSERT INTO Proveedores (nombre, nit, email, telefono, direccion, estado, created_at, created_by)
                 VALUES (:n, :nit, :e, :t, :d, :est, :c, :u)',
                [
                    ':n'   => $proveedor->getNombre(),
                    ':nit' => $proveedor->getNit(),
                    ':e'   => $proveedor->getEmail(),
                    ':t'   => $proveedor->getTelefono(),
                    ':d'   => $proveedor->getDireccion(),
                    ':est' => $proveedor->getEstado(),
                    ':c'   => $proveedor->getCreatedAt()->format('Y-m-d H:i:s'),
                    ':u'   => $proveedor->getCreatedBy(),
                ]
            );
            $proveedor->assignId((int) $this->db->lastInsertId());
            return $this->buscarPorId((int) $proveedor->getIdProveedor()) ?: $proveedor;
        }
        $this->db->query(
            'UPDATE Proveedores
             SET nombre = :n, nit = :nit, email = :e, telefono = :t, direccion = :d,
                 estado = :est, updated_at = :ua, updated_by = :ub
             WHERE id_proveedor = :id',
            [
                ':n'   => $proveedor->getNombre(),
                ':nit' => $proveedor->getNit(),
                ':e'   => $proveedor->getEmail(),
                ':t'   => $proveedor->getTelefono(),
                ':d'   => $proveedor->getDireccion(),
                ':est' => $proveedor->getEstado(),
                ':ua'  => date('Y-m-d H:i:s'),
                ':ub'  => $proveedor->getUpdatedBy(),
                ':id'  => $proveedor->getIdProveedor(),
            ]
        );
        return $this->buscarPorId((int) $proveedor->getIdProveedor()) ?: $proveedor;
    }

    private function sufijoTelefono(string $digitos): string
    {
        $solo = preg_replace('/\D+/', '', $digitos) ?? '';
        return $solo === '' ? '' : substr($solo, -10);
    }
}
