<?php

require_once __DIR__ . '/../../models/Ordenes/Servicio.php';

class ServicioRepository
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function buscarPorId(int $id): ?Servicio
    {
        $stmt = $this->db->query(
            'SELECT * FROM Servicios WHERE id_servicio = :id AND deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        return $fila ? Servicio::fromArray($fila) : null;
    }

    /** @return Servicio[] */
    public function listar(array $filtros = []): array
    {
        $sql = 'SELECT * FROM Servicios WHERE deleted_at IS NULL';
        $params = [];

        if (!empty($filtros['tipo'])) {
            $sql .= ' AND tipo = :tipo';
            $params[':tipo'] = $filtros['tipo'];
        }
        if (!empty($filtros['estado'])) {
            $sql .= ' AND estado = :estado';
            $params[':estado'] = $filtros['estado'];
        }
        if (!empty($filtros['busqueda'])) {
            $sql .= ' AND (nombre LIKE :busqueda OR descripcion LIKE :busqueda)';
            $params[':busqueda'] = '%' . $filtros['busqueda'] . '%';
        }

        $sql .= ' ORDER BY nombre ASC';
        $stmt = $this->db->query($sql, $params);

        $lista = [];
        foreach ($stmt->fetchAll() as $fila) {
            $lista[] = Servicio::fromArray($fila);
        }
        return $lista;
    }

    public function guardar(Servicio $servicio): Servicio
    {
        if ($servicio->getIdServicio() === null) {
            $sql = 'INSERT INTO Servicios (
                        tipo, nombre, descripcion, precio, estado, created_at, created_by
                    ) VALUES (
                        :tipo, :nombre, :descripcion, :precio, :estado, :created_at, :created_by
                    )';
            $this->db->query($sql, [
                ':tipo'        => $servicio->getTipo(),
                ':nombre'      => $servicio->getNombre(),
                ':descripcion' => $servicio->getDescripcion(),
                ':precio'      => $servicio->getPrecio(),
                ':estado'      => $servicio->getEstado(),
                ':created_at'  => $servicio->getCreatedAt()->format('Y-m-d H:i:s'),
                ':created_by'  => $servicio->getCreatedBy(),
            ]);
            $servicio->assignId((int) $this->db->lastInsertId());
            return $servicio;
        }

        $sql = 'UPDATE Servicios SET
                    tipo = :tipo,
                    nombre = :nombre,
                    descripcion = :descripcion,
                    precio = :precio,
                    estado = :estado,
                    updated_at = :updated_at,
                    updated_by = :updated_by,
                    deleted_at = :deleted_at
                WHERE id_servicio = :id';
        $this->db->query($sql, [
            ':tipo'        => $servicio->getTipo(),
            ':nombre'      => $servicio->getNombre(),
            ':descripcion' => $servicio->getDescripcion(),
            ':precio'      => $servicio->getPrecio(),
            ':estado'      => $servicio->getEstado(),
            ':updated_at'  => $servicio->getUpdatedAt()
                ? $servicio->getUpdatedAt()->format('Y-m-d H:i:s')
                : date('Y-m-d H:i:s'),
            ':updated_by'  => $servicio->getUpdatedBy(),
            ':deleted_at'  => $servicio->getDeletedAt()
                ? $servicio->getDeletedAt()->format('Y-m-d H:i:s')
                : null,
            ':id'          => $servicio->getIdServicio(),
        ]);
        return $servicio;
    }
}
