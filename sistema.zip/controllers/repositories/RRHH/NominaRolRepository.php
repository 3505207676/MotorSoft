<?php

require_once __DIR__ . '/../../models/RRHH/NominaRol.php';

class NominaRolRepository
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /** @return NominaRol[] */
    public function listarPorNomina(int $idNomina): array
    {
        $stmt = $this->db->query(
            'SELECT * FROM Nomina_Rol WHERE id_nomina = :id AND deleted_at IS NULL ORDER BY id_nomina_rol',
            [':id' => $idNomina]
        );
        $lista = [];
        foreach ($stmt->fetchAll() as $fila) {
            $lista[] = NominaRol::fromArray($fila);
        }
        return $lista;
    }

    public function guardar(NominaRol $linea): NominaRol
    {
        $this->db->query(
            'INSERT INTO Nomina_Rol
                (id_nomina, tipo_concepto, descripcion, valor, created_at, created_by)
             VALUES
                (:id_nomina, :tipo, :descripcion, :valor, :created_at, :created_by)',
            [
                ':id_nomina'   => $linea->getIdNomina(),
                ':tipo'        => $linea->getTipoConcepto(),
                ':descripcion' => $linea->getDescripcion(),
                ':valor'       => $linea->getValor(),
                ':created_at'  => $linea->getCreatedAt()->format('Y-m-d H:i:s'),
                ':created_by'  => $linea->getCreatedBy(),
            ]
        );
        $linea->assignId((int) $this->db->lastInsertId());
        return $linea;
    }
}
