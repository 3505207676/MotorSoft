<?php

require_once __DIR__ . '/../../models/RRHH/Nomina.php';
require_once __DIR__ . '/ContratoRepository.php';
require_once __DIR__ . '/NominaRolRepository.php';

class NominaRepository
{
    private Database $db;
    private ContratoRepository $contratos;
    private NominaRolRepository $lineas;

    public function __construct(
        Database $db,
        ContratoRepository $contratos,
        NominaRolRepository $lineas
    ) {
        $this->db        = $db;
        $this->contratos = $contratos;
        $this->lineas    = $lineas;
    }

    private const SELECT = 'SELECT n.*, u.nombre AS usuario_nombre
            FROM Nominas n
            INNER JOIN Contratos c ON c.id_contrato = n.id_contrato
            INNER JOIN Usuarios u ON u.id_usuario = c.id_usuario';

    public function buscarPorId(int $id): ?Nomina
    {
        $fila = $this->db->query(
            self::SELECT . ' WHERE n.id_nomina = :id AND n.deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        )->fetch();
        return $this->hydrate($fila ?: null);
    }

    public function existePeriodo(int $idContrato, string $periodo, ?int $exceptoId = null): bool
    {
        $sql = 'SELECT COUNT(*) AS total FROM Nominas
                WHERE id_contrato = :c AND periodo_pago = :p AND deleted_at IS NULL';
        $params = [':c' => $idContrato, ':p' => $periodo];
        if ($exceptoId !== null) {
            $sql .= ' AND id_nomina <> :id';
            $params[':id'] = $exceptoId;
        }
        $fila = $this->db->query($sql, $params)->fetch();
        return (int) ($fila['total'] ?? 0) > 0;
    }

    public function contarPorContrato(int $idContrato): int
    {
        $fila = $this->db->query(
            'SELECT COUNT(*) AS total FROM Nominas WHERE id_contrato = :c AND deleted_at IS NULL',
            [':c' => $idContrato]
        )->fetch();
        return (int) ($fila['total'] ?? 0);
    }

    /** @return Nomina[] */
    public function listar(array $filtros = []): array
    {
        $sql = self::SELECT . ' WHERE n.deleted_at IS NULL';
        $params = [];
        if (!empty($filtros['desde'])) {
            $sql .= ' AND n.fecha_pago >= :desde';
            $params[':desde'] = $filtros['desde'];
        }
        if (!empty($filtros['hasta'])) {
            $sql .= ' AND n.fecha_pago <= :hasta';
            $params[':hasta'] = $filtros['hasta'];
        }
        $stmt = $this->db->query(
            $sql . ' ORDER BY n.fecha_pago DESC, n.id_nomina DESC',
            $params
        );
        $lista = [];
        foreach ($stmt->fetchAll() as $fila) {
            $lista[] = $this->hydrate($fila);
        }
        return $lista;
    }

    public function guardar(Nomina $nomina): Nomina
    {
        if ($nomina->getIdNomina() === null) {
            $this->db->query(
                'INSERT INTO Nominas
                    (id_contrato, periodo_pago, fecha_pago, total_neto, created_at, created_by)
                 VALUES
                    (:id_contrato, :periodo_pago, :fecha_pago, :total_neto, :created_at, :created_by)',
                [
                    ':id_contrato'  => $nomina->getIdContrato(),
                    ':periodo_pago' => $nomina->getPeriodoPago(),
                    ':fecha_pago'   => $nomina->getFechaPago(),
                    ':total_neto'   => $nomina->getTotalNeto(),
                    ':created_at'   => $nomina->getCreatedAt()->format('Y-m-d H:i:s'),
                    ':created_by'   => $nomina->getCreatedBy(),
                ]
            );
            $nomina->assignId((int) $this->db->lastInsertId());
            return $this->buscarPorId((int) $nomina->getIdNomina()) ?: $nomina;
        }

        $this->db->query(
            'UPDATE Nominas SET
                periodo_pago = :periodo_pago,
                fecha_pago = :fecha_pago,
                total_neto = :total_neto,
                updated_at = :updated_at,
                updated_by = :updated_by,
                deleted_at = :deleted_at
             WHERE id_nomina = :id',
            [
                ':periodo_pago' => $nomina->getPeriodoPago(),
                ':fecha_pago'   => $nomina->getFechaPago(),
                ':total_neto'   => $nomina->getTotalNeto(),
                ':updated_at'   => $nomina->getUpdatedAt()
                    ? $nomina->getUpdatedAt()->format('Y-m-d H:i:s')
                    : date('Y-m-d H:i:s'),
                ':updated_by'   => $nomina->getUpdatedBy(),
                ':deleted_at'   => $nomina->getDeletedAt()
                    ? $nomina->getDeletedAt()->format('Y-m-d H:i:s')
                    : null,
                ':id'           => $nomina->getIdNomina(),
            ]
        );
        return $this->buscarPorId((int) $nomina->getIdNomina()) ?: $nomina;
    }

    private function hydrate(?array $fila): ?Nomina
    {
        if (!$fila) {
            return null;
        }
        $id = (int) ($fila['id_nomina'] ?? 0);
        $detalle = $id > 0 ? $this->lineas->listarPorNomina($id) : [];
        $contrato = !empty($fila['id_contrato'])
            ? $this->contratos->buscarPorId((int) $fila['id_contrato'])
            : null;
        $nomina = Nomina::fromArray($fila, $detalle, $contrato);
        if ($contrato) {
            $nomina->setContrato($contrato);
        }
        return $nomina;
    }
}
