<?php

require_once __DIR__ . '/../../models/RRHH/Contrato.php';

class ContratoRepository
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    private const SELECT = 'SELECT c.*, c.porcentaje_comicion AS porcentaje_comision, u.nombre AS usuario_nombre
            FROM Contratos c
            INNER JOIN Usuarios u ON u.id_usuario = c.id_usuario';

    public function buscarPorId(int $id): ?Contrato
    {
        $stmt = $this->db->query(
            self::SELECT . ' WHERE c.id_contrato = :id AND c.deleted_at IS NULL LIMIT 1',
            [':id' => $id]
        );
        $fila = $stmt->fetch();
        return $fila ? Contrato::fromArray($fila) : null;
    }

    public function vigentePorUsuario(int $idUsuario, ?int $exceptoId = null): ?Contrato
    {
        $sql = self::SELECT . ' WHERE c.id_usuario = :u AND c.estado_contrato = :e AND c.deleted_at IS NULL';
        $params = [':u' => $idUsuario, ':e' => Contrato::VIGENTE];
        if ($exceptoId !== null) {
            $sql .= ' AND c.id_contrato <> :id';
            $params[':id'] = $exceptoId;
        }
        $sql .= ' LIMIT 1';
        $fila = $this->db->query($sql, $params)->fetch();
        return $fila ? Contrato::fromArray($fila) : null;
    }

    /** @return Contrato[] */
    public function listar(): array
    {
        $stmt = $this->db->query(
            self::SELECT . ' WHERE c.deleted_at IS NULL ORDER BY c.fecha_ingreso DESC, c.id_contrato DESC'
        );
        $lista = [];
        foreach ($stmt->fetchAll() as $fila) {
            $lista[] = Contrato::fromArray($fila);
        }
        return $lista;
    }

    public function guardar(Contrato $contrato): Contrato
    {
        $params = [
            ':id_usuario'          => $contrato->getIdUsuario(),
            ':salario_base'        => $contrato->getSalarioBase(),
            ':porcentaje_comicion' => $contrato->getPorcentajeComision(),
            ':fecha_ingreso'       => $contrato->getFechaIngreso(),
            ':fecha_retiro'        => $contrato->getFechaRetiro(),
            ':estado_contrato'     => $contrato->getEstadoContrato(),
        ];

        if ($contrato->getIdContrato() === null) {
            $this->db->query(
                'INSERT INTO Contratos
                    (id_usuario, salario_base, porcentaje_comicion, fecha_ingreso, fecha_retiro,
                     estado_contrato, created_at, created_by)
                 VALUES
                    (:id_usuario, :salario_base, :porcentaje_comicion, :fecha_ingreso, :fecha_retiro,
                     :estado_contrato, :created_at, :created_by)',
                $params + [
                    ':created_at' => $contrato->getCreatedAt()->format('Y-m-d H:i:s'),
                    ':created_by' => $contrato->getCreatedBy(),
                ]
            );
            $contrato->assignId((int) $this->db->lastInsertId());
            return $this->buscarPorId((int) $contrato->getIdContrato()) ?: $contrato;
        }

        $this->db->query(
            'UPDATE Contratos SET
                id_usuario = :id_usuario,
                salario_base = :salario_base,
                porcentaje_comicion = :porcentaje_comicion,
                fecha_ingreso = :fecha_ingreso,
                fecha_retiro = :fecha_retiro,
                estado_contrato = :estado_contrato,
                updated_at = :updated_at,
                updated_by = :updated_by,
                deleted_at = :deleted_at
             WHERE id_contrato = :id',
            $params + [
                ':updated_at' => $contrato->getUpdatedAt()
                    ? $contrato->getUpdatedAt()->format('Y-m-d H:i:s')
                    : date('Y-m-d H:i:s'),
                ':updated_by' => $contrato->getUpdatedBy(),
                ':deleted_at' => $contrato->getDeletedAt()
                    ? $contrato->getDeletedAt()->format('Y-m-d H:i:s')
                    : null,
                ':id'         => $contrato->getIdContrato(),
            ]
        );
        return $this->buscarPorId((int) $contrato->getIdContrato()) ?: $contrato;
    }
}
