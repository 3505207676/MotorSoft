// Funciones auxiliares para llamadas a la API

async function apiCall(endpoint, options = {}) {
    const baseUrl = (typeof APP_CONFIG !== 'undefined' && APP_CONFIG.apiBaseUrl) ? APP_CONFIG.apiBaseUrl : '../../controllers/api';
    const url = baseUrl + endpoint;

    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('authToken') || ''}`
        }
    };

    const finalOptions = { ...defaultOptions, ...options };

    try {
        const response = await fetch(url, finalOptions);
        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.mensaje || 'Error en la petición');
        }

        return data;
    } catch (error) {
        console.error('Error en API:', error);
        throw error;
    }
}

async function obtenerOrdenes(filtros = {}) {
    const endpoint = (typeof APP_CONFIG !== 'undefined') ? APP_CONFIG.endpoints.ordenesObtener : '/ordenes/obtener.php';
    const queryString = new URLSearchParams(filtros).toString();
    return await apiCall(`${endpoint}?${queryString}`);
}

async function crearOrden(datos) {
    const endpoint = (typeof APP_CONFIG !== 'undefined') ? APP_CONFIG.endpoints.ordenesCrear : '/ordenes/crear.php';
    return await apiCall(endpoint, {
        method: 'POST',
        body: JSON.stringify(datos)
    });
}

window.API = {
    obtenerOrdenes,
    crearOrden
    // ... más funciones según crezcan los endpoints
};

