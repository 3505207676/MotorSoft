/**
 * Auditoría: frases en español, con fechas en servidor y export CSV.
 */
const AuditoriaModule = (() => {
    const state = {
        logs: [],
        modulos: [],
        resumen: {},
        filtros: { accion: 'todos', modulo: 'todos', busqueda: '' }
    };

    function mc() {
        return window.ModuleCore;
    }

    function esc(valor) {
        return String(valor ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function iso(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function rangoPreset(kind) {
        const now = new Date();
        const hasta = iso(now);
        if (kind === 'hoy') {
            return { desde: hasta, hasta };
        }
        if (kind === 'semana') {
            const d = new Date(now);
            const day = (d.getDay() + 6) % 7;
            d.setDate(d.getDate() - day);
            return { desde: iso(d), hasta };
        }
        return {
            desde: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`,
            hasta
        };
    }

    function params() {
        const p = {
            desde: document.getElementById('audit-desde')?.value || '',
            hasta: document.getElementById('audit-hasta')?.value || ''
        };
        if (state.filtros.accion && state.filtros.accion !== 'todos') {
            p.accion = state.filtros.accion;
        }
        if (state.filtros.modulo && state.filtros.modulo !== 'todos') {
            p.modulo = state.filtros.modulo;
        }
        if (state.filtros.busqueda) {
            p.q = state.filtros.busqueda;
        }
        return p;
    }

    async function init() {
        const mes = rangoPreset('mes');
        const d = document.getElementById('audit-desde');
        const h = document.getElementById('audit-hasta');
        if (d) d.value = mes.desde;
        if (h) h.value = mes.hasta;
        bindEvents();
        await loadAll();
        render();
    }

    async function loadAll() {
        const res = await window.apiAuditoria(params());
        const data = res.data || {};
        state.logs = data.logs || [];
        state.modulos = data.modulos || [];
        state.resumen = data.resumen || {};
        llenarModulos();
    }

    function llenarModulos() {
        const sel = document.getElementById('filter-modulo');
        if (!sel) return;
        const actual = state.filtros.modulo || sel.value || 'todos';
        const extras = state.modulos.map(m => `<option value="${esc(m.id)}">${esc(m.etiqueta)}</option>`).join('');
        sel.innerHTML = '<option value="todos">Todos los módulos</option>' + extras;
        if ([...sel.options].some(o => o.value === actual)) {
            sel.value = actual;
        }
    }

    function marcarPreset(kind) {
        document.querySelectorAll('[data-rango]').forEach(b => {
            b.classList.toggle('active', b.getAttribute('data-rango') === kind);
        });
    }

    function bindEvents() {
        document.getElementById('btn-refresh-audit')?.addEventListener('click', async () => {
            await recargar();
            mc().toast?.('Auditoría actualizada', 'success');
        });
        document.getElementById('btn-aplicar-audit')?.addEventListener('click', async () => {
            marcarPreset('');
            await recargar();
        });
        document.getElementById('btn-export-audit')?.addEventListener('click', exportar);
        document.querySelectorAll('[data-rango]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const kind = btn.getAttribute('data-rango');
                const r = rangoPreset(kind);
                marcarPreset(kind);
                const d = document.getElementById('audit-desde');
                const h = document.getElementById('audit-hasta');
                if (d) d.value = r.desde;
                if (h) h.value = r.hasta;
                await recargar();
            });
        });
        document.getElementById('filter-accion')?.addEventListener('change', async e => {
            state.filtros.accion = e.target.value;
            await recargar();
        });
        document.getElementById('filter-modulo')?.addEventListener('change', async e => {
            state.filtros.modulo = e.target.value;
            await recargar();
        });
        document.getElementById('search-audit')?.addEventListener('input', mc().debounce(async e => {
            state.filtros.busqueda = e.target.value.trim();
            await recargar();
        }, 400));
        document.getElementById('tabla-auditoria')?.addEventListener('click', e => {
            const btn = e.target.closest('.btn-view');
            if (!btn) return;
            const log = state.logs.find(l => Number(l.id_log) === parseInt(btn.dataset.id, 10));
            if (log) showDetail(log);
        });
    }

    async function recargar() {
        try {
            await loadAll();
            render();
        } catch (err) {
            mc().toast?.(err.message || 'No se pudo cargar la auditoría', 'error');
        }
    }

    function filtered() {
        const q = (state.filtros.busqueda || '').toLowerCase();
        if (!q) return state.logs;
        return state.logs.filter(l => (
            [l.usuario_nombre, l.resumen, l.modulo_etiqueta, l.sujeto, l.accion_etiqueta]
                .some(v => String(v || '').toLowerCase().includes(q))
        ));
    }

    function render() {
        const tbody = document.querySelector('#tabla-auditoria tbody');
        if (!tbody) return;
        const items = filtered();
        const r = state.resumen || {};
        setText('kpi-audit-hoy', r.hoy ?? 0);
        setText('kpi-audit-periodo', r.total ?? items.length);
        setText('kpi-audit-mostrados', items.length);
        const aviso = document.getElementById('audit-aviso-truncado');
        if (aviso) aviso.hidden = !r.truncado;
        tbody.innerHTML = items.map(l => `<tr>
            <td>${esc(mc().formatDateTime(l.fecha))}</td>
            <td>${esc(l.usuario_nombre || 'Sistema')}</td>
            <td class="col-hecho">${esc(l.resumen || 'Actividad en el sistema')}</td>
            <td>${esc(l.modulo_etiqueta || '—')}</td>
            <td><button type="button" class="btn-icon btn-sm btn-view" data-id="${l.id_log}" title="Ver detalle"><i class="fas fa-eye"></i></button></td>
        </tr>`).join('') || mc().emptyRow(5, 'No hay actividad con esos filtros');
    }

    function setText(id, val) {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    }

    function exportar() {
        const items = filtered();
        if (!items.length) {
            mc().toast?.('No hay actividad para exportar', 'warning');
            return;
        }
        if (state.resumen?.truncado) {
            mc().toast?.('Se exportan solo los eventos mostrados. Acote fechas si necesita el resto.', 'warning');
        }
        window.descargarCsv('auditoria', ['Cuándo', 'Quién', 'Qué ocurrió', 'Módulo', 'IP'], items.map(l => [
            l.fecha || '', l.usuario_nombre || 'Sistema', l.resumen || '', l.modulo_etiqueta || '', l.ip_address || ''
        ]));
    }

    function showDetail(log) {
        const cambios = Array.isArray(log.cambios) ? log.cambios : [];
        const filas = cambios.map(c => `<tr>
            <td>${esc(c.campo)}</td>
            <td class="audit-antes">${esc(c.antes)}</td>
            <td class="audit-despues">${esc(c.despues)}</td>
        </tr>`).join('');
        const bloqueCambios = filas
            ? `<table class="audit-cambios"><thead><tr><th>Dato</th><th>Antes</th><th>Quedó</th></tr></thead><tbody>${filas}</tbody></table>`
            : '<p class="text-muted">No hay un antes/después de campos. El resumen de arriba es el registro.</p>';
        const viejo = document.getElementById('audit-det');
        if (viejo) viejo.remove();
        window.createModal?.('audit-det', 'Qué ocurrió', `
            <p class="audit-resumen">${esc(log.resumen || '')}</p>
            <div class="audit-meta">
                <div><label>Quién</label><p>${esc(log.usuario_nombre || 'Sistema')}</p></div>
                <div><label>Módulo</label><p>${esc(log.modulo_etiqueta || '—')}</p></div>
                <div><label>Cuándo</label><p>${esc(mc().formatDateTime(log.fecha))}</p></div>
                <div><label>Desde</label><p>${esc(log.ip_address || '—')}</p></div>
            </div>
            ${bloqueCambios}
        `);
        const pie = document.querySelector('#audit-det .modal-footer');
        if (pie) pie.style.display = 'none';
    }

    return { init };
})();

window.__auditoriaInit = false;
function iniciarAuditoria() {
    if (window.__auditoriaInit) return;
    window.__auditoriaInit = true;
    AuditoriaModule.init();
}
document.addEventListener('DOMContentLoaded', iniciarAuditoria);
if (document.readyState !== 'loading') {
    iniciarAuditoria();
}
