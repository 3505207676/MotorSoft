/**
 * Catálogo de servicios del taller (mano de obra que se usa en las OT).
 */
const ServiciosCatalogo = (() => {
    const state = {
        items: [],
        edit: null,
        filtro: { estado: 'todos', busqueda: '' }
    };

    function puede(slug) {
        return !window.MotorSoftGuard || window.MotorSoftGuard.puede(slug);
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function money(n) {
        if (window.ModuleCore?.formatCurrency) return ModuleCore.formatCurrency(n);
        return Number(n || 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
    }

    function aplicarPermisos() {
        const crear = puede('servicios.crear');
        const btn = document.getElementById('btn-nuevo-servicio');
        if (btn) btn.hidden = !crear;
        const aviso = document.getElementById('catalogo-rol-aviso');
        if (aviso && !puede('servicios.editar') && !crear) {
            aviso.textContent = 'Solo lectura: los nombres y precios del catálogo los define un administrador o gerente.';
        }
    }

    async function cargar() {
        try {
            const res = await window.apiServicios();
            state.items = Array.isArray(res.data) ? res.data : [];
            pintar();
            document.dispatchEvent(new CustomEvent('motorsoft:servicios-actualizados', { detail: state.items }));
        } catch (e) {
            state.items = [];
            pintar();
            window.showToast?.(e.message || 'No se pudo cargar el catálogo', 'error');
        }
    }

    function filtrados() {
        return state.items.filter(s => {
            if (state.filtro.estado !== 'todos' && s.estado !== state.filtro.estado) return false;
            if (state.filtro.busqueda) {
                const q = state.filtro.busqueda;
                return [s.nombre, s.tipo, s.descripcion].some(v => String(v || '').toLowerCase().includes(q));
            }
            return true;
        });
    }

    function pintar() {
        const tbody = document.querySelector('#tabla-servicios tbody');
        if (!tbody) return;
        const items = filtrados();
        if (!items.length) {
            tbody.innerHTML = ModuleCore.emptyRow(5, 'No hay servicios en el catálogo');
            return;
        }
        const puedeEditar = puede('servicios.editar');
        const puedeBorrar = puede('servicios.eliminar') || puede('servicios.editar');
        tbody.innerHTML = items.map(s => `<tr>
            <td><strong>${esc(s.nombre)}</strong>${s.descripcion ? `<br><small class="text-muted">${esc(s.descripcion)}</small>` : ''}</td>
            <td>${esc(s.tipo || '—')}</td>
            <td>${money(s.precio)}</td>
            <td>${ModuleCore.badge(s.estado)}</td>
            <td>${ModuleCore.actionButtons(s.id_servicio, { view: false, edit: puedeEditar, del: puedeBorrar && s.estado === 'Activo' })}</td>
        </tr>`).join('');
    }

    function abrir(servicio = null) {
        if (!puede(servicio ? 'servicios.editar' : 'servicios.crear')) {
            window.showToast?.('No tiene permiso para cambiar el catálogo', 'error');
            return;
        }
        state.edit = servicio;
        const titulo = document.getElementById('modal-servicio-title');
        if (titulo) titulo.textContent = servicio ? `Editar: ${servicio.nombre}` : 'Nuevo servicio';
        const f = document.getElementById('form-servicio');
        if (f) f.reset();
        document.getElementById('srv-nombre').value = servicio?.nombre || '';
        document.getElementById('srv-tipo').value = servicio?.tipo || '';
        document.getElementById('srv-precio').value = servicio ? Number(servicio.precio || 0) : '';
        document.getElementById('srv-descripcion').value = servicio?.descripcion || '';
        document.getElementById('srv-estado').value = servicio?.estado || 'Activo';
        ModuleCore.openModal('modal-servicio');
    }

    async function guardar() {
        const f = document.getElementById('form-servicio');
        if (!f.checkValidity()) {
            f.reportValidity();
            return;
        }
        const data = {
            nombre: document.getElementById('srv-nombre').value.trim(),
            tipo: document.getElementById('srv-tipo').value.trim() || null,
            precio: Number(document.getElementById('srv-precio').value),
            descripcion: document.getElementById('srv-descripcion').value.trim() || null,
            estado: document.getElementById('srv-estado').value
        };
        if (!data.nombre || Number.isNaN(data.precio) || data.precio < 0) {
            window.showToast?.('Indique nombre y un precio válido', 'error');
            return;
        }
        try {
            if (state.edit) {
                await window.apiServiciosActualizar(state.edit.id_servicio, data);
                window.showToast?.('Servicio actualizado', 'success');
            } else {
                await window.apiServiciosCrear(data);
                window.showToast?.('Servicio creado', 'success');
            }
            ModuleCore.closeModal('modal-servicio');
            await cargar();
        } catch (e) {
            window.showToast?.(e.message || 'No se pudo guardar el servicio', 'error');
        }
    }

    async function desactivar(servicio) {
        try {
            if (typeof window.apiServiciosEstado === 'function' && puede('servicios.eliminar')) {
                await window.apiServiciosEstado(servicio.id_servicio, 'Inactivo');
            } else {
                await window.apiServiciosActualizar(servicio.id_servicio, { estado: 'Inactivo' });
            }
            window.showToast?.('Servicio desactivado', 'success');
            await cargar();
        } catch (e) {
            window.showToast?.(e.message || 'No se pudo desactivar', 'error');
        }
    }

    function onTabla(e) {
        const btn = e.target.closest('.btn-edit, .btn-delete');
        if (!btn) return;
        const id = Number(btn.dataset.id);
        const servicio = state.items.find(s => Number(s.id_servicio) === id);
        if (!servicio) return;
        if (btn.classList.contains('btn-edit')) abrir(servicio);
        else {
            ModuleCore.confirm(
                'Desactivar servicio',
                `¿Desactivar “${servicio.nombre}”? Dejará de aparecer al crear órdenes.`,
                () => desactivar(servicio)
            );
        }
    }

    function init() {
        if (!document.getElementById('tabla-servicios')) return;
        if (init._done) return;
        init._done = true;
        aplicarPermisos();
        ModuleCore.initTabs('#modulo-ordenes');
        ModuleCore.bindModalClose('modal-servicio', 'btn-cancelar-servicio', 'btn-cerrar-servicio');
        document.getElementById('btn-nuevo-servicio')?.addEventListener('click', () => abrir());
        document.getElementById('btn-guardar-servicio')?.addEventListener('click', guardar);
        document.getElementById('btn-refresh-servicios')?.addEventListener('click', cargar);
        document.getElementById('search-servicio')?.addEventListener('input', ModuleCore.debounce(e => {
            state.filtro.busqueda = (e.target.value || '').trim().toLowerCase();
            pintar();
        }));
        document.getElementById('filter-servicio-estado')?.addEventListener('change', e => {
            state.filtro.estado = e.target.value;
            pintar();
        });
        document.getElementById('tabla-servicios')?.addEventListener('click', onTabla);
        cargar();
    }

    return { init, cargar, items: () => state.items };
})();

document.addEventListener('DOMContentLoaded', () => ServiciosCatalogo.init());
if (document.readyState !== 'loading') {
    ServiciosCatalogo.init();
}
window.ServiciosCatalogo = ServiciosCatalogo;
