/**
 * Módulo RRHH: Usuarios, Contratos, Nóminas, Especialidades y Roles
 */
const UsuariosRRHHModule = (() => {
    const state = {
        usuarios: [], contratos: [], nominas: [], nominaDetalle: [],
        roles: [], catalogoPermisos: [], especialidades: [],
        yo: null,
        esAdmin: false,
        puedeCrear: false,
        puedeEditar: false,
        puedeEliminar: false,
        puedeContratos: false,
        puedeNominas: false,
        puedeVerContratos: false,
        puedeVerNominas: false,
        puedeVerEspecialidades: false,
        puedeEspecialidades: false,
        puedeRoles: false,
        cajaAbierta: false,
        editUsuario: null, editContrato: null, editNomina: null,
        editEspecialidad: null, asignarEspecialidad: null,
        rolActivoId: null,
        pag: { page: 1, perPage: 8, totalPages: 1 },
        filtros: { rol: 'todos', busqueda: '' }
    };

    async function init() {
        try {
            await loadAll();
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudieron cargar los usuarios', 'error');
        }
        ModuleCore.initTabs('#modulo-usuarios', () => {});
        forzarBotonNuevoUsuario();
        bindEvents();
        renderAll();
    }

    async function loadAll() {
        const peticiones = [
            window.apiUsuarios(true),
            window.apiRoles(),
            window.apiContratos().catch(() => ({ data: [] })),
            window.apiNominas().catch(() => ({ data: [] })),
            window.apiMe ? window.apiMe().catch(() => null) : Promise.resolve(null),
            window.apiCajaActiva ? window.apiCajaActiva().catch(() => null) : Promise.resolve(null),
            window.apiEspecialidades
                ? window.apiEspecialidades({ usuarios: 1 }).catch(() => ({ data: [] }))
                : Promise.resolve({ data: [] }),
        ];
        const [usr, roles, contratosRes, nominasRes, me, caja, espeRes] = await Promise.all(peticiones);
        state.usuarios = usr.data || [];
        const rawRoles = roles.data;
        if (Array.isArray(rawRoles)) {
            state.roles = rawRoles;
            state.catalogoPermisos = [];
        } else {
            state.roles = rawRoles?.roles || [];
            state.catalogoPermisos = rawRoles?.catalogo || [];
        }
        state.contratos = contratosRes.data || [];
        state.nominas = nominasRes.data || [];
        state.nominaDetalle = state.nominas.flatMap(n => (n.detalle || []).map(d => ({ ...d, id_nomina: n.id_nomina })));
        state.especialidades = Array.isArray(espeRes?.data) ? espeRes.data : [];
        state.yo = me?.data?.usuario || null;
        state.cajaAbierta = !!(caja?.data?.sesion);
        const sesionLocal = (() => {
            try { return JSON.parse(localStorage.getItem('motorsoft_sesion') || 'null'); } catch (e) { return null; }
        })();
        const rolNombre = (nombreRol(state.yo) + ' ' + (sesionLocal?.rol || '')).toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        state.esAdmin = !!(state.yo?.es_admin || rolNombre.includes('admin'));
        const puede = (slug) => window.MotorSoftGuard?.puede
            ? window.MotorSoftGuard.puede(slug, state.yo)
            : state.esAdmin;
        state.puedeCrear = puede('usuarios.crear');
        state.puedeEditar = puede('usuarios.editar');
        state.puedeEliminar = puede('usuarios.eliminar');
        state.puedeContratos = puede('contratos.gestionar');
        state.puedeNominas = puede('nominas.crear');
        state.puedeVerContratos = puede('contratos.ver') || state.puedeContratos;
        state.puedeVerNominas = puede('nominas.ver') || state.puedeNominas;
        state.puedeVerEspecialidades = puede('especialidades.ver') || puede('especialidades.gestionar');
        state.puedeEspecialidades = puede('especialidades.gestionar');
        state.puedeRoles = puede('roles.gestionar') && !state.yo?.es_gerente;
        if (state.yo) {
            window.pintarSidebarUsuario?.(state.yo);
        }
        llenarSelectRoles();
        pintarAvisoCaja();
        forzarBotonNuevoUsuario();
    }

    function pintarAvisoCaja() {
        const texto = state.cajaAbierta
            ? ''
            : 'Para registrar una nómina debe abrir caja en Contabilidad.';
        ['aviso-caja-nomina', 'aviso-caja-modal-nomina'].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.style.display = texto ? 'block' : 'none';
            if (id === 'aviso-caja-nomina') el.textContent = texto;
        });
    }

    function marcarCampo(input, invalido) {
        if (!input) return;
        input.classList.toggle('campo-invalido', !!invalido);
    }

    function mostrarErrores(lista) {
        const box = document.getElementById('usuario-form-errores');
        if (!box) return;
        if (!lista.length) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        box.style.display = 'block';
        box.innerHTML = '<strong>Revise el formulario:</strong><ul style="margin:0.4rem 0 0;padding-left:1.2rem">' +
            lista.map(e => `<li>${e}</li>`).join('') + '</ul>';
    }

    function validarFormularioUsuario(f, esEdicion) {
        const errores = [];
        const nombre = (f.nombre.value || '').trim();
        const apellido = (f.apellido?.value || '').trim();
        const correo = (f.correo.value || '').trim();
        const telefono = (f.telefono.value || '').trim();
        const documento = (f.documento.value || '').trim();
        const idRol = parseInt(f.id_rol.value, 10);
        const password = (f.password.value || '').trim();

        const nombreMal = nombre.length < 2 || /[^A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]/.test(nombre);
        const apellidoMal = !!apellido && /[^A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]/.test(apellido);
        const correoMal = !correo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo);
        const telefonoMal = !/^\d{7,15}$/.test(telefono);
        const documentoMal = !/^\d{5,15}$/.test(documento);
        const rolMal = !idRol;
        const passMal = esEdicion && password && password.length < 6;

        if (nombre.length < 2) errores.push('El nombre es obligatorio (mínimo 2 letras).');
        else if (/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]/.test(nombre)) errores.push('El nombre solo admite letras.');
        if (apellidoMal) errores.push('El apellido solo admite letras.');
        if (!correo) errores.push('El correo es obligatorio.');
        else if (correoMal) errores.push('El correo no es válido.');
        if (!telefono) errores.push('El teléfono es obligatorio.');
        else if (telefonoMal) errores.push('El teléfono debe tener entre 7 y 15 dígitos.');
        if (!documento) errores.push('El documento es obligatorio.');
        else if (documentoMal) errores.push('El documento debe tener entre 5 y 15 dígitos.');
        if (rolMal) errores.push('Seleccione un rol.');
        if (!esEdicion && password && password.length < 6) errores.push('Si asigna una contraseña, use al menos 6 caracteres.');
        if (esEdicion && password && password.length < 6) errores.push('Si cambia la contraseña, use al menos 6 caracteres.');

        marcarCampo(f.nombre, nombreMal);
        marcarCampo(f.apellido, apellidoMal);
        marcarCampo(f.correo, correoMal);
        marcarCampo(f.telefono, telefonoMal);
        marcarCampo(f.documento, documentoMal);
        marcarCampo(f.id_rol, rolMal);
        marcarCampo(f.password, passMal);
        return errores;
    }

    function forzarBotonNuevoUsuario() {
        const visible = !!state.puedeCrear;
        const btnNuevo = document.getElementById('btn-nuevo-usuario');
        if (btnNuevo) {
            btnNuevo.hidden = !visible;
            btnNuevo.style.display = visible ? 'inline-flex' : 'none';
        }
        const btnContrato = document.getElementById('btn-nuevo-contrato');
        if (btnContrato) btnContrato.style.display = state.puedeContratos ? '' : 'none';
        const btnNomina = document.getElementById('btn-nueva-nomina');
        if (btnNomina) btnNomina.style.display = state.puedeNominas ? '' : 'none';
        const btnEsp = document.getElementById('btn-nueva-especialidad');
        if (btnEsp) btnEsp.style.display = state.puedeEspecialidades ? '' : 'none';
        pintarVisibilidadTabs();
    }

    function pintarVisibilidadTabs() {
        const vis = {
            personal: true,
            contratos: state.puedeVerContratos,
            nominas: state.puedeVerNominas,
            especialidades: state.puedeVerEspecialidades,
            roles: state.puedeRoles
        };
        Object.keys(vis).forEach(tab => {
            const btn = document.querySelector(`#modulo-usuarios [data-tab="${tab}"]`);
            const panel = document.querySelector(`#modulo-usuarios [data-panel="${tab}"]`);
            btn?.classList.toggle('tab-hidden', !vis[tab]);
            if (!vis[tab] && panel?.classList.contains('active')) {
                document.querySelector('#modulo-usuarios [data-tab="personal"]')?.click();
            }
        });
    }

    function nombreRol(u) {
        if (!u) return '';
        if (u.rol && typeof u.rol === 'object') return u.rol.nombre || '';
        return u.rol || '';
    }

    function nombreCompleto(u) {
        return (u?.nombre || '').trim();
    }

    function idRolDe(u) {
        if (!u) return '';
        if (u.rol && typeof u.rol === 'object' && u.rol.id_rol) return String(u.rol.id_rol);
        return String(u.id_rol || '');
    }

    function esRolAdmin(rol) {
        return /admin/i.test(String(rol?.nombre || ''));
    }

    function especialidadesDe(u) {
        const id = Number(u?.id_usuario);
        return state.especialidades.filter(e =>
            (e.usuarios || []).some(x => Number(x.id_usuario) === id)
        );
    }

    function idsEspecialidadMarcadas() {
        return Array.from(document.querySelectorAll('#usuario-especialidades input[type="checkbox"]:checked'))
            .map(el => parseInt(el.value, 10))
            .filter(n => n > 0);
    }

    function llenarSelectRoles() {
        const sel = document.getElementById('usuario-rol') || document.querySelector('#form-usuario [name="id_rol"]');
        const filter = document.getElementById('filter-rol');
        const rolesVisibles = state.esAdmin
            ? state.roles
            : state.roles.filter(r => !/admin/i.test(String(r.nombre || '')));
        const opts = rolesVisibles.map(r => `<option value="${r.id_rol}">${r.nombre}</option>`).join('');
        if (sel) sel.innerHTML = '<option value="">Seleccione...</option>' + opts;
        if (filter) {
            const actual = filter.value || 'todos';
            const nombres = state.roles.map(r => `<option value="${r.nombre}">${r.nombre}</option>`).join('');
            filter.innerHTML = '<option value="todos">Todos los roles</option>' + nombres;
            filter.value = actual;
        }
    }

    function pintarChipsEspecialidad(u) {
        const box = document.getElementById('usuario-especialidades');
        const grupo = document.getElementById('grupo-usuario-especialidades');
        if (!box || !grupo) return;
        if (!state.puedeVerEspecialidades) {
            grupo.style.display = 'none';
            return;
        }
        grupo.style.display = '';
        const asignadas = new Set(especialidadesDe(u || {}).map(e => Number(e.id_especialidad)));
        const lista = state.especialidades.filter(e =>
            String(e.estado || '').toLowerCase() === 'activo' || asignadas.has(Number(e.id_especialidad))
        );
        const puedeMarcar = state.puedeEspecialidades;
        box.innerHTML = lista.map(e => {
            const id = Number(e.id_especialidad);
            const checked = asignadas.has(id) ? 'checked' : '';
            const disabled = puedeMarcar ? '' : 'disabled';
            return `<label><input type="checkbox" value="${id}" ${checked} ${disabled}> ${e.nombre_especialidad}</label>`;
        }).join('') || '<span class="text-muted">No hay especialidades. Créelas en la pestaña Especialidades.</span>';
    }

    function bindEvents() {
        const abrir = (e) => {
            e.preventDefault();
            e.stopPropagation();
            openUsuarioModal();
        };
        document.getElementById('btn-nuevo-usuario')?.addEventListener('click', abrir);
        const form = document.getElementById('form-usuario');
        form?.addEventListener('input', () => {
            if (form.querySelector('.campo-invalido')) {
                validarFormularioUsuario(form, !!state.editUsuario?.id_usuario);
            }
        });
        document.getElementById('btn-nuevo-contrato')?.addEventListener('click', () => openContratoModal());
        document.getElementById('btn-nueva-nomina')?.addEventListener('click', () => openNominaModal());
        document.getElementById('btn-nueva-especialidad')?.addEventListener('click', () => openEspecialidadModal());
        document.getElementById('btn-refresh-usr')?.addEventListener('click', async () => { await loadAll(); renderAll(); });
        document.getElementById('filter-rol')?.addEventListener('change', e => { state.filtros.rol = e.target.value; state.pag.page = 1; renderUsuarios(); });
        document.getElementById('search-usuario')?.addEventListener('input', ModuleCore.debounce(e => {
            state.filtros.busqueda = e.target.value.trim().toLowerCase();
            state.pag.page = 1;
            renderUsuarios();
        }));
        document.getElementById('btn-guardar-usuario')?.addEventListener('click', saveUsuario);
        document.getElementById('btn-guardar-contrato')?.addEventListener('click', saveContrato);
        document.getElementById('btn-guardar-nomina')?.addEventListener('click', saveNomina);
        document.getElementById('btn-guardar-especialidad')?.addEventListener('click', saveEspecialidad);
        document.getElementById('btn-guardar-asignar')?.addEventListener('click', saveAsignacionEspecialidad);
        document.getElementById('contrato-estado')?.addEventListener('change', sincronizarFechaRetiro);
        document.getElementById('nomina-id-contrato')?.addEventListener('change', e => {
            const c = state.contratos.find(x => Number(x.id_contrato) === Number(e.target.value));
            const f = document.getElementById('form-nomina');
            if (f && c) f.total_neto.value = Math.round(Number(c.salario_base) || 0);
        });
        ModuleCore.bindModalClose('modal-usuario-form', 'btn-cancelar-usuario', 'btn-cerrar-modal-usuario');
        ModuleCore.bindModalClose('modal-contrato', 'btn-cancelar-contrato', 'btn-cerrar-contrato');
        ModuleCore.bindModalClose('modal-nomina', 'btn-cancelar-nomina', 'btn-cerrar-nomina');
        ModuleCore.bindModalClose('modal-especialidad', 'btn-cancelar-especialidad', 'btn-cerrar-especialidad');
        ModuleCore.bindModalClose('modal-asignar-especialidad', 'btn-cancelar-asignar', 'btn-cerrar-asignar');
        document.getElementById('tabla-usuarios')?.addEventListener('click', onUsuarioClick);
        document.getElementById('tabla-contratos')?.addEventListener('click', onContratoClick);
        document.getElementById('tabla-nominas')?.addEventListener('click', onNominaClick);
        document.getElementById('tabla-especialidades')?.addEventListener('click', onEspecialidadClick);
        document.getElementById('lista-roles-rrhh')?.addEventListener('click', onRolListaClick);
        document.getElementById('panel-matriz-rol')?.addEventListener('click', onMatrizClick);
        ModuleCore.bindPagination(document.getElementById('prev-page'), document.getElementById('next-page'), document.querySelector('#user-list-view .pagination span'), state.pag, renderUsuarios);
    }

    function renderAll() {
        renderUsuarios();
        renderContratos();
        renderNominas();
        renderEspecialidades();
        renderRoles();
        populateUsuarioSelects();
    }

    function filteredUsuarios() {
        return state.usuarios.filter(u => {
            if (state.filtros.rol !== 'todos' && nombreRol(u) !== state.filtros.rol) return false;
            if (state.filtros.busqueda) {
                const q = state.filtros.busqueda;
                return [nombreCompleto(u), u.correo, u.documento].some(v => String(v).toLowerCase().includes(q));
            }
            return true;
        });
    }

    function renderUsuarios() {
        const tbody = document.querySelector('#tabla-usuarios tbody');
        if (!tbody) return;
        const filtered = filteredUsuarios();
        const { items, totalPages } = ModuleCore.paginate(filtered, state.pag.page, state.pag.perPage);
        state.pag.totalPages = totalPages;

        tbody.innerHTML = items.map(u => {
            const oficios = especialidadesDe(u).map(e => e.nombre_especialidad).join(', ') || '—';
            return `<tr>
            <td><strong>${nombreCompleto(u)}</strong></td>
            <td>${u.correo}</td>
            <td>${u.documento}</td>
            <td>${u.telefono}</td>
            <td>${nombreRol(u)}</td>
            <td>${oficios}</td>
            <td>${ModuleCore.badge(u.estado)}${u.invitacion_pendiente ? ' <span class="badge bg-warning">Pendiente clave</span>' : ''}</td>
            <td>
                <div class="table-actions">
                    ${state.puedeEditar ? `<button class="btn-icon btn-sm btn-invitar" data-id="${u.id_usuario}" title="Enviar correo de acceso"><i class="fas fa-envelope"></i></button>` : ''}
                    ${ModuleCore.actionButtons(u.id_usuario, { view: false, edit: state.puedeEditar, del: state.puedeEliminar })}
                </div>
            </td>
        </tr>`;
        }).join('') || ModuleCore.emptyRow(8);
    }

    function empleadoDeContrato(c) {
        if (!c) return '';
        if (c.usuario_nombre) return c.usuario_nombre;
        const u = state.usuarios.find(x => Number(x.id_usuario) === Number(c.id_usuario));
        return nombreCompleto(u || {});
    }

    function renderContratos() {
        const tbody = document.querySelector('#tabla-contratos tbody');
        if (!tbody) return;
        tbody.innerHTML = state.contratos.map(c => {
            const pct = Number(c.porcentaje_comision ?? c.porcentaje_comicion ?? 0);
            return `<tr>
                <td>${empleadoDeContrato(c)}</td>
                <td>${ModuleCore.formatCurrency(c.salario_base)}</td>
                <td>${(pct * 100).toFixed(0)}%</td>
                <td>${ModuleCore.formatDate(c.fecha_ingreso)}</td>
                <td>${c.fecha_retiro ? ModuleCore.formatDate(c.fecha_retiro) : '—'}</td>
                <td>${ModuleCore.badge(c.estado_contrato)}</td>
                <td>${ModuleCore.actionButtons(c.id_contrato, { view: false, edit: state.puedeContratos, del: state.puedeContratos })}</td>
            </tr>`;
        }).join('') || ModuleCore.emptyRow(7);
    }

    function renderNominas() {
        const tbody = document.querySelector('#tabla-nominas tbody');
        if (!tbody) return;
        tbody.innerHTML = state.nominas.map(n => {
            const c = n.contrato || state.contratos.find(x => Number(x.id_contrato) === Number(n.id_contrato));
            const nombre = n.usuario_nombre || empleadoDeContrato(c);
            return `<tr>
                <td>${nombre}</td>
                <td>${n.periodo_pago}</td>
                <td>${ModuleCore.formatDate(n.fecha_pago)}</td>
                <td>${ModuleCore.formatCurrency(n.total_neto)}</td>
                <td>${ModuleCore.actionButtons(n.id_nomina, { view: true, edit: false, del: false })}</td>
            </tr>`;
        }).join('') || ModuleCore.emptyRow(5);
    }

    function renderEspecialidades() {
        const tbody = document.querySelector('#tabla-especialidades tbody');
        if (!tbody) return;
        tbody.innerHTML = state.especialidades.map(e => {
            const nombres = (e.usuarios || []).map(u => u.nombre).filter(Boolean);
            return `<tr>
                <td><strong>${e.nombre_especialidad}</strong></td>
                <td>${e.descripcion || '—'}</td>
                <td>${ModuleCore.badge(e.estado)}</td>
                <td>${nombres.length ? nombres.join(', ') : 'Sin asignar'}</td>
                <td>
                    <div class="table-actions">
                        ${state.puedeEspecialidades ? `<button class="btn-icon btn-sm btn-asignar" data-id="${e.id_especialidad}" title="Asignar personal"><i class="fas fa-user-plus"></i></button>` : ''}
                        ${ModuleCore.actionButtons(e.id_especialidad, { view: false, edit: state.puedeEspecialidades, del: state.puedeEspecialidades })}
                    </div>
                </td>
            </tr>`;
        }).join('') || ModuleCore.emptyRow(5);
    }

    function renderRoles() {
        const lista = document.getElementById('lista-roles-rrhh');
        if (!lista) return;
        if (!state.puedeRoles) {
            lista.innerHTML = '';
            const panel = document.getElementById('panel-matriz-rol');
            if (panel) panel.innerHTML = '';
            return;
        }
        if (!state.rolActivoId && state.roles.length) {
            const primero = state.roles.find(r => !esRolAdmin(r)) || state.roles[0];
            state.rolActivoId = Number(primero.id_rol);
        }
        lista.innerHTML = state.roles.map(r => {
            const activo = Number(r.id_rol) === Number(state.rolActivoId) ? 'active' : '';
            const extra = r.matriz_manual ? '<small class="text-muted">Personalizada</small>' : '<small class="text-muted">Catálogo</small>';
            return `<button type="button" class="rrhh-rol-btn ${activo}" data-id="${r.id_rol}">
                <strong>${r.nombre}</strong><br>${extra}
            </button>`;
        }).join('');
        renderMatrizRol();
    }

    function renderMatrizRol() {
        const panel = document.getElementById('panel-matriz-rol');
        if (!panel) return;
        const rol = state.roles.find(r => Number(r.id_rol) === Number(state.rolActivoId));
        if (!rol) {
            panel.innerHTML = '<p class="text-muted">Seleccione un rol.</p>';
            return;
        }
        if (esRolAdmin(rol)) {
            panel.innerHTML = `<h3>${rol.nombre}</h3>
                <p>Este rol tiene acceso total por nombre. No se recorta desde la matriz: un administrador siempre entra a todo el sistema.</p>`;
            return;
        }
        const asignados = new Set((rol.permisos || []).map(p => p.slug));
        const grupos = {};
        (state.catalogoPermisos || []).forEach(p => {
            if (p.slug === 'roles.gestionar') return;
            const mod = p.modulo || 'otros';
            if (!grupos[mod]) grupos[mod] = [];
            grupos[mod].push(p);
        });
        const bloques = Object.keys(grupos).sort().map(mod => {
            const checks = grupos[mod].map(p => {
                const checked = asignados.has(p.slug) ? 'checked' : '';
                return `<label><input type="checkbox" data-slug="${p.slug}" ${checked}> <span>${p.nombre}<br><small class="text-muted">${p.descripcion || p.slug}</small></span></label>`;
            }).join('');
            return `<div class="rrhh-matriz-grupo"><h4>${mod}</h4>${checks}</div>`;
        }).join('');
        panel.innerHTML = `<div style="display:flex;justify-content:space-between;gap:0.75rem;align-items:center;flex-wrap:wrap;margin-bottom:0.8rem">
                <h3 style="margin:0">${rol.nombre}</h3>
                <div style="display:flex;gap:0.5rem">
                    <button type="button" class="btn btn-outline btn-sm" id="btn-restaurar-rol">Restaurar catálogo</button>
                    <button type="button" class="btn btn-primary btn-sm" id="btn-guardar-rol">Guardar matriz</button>
                </div>
            </div>
            <div class="rrhh-matriz-grupos">${bloques || '<p class="text-muted">No hay catálogo de permisos.</p>'}</div>`;
    }

    function populateUsuarioSelects() {
        const vigentesId = new Set(
            state.contratos.filter(c => c.estado_contrato === 'Vigente').map(c => Number(c.id_usuario))
        );
        const editId = state.editContrato ? Number(state.editContrato.id_usuario) : null;
        const opts = state.usuarios.filter(u => u.estado === 'Activo' && (!vigentesId.has(Number(u.id_usuario)) || Number(u.id_usuario) === editId))
            .map(u => `<option value="${u.id_usuario}">${nombreCompleto(u)}</option>`).join('');
        const selUser = document.getElementById('contrato-id-usuario');
        const selContrato = document.getElementById('nomina-id-contrato');
        if (selUser) selUser.innerHTML = '<option value="">Seleccione...</option>' + opts;
        if (selContrato) {
            selContrato.innerHTML = '<option value="">Seleccione...</option>' +
                state.contratos.filter(c => c.estado_contrato === 'Vigente').map(c =>
                    `<option value="${c.id_contrato}">${empleadoDeContrato(c)} — ${ModuleCore.formatCurrency(c.salario_base)}</option>`
                ).join('');
        }
    }

    function sincronizarFechaRetiro() {
        const estado = document.getElementById('contrato-estado')?.value;
        const grupo = document.getElementById('grupo-fecha-retiro');
        if (grupo) grupo.style.display = estado === 'Finalizado' ? 'block' : 'none';
    }

    function openUsuarioModal(u = null) {
        state.editUsuario = u;
        mostrarErrores([]);
        const titulo = document.getElementById('modal-usuario-title');
        if (titulo) titulo.textContent = u ? 'Editar Usuario' : 'Nuevo Usuario';
        const f = document.getElementById('form-usuario');
        if (!f) return;
        f.reset();
        const pass = f.password;
        const hint = document.getElementById('usuario-pass-hint');
        const ayuda = document.getElementById('usuario-pass-ayuda');
        if (pass) pass.required = false;
        if (hint) hint.style.display = 'none';
        if (ayuda) {
            ayuda.textContent = u
                ? 'Déjela vacía para no cambiarla. El sobre en la tabla reenvía el correo de acceso.'
                : 'Si la deja vacía se envía un correo para que la persona cree su clave.';
        }
        llenarSelectRoles();
        pintarChipsEspecialidad(u);
        if (u) {
            const partes = String(u.nombre || '').trim().split(/\s+/);
            f.nombre.value = partes[0] || u.nombre || '';
            if (f.apellido) f.apellido.value = partes.slice(1).join(' ');
            f.correo.value = u.correo || '';
            f.telefono.value = u.telefono || '';
            f.documento.value = u.documento || '';
            if (f.id_rol) f.id_rol.value = idRolDe(u);
            if (f.estado) f.estado.value = u.estado || 'Activo';
        }
        Array.from(f.querySelectorAll('.campo-invalido')).forEach(el => el.classList.remove('campo-invalido'));
        const modal = document.getElementById('modal-usuario-form');
        if (modal) {
            modal.classList.add('active', 'show');
            modal.style.display = 'flex';
            modal.style.opacity = '1';
            modal.style.visibility = 'visible';
        }
    }

    function mostrarCajaErrores(id, lista) {
        const box = document.getElementById(id);
        if (!box) return;
        if (!lista.length) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        box.style.display = 'block';
        box.innerHTML = '<strong>Revise el formulario:</strong><ul style="margin:0.4rem 0 0;padding-left:1.2rem">' +
            lista.map(e => `<li>${e}</li>`).join('') + '</ul>';
    }

    function openContratoModal(c = null) {
        state.editContrato = c;
        mostrarCajaErrores('contrato-form-errores', []);
        populateUsuarioSelects();
        document.getElementById('modal-contrato-title').textContent = c ? 'Editar Contrato' : 'Nuevo Contrato';
        const f = document.getElementById('form-contrato');
        f.reset();
        if (c) {
            f.id_usuario.value = c.id_usuario;
            f.salario_base.value = c.salario_base;
            const pct = Number(c.porcentaje_comision ?? c.porcentaje_comicion ?? 0);
            f.porcentaje_comision.value = (pct * 100).toFixed(2);
            f.fecha_ingreso.value = c.fecha_ingreso;
            f.estado_contrato.value = c.estado_contrato;
            if (f.fecha_retiro) f.fecha_retiro.value = c.fecha_retiro || '';
        } else {
            f.fecha_ingreso.value = new Date().toISOString().split('T')[0];
            f.porcentaje_comision.value = 0;
        }
        sincronizarFechaRetiro();
        ModuleCore.openModal('modal-contrato');
    }

    function openNominaModal(n = null) {
        state.editNomina = n;
        mostrarCajaErrores('nomina-form-errores', []);
        pintarAvisoCaja();
        populateUsuarioSelects();
        document.getElementById('modal-nomina-title').textContent = n ? 'Detalle Nómina' : 'Registrar Nómina';
        const f = document.getElementById('form-nomina');
        f.reset();
        const guardar = document.getElementById('btn-guardar-nomina');
        if (n) {
            f.id_contrato.value = n.id_contrato;
            f.periodo_pago.value = n.periodo_pago;
            f.fecha_pago.value = n.fecha_pago;
            f.total_neto.value = n.total_neto;
            Array.from(f.elements).forEach(el => { el.disabled = true; });
            if (guardar) guardar.style.display = 'none';
        } else {
            Array.from(f.elements).forEach(el => { el.disabled = false; });
            if (guardar) guardar.style.display = '';
            f.fecha_pago.value = new Date().toISOString().split('T')[0];
            const now = new Date();
            const mes = String(now.getMonth() + 1).padStart(2, '0');
            f.periodo_pago.placeholder = `${now.getFullYear()}-${mes}-1ra quincena`;
        }
        ModuleCore.openModal('modal-nomina');
    }

    function openEspecialidadModal(e = null) {
        state.editEspecialidad = e;
        mostrarCajaErrores('especialidad-form-errores', []);
        document.getElementById('modal-especialidad-title').textContent = e ? 'Editar especialidad' : 'Nueva especialidad';
        const f = document.getElementById('form-especialidad');
        f.reset();
        if (e) {
            f.nombre_especialidad.value = e.nombre_especialidad || '';
            f.descripcion.value = e.descripcion || '';
            f.estado.value = e.estado || 'Activo';
        }
        ModuleCore.openModal('modal-especialidad');
    }

    function openAsignarModal(e) {
        state.asignarEspecialidad = e;
        document.getElementById('modal-asignar-title').textContent = `Asignar: ${e.nombre_especialidad}`;
        const asignados = new Set((e.usuarios || []).map(u => Number(u.id_usuario)));
        const box = document.getElementById('asignar-usuarios-lista');
        const candidatos = state.usuarios.filter(u => u.estado === 'Activo');
        box.innerHTML = candidatos.map(u => {
            const checked = asignados.has(Number(u.id_usuario)) ? 'checked' : '';
            return `<label><input type="checkbox" value="${u.id_usuario}" ${checked}> ${nombreCompleto(u)} <small class="text-muted">(${nombreRol(u)})</small></label>`;
        }).join('') || '<span class="text-muted">No hay personal activo.</span>';
        ModuleCore.openModal('modal-asignar-especialidad');
    }

    async function saveUsuario() {
        const f = document.getElementById('form-usuario');
        const esEdicion = !!state.editUsuario?.id_usuario;
        const errores = validarFormularioUsuario(f, esEdicion);
        mostrarErrores(errores);
        if (errores.length) {
            f.reportValidity();
            return;
        }
        const apellido = f.apellido.value.trim();
        const nombre = [f.nombre.value.trim(), apellido].filter(Boolean).join(' ');
        const payload = {
            nombre,
            correo: f.correo.value.trim(),
            telefono: f.telefono.value.trim(),
            documento: f.documento.value.trim(),
            id_rol: parseInt(f.id_rol.value, 10),
            estado: f.estado?.value || 'Activo'
        };
        if (f.password.value.trim()) payload.password = f.password.value.trim();
        try {
            let res;
            if (esEdicion) {
                res = await window.apiUsuariosActualizar(state.editUsuario.id_usuario, payload);
            } else {
                res = await window.apiUsuarios(false, payload);
            }
            const idGuardado = Number(res?.data?.id_usuario || state.editUsuario?.id_usuario || 0);
            if (state.puedeEspecialidades && idGuardado && window.apiEspecialidadesAsignar) {
                try {
                    await window.apiEspecialidadesAsignar({
                        id_usuario: idGuardado,
                        especialidades: idsEspecialidadMarcadas()
                    });
                } catch (errEsp) {
                    ModuleCore.toast(errEsp.message || 'El usuario se guardó, pero no se pudieron asignar especialidades', 'error');
                }
            }
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-usuario-form');
            window.cerrarModalUsuario?.();
            await avisarEnlaceAcceso(res?.data, esEdicion ? 'Usuario guardado' : (payload.password ? 'Usuario guardado' : 'Usuario creado. Se envió el correo de acceso.'));
            if (state.yo && Number(state.editUsuario?.id_usuario) === Number(state.yo.id_usuario)) {
                window.cargarUsuarioSidebar?.();
            }
        } catch (e) {
            mostrarErrores([e.message || 'No se pudo guardar el usuario']);
            ModuleCore.toast(e.message || 'No se pudo guardar el usuario', 'error');
        }
    }

    async function saveContrato() {
        const f = document.getElementById('form-contrato');
        const errores = [];
        const idUsuario = parseInt(f.id_usuario.value, 10);
        const salario = parseFloat(f.salario_base.value);
        const comision = parseFloat(f.porcentaje_comision.value);
        const ingreso = (f.fecha_ingreso.value || '').trim();
        if (!idUsuario) errores.push('Seleccione un empleado.');
        if (!(salario > 0)) errores.push('El salario base debe ser mayor a cero.');
        if (Number.isNaN(comision) || comision < 0 || comision > 100) errores.push('La comisión debe estar entre 0 y 100%.');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(ingreso)) errores.push('La fecha de ingreso es obligatoria.');
        mostrarCajaErrores('contrato-form-errores', errores);
        if (errores.length) return;
        const payload = {
            id_usuario: idUsuario,
            salario_base: salario,
            porcentaje_comision: comision,
            fecha_ingreso: ingreso,
            estado_contrato: f.estado_contrato.value,
            fecha_retiro: f.fecha_retiro?.value || null
        };
        try {
            if (state.editContrato?.id_contrato) {
                await window.apiContratosActualizar(state.editContrato.id_contrato, payload);
            } else {
                await window.apiContratosCrear(payload);
            }
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-contrato');
            ModuleCore.toast('Contrato guardado', 'success');
        } catch (e) {
            mostrarCajaErrores('contrato-form-errores', [e.message || 'No se pudo guardar el contrato']);
            ModuleCore.toast(e.message || 'No se pudo guardar el contrato', 'error');
        }
    }

    async function saveNomina() {
        const f = document.getElementById('form-nomina');
        if (state.editNomina) return;
        const errores = [];
        const id_contrato = parseInt(f.id_contrato.value, 10);
        const periodo = (f.periodo_pago.value || '').trim();
        const fecha = (f.fecha_pago.value || '').trim();
        const total = parseFloat(f.total_neto.value);
        if (!id_contrato) errores.push('Seleccione un contrato vigente.');
        if (periodo.length < 3) errores.push('Indique el periodo de pago.');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) errores.push('La fecha de pago es obligatoria.');
        if (!(total > 0)) errores.push('El total neto debe ser mayor a cero.');
        if (!state.cajaAbierta) errores.push('Abra caja en Contabilidad para registrar el pago.');
        mostrarCajaErrores('nomina-form-errores', errores);
        if (errores.length) return;
        try {
            await window.apiNominasCrear({
                id_contrato,
                periodo_pago: periodo,
                fecha_pago: fecha,
                total_neto: total
            });
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-nomina');
            ModuleCore.toast('Nómina registrada y pagada en caja', 'success');
        } catch (e) {
            mostrarCajaErrores('nomina-form-errores', [e.message || 'No se pudo registrar la nómina']);
            ModuleCore.toast(e.message || 'No se pudo registrar la nómina', 'error');
        }
    }

    async function saveEspecialidad() {
        const f = document.getElementById('form-especialidad');
        const errores = [];
        const nombre = (f.nombre_especialidad.value || '').trim();
        if (nombre.length < 2) errores.push('El nombre debe tener al menos 2 caracteres.');
        mostrarCajaErrores('especialidad-form-errores', errores);
        if (errores.length) return;
        const payload = {
            nombre_especialidad: nombre,
            descripcion: (f.descripcion.value || '').trim(),
            estado: f.estado.value
        };
        try {
            if (state.editEspecialidad?.id_especialidad) {
                await window.apiEspecialidadesActualizar(state.editEspecialidad.id_especialidad, payload);
            } else {
                await window.apiEspecialidadesCrear(payload);
            }
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-especialidad');
            ModuleCore.toast('Especialidad guardada', 'success');
        } catch (e) {
            mostrarCajaErrores('especialidad-form-errores', [e.message || 'No se pudo guardar']);
            ModuleCore.toast(e.message || 'No se pudo guardar', 'error');
        }
    }

    async function saveAsignacionEspecialidad() {
        const esp = state.asignarEspecialidad;
        if (!esp) return;
        const ids = Array.from(document.querySelectorAll('#asignar-usuarios-lista input[type="checkbox"]:checked'))
            .map(el => parseInt(el.value, 10))
            .filter(n => n > 0);
        try {
            await window.apiEspecialidadesAsignar({
                id_especialidad: esp.id_especialidad,
                usuarios: ids
            });
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-asignar-especialidad');
            ModuleCore.toast('Asignación guardada', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo asignar', 'error');
        }
    }

    function onUsuarioClick(e) {
        const btn = e.target.closest('.btn-edit, .btn-delete, .btn-view, .btn-invitar');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const u = state.usuarios.find(x => Number(x.id_usuario) === id);
        if (!u) return;
        if (btn.classList.contains('btn-invitar')) {
            ModuleCore.confirm('Correo de acceso', `¿Enviar a ${u.correo} el enlace para definir su contraseña?`, async () => {
                try {
                    const res = await window.apiUsuariosInvitar(id);
                    await loadAll();
                    renderAll();
                    await avisarEnlaceAcceso(res?.data, res?.mensaje || 'Correo enviado');
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo enviar el correo', 'error');
                }
            });
            return;
        }
        if (btn.classList.contains('btn-edit')) openUsuarioModal(u);
        else if (btn.classList.contains('btn-delete')) {
            ModuleCore.confirm('Eliminar', `¿Eliminar a ${nombreCompleto(u)}?`, async () => {
                try {
                    await window.apiUsuariosEliminar(id);
                    await loadAll();
                    renderAll();
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo eliminar', 'error');
                }
            });
        } else {
            const contrato = state.contratos.find(c => Number(c.id_usuario) === id);
            const oficios = especialidadesDe(u).map(x => x.nombre_especialidad).join(', ') || 'Sin especialidad';
            window.createModal?.('modal-det', nombreCompleto(u), `
                <div class="detail-grid">
                    <div class="detail-item"><label>Correo</label><p>${u.correo}</p></div>
                    <div class="detail-item"><label>Rol</label><p>${nombreRol(u)}</p></div>
                    <div class="detail-item"><label>Oficios</label><p>${oficios}</p></div>
                    <div class="detail-item"><label>Contrato</label><p>${contrato ? ModuleCore.badge(contrato.estado_contrato) + ' ' + ModuleCore.formatCurrency(contrato.salario_base) : 'Sin contrato'}</p></div>
                </div>`);
        }
    }

    function onContratoClick(e) {
        const btn = e.target.closest('.btn-edit, .btn-delete');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const c = state.contratos.find(x => Number(x.id_contrato) === id);
        if (!c) return;
        if (btn.classList.contains('btn-edit')) openContratoModal(c);
        else if (btn.classList.contains('btn-delete')) {
            ModuleCore.confirm('Eliminar contrato', '¿Confirmar eliminación? Si tiene nóminas, no se podrá borrar.', async () => {
                try {
                    await window.apiContratosEliminar(id);
                    await loadAll();
                    renderAll();
                    ModuleCore.toast('Contrato eliminado', 'success');
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo eliminar', 'error');
                }
            });
        }
    }

    function onNominaClick(e) {
        const btn = e.target.closest('.btn-view, .btn-edit');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const n = state.nominas.find(x => Number(x.id_nomina) === id);
        if (!n) return;
        const detalle = n.detalle || state.nominaDetalle.filter(d => Number(d.id_nomina) === id);
        const rows = detalle.map(d => `<tr><td>${d.tipo_concepto}</td><td>${d.descripcion}</td><td>${ModuleCore.formatCurrency(d.valor)}</td></tr>`).join('');
        window.createModal?.('modal-det', `Nómina: ${n.periodo_pago}`, `
            <p><strong>Empleado:</strong> ${n.usuario_nombre || empleadoDeContrato(n.contrato)}</p>
            <p><strong>Total neto:</strong> ${ModuleCore.formatCurrency(n.total_neto)}</p>
            <table class="table"><thead><tr><th>Tipo</th><th>Concepto</th><th>Valor</th></tr></thead><tbody>${rows || ModuleCore.emptyRow(3)}</tbody></table>`);
    }

    function onEspecialidadClick(e) {
        const btn = e.target.closest('.btn-edit, .btn-delete, .btn-asignar');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const esp = state.especialidades.find(x => Number(x.id_especialidad) === id);
        if (!esp) return;
        if (btn.classList.contains('btn-asignar')) {
            openAsignarModal(esp);
            return;
        }
        if (btn.classList.contains('btn-edit')) {
            openEspecialidadModal(esp);
            return;
        }
        ModuleCore.confirm('Eliminar especialidad', `¿Quitar "${esp.nombre_especialidad}"? Se desasigna de los mecánicos, no se borra el personal.`, async () => {
            try {
                await window.apiEspecialidadesEliminar(id);
                await loadAll();
                renderAll();
                ModuleCore.toast('Especialidad eliminada', 'success');
            } catch (err) {
                ModuleCore.toast(err.message || 'No se pudo eliminar', 'error');
            }
        });
    }

    function onRolListaClick(e) {
        const btn = e.target.closest('.rrhh-rol-btn');
        if (!btn) return;
        state.rolActivoId = parseInt(btn.dataset.id, 10);
        renderRoles();
    }

    function onMatrizClick(e) {
        if (e.target.id === 'btn-guardar-rol') {
            guardarMatrizRol();
            return;
        }
        if (e.target.id === 'btn-restaurar-rol') {
            ModuleCore.confirm('Restaurar catálogo', '¿Volver a los permisos originales de este rol?', async () => {
                try {
                    await window.apiRolesRestaurar(state.rolActivoId);
                    await loadAll();
                    renderAll();
                    ModuleCore.toast('Matriz restaurada', 'success');
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo restaurar', 'error');
                }
            });
        }
    }

    async function guardarMatrizRol() {
        const slugs = Array.from(document.querySelectorAll('#panel-matriz-rol input[type="checkbox"]:checked'))
            .map(el => el.dataset.slug)
            .filter(Boolean);
        try {
            await window.apiRolesPermisos(state.rolActivoId, slugs);
            await loadAll();
            renderAll();
            ModuleCore.toast('Matriz guardada. Aplica a todo el personal de ese rol.', 'success');
        } catch (err) {
            ModuleCore.toast(err.message || 'No se pudo guardar la matriz', 'error');
        }
    }

    async function avisarEnlaceAcceso(data, fallback) {
        const url = data?.url_activacion;
        const canal = data?.correo_canal;
        if (url && canal === 'local') {
            try {
                await navigator.clipboard.writeText(url);
                ModuleCore.toast('Sin SMTP: enlace copiado. También está en Configuración → buzón interno.', 'success');
                return;
            } catch (e) {
                ModuleCore.toast('Sin SMTP: el enlace quedó en Configuración → buzón interno.', 'success');
                return;
            }
        }
        ModuleCore.toast(fallback || 'Correo enviado', 'success');
    }

    return { init, openUsuarioModal };
})();

window.openUsuarioModal = function (u) {
    UsuariosRRHHModule.openUsuarioModal(u || null);
};

document.addEventListener('DOMContentLoaded', iniciarUsuarios);
if (document.readyState !== 'loading') {
    iniciarUsuarios();
}

function iniciarUsuarios() {
    if (window.__usuariosRrhhInit) return;
    window.__usuariosRrhhInit = true;
    UsuariosRRHHModule.init();
}
