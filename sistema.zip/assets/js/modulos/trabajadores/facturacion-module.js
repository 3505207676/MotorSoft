/**
 * Facturación + ventas de mostrador, cuadradas con caja y banco.
 */
const FacturacionModule = (() => {
    const state = {
        facturas: [],
        ventas: [],
        clientes: [],
        productos: [],
        ordenes: [],
        config: { iva_activo: true, iva_porcentaje: 19 },
        preview: null,
        ventaItems: [],
        filtros: { estado: 'todos', tipo: 'todos', busqueda: '' },
        caja: { sesion: null, puede_operar: false, cuentas: [] },
        cobroId: null
    };

    function puede(slug) {
        return !window.MotorSoftGuard || window.MotorSoftGuard.puede(slug);
    }

    function cajaAbierta() {
        return !!state.caja.sesion;
    }

    function leerIva(mapa) {
        const src = mapa || {};
        const activo = src.iva_activo !== false && src.iva_activo !== 0
            && src.iva_activo !== '0' && src.iva_activo !== 'false';
        return {
            iva_activo: activo,
            iva_porcentaje: Number(src.iva_porcentaje || 19)
        };
    }

    async function init() {
        if (init._done) return;
        init._done = true;
        await loadAll();
        ModuleCore.initTabs('#modulo-facturacion');
        bindEvents();
        aplicarPermisos();
        renderFacturas();
        renderVentas();
        abrirDesdeQuery();
        document.addEventListener('motorsoft:usuario-actualizado', aplicarPermisos);
    }

    function aplicarPermisos() {
        const btnFac = document.getElementById('btn-nueva-factura');
        const btnVen = document.getElementById('btn-nueva-venta');
        if (btnFac) {
            const ok = puede('facturas.crear');
            btnFac.hidden = !ok;
            btnFac.style.display = ok ? '' : 'none';
        }
        if (btnVen) {
            const ok = puede('ventas.crear') || puede('facturas.crear');
            btnVen.hidden = !ok;
            btnVen.style.display = ok ? '' : 'none';
        }
        renderFacturas();
        renderVentas();
    }

    function abrirDesdeQuery() {
        const params = new URLSearchParams(location.search);
        const estado = params.get('estado');
        if (estado) {
            const sel = document.getElementById('filter-estado');
            if (sel && Array.from(sel.options).some(o => o.value === estado)) {
                sel.value = estado;
                state.filtros.estado = estado;
                renderFacturas();
            }
        }
        const ordenId = params.get('orden');
        if (!ordenId) return;
        openFacturaModal();
        const sel = document.getElementById('factura-orden');
        if (!sel) return;
        const existe = Array.from(sel.options).some(o => String(o.value) === String(ordenId));
        if (!existe) {
            ModuleCore.toast('Esa orden no está lista para facturar o ya tiene una factura activa', 'warning');
            return;
        }
        sel.value = String(ordenId);
        onOrdenChange();
    }

    async function loadAll() {
        const [fac, ven, cli, prod, cfg, ots, caja] = await Promise.all([
            window.apiFacturas(true),
            window.apiVentas(true),
            window.apiClientes(true),
            window.apiProductos(true),
            window.apiConfiguracion().catch(() => ({ data: { mapa: {} } })),
            window.apiFacturas(true, { ordenes_facturables: 1 }),
            window.apiCajaActiva().catch(() => ({ data: { sesion: null } }))
        ]);
        state.facturas = fac.data || [];
        state.ventas = ven.data || [];
        state.clientes = cli.data || [];
        state.productos = (prod.data || []).map(p => ({
            ...p,
            stock: p.cantidad ?? p.stock ?? 0,
            precio_unitario: Number(p.precio_unitario ?? p.precio ?? 0)
        }));
        state.config = leerIva(cfg.data?.mapa);
        state.ordenes = ots.data || [];
        state.caja = {
            sesion: caja.data?.sesion || null,
            puede_operar: !!caja.data?.puede_operar,
            cuentas: caja.data?.cuentas || []
        };
        pintarBarraCaja();
        syncEstadoCobroUi();
    }

    function pintarBarraCaja() {
        const texto = document.getElementById('estado-caja-facturacion');
        const btnAbrir = document.getElementById('btn-abrir-caja-fac');
        const btnCerrar = document.getElementById('btn-cerrar-caja-fac');
        const barra = document.getElementById('barra-caja-facturacion');
        if (!texto || !barra) return;
        const sesion = state.caja.sesion;
        const puedeCaja = !!state.caja.puede_operar;
        if (sesion) {
            barra.classList.add('abierta');
            barra.classList.remove('cerrada');
            const saldo = ModuleCore.formatCurrency(sesion.monto_sistema ?? sesion.monto_apertura ?? 0);
            const quien = sesion.usuario ? ` · Responsable: ${sesion.usuario}` : '';
            texto.innerHTML = `<strong><i class="fas fa-cash-register"></i> Caja abierta</strong>
                <span class="text-muted"> · ${sesion.cuenta || 'Efectivo'}${quien} · Desde ${ModuleCore.formatDateTime(sesion.fecha_apertura)} · Saldo ${saldo}</span>`;
            if (btnAbrir) {
                btnAbrir.hidden = true;
                btnAbrir.style.display = 'none';
            }
            if (btnCerrar) {
                btnCerrar.hidden = !puedeCaja;
                btnCerrar.style.display = puedeCaja ? '' : 'none';
            }
            return;
        }
        barra.classList.add('cerrada');
        barra.classList.remove('abierta');
        texto.innerHTML = puedeCaja
            ? '<strong>Caja cerrada.</strong> Puede dejar facturas de OT pendientes. No puede cobrar ni vender de mostrador.'
            : '<strong>Caja cerrada.</strong> Pida a recepción o gerencia abrir caja para cobrar.';
        if (btnAbrir) {
            btnAbrir.hidden = !puedeCaja;
            btnAbrir.style.display = puedeCaja ? '' : 'none';
        }
        if (btnCerrar) {
            btnCerrar.hidden = true;
            btnCerrar.style.display = 'none';
        }
    }

    function syncEstadoCobroUi() {
        const sel = document.getElementById('factura-estado');
        const hint = document.getElementById('factura-caja-hint');
        if (sel) {
            const opPagada = Array.from(sel.options).find(o => o.value === 'Pagada');
            if (opPagada) opPagada.disabled = !cajaAbierta();
            if (!cajaAbierta()) sel.value = 'Pendiente';
            else if (!sel.value) sel.value = 'Pagada';
        }
        if (hint) {
            hint.textContent = cajaAbierta()
                ? 'Efectivo suma al cajón. Tarjeta o transferencia van a Banco.'
                : 'Caja cerrada: la factura quedará pendiente. Ábrala para cobrar ahora.';
        }
    }

    function llenarCuentasCaja() {
        const sel = document.getElementById('fac-caja-cuenta');
        if (!sel) return;
        const cuentas = state.caja.cuentas || [];
        sel.innerHTML = cuentas.map(c => `<option value="${c.id_cuenta}">${c.nombre}</option>`).join('')
            || '<option value="">No hay cuenta de efectivo</option>';
        syncMontoAperturaFac();
    }

    function syncMontoAperturaFac() {
        const sel = document.getElementById('fac-caja-cuenta');
        const monto = document.getElementById('fac-caja-monto');
        if (!sel || !monto) return;
        const id = parseInt(sel.value, 10);
        const cuenta = (state.caja.cuentas || []).find(c => Number(c.id_cuenta) === id);
        if (cuenta) monto.value = String(Number(cuenta.saldo_actual || 0));
    }

    function openAbrirCaja() {
        if (!state.caja.puede_operar) {
            ModuleCore.toast('No tiene permiso para abrir caja', 'warning');
            return;
        }
        if (state.caja.sesion) {
            ModuleCore.toast('Ya tiene una caja abierta', 'warning');
            return;
        }
        llenarCuentasCaja();
        syncMontoAperturaFac();
        ModuleCore.openModal('modal-abrir-caja-fac');
    }

    function openCerrarCaja() {
        if (!state.caja.sesion) {
            ModuleCore.toast('No hay caja abierta', 'warning');
            return;
        }
        const s = state.caja.sesion;
        const resumen = document.getElementById('fac-caja-cierre-resumen');
        if (resumen) {
            resumen.textContent = `${s.cuenta || 'Caja'} · Apertura ${ModuleCore.formatCurrency(s.monto_apertura)} · Sistema ${ModuleCore.formatCurrency(s.monto_sistema ?? s.monto_apertura)}`;
        }
        const real = document.getElementById('fac-caja-monto-real');
        const sistema = Number(s.monto_sistema ?? s.monto_apertura ?? 0);
        if (real) real.value = String(sistema > 0 ? sistema : 0);
        ModuleCore.openModal('modal-cerrar-caja-fac');
    }

    async function confirmarAbrirCaja() {
        const idCuenta = parseInt(document.getElementById('fac-caja-cuenta')?.value, 10);
        const monto = parseFloat(document.getElementById('fac-caja-monto')?.value) || 0;
        if (!idCuenta) {
            ModuleCore.toast('Seleccione una cuenta de efectivo', 'warning');
            return;
        }
        try {
            await window.apiCajaAbrir({ id_cuenta: idCuenta, monto_apertura: monto });
            ModuleCore.closeModal('modal-abrir-caja-fac');
            await loadAll();
            renderFacturas();
            renderVentas();
            ModuleCore.toast('Caja abierta. Ya puede cobrar', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo abrir caja', 'error');
        }
    }

    async function confirmarCerrarCaja() {
        const montoReal = parseFloat(document.getElementById('fac-caja-monto-real')?.value);
        if (!(montoReal >= 0)) {
            ModuleCore.toast('Indique el monto real en caja', 'warning');
            return;
        }
        try {
            await window.apiCajaCerrar({
                id_caja: state.caja.sesion?.id_caja,
                monto_real: montoReal
            });
            ModuleCore.closeModal('modal-cerrar-caja-fac');
            await loadAll();
            renderFacturas();
            renderVentas();
            ModuleCore.toast('Caja cerrada', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo cerrar caja', 'error');
        }
    }

    function bindEvents() {
        document.getElementById('btn-nueva-factura')?.addEventListener('click', openFacturaModal);
        document.getElementById('btn-nueva-venta')?.addEventListener('click', openVentaModal);
        document.getElementById('btn-refresh-fac')?.addEventListener('click', async () => {
            await loadAll();
            renderFacturas();
            renderVentas();
        });
        document.getElementById('filter-estado')?.addEventListener('change', applyFilters);
        document.getElementById('filter-tipo')?.addEventListener('change', applyFilters);
        document.getElementById('search-factura')?.addEventListener('input', ModuleCore.debounce(applyFilters));
        document.getElementById('btn-guardar-factura')?.addEventListener('click', saveFactura);
        document.getElementById('btn-guardar-venta')?.addEventListener('click', saveVenta);
        document.getElementById('btn-add-venta-item')?.addEventListener('click', addVentaItem);
        document.getElementById('factura-orden')?.addEventListener('change', onOrdenChange);
        document.getElementById('factura-estado')?.addEventListener('change', () => {
            if (document.getElementById('factura-estado')?.value === 'Pagada' && !cajaAbierta()) {
                ModuleCore.toast('Abra caja para cobrar ahora', 'warning');
                document.getElementById('factura-estado').value = 'Pendiente';
            }
        });
        ModuleCore.bindModalClose('modal-factura', 'btn-cancelar-factura', 'btn-cerrar-factura');
        ModuleCore.bindModalClose('modal-venta', 'btn-cancelar-venta', 'btn-cerrar-venta');
        ModuleCore.bindModalClose('modal-cobrar-factura', 'btn-cancelar-cobrar', 'btn-cerrar-cobrar');
        document.getElementById('tabla-facturas')?.addEventListener('click', onFacturaClick);
        document.getElementById('tabla-ventas')?.addEventListener('click', onVentaClick);
        document.getElementById('btn-abrir-caja-fac')?.addEventListener('click', openAbrirCaja);
        document.getElementById('fac-caja-cuenta')?.addEventListener('change', syncMontoAperturaFac);
        document.getElementById('btn-cerrar-caja-fac')?.addEventListener('click', openCerrarCaja);
        document.getElementById('btn-confirmar-abrir-caja')?.addEventListener('click', confirmarAbrirCaja);
        document.getElementById('btn-confirmar-cierre-caja')?.addEventListener('click', confirmarCerrarCaja);
        document.getElementById('btn-confirmar-cobrar')?.addEventListener('click', confirmarCobro);
        ModuleCore.bindModalClose('modal-abrir-caja-fac', 'btn-cancelar-abrir-caja', 'btn-cerrar-abrir-caja');
        ModuleCore.bindModalClose('modal-cerrar-caja-fac', 'btn-cancelar-cierre-caja', 'btn-cerrar-cierre-caja');
    }

    function applyFilters() {
        state.filtros.estado = document.getElementById('filter-estado')?.value || 'todos';
        state.filtros.tipo = document.getElementById('filter-tipo')?.value || 'todos';
        state.filtros.busqueda = (document.getElementById('search-factura')?.value || '').toLowerCase();
        renderFacturas();
    }

    function filteredFacturas() {
        return state.facturas.filter(f => {
            if (state.filtros.estado !== 'todos' && f.estado !== state.filtros.estado) return false;
            if (state.filtros.tipo !== 'todos' && f.tipo_factura !== state.filtros.tipo) return false;
            if (state.filtros.busqueda) {
                const q = state.filtros.busqueda;
                return [f.numero, f.cliente, f.metodo_pago, f.vehiculo_placa].some(v => String(v || '').toLowerCase().includes(q));
            }
            return true;
        });
    }

    function esHoy(fecha) {
        const local = new Date();
        const ymd = `${local.getFullYear()}-${String(local.getMonth() + 1).padStart(2, '0')}-${String(local.getDate()).padStart(2, '0')}`;
        return String(fecha || '').startsWith(ymd);
    }

    function pintarKpis() {
        const pendientes = state.facturas.filter(f => f.estado === 'Pendiente');
        const elPend = document.getElementById('kpi-facturas-pendientes');
        const elMonto = document.getElementById('kpi-monto-pendiente');
        const elCobrado = document.getElementById('kpi-cobrado-hoy');
        const elVentas = document.getElementById('kpi-ventas-hoy');
        if (elPend) elPend.textContent = pendientes.length;
        if (elMonto) elMonto.textContent = ModuleCore.formatCurrency(
            pendientes.reduce((s, f) => s + Number(f.total || 0), 0)
        );
        if (elCobrado) {
            elCobrado.textContent = ModuleCore.formatCurrency(
                state.facturas
                    .filter(f => f.estado === 'Pagada' && esHoy(f.fecha_emision))
                    .reduce((s, f) => s + Number(f.total || 0), 0)
            );
        }
        if (elVentas) {
            elVentas.textContent = ModuleCore.formatCurrency(
                state.ventas
                    .filter(v => esHoy(v.fecha) && v.estado_factura !== 'Anulada')
                    .reduce((s, v) => s + Number(v.total || 0), 0)
            );
        }
    }

    function botonesFactura(f) {
        const id = f.id_factura;
        const partes = [
            `<button type="button" class="btn-icon btn-sm btn-view" data-id="${id}" title="Ver"><i class="fas fa-eye"></i></button>`,
            `<button type="button" class="btn-icon btn-sm btn-pdf" data-id="${id}" title="Descargar PDF"><i class="fas fa-file-pdf"></i></button>`
        ];
        if (f.estado === 'Pendiente' && puede('facturas.pagar')) {
            partes.push(`<button type="button" class="btn btn-success btn-sm btn-cobrar" data-id="${id}" title="Cobrar">Cobrar</button>`);
        }
        if (f.estado !== 'Anulada' && puede('facturas.anular')) {
            partes.push(`<button type="button" class="btn-icon btn-sm btn-delete" data-id="${id}" title="Anular"><i class="fas fa-ban"></i></button>`);
        }
        return `<div class="table-actions">${partes.join('')}</div>`;
    }

    function renderFacturas() {
        const tbody = document.querySelector('#tabla-facturas tbody');
        if (!tbody) return;
        pintarKpis();
        const items = filteredFacturas();
        tbody.innerHTML = items.map(f => `
            <tr>
                <td><strong>${f.numero || 'FAC-' + f.id_factura}</strong></td>
                <td>${ModuleCore.formatDate(f.fecha_emision)}</td>
                <td>${f.id_cliente ? `<a href="../clientes/index.php?cliente=${encodeURIComponent(f.id_cliente)}">${f.cliente || '—'}</a>` : (f.cliente || '—')}</td>
                <td>${f.tipo_factura}${f.vehiculo_placa ? ` · ${f.vehiculo_placa}` : ''}${f.id_orden ? ` · <a href="../ordenes/index-trabajadores.php?orden=${encodeURIComponent(f.id_orden)}">OT #${f.id_orden}</a>` : ''}</td>
                <td>${f.metodo_pago || '—'}</td>
                <td>${ModuleCore.formatCurrency(f.total)}</td>
                <td>${ModuleCore.badge(f.estado)}</td>
                <td>${botonesFactura(f)}</td>
            </tr>
        `).join('') || ModuleCore.emptyRow(8);
    }

    function renderVentas() {
        const tbody = document.querySelector('#tabla-ventas tbody');
        if (!tbody) return;
        pintarKpis();
        tbody.innerHTML = state.ventas.map(v => {
            const idFac = v.id_factura;
            const estado = v.estado_factura || '—';
            const pdf = idFac
                ? `<button type="button" class="btn-icon btn-sm btn-pdf" data-id="${idFac}" title="PDF"><i class="fas fa-file-pdf"></i></button>`
                : '';
            const anular = idFac && estado !== 'Anulada' && puede('facturas.anular')
                ? `<button type="button" class="btn-icon btn-sm btn-delete" data-id="${idFac}" title="Anular"><i class="fas fa-ban"></i></button>`
                : '';
            return `<tr>
                <td>#${v.id_venta}</td>
                <td>${ModuleCore.formatDateTime(v.fecha)}</td>
                <td>${v.cliente || 'Mostrador'}</td>
                <td>${(v.items || []).length} producto(s)</td>
                <td>${ModuleCore.formatCurrency(v.total)}</td>
                <td>${v.numero_factura || '—'} ${estado !== '—' ? ModuleCore.badge(estado) : ''}</td>
                <td>
                    <button type="button" class="btn-icon btn-sm btn-view" data-id="${v.id_venta}" title="Ver"><i class="fas fa-eye"></i></button>
                    ${pdf}${anular}
                </td>
            </tr>`;
        }).join('') || ModuleCore.emptyRow(7);
    }

    function openFacturaModal() {
        if (!puede('facturas.crear')) {
            ModuleCore.toast('No puede emitir facturas', 'warning');
            return;
        }
        state.preview = null;
        const sel = document.getElementById('factura-orden');
        sel.innerHTML = '<option value="">Seleccione una orden lista para cobro...</option>' +
            state.ordenes.map(o => {
                const placa = o.placa || o.vehiculo?.placa || '';
                const cliente = o.cliente_nombre ? ` · ${o.cliente_nombre}` : '';
                const extra = placa ? ` — ${placa}` : '';
                return `<option value="${o.id_orden}">OT #${o.id_orden}${extra}${cliente} (${o.estado})</option>`;
            }).join('');
        document.getElementById('form-factura').reset();
        document.getElementById('factura-cliente-nombre').value = '';
        document.getElementById('factura-vehiculo').value = '';
        document.getElementById('factura-lineas-tbody').innerHTML = ModuleCore.emptyRow(3, 'Seleccione una orden');
        pintarFacturaTotales(0, 0, 0);
        syncEstadoCobroUi();
        if (cajaAbierta()) document.getElementById('factura-estado').value = 'Pagada';
        ModuleCore.openModal('modal-factura');
    }

    async function onOrdenChange() {
        const id = parseInt(document.getElementById('factura-orden').value, 10);
        if (!id) return;
        try {
            const res = await window.apiFacturas(true, { preview_orden: id });
            state.preview = res.data;
            document.getElementById('factura-cliente-nombre').value = state.preview.cliente || '';
            const v = state.preview.vehiculo || {};
            document.getElementById('factura-vehiculo').value = v.placa ? `${v.placa} ${v.marca || ''} ${v.modelo || ''}` : '';
            const tbody = document.getElementById('factura-lineas-tbody');
            tbody.innerHTML = (state.preview.lineas || []).map(l => `
                <tr><td>${l.tipo}</td><td>${l.descripcion}</td><td>${ModuleCore.formatCurrency(l.monto)}</td></tr>
            `).join('') || ModuleCore.emptyRow(3, 'La orden no tiene líneas');
            pintarFacturaTotales(state.preview.subtotal, state.preview.iva, state.preview.total);
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo cargar la orden', 'error');
        }
    }

    function etiquetaIva() {
        const pct = state.config.iva_activo ? state.config.iva_porcentaje : 0;
        return state.config.iva_activo
            ? `IVA ${pct}% (configuración del taller)`
            : 'IVA desactivado en configuración';
    }

    function pintarFacturaTotales(subtotal, iva, total) {
        const label = document.getElementById('factura-iva-label');
        if (label) label.textContent = etiquetaIva();
        const s = document.getElementById('factura-subtotal-preview');
        const i = document.getElementById('factura-iva-preview');
        const t = document.getElementById('factura-total-preview');
        if (s) s.textContent = ModuleCore.formatCurrency(subtotal);
        if (i) i.textContent = ModuleCore.formatCurrency(iva);
        if (t) t.textContent = ModuleCore.formatCurrency(total);
    }

    function pintarVentaTotales(subtotal, iva, total) {
        const s = document.getElementById('venta-subtotal-preview');
        const i = document.getElementById('venta-iva-preview');
        const t = document.getElementById('venta-total-preview');
        if (s) s.textContent = ModuleCore.formatCurrency(subtotal);
        if (i) i.textContent = ModuleCore.formatCurrency(iva);
        if (t) t.textContent = ModuleCore.formatCurrency(total);
    }

    function calcIva(subtotal) {
        const activo = !!state.config.iva_activo;
        const pct = Number(state.config.iva_porcentaje || 0);
        const iva = activo ? Math.round(subtotal * (pct / 100)) : 0;
        return { subtotal, iva, total: subtotal + iva };
    }

    async function saveFactura() {
        const idOrden = parseInt(document.getElementById('factura-orden').value, 10);
        if (!idOrden) {
            ModuleCore.toast('Seleccione una orden', 'warning');
            return;
        }
        if (!state.preview?.lineas?.length) {
            ModuleCore.toast('La orden no tiene servicios ni productos para facturar', 'warning');
            return;
        }
        const estado = document.getElementById('factura-estado').value;
        if (estado === 'Pagada' && !cajaAbierta()) {
            ModuleCore.toast('Abra caja para cobrar ahora, o deje la factura pendiente', 'warning');
            return;
        }
        try {
            await window.apiFacturas(false, {
                id_orden: idOrden,
                tipo_factura: 'Orden de servicio',
                metodo_pago: document.getElementById('factura-metodo').value,
                estado
            });
            ModuleCore.closeModal('modal-factura');
            await loadAll();
            renderFacturas();
            renderVentas();
            ModuleCore.toast(estado === 'Pagada' ? 'Factura emitida y cobrada' : 'Factura emitida. Queda pendiente de cobro', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo emitir', 'error');
        }
    }

    function populateVentaClientes() {
        const sel = document.getElementById('venta-cliente');
        if (!sel) return;
        sel.innerHTML = state.clientes.map(c =>
            `<option value="${c.id_cliente}">${c.nombre}${c.documento === '2222222222' ? ' (mostrador)' : ''}</option>`
        ).join('');
        const gen = state.clientes.find(c => c.documento === '2222222222');
        if (gen) sel.value = gen.id_cliente;
    }

    function openVentaModal() {
        if (!(puede('ventas.crear') || puede('facturas.crear'))) {
            ModuleCore.toast('No puede registrar ventas', 'warning');
            return;
        }
        if (!cajaAbierta()) {
            ModuleCore.toast('Abra caja para vender de mostrador. El cobro se registra al confirmar.', 'warning');
            return;
        }
        state.ventaItems = [{ id_producto: '', cantidad: 1, precio: 0, stock: 0 }];
        populateVentaClientes();
        renderVentaItems();
        ModuleCore.openModal('modal-venta');
    }

    function addVentaItem() {
        state.ventaItems.push({ id_producto: '', cantidad: 1, precio: 0, stock: 0 });
        renderVentaItems();
    }

    function renderVentaItems() {
        const tbody = document.querySelector('#venta-items-tbody');
        if (!tbody) return;
        const prodOpts = state.productos.map(p =>
            `<option value="${p.id_producto}" data-precio="${p.precio_unitario}" data-nombre="${p.nombre}" data-stock="${p.stock}">${p.nombre} — ${ModuleCore.formatCurrency(p.precio_unitario)} (Stock: ${p.stock})</option>`
        ).join('');
        tbody.innerHTML = state.ventaItems.map((item, i) => `
            <tr data-idx="${i}">
                <td><select class="form-control venta-prod-select" data-idx="${i}"><option value="">Seleccione...</option>${prodOpts}</select></td>
                <td><input type="number" class="form-control venta-cant-input" data-idx="${i}" value="${item.cantidad}" min="1"></td>
                <td class="venta-line-total" data-idx="${i}">$0</td>
                <td><button type="button" class="btn-icon btn-sm btn-delete venta-del-item" data-idx="${i}"><i class="fas fa-trash"></i></button></td>
            </tr>
        `).join('');
        tbody.querySelectorAll('.venta-prod-select').forEach(sel => {
            sel.addEventListener('change', updateVentaLine);
            if (state.ventaItems[sel.dataset.idx]?.id_producto) sel.value = state.ventaItems[sel.dataset.idx].id_producto;
        });
        tbody.querySelectorAll('.venta-cant-input').forEach(inp => inp.addEventListener('input', updateVentaLine));
        tbody.querySelectorAll('.venta-del-item').forEach(btn => btn.addEventListener('click', () => {
            state.ventaItems.splice(parseInt(btn.dataset.idx, 10), 1);
            if (!state.ventaItems.length) state.ventaItems.push({ id_producto: '', cantidad: 1, precio: 0, stock: 0 });
            renderVentaItems();
        }));
        tbody.querySelectorAll('tr').forEach(row => {
            const sel = row.querySelector('.venta-prod-select');
            if (sel?.value) {
                const fake = { target: sel };
                updateVentaLine(fake);
            }
        });
        updateVentaTotal();
    }

    function updateVentaLine(e) {
        const idx = parseInt(e.target.dataset.idx, 10);
        const row = e.target.closest('tr');
        const sel = row.querySelector('.venta-prod-select');
        let cant = parseInt(row.querySelector('.venta-cant-input').value, 10) || 1;
        const opt = sel.selectedOptions[0];
        const precio = parseFloat(opt?.dataset.precio) || 0;
        const stock = Number(opt?.dataset.stock || 0);
        if (sel.value && cant > stock) {
            cant = Math.max(1, stock);
            row.querySelector('.venta-cant-input').value = String(cant);
            ModuleCore.toast(`Solo hay ${stock} unidades de ${opt?.dataset.nombre || 'ese producto'}`, 'warning');
        }
        state.ventaItems[idx] = {
            id_producto: sel.value,
            cantidad: cant,
            producto: opt?.dataset.nombre,
            precio,
            stock
        };
        row.querySelector('.venta-line-total').textContent = ModuleCore.formatCurrency(precio * cant);
        updateVentaTotal();
    }

    function updateVentaTotal() {
        const subtotal = state.ventaItems.reduce((s, it) => s + (it.precio || 0) * (it.cantidad || 0), 0);
        const t = calcIva(subtotal);
        pintarVentaTotales(t.subtotal, t.iva, t.total);
        return t;
    }

    async function saveVenta() {
        if (!cajaAbierta()) {
            ModuleCore.toast('Abra caja para registrar la venta', 'warning');
            return;
        }
        const validItems = state.ventaItems.filter(i => i.id_producto && i.cantidad > 0);
        if (!validItems.length) {
            ModuleCore.toast('Agregue al menos un producto', 'warning');
            return;
        }
        const usados = new Set();
        for (const item of validItems) {
            if (usados.has(String(item.id_producto))) {
                ModuleCore.toast(`El producto ${item.producto} está repetido. Únalo en una sola línea.`, 'warning');
                return;
            }
            usados.add(String(item.id_producto));
            if (item.stock < item.cantidad) {
                ModuleCore.toast(`Stock insuficiente: ${item.producto}`, 'error');
                return;
            }
        }
        try {
            await window.apiVentas(false, {
                id_cliente: parseInt(document.getElementById('venta-cliente').value, 10) || 0,
                metodo_pago: document.getElementById('venta-metodo-pago').value,
                estado: 'Pagada',
                items: validItems.map(i => ({ id_producto: Number(i.id_producto), cantidad: i.cantidad }))
            });
            ModuleCore.closeModal('modal-venta');
            await loadAll();
            renderVentas();
            renderFacturas();
            ModuleCore.toast('Venta cobrada. Stock descontado.', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo registrar la venta', 'error');
        }
    }

    function onFacturaClick(e) {
        const btn = e.target.closest('.btn-view, .btn-cobrar, .btn-delete, .btn-pdf');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const f = state.facturas.find(x => x.id_factura === id);
        if (!f && !btn.classList.contains('btn-pdf')) return;
        if (btn.classList.contains('btn-pdf')) {
            window.apiFacturaPdf(id).catch(err => ModuleCore.toast(err.message || 'No se pudo descargar el PDF', 'error'));
            return;
        }
        if (btn.classList.contains('btn-view')) {
            verFactura(f);
            return;
        }
        if (btn.classList.contains('btn-cobrar')) {
            abrirCobro(id);
            return;
        }
        if (btn.classList.contains('btn-delete')) {
            anularFactura(id);
        }
    }

    function verFactura(f) {
        const rows = (f.detalles || []).filter(d => Number(d.monto) > 0).map(d =>
            `<tr><td>${d.tipo_referencia}</td><td>${d.descripcion || ''}</td><td>${ModuleCore.formatCurrency(d.monto)}</td></tr>`
        ).join('');
        window.createModal?.('det', `Factura ${f.numero}`, `
            <p><strong>Cliente:</strong> ${f.id_cliente ? `<a href="../clientes/index.php?cliente=${encodeURIComponent(f.id_cliente)}">${f.cliente || '—'}</a>` : (f.cliente || '—')}</p>
            ${f.id_orden ? `<p><strong>Orden:</strong> <a href="../ordenes/index-trabajadores.php?orden=${encodeURIComponent(f.id_orden)}">OT #${f.id_orden}</a>${f.vehiculo_placa ? ` · ${f.vehiculo_placa}` : ''}</p>` : ''}
            <p><strong>Tipo:</strong> ${f.tipo_factura} · <strong>Pago:</strong> ${f.metodo_pago} · ${ModuleCore.badge(f.estado)}</p>
            <table class="table"><thead><tr><th>Tipo</th><th>Detalle</th><th>Monto</th></tr></thead><tbody>${rows}</tbody></table>
            <p>${etiquetaIva()}</p>
            <p>Subtotal ${ModuleCore.formatCurrency(f.subtotal)} · IVA ${ModuleCore.formatCurrency(f.IVA ?? f.iva)} · <strong>Total ${ModuleCore.formatCurrency(f.total)}</strong></p>
        `);
    }

    function abrirCobro(id) {
        if (!puede('facturas.pagar')) {
            ModuleCore.toast('No puede registrar cobros', 'warning');
            return;
        }
        if (!cajaAbierta()) {
            ModuleCore.toast('Abra caja para cobrar', 'warning');
            return;
        }
        const f = state.facturas.find(x => x.id_factura === id);
        if (!f || f.estado !== 'Pendiente') return;
        state.cobroId = id;
        const resumen = document.getElementById('cobrar-resumen');
        if (resumen) {
            resumen.textContent = `${f.numero} · ${f.cliente || 'Cliente'} · ${ModuleCore.formatCurrency(f.total)}`;
        }
        const metodo = document.getElementById('cobrar-metodo');
        if (metodo) metodo.value = f.metodo_pago || 'Efectivo';
        ModuleCore.openModal('modal-cobrar-factura');
    }

    async function confirmarCobro() {
        const id = state.cobroId;
        if (!id) return;
        try {
            await window.apiFacturasActualizar(id, {
                id_factura: id,
                estado: 'Pagada',
                metodo_pago: document.getElementById('cobrar-metodo')?.value || 'Efectivo'
            });
            ModuleCore.closeModal('modal-cobrar-factura');
            state.cobroId = null;
            await loadAll();
            renderFacturas();
            ModuleCore.toast('Cobro registrado', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo cobrar', 'error');
        }
    }

    async function anularFactura(id) {
        if (!puede('facturas.anular')) {
            ModuleCore.toast('No puede anular facturas', 'warning');
            return;
        }
        const f = state.facturas.find(x => x.id_factura === id)
            || state.ventas.find(v => Number(v.id_factura) === id);
        const esMostrador = (f?.tipo_factura === 'Venta mostrador') || state.ventas.some(v => Number(v.id_factura) === id);
        const pagada = (f?.estado === 'Pagada') || (f?.estado_factura === 'Pagada');
        if (pagada && !cajaAbierta()) {
            ModuleCore.toast('Abra caja para reversar un cobro ya registrado', 'warning');
            return;
        }
        const extra = esMostrador
            ? 'Se devolverá el stock. Si estaba pagada, se reversa el dinero (cajón o Banco).'
            : 'No se devuelven los repuestos de la orden. Si estaba pagada, se reversa el cobro.';
        if (!confirm(`¿Anular esta factura?\n${extra}`)) return;
        try {
            await window.apiFacturasEliminar(id);
            await loadAll();
            renderFacturas();
            renderVentas();
            ModuleCore.toast(esMostrador ? 'Factura anulada. Stock restaurado.' : 'Factura anulada.', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo anular', 'error');
        }
    }

    function onVentaClick(e) {
        const btn = e.target.closest('.btn-view, .btn-pdf, .btn-delete');
        if (!btn) return;
        if (btn.classList.contains('btn-pdf')) {
            const idFac = parseInt(btn.dataset.id, 10);
            window.apiFacturaPdf(idFac).catch(err => ModuleCore.toast(err.message || 'No se pudo descargar el PDF', 'error'));
            return;
        }
        if (btn.classList.contains('btn-delete')) {
            anularFactura(parseInt(btn.dataset.id, 10));
            return;
        }
        const id = parseInt(btn.dataset.id, 10);
        const v = state.ventas.find(x => x.id_venta === id);
        if (!v) return;
        const rows = (v.items || []).map(i =>
            `<tr><td>${i.producto || i.id_producto}</td><td>${i.cantidad}</td><td>${ModuleCore.formatCurrency(i.subtotal)}</td></tr>`
        ).join('');
        window.createModal?.('det', `Venta #${id}`, `
            <p>${v.numero_factura || ''} · ${v.metodo_pago || ''} · ${v.estado_factura ? ModuleCore.badge(v.estado_factura) : ''}</p>
            <table class="table"><thead><tr><th>Producto</th><th>Cant.</th><th>Subtotal</th></tr></thead><tbody>${rows}</tbody></table>
            <p><strong>Total:</strong> ${ModuleCore.formatCurrency(v.total)}</p>
        `);
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => FacturacionModule.init());
if (document.readyState !== 'loading') {
    FacturacionModule.init();
}
