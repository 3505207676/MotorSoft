/**
 * Configuración del taller — IVA, SMTP y canal WhatsApp
 */
document.addEventListener('DOMContentLoaded', () => {
    cargar();
    document.getElementById('btn-guardar-config')?.addEventListener('click', guardar);
    document.querySelectorAll('.js-guardar-config').forEach(btn => btn.addEventListener('click', guardar));
    document.getElementById('btn-probar-whatsapp')?.addEventListener('click', probarWhatsApp);
    document.getElementById('btn-probar-webhook')?.addEventListener('click', probarWebhookLocal);
    document.getElementById('btn-simular-whatsapp')?.addEventListener('click', simularWhatsApp);
    document.getElementById('btn-probar-correo')?.addEventListener('click', probarCorreo);
    document.getElementById('btn-usar-url-sugerida')?.addEventListener('click', usarUrlSugerida);
    document.getElementById('correo-buzon')?.addEventListener('click', onBuzonClick);
    document.getElementById('btn-copiar-webhook')?.addEventListener('click', copiarWebhook);
    document.getElementById('empresa_logo')?.addEventListener('change', subirLogo);
    document.getElementById('btn-quitar-logo')?.addEventListener('click', quitarLogo);
    const webhook = document.getElementById('whatsapp_webhook_url');
    if (webhook) {
        webhook.value = urlWebhook();
        if (!/^https:\/\//i.test(webhook.value) || /localhost|127\.0\.0\.1/i.test(webhook.value)) {
            const aviso = document.getElementById('whatsapp-webhook-aviso');
            if (aviso) {
                aviso.hidden = false;
                aviso.textContent = 'Meta no alcanza localhost. En producción use una URL pública HTTPS (o un túnel) apuntando a este mismo archivo.';
            }
        }
    }
});

function urlWebhook() {
    return new URL('../../controllers/api/chat/whatsapp-webhook.php', window.location.href).href;
}

function val(id, fallback = '') {
    const el = document.getElementById(id);
    if (!el) return fallback;
    if (el.type === 'checkbox') return el.checked;
    return el.value;
}

function setVal(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    if (el.type === 'checkbox') {
        el.checked = !!value;
        return;
    }
    el.value = value ?? '';
}

function setEstado(id, texto, ok) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = texto;
    el.style.color = ok ? '#0a7a32' : (ok === false ? '#b42318' : '');
}

async function cargar() {
    try {
        const res = await window.apiConfiguracion();
        const mapa = res.data?.mapa || {};
        const esAdmin = !!(res.data?.puede_editar || res.data?.es_admin);
        setVal('iva_activo', !!mapa.iva_activo);
        setVal('iva_porcentaje', mapa.iva_porcentaje ?? 19);
        setVal('factura_prefijo', mapa.factura_prefijo || 'FAC');
        setVal('moneda', mapa.moneda || 'COP');
        setVal('empresa_nombre', mapa.empresa_nombre || '');
        setVal('empresa_nit', mapa.empresa_nit || '');
        setVal('empresa_direccion', mapa.empresa_direccion || '');
        setVal('empresa_telefono', mapa.empresa_telefono || '');
        await pintarLogo(!!mapa.empresa_logo_set);
        setVal('correo_activo', !!mapa.correo_activo);
        setVal('correo_host', mapa.correo_host || 'smtp.gmail.com');
        setVal('correo_puerto', mapa.correo_puerto ?? 587);
        setVal('correo_cifrado', mapa.correo_cifrado || 'tls');
        setVal('correo_usuario', mapa.correo_usuario || '');
        setVal('correo_password', '');
        const passMail = document.getElementById('correo_password');
        if (passMail) {
            passMail.placeholder = mapa.correo_password_set
                ? 'Contraseña guardada. Déjela en blanco para no cambiarla'
                : 'Contraseña o clave de aplicación';
        }
        setVal('correo_remitente', mapa.correo_remitente || '');
        setVal('correo_remitente_nombre', mapa.correo_remitente_nombre || mapa.empresa_nombre || '');
        setVal('app_url_publica', mapa.app_url_publica || '');
        const diag = res.data?.diagnostico_correo || {};
        const sugerida = diag.url_sugerida || urlAppSugerida();
        const hintUrl = document.getElementById('app-url-sugerida');
        if (hintUrl) {
            hintUrl.textContent = sugerida
                ? ('Sugerida ahora: ' + sugerida + '. En producción use HTTPS.')
                : 'En local puede dejarlo vacío. En producción ponga la URL HTTPS con la que entra la gente.';
            hintUrl.dataset.sugerida = sugerida || '';
        }
        if (diag.smtp_listo) {
            setEstado('correo-estado', 'SMTP listo. Use “Probar envío” para confirmar con el servidor.', true);
        } else {
            setEstado('correo-estado', diag.error || 'Sin SMTP. Las invitaciones quedan en el buzón interno.', null);
        }
        pintarBuzon(res.data?.buzon || []);
        setVal('whatsapp_activo', !!mapa.whatsapp_activo);
        setVal('whatsapp_phone_id', mapa.whatsapp_phone_id || '');
        setVal('whatsapp_waba_id', mapa.whatsapp_waba_id || '');
        setVal('whatsapp_token', '');
        const tokenInput = document.getElementById('whatsapp_token');
        if (tokenInput) {
            tokenInput.placeholder = mapa.whatsapp_token_set
                ? 'Token guardado. Déjelo en blanco para no cambiarlo'
                : 'Pegue el token permanente de Meta';
        }
        setVal('whatsapp_verify_token', mapa.whatsapp_verify_token || 'motorsoft-wa');
        if (mapa.whatsapp_activo && mapa.whatsapp_token_set && mapa.whatsapp_phone_id) {
            setEstado('whatsapp-estado', 'Credenciales guardadas. Use “Probar conexión” para validarlas con Meta.', null);
        } else {
            setEstado('whatsapp-estado', 'Canal interno listo. WhatsApp en Chat funciona en local; el celular espera token + HTTPS.', null);
        }
        await pintarWhatsAppEstado();
        document.querySelectorAll('#form-config input, #form-correo input, #form-correo select, #form-correo button, #form-whatsapp input, #form-whatsapp button, .js-guardar-config').forEach(el => {
            if (el.id === 'whatsapp_webhook_url' || el.id === 'btn-copiar-webhook') return;
            if (el.classList && (el.classList.contains('js-ver-buzon') || el.classList.contains('js-ver-wa'))) return;
            if (el.classList && el.classList.contains('js-ver-buzon')) return;
            el.disabled = !esAdmin;
        });
        const btn = document.getElementById('btn-guardar-config');
        if (btn) btn.style.display = esAdmin ? '' : 'none';
        document.querySelectorAll('.js-guardar-config').forEach(b => {
            b.style.display = esAdmin ? '' : 'none';
        });
        const probarWa = document.getElementById('btn-probar-whatsapp');
        if (probarWa) probarWa.style.display = esAdmin ? '' : 'none';
        const probarMail = document.getElementById('btn-probar-correo');
        if (probarMail) probarMail.style.display = esAdmin ? '' : 'none';
        const btnLogo = document.getElementById('btn-quitar-logo');
        if (btnLogo) btnLogo.style.display = esAdmin ? '' : 'none';
        if (!esAdmin) {
            const aviso = document.getElementById('config-rol-aviso');
            if (aviso) aviso.textContent = 'Solo lectura: pide a un administrador si necesitas cambiar IVA, correo o WhatsApp.';
        }
    } catch (e) {
        window.showToast?.(e.message || 'No se pudo cargar la configuración', 'error');
    }
}

async function pintarLogo(hay) {
    const img = document.getElementById('logo-preview');
    if (!img) return;
    if (img.dataset.blob) {
        URL.revokeObjectURL(img.dataset.blob);
        delete img.dataset.blob;
    }
    const sello = '../../assets/images/logo-taller.png';
    if (!hay || typeof window.apiConfiguracionLogoBlob !== 'function') {
        img.hidden = false;
        img.src = sello;
        return;
    }
    try {
        const blob = await window.apiConfiguracionLogoBlob();
        if (!blob) {
            img.hidden = false;
            img.src = sello;
            return;
        }
        const href = URL.createObjectURL(blob);
        img.dataset.blob = href;
        img.src = href;
        img.hidden = false;
    } catch (e) {
        img.hidden = false;
        img.src = sello;
    }
}

async function subirLogo(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    try {
        await window.apiConfiguracionLogoSubir(file);
        window.showToast?.('Logo actualizado. Ya sale en el PDF de cobro.', 'success');
        await cargar();
    } catch (err) {
        window.showToast?.(err.message || 'No se pudo subir el logo', 'error');
    }
}

async function quitarLogo() {
    try {
        await window.apiConfiguracionLogoQuitar();
        window.showToast?.('Se volvió al sello de Taller El Paisa', 'success');
        await cargar();
    } catch (err) {
        window.showToast?.(err.message || 'No se pudo quitar el logo', 'error');
    }
}

async function guardar() {
    try {
        const payload = {
            iva_activo: val('iva_activo') ? '1' : '0',
            iva_porcentaje: val('iva_porcentaje'),
            factura_prefijo: val('factura_prefijo'),
            moneda: val('moneda'),
            empresa_nombre: val('empresa_nombre'),
            empresa_nit: val('empresa_nit'),
            empresa_direccion: val('empresa_direccion'),
            empresa_telefono: val('empresa_telefono'),
            correo_activo: val('correo_activo') ? '1' : '0',
            correo_host: val('correo_host'),
            correo_puerto: val('correo_puerto'),
            correo_cifrado: val('correo_cifrado'),
            correo_usuario: val('correo_usuario'),
            correo_remitente: val('correo_remitente'),
            correo_remitente_nombre: val('correo_remitente_nombre'),
            app_url_publica: val('app_url_publica'),
            whatsapp_activo: val('whatsapp_activo') ? '1' : '0',
            whatsapp_phone_id: val('whatsapp_phone_id'),
            whatsapp_waba_id: val('whatsapp_waba_id'),
            whatsapp_verify_token: val('whatsapp_verify_token')
        };
        const passMail = String(val('correo_password') || '').trim();
        if (passMail) payload.correo_password = passMail;
        const token = String(val('whatsapp_token') || '').trim();
        if (token) payload.whatsapp_token = token;
        await window.apiConfiguracionActualizar(payload);
        window.showToast?.('Configuración guardada', 'success');
        await cargar();
    } catch (e) {
        window.showToast?.(e.message || 'No se pudo guardar', 'error');
    }
}

async function probarCorreo() {
    setEstado('correo-estado', 'Enviando correo de prueba…', null);
    try {
        const destino = String(val('correo_prueba_destino') || val('correo_usuario') || val('correo_remitente') || '').trim();
        if (!destino) {
            setEstado('correo-estado', 'Indique un correo de prueba.', false);
            return;
        }
        const res = await window.apiCorreoProbar({ destino });
        const d = res.data || {};
        const canal = d.canal === 'smtp' ? 'SMTP' : 'buzón interno';
        setEstado('correo-estado', 'Prueba entregada por ' + canal + ' a ' + (d.destino || destino), true);
        window.showToast?.(
            d.canal === 'smtp' ? 'Revise la bandeja de entrada (y spam)' : 'Sin SMTP: abra el mensaje en el buzón interno',
            'success'
        );
        await cargar();
        setEstado('correo-estado', 'Prueba entregada por ' + canal + ' a ' + (d.destino || destino), true);
    } catch (e) {
        setEstado('correo-estado', e.message || 'No se pudo enviar el correo de prueba', false);
        window.showToast?.(e.message || 'No se pudo enviar el correo de prueba', 'error');
    }
}

function urlAppSugerida() {
    try {
        return new URL('../../', window.location.href).href.replace(/\/+$/, '');
    } catch (e) {
        return '';
    }
}

function usarUrlSugerida() {
    const hint = document.getElementById('app-url-sugerida');
    let url = (hint && hint.dataset.sugerida) || urlAppSugerida();
    if (!url) return;
    try {
        url = new URL(url).href.replace(/\/+$/, '');
    } catch (e) {
        url = String(url).trim();
    }
    setVal('app_url_publica', url);
    window.showToast?.('URL actual copiada al campo. Recuerde Guardar.', 'info');
}

function pintarBuzon(items) {
    const box = document.getElementById('correo-buzon');
    if (!box) return;
    if (!Array.isArray(items) || !items.length) {
        box.innerHTML = '<span class="text-muted">Sin mensajes todavía. Use “Probar envío” o invite a un usuario.</span>';
        return;
    }
    box.innerHTML = '<div style="overflow:auto"><table class="table" style="width:100%;font-size:0.9rem">'
        + '<thead><tr><th>Fecha</th><th>Para</th><th>Asunto</th><th>Canal</th><th></th></tr></thead><tbody>'
        + items.map((m) => {
            const fecha = String(m.fecha || '').replace('T', ' ').slice(0, 19);
            const canal = m.canal === 'smtp' ? 'SMTP' : 'Interno';
            const ok = m.ok === false ? ' (falló SMTP)' : '';
            return '<tr>'
                + '<td>' + escapeHtml(fecha) + '</td>'
                + '<td>' + escapeHtml(m.para || '') + '</td>'
                + '<td>' + escapeHtml(m.asunto || '') + '</td>'
                + '<td>' + escapeHtml(canal + ok) + '</td>'
                + '<td><button type="button" class="btn btn-outline btn-sm js-ver-buzon" data-id="' + escapeHtml(m.id || '') + '">Ver</button></td>'
                + '</tr>';
        }).join('')
        + '</tbody></table></div>';
}

function escapeHtml(s) {
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

async function onBuzonClick(e) {
    const btn = e.target.closest('.js-ver-buzon');
    if (!btn) return;
    const id = btn.getAttribute('data-id') || '';
    if (!id || typeof window.apiConfiguracionBuzon !== 'function') return;
    try {
        const res = await window.apiConfiguracionBuzon(id);
        const html = res.data?.html || '';
        const blob = new Blob([html || '<p>Sin contenido</p>'], { type: 'text/html;charset=utf-8' });
        const href = URL.createObjectURL(blob);
        const win = window.open(href, '_blank');
        if (!win) {
            window.showToast?.('Permita ventanas emergentes para ver el correo', 'info');
        }
    } catch (err) {
        window.showToast?.(err.message || 'No se pudo abrir el correo', 'error');
    }
}

async function probarWhatsApp() {
    setEstado('whatsapp-estado', 'Probando conexión con Meta…', null);
    try {
        const res = await window.apiWhatsAppProbar();
        const d = res.data || {};
        if (d.ok) {
            const bits = [d.nombre, d.numero, d.calidad ? `calidad ${d.calidad}` : ''].filter(Boolean);
            setEstado('whatsapp-estado', 'Conexión correcta' + (bits.length ? ': ' + bits.join(' · ') : '.'), true);
            window.showToast?.('WhatsApp Cloud API respondió bien', 'success');
            pintarEventosWa(d.eventos || []);
            return;
        }
        setEstado('whatsapp-estado', d.error || 'No se pudo validar WhatsApp', false);
        window.showToast?.(d.error || 'No se pudo validar WhatsApp', 'error');
        pintarEventosWa(d.eventos || []);
    } catch (e) {
        setEstado('whatsapp-estado', e.message || 'No se pudo validar WhatsApp', false);
        window.showToast?.(e.message || 'No se pudo validar WhatsApp', 'error');
    }
}

async function pintarWhatsAppEstado() {
    if (typeof window.apiWhatsAppEstado !== 'function') return;
    try {
        const res = await window.apiWhatsAppEstado();
        const d = res.data || {};
        const hook = document.getElementById('whatsapp_webhook_url');
        if (hook && d.webhook_publico) {
            try {
                hook.value = new URL(d.webhook_publico).href;
            } catch (err) {
                hook.value = d.webhook_publico;
            }
        }
        const aviso = document.getElementById('whatsapp-webhook-aviso');
        if (aviso) {
            if (!d.https) {
                aviso.hidden = false;
                aviso.textContent = 'Meta no alcanza localhost. En producción use HTTPS (o un túnel) y ponga esa URL en app URL pública. Mientras tanto simule un mensaje.';
            } else {
                aviso.hidden = true;
            }
        }
        if (d.error && !(d.configurado && d.https)) {
            setEstado('whatsapp-estado', d.error, null);
        }
        pintarEventosWa(d.eventos || []);
    } catch (e) {
        /* el bloque de WhatsApp no debe tumbar Configuración */
    }
}

function pintarEventosWa(items) {
    const box = document.getElementById('whatsapp-eventos');
    if (!box) return;
    if (!Array.isArray(items) || !items.length) {
        box.textContent = 'Sin eventos todavía. Pruebe el webhook o simule un mensaje.';
        return;
    }
    box.innerHTML = '<div style="overflow:auto"><table class="table" style="width:100%;font-size:0.9rem">'
        + '<thead><tr><th>Fecha</th><th>Tipo</th><th>Detalle</th></tr></thead><tbody>'
        + items.map((m) => {
            const fecha = String(m.fecha || '').replace('T', ' ').slice(0, 19);
            const tipo = m.tipo || '';
            const det = (m.detalle || '') + (m.telefono ? ' · ' + m.telefono : '');
            const marca = m.ok === false ? ' (error)' : '';
            return '<tr><td>' + escapeHtml(fecha) + '</td><td>' + escapeHtml(tipo + marca) + '</td><td>' + escapeHtml(det) + '</td></tr>';
        }).join('')
        + '</tbody></table></div>';
}

async function probarWebhookLocal() {
    setEstado('whatsapp-estado', 'Probando verify token del webhook…', null);
    const token = String(val('whatsapp_verify_token') || 'motorsoft-wa');
    const url = (document.getElementById('whatsapp_webhook_url')?.value || urlWebhook())
        + '?hub.mode=subscribe&hub.verify_token=' + encodeURIComponent(token)
        + '&hub.challenge=ok-taller';
    try {
        const res = await fetch(url, { cache: 'no-store' });
        const text = (await res.text()).trim();
        if (res.ok && text === 'ok-taller') {
            const okMsg = 'Webhook local correcto. Meta usará el mismo verify token en HTTPS.';
            setEstado('whatsapp-estado', okMsg, true);
            window.showToast?.('El webhook respondió el challenge', 'success');
            await pintarWhatsAppEstado();
            setEstado('whatsapp-estado', okMsg, true);
            return;
        }
        setEstado('whatsapp-estado', 'Webhook rechazó la prueba (HTTP ' + res.status + '). Revise el verify token y guarde.', false);
        window.showToast?.('El webhook no validó el token', 'error');
    } catch (e) {
        setEstado('whatsapp-estado', e.message || 'No se alcanzó el webhook', false);
        window.showToast?.(e.message || 'No se alcanzó el webhook', 'error');
    }
}

async function simularWhatsApp() {
    const telefono = String(val('wa_sim_telefono') || '').trim();
    const texto = String(val('wa_sim_texto') || '').trim();
    const nombre = String(val('wa_sim_nombre') || '').trim();
    if (!telefono || !texto) {
        setEstado('whatsapp-estado', 'Indique celular y texto para simular.', false);
        return;
    }
    setEstado('whatsapp-estado', 'Simulando mensaje entrante…', null);
    try {
        const res = await window.apiWhatsAppSimular({ telefono, texto, nombre });
        const d = res.data || {};
        setEstado('whatsapp-estado', 'Simulado a ' + (d.telefono || telefono) + '. Ábralo en Chat → WhatsApp.', true);
        window.showToast?.('Mensaje simulado. Revise Chat.', 'success');
        await pintarWhatsAppEstado();
        setVal('wa_sim_texto', '');
    } catch (e) {
        setEstado('whatsapp-estado', e.message || 'No se pudo simular', false);
        window.showToast?.(e.message || 'No se pudo simular', 'error');
    }
}

async function copiarWebhook() {
    const url = document.getElementById('whatsapp_webhook_url')?.value || urlWebhook();
    try {
        await navigator.clipboard.writeText(url);
        window.showToast?.('URL del webhook copiada', 'success');
    } catch (e) {
        window.showToast?.(url, 'info');
    }
}
