/**
 * Contabilidad: cuentas, caja y movimientos reales
 */
const ContabilidadModule = (() => {
    const state = {
        tab: 'resumen',
        cuentas: [],
        transacciones: [],
        conceptos: [],
        sesiones: [],
        sesionActiva: null,
        puedeOperar: false,
        esAdmin: false,
        puedeCuentas: false,
        editCuenta: null,
        filtros: { tipo: 'todos', cuenta: 'todos', ambito: 'turno' }
    };

    async function init() {
        try {
            await loadAll();
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo cargar contabilidad', 'error');
        }
        ModuleCore.initTabs('#modulo-contabilidad', id => { state.tab = id; if (id === 'caja') renderCaja(); });
        bindEvents();
        renderResumen();
        renderCuentas();
        renderTransacciones();
        renderCaja();
    }

    async function loadAll() {
        const res = await window.apiCaja();
        const d = res.data || {};
        state.cuentas = d.cuentas || [];
        state.transacciones = d.transacciones || [];
        state.conceptos = d.conceptos || [];
        state.sesiones = d.sesiones || [];
        state.sesionActiva = d.sesion_activa || null;
        state.puedeOperar = !!d.puede_operar;
        state.esAdmin = !!d.es_admin;
        state.puedeCuentas = !!(d.puede_cuentas || d.es_admin);
        if (d.totales) {
            state.totalesApi = d.totales;
        }
        aplicarPermisosUi();
        syncMontoApertura();
    }

    function totales() {
        const sesion = sesionParaCerrar();
        const saldoCuentas = state.totalesApi?.saldo_cuentas
            ?? state.cuentas.reduce((s, c) => s + Number(c.saldo_actual || 0), 0);
        if (!sesion) {
            return { ingresos: 0, egresos: 0, balance: 0, saldoCuentas };
        }
        const ingresos = Number(state.totalesApi?.ingresos ?? 0);
        const egresos = Number(state.totalesApi?.egresos ?? 0);
        const saldoSistema = Number(sesion.monto_sistema ?? (Number(sesion.monto_apertura || 0) + ingresos - egresos));
        return { ingresos, egresos, balance: saldoSistema, saldoCuentas };
    }

    function aplicarPermisosUi() {
        const btnCuenta = document.getElementById('btn-nueva-cuenta');
        if (!btnCuenta) return;
        btnCuenta.hidden = !state.puedeCuentas;
        btnCuenta.style.display = state.puedeCuentas ? '' : 'none';
    }

    function syncMontoApertura() {
        const sel = document.getElementById('caja-id-cuenta');
        const inp = document.getElementById('caja-monto-apertura');
        if (!sel || !inp || sesionParaCerrar()) return;
        const id = parseInt(sel.value, 10);
        const cuenta = state.cuentas.find(c => Number(c.id_cuenta) === id);
        if (cuenta) inp.value = String(Number(cuenta.saldo_actual || 0));
    }

    function bindEvents() {
        document.getElementById('btn-refresh-cont')?.addEventListener('click', async () => {
            await loadAll();
            renderAll();
            ModuleCore.toast('Contabilidad actualizada', 'success');
        });
        document.getElementById('filter-tipo-tx')?.addEventListener('change', e => {
            state.filtros.tipo = e.target.value;
            renderTransacciones();
        });
        document.getElementById('filter-cuenta-tx')?.addEventListener('change', e => {
            state.filtros.cuenta = e.target.value;
            renderTransacciones();
        });
        document.getElementById('filter-ambito-tx')?.addEventListener('change', e => {
            state.filtros.ambito = e.target.value || 'turno';
            renderTransacciones();
        });
        document.getElementById('caja-id-cuenta')?.addEventListener('change', syncMontoApertura);
        document.getElementById('btn-nueva-transaccion')?.addEventListener('click', () => openTransaccionModal());
        document.getElementById('btn-nueva-cuenta')?.addEventListener('click', () => openCuentaModal());
        document.getElementById('btn-abrir-caja')?.addEventListener('click', abrirCaja);
        document.getElementById('btn-cerrar-caja')?.addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            abrirCierreCaja(sesionParaCerrar());
        });
        document.getElementById('tabla-sesiones-caja')?.addEventListener('click', e => {
            const btn = e.target.closest('.btn-cerrar-sesion');
            if (!btn) return;
            e.preventDefault();
            e.stopPropagation();
            const id = parseInt(btn.dataset.id, 10);
            const sesion = state.sesiones.find(s => Number(s.id_caja) === id) || sesionParaCerrar();
            abrirCierreCaja(sesion);
        });
        document.getElementById('btn-confirmar-cierre')?.addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            const f = document.getElementById('form-cerrar-caja');
            ejecutarCierre(f?.monto_real?.value);
        });
        document.getElementById('btn-guardar-transaccion')?.addEventListener('click', saveTransaccion);
        document.getElementById('btn-guardar-cuenta')?.addEventListener('click', saveCuenta);
        document.getElementById('tx-id-concepto')?.addEventListener('change', e => {
            const tipo = document.querySelector('#form-transaccion [name="tipo"]');
            const opt = e.target.selectedOptions[0];
            if (tipo && opt?.dataset.tipo) tipo.value = opt.dataset.tipo;
        });
        ModuleCore.bindModalClose('modal-transaccion', 'btn-cancelar-tx', 'btn-cerrar-tx');
        ModuleCore.bindModalClose('modal-cuenta', 'btn-cancelar-cuenta', 'btn-cerrar-cuenta');
        document.getElementById('btn-cancelar-cierre')?.addEventListener('click', () => ModuleCore.closeModal('modal-cerrar-caja'));
        document.getElementById('btn-cerrar-cierre')?.addEventListener('click', () => ModuleCore.closeModal('modal-cerrar-caja'));
        document.getElementById('tabla-transacciones')?.addEventListener('click', onTxClick);
        document.getElementById('tabla-cuentas')?.addEventListener('click', onCuentaClick);
    }

    function renderAll() {
        renderResumen();
        renderCuentas();
        renderTransacciones();
        renderCaja();
        populateSelects();
        pintarAvisoCaja();
    }

    function pintarAvisoCaja() {
        const el = document.getElementById('aviso-caja');
        if (!el) return;
        if (state.sesionActiva) {
            el.style.display = 'none';
            return;
        }
        el.style.display = 'block';
        el.textContent = state.puedeOperar
            ? 'No hay caja abierta. Nadie puede registrar cobros ni movimientos de dinero hasta abrir sesión.'
            : 'No hay caja abierta. Pida a recepción o administración que abra caja antes de cobrar.';
    }

    function populateSelects() {
        const selCuenta = document.getElementById('tx-id-cuenta');
        const selConcepto = document.getElementById('tx-id-concepto');
        const filterCuenta = document.getElementById('filter-cuenta-tx');
        const cajaCuenta = document.getElementById('caja-id-cuenta');

        const cuentaOpts = state.cuentas.map(c => `<option value="${c.id_cuenta}">${c.nombre}</option>`).join('');
        const efectivoOpts = state.cuentas.filter(c => String(c.tipo).toLowerCase() === 'efectivo' && String(c.estado).toLowerCase() === 'activa')
            .map(c => `<option value="${c.id_cuenta}">${c.nombre}</option>`).join('');
        if (selCuenta) {
            selCuenta.innerHTML = '<option value="">La cuenta de la caja abierta</option>' + cuentaOpts;
            selCuenta.disabled = true;
        }
        if (filterCuenta) filterCuenta.innerHTML = '<option value="todos">Todas las cuentas</option>' + cuentaOpts;
        if (cajaCuenta) {
            cajaCuenta.innerHTML = efectivoOpts || cuentaOpts;
            syncMontoApertura();
        }

        if (selConcepto) {
            selConcepto.innerHTML = '<option value="">Seleccione...</option>' +
                state.conceptos.map(c => `<option value="${c.id_concepto}" data-tipo="${c.tipo}">${c.nombre} (${c.tipo})</option>`).join('');
        }
    }

    function renderResumen() {
        const t = totales();
        document.getElementById('total-ingresos').textContent = ModuleCore.formatCurrency(t.ingresos);
        document.getElementById('total-egresos').textContent = ModuleCore.formatCurrency(t.egresos);
        document.getElementById('balance').textContent = ModuleCore.formatCurrency(t.balance);
        document.getElementById('saldo-cuentas').textContent = ModuleCore.formatCurrency(t.saldoCuentas);
        pintarAvisoCaja();
        pintarBannerTurno();

        const tbody = document.querySelector('#tabla-resumen-cuentas tbody');
        const sesion = sesionParaCerrar();
        if (tbody) {
            tbody.innerHTML = state.cuentas.map(c => {
                const cuentaActiva = String(c.estado || '').toLowerCase() === 'activa';
                const turnoAbierto = sesion && Number(sesion.id_cuenta) === Number(c.id_cuenta);
                return `<tr>
                    <td>${c.nombre}</td><td>${c.tipo}</td>
                    <td>${ModuleCore.formatCurrency(c.saldo_actual)}</td>
                    <td>${ModuleCore.badge(cuentaActiva ? 'Habilitada' : 'Inhabilitada', { Habilitada: 'bg-secondary', Inhabilitada: 'bg-secondary' })}</td>
                    <td>${turnoAbierto ? ModuleCore.badge('Turno abierto', { 'Turno abierto': 'bg-success' }) : '<span class="text-muted">Sin turno</span>'}</td>
                </tr>`;
            }).join('') || ModuleCore.emptyRow(5);
        }
    }

    function pintarBannerTurno() {
        const el = document.getElementById('banner-turno-caja');
        if (!el) return;
        const sesion = sesionParaCerrar();
        if (!sesion) {
            el.className = 'banner-turno cerrada';
            el.innerHTML = '<strong>Turno de caja cerrado.</strong> <span class="text-muted">Las cuentas pueden seguir habilitadas; eso no significa que haya caja abierta.</span>';
            return;
        }
        el.className = 'banner-turno abierta';
        el.innerHTML = `<strong>Turno de caja abierto</strong>
            <span class="text-muted">${sesion.usuario || 'Responsable'} · ${sesion.cuenta || 'Caja'} · Sistema ${ModuleCore.formatCurrency(sesion.monto_sistema ?? 0)}</span>
            <button type="button" class="btn btn-danger btn-sm" id="btn-cerrar-caja-resumen"><i class="fas fa-lock"></i> Cerrar caja</button>`;
        document.getElementById('btn-cerrar-caja-resumen')?.addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            abrirCierreCaja(sesion);
        });
    }

    function renderCuentas() {
        const tbody = document.querySelector('#tabla-cuentas tbody');
        if (!tbody) return;
        tbody.innerHTML = state.cuentas.map(c => `<tr>
            <td><strong>${c.nombre}</strong></td>
            <td>${c.tipo}</td>
            <td>${ModuleCore.formatCurrency(c.saldo_actual)}</td>
            <td>${ModuleCore.badge(c.estado)}</td>
            <td>${state.puedeCuentas ? ModuleCore.actionButtons(c.id_cuenta, { view: false, del: false }) : '—'}</td>
        </tr>`).join('') || ModuleCore.emptyRow(5);
    }

    function filteredTransacciones() {
        const sesion = sesionParaCerrar();
        const idTurno = sesion ? Number(sesion.id_caja) : null;
        return state.transacciones.filter(t => {
            if (state.filtros.tipo !== 'todos' && t.tipo !== state.filtros.tipo) return false;
            if (state.filtros.cuenta !== 'todos' && Number(t.id_cuenta) !== parseInt(state.filtros.cuenta, 10)) return false;
            if (state.filtros.ambito !== 'todos') {
                if (!idTurno || Number(t.id_caja) !== idTurno) return false;
            }
            return true;
        }).sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
    }

    function renderTransacciones() {
        populateSelects();
        const tbody = document.querySelector('#tabla-transacciones tbody');
        if (!tbody) return;
        const items = filteredTransacciones();
        tbody.innerHTML = items.map(t => {
            const concepto = t.concepto || state.conceptos.find(c => c.id_concepto === t.id_concepto)?.nombre;
            const cuenta = t.cuenta || state.cuentas.find(c => c.id_cuenta === t.id_cuenta)?.nombre;
            return `<tr>
                <td>${ModuleCore.formatDateTime(t.fecha)}</td>
                <td>${concepto || '—'}</td>
                <td>${ModuleCore.badge(t.tipo)}</td>
                <td>${cuenta || '—'}</td>
                <td class="${t.tipo === 'Ingreso' ? 'text-success' : 'text-danger'}">${ModuleCore.formatCurrency(t.monto)}</td>
                <td>${ModuleCore.actionButtons(t.id_transaccion, { edit: false, del: false })}</td>
            </tr>`;
        }).join('') || ModuleCore.emptyRow(6);
    }

    function renderCaja() {
        const sesion = sesionParaCerrar() || state.sesionActiva;
        const statusEl = document.getElementById('caja-status');
        const btnAbrir = document.getElementById('btn-abrir-caja');
        const btnCerrar = document.getElementById('btn-cerrar-caja');
        const formAbrir = document.getElementById('form-abrir-caja');
        populateSelects();

        const acciones = document.getElementById('caja-acciones-abierta');
        if (sesion) {
            statusEl.className = 'caja-status abierta';
            statusEl.innerHTML = `
                <div><strong><i class="fas fa-cash-register"></i> Caja abierta</strong>
                <p class="text-muted" style="margin:0.25rem 0 0">
                    ${sesion.usuario || 'Usted'} · ${sesion.cuenta || ''} · Desde ${ModuleCore.formatDateTime(sesion.fecha_apertura)} · Apertura: ${ModuleCore.formatCurrency(sesion.monto_apertura)}
                </p></div>
                <div><span class="kpi-value">${ModuleCore.formatCurrency(sesion.monto_sistema || 0)}</span><p class="kpi-label">Saldo en sistema</p></div>`;
            if (btnAbrir) btnAbrir.style.display = 'none';
            if (formAbrir) formAbrir.style.display = 'none';
            if (acciones) {
                acciones.hidden = false;
                acciones.style.display = 'flex';
            }
            if (btnCerrar) {
                btnCerrar.hidden = false;
                btnCerrar.style.display = 'inline-flex';
            }
        } else {
            statusEl.className = 'caja-status cerrada';
            statusEl.innerHTML = `<div><strong><i class="fas fa-lock"></i> Caja cerrada</strong>
                <p class="text-muted" style="margin:0.25rem 0 0">${state.puedeOperar ? 'Abra una sesión para registrar cobros' : 'Solo recepción o administración pueden abrir caja'}</p></div>`;
            if (btnAbrir) btnAbrir.style.display = state.puedeOperar ? 'inline-flex' : 'none';
            if (formAbrir) formAbrir.style.display = state.puedeOperar ? 'block' : 'none';
            if (acciones) {
                acciones.hidden = true;
                acciones.style.display = 'none';
            }
            if (btnCerrar) {
                btnCerrar.hidden = true;
                btnCerrar.style.display = 'none';
            }
        }

        const tbody = document.querySelector('#tabla-sesiones-caja tbody');
        if (tbody) {
            tbody.innerHTML = state.sesiones.map(s => {
                const cuenta = s.cuenta || state.cuentas.find(c => c.id_cuenta === s.id_cuenta)?.nombre;
                return `<tr>
                    <td>${ModuleCore.formatDateTime(s.fecha_apertura)}</td>
                    <td>${s.fecha_cierra ? ModuleCore.formatDateTime(s.fecha_cierra) : '—'}</td>
                    <td>${s.usuario || '—'}</td>
                    <td>${cuenta || '—'}</td>
                    <td>${ModuleCore.formatCurrency(s.monto_apertura)}</td>
                    <td>${s.monto_real != null ? ModuleCore.formatCurrency(s.monto_real) : '—'}</td>
                    <td>${s.diferencia != null ? ModuleCore.formatCurrency(s.diferencia) : '—'}</td>
                    <td>${ModuleCore.badge(s.estado_sesion)}${
                        String(s.estado_sesion) === 'Activa'
                            ? ` <button type="button" class="btn btn-danger btn-sm btn-cerrar-sesion" data-id="${s.id_caja}">Cerrar</button>`
                            : ''
                    }</td>
                </tr>`;
            }).join('') || ModuleCore.emptyRow(8);
        }
    }

    function openTransaccionModal() {
        if (!state.sesionActiva) {
            ModuleCore.toast('Abra caja para registrar un movimiento de dinero', 'warning');
            return;
        }
        populateSelects();
        document.getElementById('modal-transaccion-title').textContent = 'Nueva transacción';
        const f = document.getElementById('form-transaccion');
        f.reset();
        if (f.fecha) f.fecha.value = new Date().toISOString().slice(0, 16);
        ModuleCore.openModal('modal-transaccion');
    }

    function openCuentaModal(cuenta = null) {
        if (!state.puedeCuentas) {
            ModuleCore.toast('No tiene permiso para gestionar cuentas', 'warning');
            return;
        }
        state.editCuenta = cuenta;
        document.getElementById('modal-cuenta-title').textContent = cuenta ? 'Editar cuenta' : 'Nueva cuenta';
        const f = document.getElementById('form-cuenta');
        f.reset();
        const saldo = f.saldo_actual;
        if (saldo) saldo.disabled = !!cuenta;
        if (cuenta) {
            f.nombre.value = cuenta.nombre;
            f.tipo.value = cuenta.tipo;
            if (saldo) saldo.value = cuenta.saldo_actual;
            f.estado.value = cuenta.estado;
        }
        ModuleCore.openModal('modal-cuenta');
    }

    async function saveTransaccion() {
        const f = document.getElementById('form-transaccion');
        if (!f.checkValidity()) { f.reportValidity(); return; }
        try {
            await window.apiCajaTransaccion({
                id_concepto: parseInt(f.id_concepto.value, 10),
                monto: parseFloat(f.monto.value),
                tipo: f.tipo.value
            });
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-transaccion');
            ModuleCore.toast('Movimiento registrado en la caja abierta', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo registrar el movimiento', 'error');
        }
    }

    async function saveCuenta() {
        const f = document.getElementById('form-cuenta');
        if (!f.checkValidity()) { f.reportValidity(); return; }
        try {
            await window.apiCuentasCrear({
                id_cuenta: state.editCuenta?.id_cuenta,
                nombre: f.nombre.value.trim(),
                tipo: f.tipo.value,
                saldo_actual: parseFloat(f.saldo_actual.value) || 0,
                estado: f.estado.value
            });
            await loadAll();
            renderAll();
            ModuleCore.closeModal('modal-cuenta');
            ModuleCore.toast('Cuenta guardada', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo guardar la cuenta', 'error');
        }
    }

    async function abrirCaja() {
        if (state.sesionActiva) {
            ModuleCore.toast('Ya tiene una caja abierta', 'warning');
            return;
        }
        try {
            await window.apiCajaAbrir({
                id_cuenta: parseInt(document.getElementById('caja-id-cuenta').value, 10),
                monto_apertura: parseFloat(document.getElementById('caja-monto-apertura').value) || 0
            });
            await loadAll();
            renderAll();
            ModuleCore.toast('Caja abierta. Ya puede registrar cobros', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo abrir caja', 'error');
        }
    }

    function sesionEstaAbierta(sesion) {
        if (!sesion) return false;
        const estado = String(sesion.estado_sesion || 'Activa');
        return estado === 'Activa' && !sesion.fecha_cierra;
    }

    function sesionParaCerrar() {
        if (sesionEstaAbierta(state.sesionActiva)) return state.sesionActiva;
        return state.sesiones.find(sesionEstaAbierta) || null;
    }

    function efectivoSugerido(sesion) {
        const sistema = Number(sesion?.monto_sistema ?? sesion?.monto_apertura ?? 0);
        return sistema > 0 ? sistema : 0;
    }

    function avisar(msg, type = 'info') {
        ModuleCore.toast(msg, type);
        if (typeof window.showToast !== 'function') {
            window.alert(msg);
        }
    }

    function abrirCierreCaja(sesion) {
        const actual = sesionEstaAbierta(sesion) ? sesion : sesionParaCerrar();
        if (!actual) {
            avisar('No hay un turno de caja abierto para cerrar', 'warning');
            return;
        }
        state.sesionActiva = actual;
        const f = document.getElementById('form-cerrar-caja');
        const resumen = document.getElementById('resumen-cierre-caja');
        const sistema = Number(actual.monto_sistema ?? actual.monto_apertura ?? 0);
        if (f) f.monto_real.value = String(efectivoSugerido(actual));
        if (resumen) {
            resumen.textContent = `${actual.usuario || 'Responsable'} · ${actual.cuenta || 'Caja'} · Sistema ${ModuleCore.formatCurrency(sistema)}`;
        }
        window.setTimeout(() => ModuleCore.openModal('modal-cerrar-caja'), 0);
    }

    async function ejecutarCierre(montoCrudo) {
        const sesion = sesionParaCerrar();
        if (!sesion) {
            avisar('No hay un turno de caja abierto para cerrar', 'warning');
            return;
        }
        const crudo = parseFloat(montoCrudo);
        if (!Number.isFinite(crudo) || crudo < 0) {
            avisar('Indique el efectivo físico al cerrar', 'warning');
            abrirCierreCaja(sesion);
            return;
        }
        const montoReal = Math.round(crudo * 100) / 100;
        try {
            await window.apiCajaCerrar({
                id_caja: sesion.id_caja,
                monto_real: montoReal
            });
            ModuleCore.closeModal('modal-cerrar-caja');
            state.sesionActiva = null;
            state.sesiones = (state.sesiones || []).map(s => (
                Number(s.id_caja) === Number(sesion.id_caja)
                    ? { ...s, estado_sesion: 'Cerrada', fecha_cierra: new Date().toISOString(), monto_real: montoReal }
                    : s
            ));
            renderAll();
            await loadAll();
            renderAll();
            avisar('Caja cerrada', 'success');
        } catch (e) {
            avisar(e.message || 'No se pudo cerrar caja', 'error');
        }
    }

    function onTxClick(e) {
        const btn = e.target.closest('.btn-view');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const tx = state.transacciones.find(t => t.id_transaccion === id);
        if (!tx) return;
        window.createModal?.('modal-det', 'Movimiento de caja', `
            <div class="detail-grid">
                <div class="detail-item"><label>Concepto</label><p>${tx.concepto || '—'}</p></div>
                <div class="detail-item"><label>Tipo</label><p>${tx.tipo}</p></div>
                <div class="detail-item"><label>Cuenta</label><p>${tx.cuenta || '—'}</p></div>
                <div class="detail-item"><label>Monto</label><p>${ModuleCore.formatCurrency(tx.monto)}</p></div>
                <div class="detail-item"><label>Factura</label><p>${tx.id_factura || '—'}</p></div>
                <div class="detail-item"><label>Sesión</label><p>${tx.id_caja || '—'}</p></div>
            </div>`);
    }

    function onCuentaClick(e) {
        const btn = e.target.closest('.btn-edit');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const cuenta = state.cuentas.find(c => c.id_cuenta === id);
        if (cuenta) openCuentaModal(cuenta);
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => ContabilidadModule.init());
