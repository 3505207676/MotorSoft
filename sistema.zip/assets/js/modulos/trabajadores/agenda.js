/**
 * Módulo Agenda y Citas — oficina, recepción y gerencia.
 */
const AgendaModule = (() => {
    const state = {
        citas: [],
        agenda: [],
        clientes: [],
        vehiculos: [],
        servicios: [],
        mecanicos: [],
        editCita: null,
        filtros: { fecha: hoyISO(), estado: 'todos' }
    };

    function hoyISO() {
        const d = new Date();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${d.getFullYear()}-${m}-${day}`;
    }

    function unwrap(res) {
        return Array.isArray(res?.data) ? res.data : (res?.data || []);
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function estadoDe(c) {
        return String(c.estado_cita || '').toLowerCase();
    }

    function esCancelada(c) { return estadoDe(c) === 'cancelada'; }
    function esConvertida(c) { return Number(c.id_orden) > 0; }
    function esPendiente(c) {
        const e = estadoDe(c);
        return !esConvertida(c) && (e === 'programada' || e === 'confirmada');
    }

    function nombreMecanico(u) {
        return (u && (u.nombre || '').trim()) || 'Mecánico';
    }

    function esMecanico(u) {
        const rol = (u?.rol && typeof u.rol === 'object') ? (u.rol.nombre || '') : (u?.rol || '');
        return String(rol).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').includes('mecanic');
    }

    function marcarCampo(input, invalido) {
        if (!input) return;
        input.classList.toggle('campo-invalido', !!invalido);
    }

    function mostrarErrores(id, lista) {
        const box = document.getElementById(id);
        if (!box) return;
        if (!lista.length) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }
        box.style.display = 'block';
        box.innerHTML = '<strong>Revise el formulario:</strong><ul style="margin:0.4rem 0 0;padding-left:1.2rem">' +
            lista.map(e => `<li>${esc(e)}</li>`).join('') + '</ul>';
    }

    function puede(slug) {
        return !!(window.MotorSoftGuard && window.MotorSoftGuard.puede(slug));
    }

    async function init() {
        const fechaFilter = document.getElementById('filter-fecha-agenda');
        if (fechaFilter && !fechaFilter.value) fechaFilter.value = state.filtros.fecha;
        const estadoFilter = document.getElementById('filter-estado-citas');
        if (estadoFilter) estadoFilter.value = state.filtros.estado;
        aplicarPermisosUi();
        try {
            await loadAll();
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo cargar la agenda', 'error');
        }
        ModuleCore.initTabs('#modulo-agenda');
        bindEvents();
        if ((location.hash || '').replace('#', '') === 'citas') {
            document.querySelector('#modulo-agenda [data-tab="citas"]')?.click();
        }
        renderAgenda();
        renderCitas();
        populateSelects();
    }

    function aplicarPermisosUi() {
        const btnHorario = document.getElementById('btn-nuevo-horario');
        if (btnHorario) btnHorario.style.display = puede('agenda.horarios') ? '' : 'none';
        const btnCita = document.getElementById('btn-nueva-cita');
        if (btnCita) btnCita.style.display = puede('citas.crear') ? '' : 'none';
    }

    async function loadAll() {
        const fecha = state.filtros.fecha;
        const [citasRes, agendaRes, clientesRes, vehRes, servRes, mecRes] = await Promise.all([
            window.apiCitas({ fecha }).catch(() => ({ data: [] })),
            window.apiAgenda({ fecha }).catch(() => ({ data: [] })),
            window.apiClientes(true).catch(() => ({ data: [] })),
            window.apiVehiculos(true).catch(() => ({ data: [] })),
            window.apiServicios({ estado: 'Activo' }).catch(() => ({ data: [] })),
            window.apiAgendaMecanicos ? window.apiAgendaMecanicos().catch(() => ({ data: [] })) : Promise.resolve({ data: [] }),
        ]);
        state.citas = unwrap(citasRes);
        state.agenda = unwrap(agendaRes);
        state.clientes = unwrap(clientesRes);
        state.vehiculos = unwrap(vehRes);
        state.servicios = unwrap(servRes).filter(s => String(s.estado || 'Activo').toLowerCase() === 'activo');
        let mecanicos = unwrap(mecRes);
        if (!mecanicos.length) {
            const usr = await window.apiUsuarios(true).catch(() => ({ data: [] }));
            mecanicos = unwrap(usr).filter(esMecanico);
        }
        state.mecanicos = mecanicos;
    }

    function bindEvents() {
        document.getElementById('btn-nueva-cita')?.addEventListener('click', () => openCitaModal());
        document.getElementById('btn-nuevo-horario')?.addEventListener('click', () => openHorarioModal());
        document.getElementById('btn-refresh-agenda')?.addEventListener('click', recargar);
        document.getElementById('filter-fecha-agenda')?.addEventListener('change', async (e) => {
            state.filtros.fecha = e.target.value || hoyISO();
            await recargar();
        });
        document.getElementById('filter-estado-citas')?.addEventListener('change', (e) => {
            state.filtros.estado = e.target.value || 'todos';
            renderCitas();
        });
        document.getElementById('btn-guardar-cita')?.addEventListener('click', saveCita);
        document.getElementById('btn-guardar-horario')?.addEventListener('click', saveHorario);
        document.getElementById('cita-id-cliente')?.addEventListener('change', updateVehiculosSelect);
        document.getElementById('cita-fecha')?.addEventListener('change', llenarHorariosCita);
        ModuleCore.bindModalClose('modal-cita', 'btn-cancelar-cita', 'btn-cerrar-cita');
        ModuleCore.bindModalClose('modal-horario', 'btn-cancelar-horario', 'btn-cerrar-horario');
        document.getElementById('tabla-citas')?.addEventListener('click', onCitaClick);
        document.getElementById('agenda-grid')?.addEventListener('click', onSlotClick);
    }

    async function recargar() {
        try {
            await loadAll();
            renderAgenda();
            renderCitas();
            populateSelects();
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo actualizar', 'error');
        }
    }

    function populateSelects() {
        const selCliente = document.getElementById('cita-id-cliente');
        const selServicio = document.getElementById('cita-id-servicio');
        const selMecanico = document.getElementById('horario-id-usuario');
        if (selCliente) {
            selCliente.innerHTML = '<option value="">Seleccione...</option>' +
                state.clientes.map(c => `<option value="${c.id_cliente}">${esc(c.nombre)}</option>`).join('');
        }
        if (selServicio) {
            selServicio.innerHTML = '<option value="">Seleccione...</option>' +
                state.servicios.map(s => `<option value="${s.id_servicio}">${esc(s.nombre)} — ${ModuleCore.formatCurrency(s.precio)}</option>`).join('');
        }
        if (selMecanico) {
            selMecanico.innerHTML = '<option value="">Seleccione...</option>' +
                state.mecanicos.map(u => `<option value="${u.id_usuario}">${esc(nombreMecanico(u))}</option>`).join('');
        }
        const fechaFilter = document.getElementById('filter-fecha-agenda');
        if (fechaFilter && !fechaFilter.value) fechaFilter.value = state.filtros.fecha;
    }

    function updateVehiculosSelect() {
        const idCliente = parseInt(document.getElementById('cita-id-cliente')?.value, 10) || 0;
        const sel = document.getElementById('cita-id-vehiculo');
        if (!sel) return;
        const vehs = state.vehiculos.filter(v => Number(v.id_cliente) === idCliente);
        sel.innerHTML = '<option value="">Seleccione...</option>' + vehs.map(v =>
            `<option value="${v.id_vehiculo}">${esc(v.placa)}${v.tipo ? ' · ' + esc(v.tipo) : ''} — ${esc(v.marca || '')} ${esc(v.modelo || '')}</option>`
        ).join('');
    }

    async function llenarHorariosCita(preselectId) {
        const fecha = document.getElementById('cita-fecha')?.value;
        const sel = document.getElementById('cita-id-horario');
        if (!sel) return;
        if (!fecha) {
            sel.innerHTML = '<option value="">Elija una fecha</option>';
            return;
        }
        try {
            const res = await window.apiAgenda({ fecha });
            const slots = unwrap(res).filter(h =>
                (h.estado === 'Disponible' && (h.cupos_libres ?? 1) > 0) ||
                Number(h.id_horario) === Number(preselectId)
            );
            sel.innerHTML = '<option value="">Seleccione horario...</option>' + slots.map(h =>
                `<option value="${h.id_horario}">${esc(h.hora_inicio)} — ${esc(h.mecanico_nombre || 'Mecánico')} (${h.cupos_libres ?? 0} cupos)</option>`
            ).join('');
            if (preselectId) sel.value = String(preselectId);
        } catch (e) {
            sel.innerHTML = '<option value="">No hay horarios</option>';
        }
    }

    function slotsDelDia() {
        return state.agenda.filter(h => (h.fecha || '').slice(0, 10) === state.filtros.fecha);
    }

    function citasDelSlot(idHorario) {
        return state.citas.filter(c => Number(c.id_horario) === Number(idHorario) && esPendiente(c));
    }

    function pintarKpis() {
        const delDia = state.citas.filter(c => (c.fecha || '').slice(0, 10) === state.filtros.fecha);
        const set = (id, n) => {
            const el = document.getElementById(id);
            if (el) el.textContent = String(n);
        };
        set('kpi-citas-hoy', delDia.filter(c => estadoDe(c) === 'programada').length);
        set('kpi-citas-confirmadas', delDia.filter(c => estadoDe(c) === 'confirmada' && !esConvertida(c)).length);
        set('kpi-citas-ot', delDia.filter(esConvertida).length);
    }

    function renderAgenda() {
        pintarKpis();
        const grid = document.getElementById('agenda-grid');
        if (!grid) return;
        const slots = slotsDelDia();
        if (!slots.length) {
            grid.innerHTML = '<p class="text-muted text-center" style="grid-column:1/-1">No hay horarios para esta fecha. Cree disponibilidad.</p>';
            return;
        }

        grid.innerHTML = slots.map(s => {
            const citas = citasDelSlot(s.id_horario);
            const libre = (s.cupos_libres ?? 0) > 0 && s.estado === 'Disponible';
            const cls = s.estado === 'Cancelado' ? 'cancelado' : (libre ? 'disponible' : 'ocupado');
            const puedeAgendar = libre && puede('citas.crear');
            const puedeCancelarSlot = puede('agenda.horarios') && citas.length < 1 && !(s.ocupacion > 0);
            const resumen = citas.length
                ? citas.map(c => `<span class="slot-cita">${esc(c.cliente_nombre || 'Cliente')}</span>`).join('')
                : (libre ? '<span class="slot-libre">Cupo libre</span>' : '');
            return `<div class="agenda-slot ${cls}" data-id="${s.id_horario}" data-estado="${esc(s.estado)}">
                <strong>${esc(s.hora_inicio)}</strong><br>
                <small>${esc(s.mecanico_nombre || 'Mecánico')}</small><br>
                <span class="badge ${libre ? 'bg-success' : 'bg-warning'}">${esc(s.estado)}</span>
                <div class="slot-citas">${resumen}</div>
                <div class="slot-actions">
                    ${puedeAgendar ? '<button type="button" class="btn-slot-agendar btn btn-outline btn-sm">Agendar</button>' : ''}
                    ${citas.length ? '<button type="button" class="btn-slot-ver btn btn-outline btn-sm">Ver cita</button>' : ''}
                    ${puedeCancelarSlot ? '<button type="button" class="btn-slot-cancel" title="Cancelar horario"><i class="fas fa-times"></i></button>' : ''}
                </div>
            </div>`;
        }).join('');
    }

    function citasFiltradas() {
        const est = state.filtros.estado;
        if (!est || est === 'todos') return state.citas;
        return state.citas.filter(c => c.estado_cita === est);
    }

    function renderCitas() {
        pintarKpis();
        const tbody = document.querySelector('#tabla-citas tbody');
        if (!tbody) return;
        const lista = citasFiltradas();
        if (!lista.length) {
            tbody.innerHTML = ModuleCore.emptyRow(7, 'No hay citas en esta fecha');
            return;
        }
        tbody.innerHTML = lista.map(c => {
            const cuando = [c.fecha, c.hora_inicio].filter(Boolean).join(' ');
            const abierta = esPendiente(c);
            const puedeEditar = abierta && (puede('citas.crear') || puede('citas.confirmar'));
            const puedeCancelar = abierta && puede('citas.cancelar');
            const puedeConvertir = abierta && puede('citas.convertir_orden');
            const puedeConfirmar = abierta && estadoDe(c) === 'programada' && puede('citas.confirmar');
            let acciones = '<div class="table-actions">';
            if (puedeEditar) {
                acciones += `<button class="btn-icon btn-sm btn-edit" data-id="${c.id_cita}" title="Editar"><i class="fas fa-edit"></i></button>`;
            }
            if (puedeConfirmar) {
                acciones += `<button class="btn-icon btn-sm btn-confirmar-cita" data-id="${c.id_cita}" title="Confirmar llegada"><i class="fas fa-check"></i></button>`;
            }
            if (puedeConvertir) {
                acciones += `<button class="btn-icon btn-sm btn-convertir-ot" data-id="${c.id_cita}" title="Convertir en orden de trabajo"><i class="fas fa-file-signature"></i></button>`;
            }
            if (esConvertida(c)) {
                acciones += `<a class="btn-icon btn-sm" href="../ordenes/index-trabajadores.php?orden=${encodeURIComponent(c.id_orden)}" title="OT #${c.id_orden}"><i class="fas fa-clipboard-list"></i></a>`;
                acciones += `<span class="text-muted" style="font-size:0.8rem">OT #${esc(c.id_orden)}</span>`;
            }
            if (puedeCancelar) {
                acciones += `<button class="btn-icon btn-sm btn-delete" data-id="${c.id_cita}" title="Cancelar"><i class="fas fa-times"></i></button>`;
            }
            acciones += '</div>';
            const badgeEstado = esConvertida(c) && estadoDe(c) === 'completada'
                ? ModuleCore.badge('En OT')
                : ModuleCore.badge(c.estado_cita);
            return `<tr>
                <td>${c.id_cliente ? `<a href="../clientes/index.php?cliente=${encodeURIComponent(c.id_cliente)}">${esc(c.cliente_nombre || '—')}</a>` : esc(c.cliente_nombre || '—')}</td>
                <td>${c.id_vehiculo ? `<a href="../clientes/index.php?vehiculo=${encodeURIComponent(c.id_vehiculo)}">${esc(c.vehiculo_placa || c.vehiculo_label || '—')}</a>` : esc(c.vehiculo_placa || c.vehiculo_label || '—')}</td>
                <td>${esc(c.servicio_nombre || '—')}</td>
                <td>${esc(c.mecanico_nombre || '—')}</td>
                <td>${esc(cuando || '—')}</td>
                <td>${badgeEstado}</td>
                <td>${acciones}</td>
            </tr>`;
        }).join('');
    }

    function openCitaModal(cita = null, horarioId = null) {
        state.editCita = cita;
        populateSelects();
        mostrarErrores('cita-form-errores', []);
        document.getElementById('modal-cita-title').textContent = cita ? 'Editar Cita' : 'Nueva Cita';
        const f = document.getElementById('form-cita');
        f.reset();
        Array.from(f.querySelectorAll('.campo-invalido')).forEach(el => el.classList.remove('campo-invalido'));
        const fechaInput = document.getElementById('cita-fecha');
        if (fechaInput) {
            fechaInput.value = cita?.fecha || state.filtros.fecha;
            fechaInput.min = hoyISO();
        }
        const grupoEstado = document.getElementById('grupo-estado-cita');
        if (grupoEstado) grupoEstado.style.display = cita ? '' : 'none';
        if (cita) {
            f.id_cliente.value = cita.id_cliente;
            updateVehiculosSelect();
            f.id_vehiculo.value = cita.id_vehiculo;
            f.id_servicio.value = cita.id_servicio;
            f.motivo.value = cita.motivo || '';
            if (f.estado_cita) {
                const val = cita.estado_cita === 'Confirmada' ? 'Confirmada' : 'Programada';
                f.estado_cita.value = val;
            }
            llenarHorariosCita(cita.id_horario);
        } else {
            updateVehiculosSelect();
            if (f.estado_cita) f.estado_cita.value = 'Programada';
            llenarHorariosCita(horarioId);
        }
        ModuleCore.openModal('modal-cita');
    }

    function openHorarioModal() {
        mostrarErrores('horario-form-errores', []);
        const f = document.getElementById('form-horario');
        f.reset();
        Array.from(f.querySelectorAll('.campo-invalido')).forEach(el => el.classList.remove('campo-invalido'));
        populateSelects();
        document.getElementById('horario-fecha').value = state.filtros.fecha;
        document.getElementById('horario-fecha').min = hoyISO();
        ModuleCore.openModal('modal-horario');
    }

    function validarCita(f) {
        const errores = [];
        const idCliente = parseInt(f.id_cliente.value, 10) || 0;
        const idVehiculo = parseInt(f.id_vehiculo.value, 10) || 0;
        const idServicio = parseInt(f.id_servicio.value, 10) || 0;
        const idHorario = parseInt(f.id_horario.value, 10) || 0;
        const fecha = document.getElementById('cita-fecha')?.value || '';
        if (!idCliente) errores.push('Seleccione un cliente.');
        if (!idVehiculo) errores.push('Seleccione un vehículo.');
        if (!idServicio) errores.push('Seleccione un servicio.');
        if (!fecha) errores.push('Seleccione la fecha.');
        if (!idHorario) errores.push('Seleccione un horario disponible.');
        marcarCampo(f.id_cliente, !idCliente);
        marcarCampo(f.id_vehiculo, !idVehiculo);
        marcarCampo(f.id_servicio, !idServicio);
        marcarCampo(document.getElementById('cita-fecha'), !fecha);
        marcarCampo(f.id_horario, !idHorario);
        mostrarErrores('cita-form-errores', errores);
        return errores;
    }

    function validarHorario(f) {
        const errores = [];
        const idUsuario = parseInt(f.id_usuario.value, 10) || 0;
        const fecha = (f.fecha.value || '').trim();
        const hora = (f.hora_inicio.value || '').trim();
        const capacidad = parseInt(f.capacidad.value, 10) || 0;
        if (!idUsuario) errores.push('Seleccione un mecánico.');
        if (!fecha) errores.push('La fecha es obligatoria.');
        else if (fecha < hoyISO()) errores.push('No se pueden crear horarios en fechas pasadas.');
        if (!hora) errores.push('La hora de inicio es obligatoria.');
        if (capacidad < 1) errores.push('La capacidad debe ser al menos 1.');
        marcarCampo(f.id_usuario, !idUsuario);
        marcarCampo(f.fecha, !fecha || fecha < hoyISO());
        marcarCampo(f.hora_inicio, !hora);
        marcarCampo(f.capacidad, capacidad < 1);
        mostrarErrores('horario-form-errores', errores);
        return errores;
    }

    async function saveCita() {
        const f = document.getElementById('form-cita');
        const errores = validarCita(f);
        if (errores.length) return;
        const payload = {
            id_cliente: parseInt(f.id_cliente.value, 10),
            id_vehiculo: parseInt(f.id_vehiculo.value, 10),
            id_servicio: parseInt(f.id_servicio.value, 10),
            id_horario: parseInt(f.id_horario.value, 10),
            motivo: (f.motivo.value || '').trim(),
            estado_cita: f.estado_cita?.value || 'Programada'
        };
        try {
            if (state.editCita?.id_cita) {
                await window.apiCitasActualizar(state.editCita.id_cita, payload);
            } else {
                const creada = await window.apiCitasCrear(payload);
                const id = creada?.data?.id_cita;
                if (id && payload.estado_cita && payload.estado_cita !== 'Programada') {
                    await window.apiCitasActualizar(id, { estado_cita: payload.estado_cita });
                }
            }
            ModuleCore.closeModal('modal-cita');
            ModuleCore.toast(state.editCita ? 'Cita actualizada' : 'Cita agendada', 'success');
            await recargar();
        } catch (e) {
            mostrarErrores('cita-form-errores', [e.message || 'No se pudo guardar la cita']);
            ModuleCore.toast(e.message || 'No se pudo guardar la cita', 'error');
        }
    }

    async function saveHorario() {
        const f = document.getElementById('form-horario');
        const errores = validarHorario(f);
        if (errores.length) return;
        try {
            await window.apiAgendaCrear({
                id_usuario: parseInt(f.id_usuario.value, 10),
                fecha: f.fecha.value,
                hora_inicio: f.hora_inicio.value,
                capacidad: parseInt(f.capacidad.value, 10) || 1
            });
            state.filtros.fecha = f.fecha.value;
            const filtro = document.getElementById('filter-fecha-agenda');
            if (filtro) filtro.value = f.fecha.value;
            ModuleCore.closeModal('modal-horario');
            ModuleCore.toast('Horario creado', 'success');
            await recargar();
        } catch (e) {
            mostrarErrores('horario-form-errores', [e.message || 'No se pudo crear el horario']);
            ModuleCore.toast(e.message || 'No se pudo crear el horario', 'error');
        }
    }

    function irACitas() {
        document.querySelector('#modulo-agenda [data-tab="citas"]')?.click();
    }

    function onSlotClick(e) {
        const cancelBtn = e.target.closest('.btn-slot-cancel');
        if (cancelBtn) {
            const slot = cancelBtn.closest('.agenda-slot');
            const id = parseInt(slot?.dataset.id, 10);
            if (!id) return;
            ModuleCore.confirm('Cancelar horario', '¿Cancelar este horario? Solo si no tiene citas pendientes.', async () => {
                try {
                    await window.apiAgendaCancelar(id);
                    ModuleCore.toast('Horario cancelado', 'success');
                    await recargar();
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo cancelar', 'error');
                }
            });
            return;
        }
        const verBtn = e.target.closest('.btn-slot-ver');
        if (verBtn) {
            irACitas();
            return;
        }
        const slot = e.target.closest('.agenda-slot.disponible');
        if (!slot) return;
        if (!puede('citas.crear')) return;
        if (e.target.closest('.btn-slot-agendar') || e.target === slot || e.target.closest('strong, small')) {
            openCitaModal(null, parseInt(slot.dataset.id, 10));
        }
    }

    function onCitaClick(e) {
        const convertirBtn = e.target.closest('.btn-convertir-ot');
        if (convertirBtn) {
            const id = parseInt(convertirBtn.dataset.id, 10);
            const cita = state.citas.find(x => Number(x.id_cita) === id);
            if (!cita || !window.apiCitasConvertir) return;
            const quien = cita.mecanico_nombre || 'el mecánico del horario';
            ModuleCore.confirm(
                'Convertir en orden',
                `Se abrirá una OT para ${cita.cliente_nombre || 'el cliente'} con ${quien}. El servicio de la cita queda como primera línea.`,
                async () => {
                    try {
                        const res = await window.apiCitasConvertir(id);
                        const ot = res?.data?.orden?.id_orden || res?.data?.cita?.id_orden;
                        ModuleCore.toast(ot ? `Cita convertida en OT #${ot}` : 'Cita convertida en orden', 'success');
                        await recargar();
                    } catch (err) {
                        ModuleCore.toast(err.message || 'No se pudo convertir la cita', 'error');
                    }
                }
            );
            return;
        }
        const confBtn = e.target.closest('.btn-confirmar-cita');
        if (confBtn) {
            const id = parseInt(confBtn.dataset.id, 10);
            if (!id) return;
            ModuleCore.confirm('Confirmar cita', '¿El cliente ya está en el taller?', async () => {
                try {
                    await window.apiCitasActualizar(id, { estado_cita: 'Confirmada' });
                    ModuleCore.toast('Cita confirmada', 'success');
                    await recargar();
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo confirmar', 'error');
                }
            });
            return;
        }
        const btn = e.target.closest('.btn-edit, .btn-delete');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const cita = state.citas.find(x => Number(x.id_cita) === id);
        if (!cita) return;
        if (btn.classList.contains('btn-edit')) {
            openCitaModal(cita);
            return;
        }
        ModuleCore.confirm('Cancelar cita', '¿Confirmar cancelación de esta cita?', async () => {
            try {
                await window.apiCitasActualizar(id, { estado_cita: 'Cancelada' });
                ModuleCore.toast('Cita cancelada', 'success');
                await recargar();
            } catch (err) {
                ModuleCore.toast(err.message || 'No se pudo cancelar', 'error');
            }
        });
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => AgendaModule.init());
