/**
 * Chat del taller: hilos por tipo de contacto y canal (interno / WhatsApp).
 */
window.MotorSoftChatTrabajadoresScriptCargado = true;

const ChatModule = (() => {
    const state = {
        conversaciones: [],
        canales: [],
        mensajes: [],
        actual: null,
        noLeidos: 0,
        filtro: '',
        tipo: '',
        canal: '',
        poll: null,
        abriendo: false,
        recien: new Set(),
        idsMensajes: new Set(),
        flashIds: new Set(),
        enviando: false,
        cargando: false,
        pollVersion: 0
    };

    function toast(msg, tipo) {
        if (typeof window.showToast === 'function') window.showToast(msg, tipo);
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function hora(fecha) {
        if (!fecha) return '';
        const d = new Date(String(fecha).replace(' ', 'T'));
        if (Number.isNaN(d.getTime())) return fecha;
        return d.toLocaleString('es-CO', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    }

    function horaLista(fecha) {
        if (!fecha) return '';
        const d = new Date(String(fecha).replace(' ', 'T'));
        if (Number.isNaN(d.getTime())) return '';
        const now = new Date();
        const diff = (now.getTime() - d.getTime()) / 1000;
        if (diff < 45) return 'ahora';
        if (diff < 3600) return `hace ${Math.max(1, Math.floor(diff / 60))} min`;
        if (d.toDateString() === now.toDateString()) {
            return d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
        }
        const ayer = new Date(now);
        ayer.setDate(now.getDate() - 1);
        if (d.toDateString() === ayer.toDateString()) return 'ayer';
        return d.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit' });
    }

    function actividadDe(c) {
        return c?.actividad_at || c?.ultimo?.fecha_hora || '';
    }

    function ordenarConversaciones(items) {
        return [...items].sort((a, b) => {
            const ua = Number(a.no_leidos) > 0 ? 1 : 0;
            const ub = Number(b.no_leidos) > 0 ? 1 : 0;
            if (ub !== ua) return ub - ua;
            const cmp = actividadDe(b).localeCompare(actividadDe(a));
            if (cmp) return cmp;
            return (Number(b.total_mensajes) || 0) - (Number(a.total_mensajes) || 0);
        });
    }

    function detectarRecien(anteriores, actuales) {
        const recien = new Set();
        if (!anteriores.length) return recien;
        const prev = new Map(anteriores.map(c => [clave(c), Number(c.no_leidos) || 0]));
        actuales.forEach(c => {
            const n = Number(c.no_leidos) || 0;
            if (n > 0 && n > (prev.get(clave(c)) || 0)) recien.add(clave(c));
        });
        return recien;
    }

    function preview(texto) {
        const t = String(texto || '').trim();
        return t.length > 48 ? t.slice(0, 48) + '…' : (t || 'Sin mensajes');
    }

    function previewLinea(c) {
        if (!c?.ultimo?.contenido) return 'Sin mensajes';
        const texto = preview(c.ultimo.contenido);
        return esMio(c.ultimo) ? `Tú: ${texto}` : texto;
    }

    function esMio(m) {
        return typeof window.chatMensajeEsMio === 'function' ? window.chatMensajeEsMio(m) : !!m.mio;
    }

    function idMensaje(m) {
        return Number(m && m.id_mensaje) || 0;
    }

    function clave(c) {
        if (!c) return '';
        const tipo = c.tipo_contacto || 'Cliente';
        const id = c.id_contacto || c.id_cliente || 0;
        const canal = c.canal || 'Interno';
        return `${tipo}:${id}:${canal}`;
    }

    function payloadActual() {
        const c = state.actual;
        if (!c) return null;
        const body = {
            tipo_contacto: c.tipo_contacto || 'Cliente',
            id_contacto: Number(c.id_contacto || c.id_cliente || 0),
            canal: c.canal || 'Interno'
        };
        if (c.id_conversacion) body.id_conversacion = Number(c.id_conversacion);
        if (body.tipo_contacto === 'Cliente') body.id_cliente = body.id_contacto;
        return body;
    }

    function puedeEnviar() {
        return !window.MotorSoftGuard || window.MotorSoftGuard.puede('chat.enviar');
    }

    function esMobile() {
        return window.matchMedia('(max-width: 768px)').matches;
    }

    function mostrarMovil(panel) {
        const lista = document.querySelector('.chat-page .chat-sidebar');
        const main = document.querySelector('.chat-page .chat-main');
        const back = document.getElementById('btn-volver-chats');
        if (!esMobile()) {
            lista?.classList.remove('is-hidden-mobile');
            main?.classList.remove('is-hidden-mobile');
            back?.classList.add('hidden');
            return;
        }
        const verLista = panel !== 'chat';
        lista?.classList.toggle('is-hidden-mobile', !verLista);
        main?.classList.toggle('is-hidden-mobile', verLista);
        back?.classList.toggle('hidden', verLista);
    }

    function aplicarComposer() {
        const ok = puedeEnviar() && !!state.actual && !state.enviando;
        const input = document.getElementById('input-mensaje');
        const btn = document.getElementById('btn-enviar-mensaje');
        const adj = document.getElementById('btn-adjuntar');
        const nueva = document.getElementById('btn-nueva-conversacion');
        const esWa = String(state.actual?.canal || '').toLowerCase() === 'whatsapp';
        if (input) {
            input.disabled = !ok;
            if (!state.actual) input.placeholder = 'Seleccione una conversación';
            else if (!puedeEnviar()) input.placeholder = 'No tiene permiso para enviar';
            else if (esWa && !whatsappConectado()) input.placeholder = 'Escribe (queda en MotorSoft hasta conectar Meta)';
            else input.placeholder = 'Escribe un mensaje...';
        }
        if (btn) btn.disabled = !ok;
        if (adj) adj.disabled = !ok || esWa;
        if (nueva) nueva.hidden = !puedeEnviar();
    }

    function toggleModal(id, abierto) {
        const modal = document.getElementById(id);
        if (!modal) return;
        modal.classList.toggle('active', abierto);
        modal.classList.toggle('show', abierto);
        modal.style.display = abierto ? 'flex' : 'none';
    }

    async function asegurarConversacion() {
        if (!state.actual) return null;
        if (state.actual.id_conversacion || !window.apiChatAbrir) return state.actual;
        const abierta = await window.apiChatAbrir(payloadActual());
        state.actual = { ...state.actual, ...(abierta.data || abierta) };
        return state.actual;
    }

    function iconoTipo(tipo) {
        if (tipo === 'Proveedor') return 'fa-truck';
        if (tipo === 'Usuario') return 'fa-user-tie';
        return 'fa-user';
    }

    function etiquetaTipo(tipo) {
        if (tipo === 'Proveedor') return 'Proveedor';
        if (tipo === 'Usuario') return 'Personal';
        return 'Cliente';
    }

    function whatsappListo() {
        return true;
    }

    function whatsappConectado() {
        const wa = (state.canales || []).find(c => String(c.codigo || '').toLowerCase() === 'whatsapp');
        return !!(wa && (wa.conectado || wa.configurado));
    }

    async function cargarConversaciones() {
        if (state.cargando) return;
        state.cargando = true;
        try {
            const params = {};
            if (state.tipo) params.tipo_contacto = state.tipo;
            if (state.canal) params.canal = state.canal;
            if (state.filtro) params.q = state.filtro;
            const res = await window.apiChatConversaciones(params);
            const nuevas = ordenarConversaciones(res.data?.conversaciones || []);
            state.recien = detectarRecien(state.conversaciones, nuevas);
            state.conversaciones = nuevas;
            state.noLeidos = Number(res.data?.no_leidos || 0);
            state.canales = res.data?.canales || state.canales;
            if (state.actual) {
                const k = clave(state.actual);
                const fresco = state.conversaciones.find(c => clave(c) === k);
                if (fresco) state.actual = { ...state.actual, ...fresco };
            }
            const lista = document.getElementById('lista-conversaciones');
            const scroll = lista ? lista.scrollTop : 0;
            if (pintarLista()) {
                if (lista) lista.scrollTop = scroll;
            }
            pintarBadge();
            actualizarSelectCanal();
            if (state.recien.size) {
                clearTimeout(cargarConversaciones._tRecien);
                cargarConversaciones._tRecien = setTimeout(() => {
                    state.recien = new Set();
                    pintarLista();
                }, 2500);
            }
        } finally {
            state.cargando = false;
        }
    }

    function pintarBadge() {
        document.querySelectorAll('#badge-chat-sidebar, .sidebar-nav .notification-badge').forEach(el => {
            if (!el) return;
            if (state.noLeidos > 0) {
                el.hidden = false;
                el.textContent = String(state.noLeidos);
            } else {
                el.hidden = true;
                el.textContent = '0';
            }
        });
    }

    function firmaLista() {
        const actualKey = clave(state.actual);
        return state.conversaciones.map(c => {
            const k = clave(c);
            return [
                k,
                Number(c.no_leidos) || 0,
                previewLinea(c),
                horaLista(actividadDe(c)),
                state.recien.has(k) ? 1 : 0,
                actualKey === k ? 1 : 0
            ].join(':');
        }).join('|');
    }

    function firmaMensajes(lista, flash) {
        const ids = [...(flash || [])].sort().join(',');
        return (lista || []).map(m => `${idMensaje(m)}:${m.contenido || ''}:${esMio(m) ? 1 : 0}`).join('|') + '#' + ids;
    }

    function pintarLista() {
        const lista = document.getElementById('lista-conversaciones');
        if (!lista) return false;
        const firma = firmaLista();
        if (lista.dataset.firma === firma) return false;
        lista.dataset.firma = firma;
        const items = state.conversaciones;
        if (!items.length) {
            lista.innerHTML = `<div class="chat-empty"><i class="fas fa-comments"></i><p>No hay conversaciones en este filtro.</p><p>Use + para empezar una nueva.</p></div>`;
            return true;
        }
        const actualKey = clave(state.actual);
        lista.innerHTML = items.map(c => {
            const k = clave(c);
            const noLeidos = Number(c.no_leidos) || 0;
            const clases = ['conversacion-item'];
            if (actualKey && actualKey === k) clases.push('active');
            if (noLeidos > 0) clases.push('no-leido');
            if (state.recien.has(k)) clases.push('recien');
            if (!c.ultimo && !(Number(c.total_mensajes) > 0)) clases.push('sin-actividad');
            const badge = noLeidos > 0
                ? `<span class="badge" title="${noLeidos} sin leer">${noLeidos}</span>`
                : '';
            const canalCls = c.canal === 'WhatsApp' ? 'canal-wa' : 'canal-in';
            return `<button type="button" class="${clases.join(' ')}" data-key="${esc(k)}">
                <div class="conversacion-avatar"><i class="fas ${iconoTipo(c.tipo_contacto)}"></i></div>
                <div class="conversacion-info">
                    <h4>${esc(c.nombre)}</h4>
                    <p>${esc(previewLinea(c))}</p>
                </div>
                <div class="conversacion-meta">
                    <span class="tiempo">${esc(horaLista(actividadDe(c)))}</span>
                    <span class="chat-tipo-badge ${canalCls}">${esc(c.canal || 'Interno')}</span>
                    ${badge}
                </div>
            </button>`;
        }).join('');
        return true;
    }

    async function abrirDesdeLista(key) {
        const item = state.conversaciones.find(c => clave(c) === key);
        if (!item) return;
        await abrir(item);
    }

    async function abrir(conv, { silencioso } = {}) {
        if (!conv || state.abriendo) return;
        state.abriendo = true;
        try {
            let actual = { ...conv };
            if (!actual.id_conversacion && window.apiChatAbrir) {
                try {
                    const abierta = await window.apiChatAbrir({
                        tipo_contacto: actual.tipo_contacto || 'Cliente',
                        id_contacto: Number(actual.id_contacto || actual.id_cliente || 0),
                        canal: actual.canal || 'Interno'
                    });
                    actual = { ...actual, ...(abierta.data || abierta) };
                } catch (e) {
                    if (!silencioso) toast(e.message || 'No se pudo abrir', 'error');
                }
            }
            state.actual = actual;
            const params = payloadActual();
            const res = await window.apiChatObtener(params);
            state.mensajes = Array.isArray(res.data) ? res.data : [];
            state.idsMensajes = new Set(state.mensajes.map(idMensaje).filter(Boolean));
            const header = document.getElementById('chat-header-nombre');
            if (header) header.textContent = actual.nombre || 'Conversación';
            const meta = document.getElementById('chat-header-meta');
            if (meta) {
                const bits = [
                    etiquetaTipo(actual.tipo_contacto),
                    actual.canal,
                    actual.documento,
                    actual.telefono
                ].filter(Boolean);
                if (String(actual.canal || '').toLowerCase() === 'whatsapp' && !whatsappConectado()) {
                    bits.push('sin Meta (solo MotorSoft)');
                }
                meta.textContent = bits.join(' · ');
            }
            document.getElementById('input-mensaje')?.removeAttribute('disabled');
            aplicarComposer();
            const box = document.getElementById('mensajes-contenedor');
            if (box) delete box.dataset.ready;
            pintarMensajes();
            pintarLista();
            mostrarMovil('chat');
            arrancarPoll();
            await cargarConversaciones().catch(() => {});
        } finally {
            state.abriendo = false;
        }
    }

    async function recargarMensajes() {
        const params = payloadActual();
        if (!params) return [];
        const previos = new Set(state.idsMensajes);
        const res = await window.apiChatObtener({ ...params, silencioso: 1 });
        const lista = Array.isArray(res.data) ? res.data : [];
        const idsNuevos = lista
            .filter(m => {
                const id = idMensaje(m);
                return id && !previos.has(id) && !esMio(m);
            })
            .map(idMensaje);
        idsNuevos.forEach(id => state.flashIds.add(id));
        state.mensajes = lista;
        state.idsMensajes = new Set(lista.map(idMensaje).filter(Boolean));
        const box = document.getElementById('mensajes-contenedor');
        const firma = firmaMensajes(state.mensajes, state.flashIds);
        if (!box || box.dataset.firma !== firma) {
            pintarMensajes([...state.flashIds]);
        }
        if (idsNuevos.length) {
            clearTimeout(recargarMensajes._flash);
            recargarMensajes._flash = setTimeout(() => {
                state.flashIds = new Set();
                document.querySelectorAll('#mensajes-contenedor .mensaje.recien').forEach(el => el.classList.remove('recien'));
                const box = document.getElementById('mensajes-contenedor');
                if (box) box.dataset.firma = firmaMensajes(state.mensajes, []);
            }, 2800);
        }
        return idsNuevos;
    }

    function pintarMensajes(idsNuevos = []) {
        const box = document.getElementById('mensajes-contenedor');
        if (!box) return;
        if (!state.actual) {
            box.innerHTML = '<div class="chat-empty"><i class="fas fa-comments"></i><p>Seleccione una conversación</p></div>';
            return;
        }
        if (!state.mensajes.length) {
            box.innerHTML = '<div class="chat-empty"><p>Aún no hay mensajes. Escriba el primero.</p></div>';
            return;
        }
        const primeraVez = box.dataset.ready !== '1';
        const cercaDelFinal = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
        const nuevos = new Set(idsNuevos.map(Number));
        const firma = firmaMensajes(state.mensajes, nuevos);
        if (box.dataset.firma === firma && box.dataset.ready === '1') return;
        box.dataset.firma = firma;
        box.innerHTML = state.mensajes.map(m => `
            <div class="mensaje ${esMio(m) ? 'enviado' : 'recibido'}${nuevos.has(idMensaje(m)) ? ' recien' : ''}">
                <div class="mensaje-contenido">
                    <div class="mensaje-texto">${typeof window.htmlAdjuntoMensaje === 'function' ? window.htmlAdjuntoMensaje(m, esc) : `<p>${esc(m.contenido)}</p>`}</div>
                    <span class="mensaje-hora">${esc(hora(m.fecha_hora))} · ${esc(m.emisor_nombre || '')}</span>
                </div>
            </div>
        `).join('');
        box.dataset.ready = '1';
        if (primeraVez || cercaDelFinal || idsNuevos.length) {
            box.scrollTop = box.scrollHeight;
        }
    }

    async function enviar() {
        const input = document.getElementById('input-mensaje');
        const texto = (input?.value || '').trim();
        if (!texto || !state.actual) return;
        await enviarPayload(texto, 0);
    }

    async function enviarPayload(texto, idAdjunto) {
        if (!state.actual || state.enviando) return;
        if (!puedeEnviar()) {
            toast('No tiene permiso para enviar mensajes', 'error');
            return;
        }
        state.enviando = true;
        aplicarComposer();
        const body = payloadActual();
        body.contenido = texto || '';
        if (idAdjunto) body.id_adjunto = idAdjunto;
        try {
            const res = await window.apiChatEnviar(body);
            const enviado = res.data || {};
            if (enviado.id_conversacion) {
                state.actual = { ...state.actual, id_conversacion: Number(enviado.id_conversacion) };
            }
            const input = document.getElementById('input-mensaje');
            if (input) input.value = '';
            if (enviado.whatsapp_local) {
                toast('Quedó en MotorSoft. El cliente no lo ve en el celular hasta conectar Meta.', 'info');
            }
            await recargarMensajes();
            await cargarConversaciones().catch(() => {});
        } catch (e) {
            toast(e.message || 'No se pudo enviar', 'error');
        } finally {
            state.enviando = false;
            aplicarComposer();
        }
    }

    async function adjuntarArchivo(file) {
        if (!state.actual) {
            toast('Seleccione una conversación', 'info');
            return;
        }
        if (String(state.actual.canal || '').toLowerCase() === 'whatsapp') {
            toast('En WhatsApp no se envían archivos. Use el chat interno.', 'info');
            return;
        }
        try {
            await asegurarConversacion();
            const res = await window.apiAdjuntoSubir(file, 'conversacion', state.actual.id_conversacion || 0);
            const id = res.data?.id_adjunto;
            if (!id) throw new Error('No se recibió el archivo');
            const texto = (document.getElementById('input-mensaje')?.value || '').trim();
            await enviarPayload(texto, id);
        } catch (e) {
            toast(e.message || 'No se pudo adjuntar', 'error');
        }
    }

    function setChip(group, attr, value) {
        group.querySelectorAll('.chat-chip').forEach(btn => {
            btn.classList.toggle('active', (btn.getAttribute(attr) || '') === value);
        });
    }

    function actualizarSelectCanal() {
        const sel = document.getElementById('nueva-conv-canal');
        if (!sel) return;
        const waOpt = sel.querySelector('option[value="WhatsApp"]');
        if (waOpt) {
            waOpt.disabled = false;
            waOpt.textContent = whatsappConectado() ? 'WhatsApp (Meta)' : 'WhatsApp (local)';
        }
    }

    function abrirModalNueva() {
        if (!puedeEnviar()) {
            toast('No tiene permiso para iniciar conversaciones', 'error');
            return;
        }
        toggleModal('modal-nueva-conversacion', true);
        cargarContactosModal();
    }

    function cerrarModalNueva() {
        toggleModal('modal-nueva-conversacion', false);
    }

    function pintarInfoConversacion() {
        const c = state.actual;
        const box = document.getElementById('info-conv-cuerpo');
        if (!c || !box) return;
        const filas = [
            ['Nombre', c.nombre || '—'],
            ['Tipo', etiquetaTipo(c.tipo_contacto)],
            ['Canal', c.canal || 'Interno'],
            ['Documento', c.documento || '—'],
            ['Teléfono', c.telefono || '—'],
            ['Correo', c.email || '—']
        ];
        box.innerHTML = `<dl class="chat-info-lista">${filas.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`;
    }

    async function cargarContactosModal() {
        const tipo = document.getElementById('nueva-conv-tipo')?.value || 'Cliente';
        const q = document.getElementById('nueva-conv-buscar')?.value || '';
        const box = document.getElementById('nueva-conv-lista');
        const extra = document.getElementById('nueva-conv-proveedor');
        extra?.classList.toggle('hidden', tipo !== 'Proveedor');
        if (box) box.innerHTML = '<p class="text-muted">Cargando...</p>';
        try {
            const res = await window.apiChatContactos({ tipo_contacto: tipo, q });
            const items = res.data?.contactos || [];
            if (!box) return;
            if (!items.length) {
                box.innerHTML = '<p class="text-muted">No hay contactos de este tipo.</p>';
                return;
            }
            box.innerHTML = items.map(c => `
                <button type="button" class="chat-contacto-item" data-tipo="${esc(c.tipo_contacto)}" data-id="${c.id_contacto}">
                    <strong>${esc(c.nombre)}</strong>
                    <small>${esc([c.documento, c.telefono].filter(Boolean).join(' · '))}</small>
                </button>
            `).join('');
        } catch (e) {
            if (box) box.innerHTML = `<p>${esc(e.message || 'Error')}</p>`;
        }
    }

    async function elegirContactoModal(tipo, id) {
        const canal = document.getElementById('nueva-conv-canal')?.value || 'Interno';
        cerrarModalNueva();
        await abrir({
            tipo_contacto: tipo,
            id_contacto: Number(id),
            id_cliente: tipo === 'Cliente' ? Number(id) : 0,
            canal,
            nombre: 'Conversación'
        });
        state.tipo = tipo;
        setChip(document.getElementById('chat-filtros-tipo'), 'data-tipo', tipo);
        await cargarConversaciones();
        const fresco = state.conversaciones.find(c =>
            c.tipo_contacto === tipo && Number(c.id_contacto) === Number(id) && (c.canal || 'Interno') === canal
        );
        if (fresco) await abrir(fresco);
    }

    async function crearProveedorRapido() {
        const nombre = document.getElementById('nuevo-prov-nombre')?.value.trim();
        const telefono = document.getElementById('nuevo-prov-tel')?.value.trim();
        if (!nombre || !telefono) {
            toast('Nombre y teléfono son obligatorios', 'error');
            return;
        }
        try {
            const res = await window.apiChatCrearContacto({ tipo_contacto: 'Proveedor', nombre, telefono });
            const c = res.data || {};
            document.getElementById('nuevo-prov-nombre').value = '';
            document.getElementById('nuevo-prov-tel').value = '';
            toast('Proveedor creado', 'success');
            await elegirContactoModal('Proveedor', c.id_contacto);
        } catch (e) {
            toast(e.message || 'No se pudo crear', 'error');
        }
    }

    function bind() {
        document.getElementById('lista-conversaciones')?.addEventListener('click', e => {
            const btn = e.target.closest('[data-key]');
            if (btn) abrirDesdeLista(btn.getAttribute('data-key'));
        });
        document.getElementById('btn-enviar-mensaje')?.addEventListener('click', enviar);
        document.getElementById('input-mensaje')?.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                enviar();
            }
        });
        document.getElementById('btn-nueva-conversacion')?.addEventListener('click', abrirModalNueva);
        document.getElementById('btn-cerrar-nueva-conv')?.addEventListener('click', cerrarModalNueva);
        document.getElementById('modal-nueva-conversacion')?.addEventListener('click', e => {
            if (e.target.id === 'modal-nueva-conversacion') cerrarModalNueva();
        });
        document.getElementById('btn-volver-chats')?.addEventListener('click', () => mostrarMovil('lista'));
        document.getElementById('btn-cerrar-info-conv')?.addEventListener('click', () => toggleModal('modal-info-conversacion', false));
        document.getElementById('modal-info-conversacion')?.addEventListener('click', e => {
            if (e.target.id === 'modal-info-conversacion') toggleModal('modal-info-conversacion', false);
        });
        document.getElementById('nueva-conv-tipo')?.addEventListener('change', cargarContactosModal);
        document.getElementById('nueva-conv-buscar')?.addEventListener('input', () => {
            clearTimeout(bind._t);
            bind._t = setTimeout(cargarContactosModal, 250);
        });
        document.getElementById('nueva-conv-lista')?.addEventListener('click', e => {
            const btn = e.target.closest('.chat-contacto-item');
            if (btn) elegirContactoModal(btn.dataset.tipo, btn.dataset.id);
        });
        document.getElementById('btn-crear-proveedor')?.addEventListener('click', crearProveedorRapido);
        document.getElementById('chat-filtros-tipo')?.addEventListener('click', e => {
            const btn = e.target.closest('[data-tipo]');
            if (!btn) return;
            state.tipo = btn.getAttribute('data-tipo') || '';
            setChip(document.getElementById('chat-filtros-tipo'), 'data-tipo', state.tipo);
            cargarConversaciones().catch(err => toast(err.message, 'error'));
        });
        document.getElementById('chat-filtros-canal')?.addEventListener('click', e => {
            const btn = e.target.closest('[data-canal]');
            if (!btn) return;
            state.canal = btn.getAttribute('data-canal') || '';
            setChip(document.getElementById('chat-filtros-canal'), 'data-canal', state.canal);
            cargarConversaciones().catch(err => toast(err.message, 'error'));
        });
        const buscar = document.getElementById('chat-search-input');
        if (buscar) {
            buscar.addEventListener('input', () => {
                state.filtro = buscar.value.trim();
                clearTimeout(bind._s);
                bind._s = setTimeout(() => cargarConversaciones().catch(() => {}), 250);
            });
        }
        document.getElementById('btn-info-conversacion')?.addEventListener('click', () => {
            if (!state.actual) {
                toast('Seleccione una conversación', 'info');
                return;
            }
            pintarInfoConversacion();
            toggleModal('modal-info-conversacion', true);
        });
        document.getElementById('btn-adjuntar')?.addEventListener('click', () => {
            if (!state.actual) {
                toast('Seleccione una conversación', 'info');
                return;
            }
            let input = document.getElementById('input-adjunto-chat');
            if (!input) {
                input = document.createElement('input');
                input.type = 'file';
                input.id = 'input-adjunto-chat';
                input.accept = 'image/jpeg,image/png,image/gif,application/pdf';
                input.hidden = true;
                input.addEventListener('change', () => {
                    const file = input.files && input.files[0];
                    if (file) adjuntarArchivo(file);
                    input.value = '';
                });
                document.body.appendChild(input);
            }
            input.click();
        });
    }

    async function init() {
        window.MotorSoftChatTrabajadoresIniciado = true;
        bind();
        aplicarComposer();
        mostrarMovil('lista');
        window.addEventListener('resize', () => mostrarMovil(state.actual && esMobile() ? 'chat' : 'lista'));
        try {
            await cargarConversaciones();
            const ordenId = new URLSearchParams(location.search).get('orden');
            if (ordenId) await abrirDesdeOrden(ordenId);
        } catch (e) {
            toast(e.message || 'No se pudo cargar el chat', 'error');
        }
        arrancarPoll();
    }

    async function abrirDesdeOrden(ordenId) {
        if (!ordenId || typeof window.apiOrdenes !== 'function') return;
        try {
            const res = await window.apiOrdenes(true, { id: ordenId });
            const o = Array.isArray(res?.data) ? res.data[0] : res?.data;
            const idCliente = Number(o?.id_cliente || o?.vehiculo?.id_cliente || 0);
            if (idCliente < 1) {
                toast('Esta orden no tiene un cliente asociado', 'error');
                return;
            }
            await abrir({
                tipo_contacto: 'Cliente',
                id_contacto: idCliente,
                id_cliente: idCliente,
                canal: 'Interno',
                nombre: o.cliente_nombre || 'Cliente',
                telefono: o.cliente_telefono || o.vehiculo?.cliente_telefono || '',
                documento: o.placa || o.vehiculo?.placa || ''
            });
        } catch (e) {
            toast(e.message || 'No se pudo abrir el chat de la orden', 'error');
        }
    }

    function arrancarPoll() {
        if (state.poll) clearTimeout(state.poll);
        const version = ++state.pollVersion;
        const tick = async () => {
            try {
                let nuevos = [];
                if (state.actual) nuevos = await recargarMensajes();
                await cargarConversaciones();
                if (nuevos.length && window.apiChatLeer) {
                    const body = payloadActual();
                    if (body) await window.apiChatLeer(body).catch(() => {});
                }
            } catch (_) {
                // Reintentar después, sin superponer solicitudes.
            } finally {
                if (version === state.pollVersion) {
                    state.poll = setTimeout(tick, state.actual ? 6000 : 12000);
                }
            }
        };
        state.poll = setTimeout(tick, state.actual ? 6000 : 12000);
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => ChatModule.init());
