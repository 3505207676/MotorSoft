/**
 * Panel administrador: KPIs, órdenes, actividad y gráfico desde la BD.
 */
document.addEventListener('DOMContentLoaded', () => {
    cargarDashboard();
    document.getElementById('chart-period')?.addEventListener('change', () => cargarDashboard());
    document.getElementById('btn-mensajes')?.addEventListener('click', () => {
        window.location.href = '../chat/index-trabajadores.php';
    });
    document.getElementById('search-dashboard')?.addEventListener('input', filtrarOrdenes);
    document.getElementById('btn-guardar-taller')?.addEventListener('click', guardarTaller);
    document.getElementById('kpi-stock-bajo')?.closest('.card-stat')?.addEventListener('click', () => {
        window.location.href = '../inventario/index.php';
    });
    document.getElementById('card-kpi-citas')?.addEventListener('click', () => {
        window.location.href = '../agenda/index.php#citas';
    });
    document.getElementById('lista-citas')?.addEventListener('click', () => {
        window.location.href = '../agenda/index.php#citas';
    });
    document.getElementById('kpi-ordenes-activas')?.closest('.card-stat')?.addEventListener('click', () => {
        window.location.href = '../ordenes/index-trabajadores.php';
    });
    document.getElementById('card-kpi-ingresos')?.addEventListener('click', () => {
        window.location.href = '../facturacion/index.php';
    });
});

let cacheOrdenes = [];

function moneda(n) {
    return Number(n || 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
}

function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function badgeClass(estado) {
    const e = String(estado || '').toLowerCase();
    if (e.includes('complet') || e.includes('finaliz')) return 'bg-success';
    if (e.includes('proceso') || e.includes('progreso')) return 'bg-warning';
    if (e.includes('cancel')) return 'bg-danger';
    if (e.includes('pago')) return 'bg-info';
    if (e.includes('diagn')) return 'bg-primary';
    return 'bg-secondary';
}

async function cargarDashboard() {
    const periodo = document.getElementById('chart-period')?.value || 'week';
    try {
        if (typeof window.apiDashboard !== 'function') {
            throw new Error('API del panel no disponible');
        }
        const res = await window.apiDashboard({ periodo });
        const data = res.data || {};
        aplicarVista(data.vista || {});
        pintarKpis(data.kpis || {}, data.vista || {});
        cacheOrdenes = data.ordenes_recientes || [];
        pintarOrdenes(cacheOrdenes);
        pintarCitasHoy(data.citas_hoy_lista || []);
        if (data.vista && data.vista.auditoria !== false) {
            pintarActividad(data.actividad || []);
        }
        pintarMecanicos(data.mecanicos || []);
        if (!data.vista || data.vista.finanzas !== false) {
            pintarGrafico(data.grafico || {});
        }
        pintarBadges(data.kpis || {}, data.notificaciones || []);
        pintarTaller(data.taller || {});
        if (window.MotorSoftNotificaciones && typeof window.MotorSoftNotificaciones.aplicar === 'function') {
            window.MotorSoftNotificaciones.aplicar(data.notificaciones || []);
        }
    } catch (e) {
        if (typeof window.showToast === 'function') {
            window.showToast(e.message || 'No se pudo cargar el panel', 'error');
        }
    }
}

function mostrarEl(el, visible) {
    if (!el) return;
    el.hidden = !visible;
    if (!visible) {
        el.style.display = 'none';
        return;
    }
    el.style.display = el.classList.contains('card-stat') ? 'flex' : '';
}

function aplicarVista(vista) {
    const verFinanzas = vista.finanzas !== false;
    const verAuditoria = vista.auditoria !== false;
    mostrarEl(document.getElementById('card-kpi-ingresos'), verFinanzas);
    mostrarEl(document.getElementById('card-kpi-citas'), true);
    mostrarEl(document.getElementById('seccion-finanzas'), verFinanzas);
    mostrarEl(document.getElementById('card-actividad'), verAuditoria);
    mostrarEl(document.getElementById('footer-auditoria'), verAuditoria);
    const titulo = document.getElementById('titulo-actividad');
    if (titulo) titulo.textContent = 'Actividad Reciente';
    const btnTaller = document.getElementById('btn-guardar-taller');
    if (btnTaller) btnTaller.style.display = vista.configurar_taller ? '' : 'none';
}

function pintarKpis(k, vista) {
    setText('kpi-vehiculos-taller', String(k.vehiculos_taller ?? 0));
    setText('kpi-ordenes-activas', String(k.ordenes_activas ?? 0));
    setText('kpi-stock-bajo', String(k.stock_bajo ?? 0));
    setHint('hint-vehiculos', (k.ordenes_activas || 0) + ' órdenes abiertas');
    setHint('hint-ordenes', k.detalle_ordenes || 'Datos del taller');
    setHint('hint-stock', (k.stock_bajo || 0) > 0 ? 'Revisar inventario' : 'Stock en rango');
    setText('kpi-citas-hoy', String(k.citas_hoy ?? 0));
    setHint('hint-citas', (k.citas_hoy || 0) > 0 ? 'Citas de hoy · ver agenda' : 'Sin citas para hoy');
    if (vista && vista.finanzas === false) {
        return;
    }
    setText('kpi-ingresos-dia', moneda(k.ingresos_dia));
    const hintIng = document.getElementById('hint-ingresos');
    if (hintIng) {
        hintIng.textContent = k.detalle_ingresos || 'Datos del taller';
        hintIng.className = 'stat-change' + (Number(k.ingresos_dia) >= Number(k.ingresos_ayer) ? ' positive' : ' negative');
        if (!k.ingresos_ayer && !k.ingresos_dia) hintIng.className = 'stat-change';
    }
}

function etiquetaDiaCita(fecha) {
    const f = String(fecha || '').slice(0, 10);
    if (!f) return '';
    const d = new Date();
    const hoy = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    if (f === hoy) return 'Hoy';
    return f;
}

function pintarCitasHoy(items) {
    const ul = document.getElementById('lista-citas') || document.getElementById('lista-actividad');
    if (!ul) return;
    if (!items.length) {
        ul.innerHTML = '<li class="activity-item"><div class="activity-content"><p>No hay citas próximas. Ábralas en Agenda.</p></div></li>';
        return;
    }
    ul.innerHTML = items.map(i => {
        const cuando = [etiquetaDiaCita(i.fecha), i.hora || i.hora_inicio].filter(Boolean).join(' · ');
        return `
        <li class="activity-item">
            <div class="activity-icon bg-info"><i class="fas fa-calendar-alt"></i></div>
            <div class="activity-content">
                <p>${esc(cuando)} · ${esc(i.cliente_nombre || 'Cliente')} · ${esc(i.placa || '')}</p>
                <span class="activity-time">${esc(i.mecanico_nombre || 'Sin mecánico')} · ${esc(i.estado_cita || i.estado || '')}</span>
            </div>
        </li>`;
    }).join('');
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function setHint(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function pintarOrdenes(ordenes) {
    const tbody = document.getElementById('tbody-ordenes-recientes');
    if (!tbody) return;
    if (!ordenes.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No hay órdenes registradas</td></tr>';
        return;
    }
    tbody.innerHTML = ordenes.map(o => {
        const fecha = String(o.fecha_ingreso || '').slice(0, 10);
        const veh = o.vehiculo_label ? `${o.vehiculo_label} ${o.placa || ''}`.trim() : (o.placa || '—');
        return `<tr>
            <td>#${esc(o.id_orden)}</td>
            <td>${esc(o.cliente_nombre || '—')}</td>
            <td>${esc(veh)}</td>
            <td><span class="badge ${badgeClass(o.estado)}">${esc(o.estado || '')}</span></td>
            <td>${esc(fecha || '—')}</td>
            <td><a class="btn-icon btn-sm" href="../ordenes/index-trabajadores.php?orden=${encodeURIComponent(o.id_orden)}" title="Ver orden"><i class="fas fa-eye"></i></a></td>
        </tr>`;
    }).join('');
}

function filtrarOrdenes() {
    const q = (document.getElementById('search-dashboard')?.value || '').trim().toLowerCase();
    if (!q) {
        pintarOrdenes(cacheOrdenes);
        return;
    }
    const filtradas = cacheOrdenes.filter(o => {
        const blob = [o.id_orden, o.cliente_nombre, o.placa, o.vehiculo_label, o.estado].join(' ').toLowerCase();
        return blob.includes(q);
    });
    pintarOrdenes(filtradas);
}

function pintarActividad(items) {
    const ul = document.getElementById('lista-actividad') || document.querySelector('.activity-list');
    if (!ul) return;
    if (!items.length) {
        ul.innerHTML = '<li class="activity-item"><div class="activity-content"><p>Sin actividad reciente en auditoría</p></div></li>';
        return;
    }
    ul.innerHTML = items.map(i => `
        <li class="activity-item">
            <div class="activity-icon ${esc(i.cls || 'bg-primary')}"><i class="fas ${esc(i.icono || 'fa-history')}"></i></div>
            <div class="activity-content"><p>${esc(i.texto)}</p><span class="activity-time">${esc(i.tiempo || '')}</span></div>
        </li>
    `).join('');
}

function pintarMecanicos(items) {
    const ul = document.getElementById('lista-mecanicos') || document.querySelector('.user-list');
    if (!ul) return;
    if (!items.length) {
        ul.innerHTML = '<li class="user-item"><div class="user-info"><h4>Sin mecánicos activos</h4></div></li>';
        return;
    }
    ul.innerHTML = items.map(m => {
        const n = Number(m.ordenes_activas) || 0;
        return `<li class="user-item">
            <div class="user-avatar small">
                <img src="../../assets/images/avatar-default.svg" alt="">
                <span class="status-indicator ${n ? 'busy' : 'online'}"></span>
            </div>
            <div class="user-info">
                <h4>${esc(m.nombre || '')}</h4>
                <span class="user-status">${n ? n + ' orden(es) activa(s)' : 'Disponible'}</span>
            </div>
        </li>`;
    }).join('');
}

function pintarGrafico(grafico) {
    const mock = document.querySelector('.chart-mock');
    const labels = document.querySelector('.chart-labels');
    if (!mock || !labels) return;
    const valores = Array.isArray(grafico.valores) ? grafico.valores : [];
    const etiquetas = Array.isArray(grafico.etiquetas) ? grafico.etiquetas : [];
    if (!valores.length) {
        mock.innerHTML = '<p class="text-muted" style="align-self:center;width:100%;text-align:center">Sin ingresos facturados en este periodo</p>';
        labels.innerHTML = '';
        return;
    }
    const max = Math.max(1, ...valores.map(Number));
    mock.innerHTML = valores.map((v, i) => {
        const h = Math.round((Number(v) / max) * 90) + 8;
        return `<div class="chart-bar" style="height:${h}%" title="${esc(etiquetas[i] || '')}: ${moneda(v)}"></div>`;
    }).join('');
    labels.innerHTML = etiquetas.map(e => `<span>${esc(e)}</span>`).join('');
}

function pintarBadges(kpis, notifs) {
    const chatN = Number(kpis.chat_no_leidos) || 0;
    document.querySelectorAll('#btn-mensajes .notification-badge, #badge-chat-top, #badge-chat-sidebar').forEach(el => {
        if (!el) return;
        el.textContent = String(chatN);
        el.hidden = chatN <= 0;
    });
    const n = (notifs || []).length;
    const bell = document.querySelector('#btn-notificaciones .notification-badge');
    if (bell) {
        bell.textContent = String(n);
        bell.hidden = n <= 0;
    }
}

function pintarTaller(t) {
    const nombre = document.getElementById('taller-nombre');
    const dir = document.getElementById('taller-direccion');
    const tel = document.getElementById('taller-telefono');
    if (nombre && t.nombre) nombre.value = t.nombre;
    if (dir) dir.value = t.direccion || '';
    if (tel) tel.value = t.telefono || '';
}

async function guardarTaller() {
    try {
        await window.apiConfiguracionActualizar({
            empresa_nombre: document.getElementById('taller-nombre')?.value || '',
            empresa_direccion: document.getElementById('taller-direccion')?.value || '',
            empresa_telefono: document.getElementById('taller-telefono')?.value || ''
        });
        document.getElementById('modal-configuracion')?.classList.remove('active');
        if (typeof window.showToast === 'function') window.showToast('Datos del taller guardados', 'success');
    } catch (e) {
        if (typeof window.showToast === 'function') window.showToast(e.message || 'No se pudo guardar', 'error');
    }
}
