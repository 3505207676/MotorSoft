/**
 * Reportes de órdenes, facturación y nómina (API real, con fechas y CSV).
 */
(function () {
    const state = {
        tab: 'ordenes',
        ordenes: null,
        facturacion: null,
        nomina: null,
        desde: '',
        hasta: ''
    };

    function puede(slug) {
        return !window.MotorSoftGuard || window.MotorSoftGuard.puede(slug);
    }

    function money(n) {
        return typeof ModuleCore !== 'undefined'
            ? ModuleCore.formatCurrency(n)
            : new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(n || 0);
    }

    function iso(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function hoy() {
        return new Date();
    }

    function rangoPreset(kind) {
        const now = hoy();
        const hasta = iso(now);
        if (kind === 'hoy') {
            return { desde: hasta, hasta };
        }
        if (kind === 'semana') {
            const d = new Date(now);
            const day = (d.getDay() + 6) % 7;
            d.setDate(d.getDate() - day);
            return { desde: iso(d), hasta };
        }
        if (kind === 'anio') {
            return { desde: `${now.getFullYear()}-01-01`, hasta };
        }
        return { desde: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`, hasta };
    }

    function leerFechas() {
        const desde = document.getElementById('rep-desde')?.value || '';
        const hasta = document.getElementById('rep-hasta')?.value || '';
        state.desde = desde;
        state.hasta = hasta;
        return { desde, hasta };
    }

    function pintarPeriodo(periodo) {
        const el = document.getElementById('rep-periodo-label');
        if (!el) return;
        const d = periodo?.desde || state.desde;
        const h = periodo?.hasta || state.hasta;
        el.textContent = d && h ? `Del ${fmtFecha(d)} al ${fmtFecha(h)}` : '';
    }

    function fmtFecha(v) {
        if (!v) return '—';
        if (typeof ModuleCore !== 'undefined') {
            return ModuleCore.formatDate(String(v).slice(0, 10) + 'T12:00:00');
        }
        return String(v).slice(0, 10);
    }

    function params() {
        const f = leerFechas();
        const p = {};
        if (f.desde) p.desde = f.desde;
        if (f.hasta) p.hasta = f.hasta;
        return p;
    }

    async function cargarOrdenes() {
        if (!puede('reportes.ordenes')) return;
        const res = await window.apiReportes('ordenes', params());
        state.ordenes = res.data || {};
        const r = state.ordenes.resumen || {};
        pintarPeriodo(state.ordenes.periodo);
        setText('rep-ord-total', r.total || 0);
        setText('rep-ord-pend', r.pendiente || 0);
        setText('rep-ord-proc', r.en_proceso || 0);
        setText('rep-ord-ok', r.completadas || 0);
        setText('rep-ord-valor', money(r.valor_total || 0));
        const tbody = document.querySelector('#tabla-rep-ordenes tbody');
        if (!tbody) return;
        const lista = state.ordenes.ordenes || [];
        tbody.innerHTML = lista.map(o => `<tr>
            <td>${esc(o.id_orden || '')}</td>
            <td>${ModuleCore.badge(o.estado || '')}</td>
            <td>${esc(o.cliente_nombre || '—')}</td>
            <td>${esc([o.placa, o.vehiculo_label].filter(Boolean).join(' · ') || '—')}</td>
            <td>${esc(o.mecanico_nombre || '—')}</td>
            <td>${esc(fmtFecha(o.fecha_ingreso))}</td>
            <td>${money(o.total_general)}</td>
        </tr>`).join('') || ModuleCore.emptyRow(7, 'No hay órdenes en este periodo');
    }

    async function cargarFacturacion() {
        if (!puede('reportes.ordenes')) return;
        const res = await window.apiReportes('facturacion', params());
        state.facturacion = res.data || {};
        const r = state.facturacion.resumen || {};
        pintarPeriodo(state.facturacion.periodo);
        setText('rep-fac-emi', r.emitidas || 0);
        setText('rep-fac-cobrado', money(r.cobrado || 0));
        setText('rep-fac-pend', money(r.por_cobrar || 0));
        setText('rep-fac-anu', r.anuladas || 0);
        const metodos = r.por_metodo || {};
        const chips = Object.keys(metodos).map(k => `${k}: ${money(metodos[k])}`).join(' · ');
        const elMet = document.getElementById('rep-fac-metodos');
        if (elMet) {
            elMet.textContent = chips
                ? `Cobrado por método: ${chips}`
                : 'Sin cobros pagados en el periodo.';
        }
        const tbody = document.querySelector('#tabla-rep-facturas tbody');
        if (!tbody) return;
        const lista = state.facturacion.facturas || [];
        tbody.innerHTML = lista.map(f => `<tr>
            <td>${esc(f.numero || f.id_factura || '')}</td>
            <td>${esc(f.cliente || '—')}</td>
            <td>${esc(f.tipo_factura || '—')}</td>
            <td>${esc(f.metodo_pago || '—')}</td>
            <td>${ModuleCore.badge(f.estado || '')}</td>
            <td>${esc(fmtFecha(f.fecha_emision))}</td>
            <td>${money(f.total)}</td>
        </tr>`).join('') || ModuleCore.emptyRow(7, 'No hay facturas en este periodo');
    }

    async function cargarNomina() {
        if (!puede('reportes.nomina')) return;
        const res = await window.apiReportes('nomina', params());
        state.nomina = res.data || {};
        const r = state.nomina.resumen || {};
        pintarPeriodo(state.nomina.periodo);
        setText('rep-nom-pagos', r.pagos || 0);
        setText('rep-nom-prom', money(r.promedio || 0));
        setText('rep-nom-total', money(r.total || 0));
        const tbody = document.querySelector('#tabla-rep-nomina tbody');
        if (!tbody) return;
        const lista = state.nomina.nominas || [];
        tbody.innerHTML = lista.map(n => `<tr>
            <td>${esc(n.periodo_pago || '')}</td>
            <td>${esc(n.usuario_nombre || '—')}</td>
            <td>${esc(fmtFecha(n.fecha_pago))}</td>
            <td>${money(n.total_neto)}</td>
        </tr>`).join('') || ModuleCore.emptyRow(4, 'No hay pagos de nómina en este periodo');
    }

    async function cargarTab(tab, forzar) {
        state.tab = tab;
        if (tab === 'facturacion') {
            if (forzar || !state.facturacion) await cargarFacturacion();
            return;
        }
        if (tab === 'nomina') {
            if (forzar || !state.nomina) await cargarNomina();
            return;
        }
        if (forzar || !state.ordenes) await cargarOrdenes();
    }

    function invalidar() {
        state.ordenes = null;
        state.facturacion = null;
        state.nomina = null;
    }

    function exportar() {
        const tab = state.tab;
        if (tab === 'facturacion') {
            const lista = state.facturacion?.facturas || [];
            if (!lista.length) {
                ModuleCore.toast('No hay facturas para exportar', 'warning');
                return;
            }
            window.descargarCsv('reporte-facturacion', ['Número', 'Cliente', 'Tipo', 'Método', 'Estado', 'Fecha', 'Total'], lista.map(f => [
                f.numero || f.id_factura, f.cliente || '', f.tipo_factura || '', f.metodo_pago || '',
                f.estado || '', String(f.fecha_emision || '').slice(0, 10), f.total || 0
            ]));
            return;
        }
        if (tab === 'nomina') {
            const lista = state.nomina?.nominas || [];
            if (!lista.length) {
                ModuleCore.toast('No hay nómina para exportar', 'warning');
                return;
            }
            window.descargarCsv('reporte-nomina', ['Periodo', 'Persona', 'Fecha', 'Neto'], lista.map(n => [
                n.periodo_pago || '', n.usuario_nombre || '', n.fecha_pago || '', n.total_neto || 0
            ]));
            return;
        }
        const lista = state.ordenes?.ordenes || [];
        if (!lista.length) {
            ModuleCore.toast('No hay órdenes para exportar', 'warning');
            return;
        }
        window.descargarCsv('reporte-ordenes', ['Nº', 'Estado', 'Cliente', 'Placa', 'Vehículo', 'Mecánico', 'Ingreso', 'Total'], lista.map(o => [
            o.id_orden || '', o.estado || '', o.cliente_nombre || '', o.placa || '',
            o.vehiculo_label || '', o.mecanico_nombre || '', String(o.fecha_ingreso || '').slice(0, 10), o.total_general || 0
        ]));
    }

    function aplicarPermisos() {
        const tabs = [...document.querySelectorAll('#modulo-reportes .tab-btn')];
        tabs.forEach(btn => {
            const slug = btn.getAttribute('data-permiso');
            const ok = !slug || puede(slug);
            btn.hidden = !ok;
            if (!ok) btn.classList.remove('active');
        });
        const visible = tabs.filter(t => !t.hidden);
        if (!visible.length) return;
        let activa = visible.find(t => t.classList.contains('active')) || visible[0];
        visible.forEach(t => t.classList.toggle('active', t === activa));
        const tab = activa.getAttribute('data-tab');
        document.querySelectorAll('#modulo-reportes .module-panel').forEach(p => {
            p.classList.toggle('active', p.getAttribute('data-panel') === tab);
        });
        state.tab = tab;
    }

    function marcarPreset(kind) {
        document.querySelectorAll('#modulo-reportes [data-rango]').forEach(b => {
            b.classList.toggle('active', b.getAttribute('data-rango') === kind);
        });
    }

    function setText(id, val) {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function bindTabs() {
        document.querySelectorAll('#modulo-reportes .tab-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                if (btn.hidden) return;
                document.querySelectorAll('#modulo-reportes .tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('#modulo-reportes .module-panel').forEach(p => p.classList.remove('active'));
                btn.classList.add('active');
                const tab = btn.getAttribute('data-tab');
                document.querySelector(`#modulo-reportes [data-panel="${tab}"]`)?.classList.add('active');
                try {
                    await cargarTab(tab, false);
                } catch (e) {
                    ModuleCore.toast(e.message || 'No se pudo cargar el reporte', 'error');
                }
            });
        });
    }

    async function recargar() {
        invalidar();
        try {
            await cargarTab(state.tab, true);
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo actualizar', 'error');
        }
    }

    async function init() {
        const mes = rangoPreset('mes');
        const inpD = document.getElementById('rep-desde');
        const inpH = document.getElementById('rep-hasta');
        if (inpD) inpD.value = mes.desde;
        if (inpH) inpH.value = mes.hasta;
        state.desde = mes.desde;
        state.hasta = mes.hasta;
        pintarPeriodo(mes);

        aplicarPermisos();
        bindTabs();
        document.addEventListener('motorsoft:usuario-actualizado', aplicarPermisos);

        document.querySelectorAll('#modulo-reportes [data-rango]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const kind = btn.getAttribute('data-rango');
                const r = rangoPreset(kind);
                marcarPreset(kind);
                if (inpD) inpD.value = r.desde;
                if (inpH) inpH.value = r.hasta;
                await recargar();
            });
        });
        document.getElementById('btn-aplicar-reportes')?.addEventListener('click', async () => {
            marcarPreset('');
            await recargar();
        });
        document.getElementById('btn-refresh-reportes')?.addEventListener('click', recargar);
        document.getElementById('btn-export-reportes')?.addEventListener('click', exportar);

        try {
            await cargarTab(state.tab, true);
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudieron cargar los reportes', 'error');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
