/**
 * Inventario del taller: catálogo, stock y kardex con validaciones.
 */
const InventarioModule = (() => {
    const state = {
        productos: [],
        categorias: [],
        filtros: { categoria: 'todos', estado: 'todos', busqueda: '' },
        paginacion: { paginaActual: 1, itemsPorPagina: 10, totalPaginas: 1 },
        productoActual: null,
        modoEdicion: false,
        movProducto: null
    };

    function puede(slug) {
        return !window.MotorSoftGuard || window.MotorSoftGuard.puede(slug);
    }

    function toast(msg, type) {
        if (typeof window.showToast === 'function') window.showToast(msg, type);
        else if (window.ModuleCore) ModuleCore.toast(msg, type);
    }

    function mapProducto(p) {
        const stock = Number(p.cantidad ?? p.stock?.cantidad ?? 0);
        const minimo = Number(p.stock_minimo ?? p.stock?.stock_minimo ?? 0);
        let estado = 'ok';
        if (stock <= 0) estado = 'agotado';
        else if (p.stock_bajo || stock <= minimo) estado = 'bajo';
        return {
            id: p.id_producto,
            codigo: p.codigo || p.referencia || '',
            nombre: p.nombre,
            categoria: p.categoria || '',
            id_categoria: p.id_categoria,
            precio: Number(p.precio ?? p.precio_unitario ?? 0),
            stock,
            stockMinimo: minimo,
            ubicacion: p.ubicacion || '',
            estado,
            raw: p
        };
    }

    function escapeHtml(texto) {
        return String(texto)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    async function init() {
        aplicarPermisos();
        bindEvents();
        await cargarDatos(false);
        document.addEventListener('motorsoft:usuario-actualizado', aplicarPermisos);
    }

    function aplicarPermisos() {
        const btnProd = document.getElementById('btn-nuevo-producto');
        const btnCat = document.getElementById('btn-nueva-categoria');
        if (btnProd) {
            btnProd.hidden = !puede('inventario.crear');
            btnProd.style.display = puede('inventario.crear') ? '' : 'none';
        }
        if (btnCat) {
            btnCat.hidden = !puede('inventario.categorias');
            btnCat.style.display = puede('inventario.categorias') ? '' : 'none';
        }
        renderizarTabla();
    }

    async function cargarDatos(avisar = true) {
        try {
            const [prodRes, catRes] = await Promise.all([
                window.apiProductos(true),
                window.apiCategorias()
            ]);
            state.productos = (prodRes.data || []).map(mapProducto);
            state.categorias = catRes.data || [];
            llenarSelectsCategoria();
            pintarKpis();
            renderizarTabla();
            if (avisar) toast('Inventario actualizado', 'success');
        } catch (error) {
            toast(error.message || 'No se pudo cargar el inventario', 'error');
        }
    }

    function llenarSelectsCategoria() {
        const filtro = document.getElementById('filter-categoria');
        const formSelect = document.getElementById('categoria');
        const nombres = state.categorias.map(c => c.nombre);
        if (filtro) {
            const actual = filtro.value;
            filtro.innerHTML = '<option value="todos">Todas las categorías</option>' +
                nombres.map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
            filtro.value = [...filtro.options].some(o => o.value === actual) ? actual : 'todos';
        }
        if (formSelect) {
            const actual = formSelect.value;
            formSelect.innerHTML = '<option value="">Seleccione...</option>' +
                nombres.map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
            if (actual) formSelect.value = actual;
        }
    }

    function bindEvents() {
        document.getElementById('btn-nuevo-producto')?.addEventListener('click', abrirModalProducto);
        document.getElementById('btn-guardar-producto')?.addEventListener('click', guardarProducto);
        document.getElementById('btn-refresh')?.addEventListener('click', () => cargarDatos(true));
        document.getElementById('filter-categoria')?.addEventListener('change', aplicarFiltros);
        document.getElementById('filter-estado-stock')?.addEventListener('change', aplicarFiltros);
        document.getElementById('search-producto')?.addEventListener('input', ModuleCore.debounce(aplicarFiltros, 300));
        document.getElementById('prev-page')?.addEventListener('click', () => cambiarPagina(-1));
        document.getElementById('next-page')?.addEventListener('click', () => cambiarPagina(1));
        document.querySelector('#tabla-inventario tbody')?.addEventListener('click', onTablaClick);
        document.getElementById('btn-nueva-categoria')?.addEventListener('click', () => {
            document.getElementById('form-categoria')?.reset();
            ModuleCore.openModal('modal-categoria');
        });
        document.getElementById('btn-guardar-cat')?.addEventListener('click', guardarCategoria);
        document.getElementById('btn-guardar-mov')?.addEventListener('click', guardarMovimiento);
        document.getElementById('mov-tipo')?.addEventListener('change', pintarCamposMovimiento);
        ModuleCore.bindModalClose('modal-producto', 'btn-cancelar-producto', 'btn-cerrar-producto');
        ModuleCore.bindModalClose('modal-movimiento', 'btn-cancelar-mov', 'btn-cerrar-mov');
        ModuleCore.bindModalClose('modal-kardex', 'btn-cerrar-kardex', 'btn-cerrar-kardex-2');
        ModuleCore.bindModalClose('modal-categoria', 'btn-cancelar-cat', 'btn-cerrar-cat');
    }

    function onTablaClick(e) {
        const btn = e.target.closest('[data-accion]');
        if (!btn) return;
        const id = Number(btn.dataset.id);
        if (btn.dataset.accion === 'editar') editarProducto(id);
        if (btn.dataset.accion === 'movimiento') abrirMovimiento(id);
        if (btn.dataset.accion === 'kardex') abrirKardex(id);
    }

    function estadoStock(p) {
        if (p.estado === 'agotado') return { texto: 'Agotado', cls: 'bg-danger' };
        if (p.estado === 'bajo') return { texto: 'Stock bajo', cls: 'bg-warning' };
        return { texto: 'Disponible', cls: 'bg-success' };
    }

    function filtrarProductos() {
        let resultado = [...state.productos];
        if (state.filtros.categoria !== 'todos') {
            resultado = resultado.filter(p => p.categoria === state.filtros.categoria);
        }
        if (state.filtros.estado !== 'todos') {
            resultado = resultado.filter(p => p.estado === state.filtros.estado);
        }
        if (state.filtros.busqueda) {
            const termino = state.filtros.busqueda.toLowerCase();
            resultado = resultado.filter(p =>
                p.nombre.toLowerCase().includes(termino) ||
                String(p.codigo).toLowerCase().includes(termino)
            );
        }
        return resultado;
    }

    function pintarKpis() {
        const lista = state.productos;
        document.getElementById('kpi-productos').textContent = String(lista.length);
        document.getElementById('kpi-ok').textContent = String(lista.filter(p => p.estado === 'ok').length);
        document.getElementById('kpi-bajo').textContent = String(lista.filter(p => p.estado === 'bajo').length);
        document.getElementById('kpi-agotados').textContent = String(lista.filter(p => p.estado === 'agotado').length);
    }

    function renderizarTabla() {
        const tbody = document.querySelector('#tabla-inventario tbody');
        if (!tbody) return;
        const filtrados = filtrarProductos();
        const { paginaActual, itemsPorPagina } = state.paginacion;
        state.paginacion.totalPaginas = Math.max(1, Math.ceil(filtrados.length / itemsPorPagina));
        if (state.paginacion.paginaActual > state.paginacion.totalPaginas) {
            state.paginacion.paginaActual = state.paginacion.totalPaginas;
        }
        const inicio = (state.paginacion.paginaActual - 1) * itemsPorPagina;
        const pagina = filtrados.slice(inicio, inicio + itemsPorPagina);
        const puedeEditar = puede('inventario.editar');
        const puedeAjustar = puede('inventario.ajustar');

        tbody.innerHTML = pagina.length === 0
            ? '<tr><td colspan="9" class="text-center">No hay productos con ese filtro</td></tr>'
            : pagina.map(p => {
                const est = estadoStock(p);
                const stockCls = p.estado === 'agotado' ? 'stock-agotado' : (p.estado === 'bajo' ? 'stock-bajo' : '');
                return `<tr>
                    <td>${escapeHtml(p.codigo)}</td>
                    <td>${escapeHtml(p.nombre)}</td>
                    <td>${escapeHtml(p.categoria)}</td>
                    <td><span class="badge ${est.cls}">${est.texto}</span></td>
                    <td class="${stockCls}">${p.stock}</td>
                    <td>${p.stockMinimo}</td>
                    <td>${escapeHtml(p.ubicacion || '—')}</td>
                    <td>${ModuleCore.formatCurrency(p.precio)}</td>
                    <td>
                        <button type="button" class="btn-icon btn-sm" data-accion="kardex" data-id="${p.id}" title="Historial"><i class="fas fa-list"></i></button>
                        ${puedeAjustar ? `<button type="button" class="btn-icon btn-sm" data-accion="movimiento" data-id="${p.id}" title="Entrada, salida o ajuste"><i class="fas fa-exchange-alt"></i></button>` : ''}
                        ${puedeEditar ? `<button type="button" class="btn-icon btn-sm" data-accion="editar" data-id="${p.id}" title="Editar ficha"><i class="fas fa-edit"></i></button>` : ''}
                    </td>
                </tr>`;
            }).join('');

        const span = document.getElementById('lbl-paginacion');
        if (span) span.textContent = `Página ${state.paginacion.paginaActual} de ${state.paginacion.totalPaginas}`;
        const btnPrev = document.getElementById('prev-page');
        const btnNext = document.getElementById('next-page');
        if (btnPrev) btnPrev.disabled = state.paginacion.paginaActual <= 1;
        if (btnNext) btnNext.disabled = state.paginacion.paginaActual >= state.paginacion.totalPaginas;
    }

    function aplicarFiltros() {
        state.filtros.categoria = document.getElementById('filter-categoria')?.value || 'todos';
        state.filtros.estado = document.getElementById('filter-estado-stock')?.value || 'todos';
        state.filtros.busqueda = (document.getElementById('search-producto')?.value || '').trim();
        state.paginacion.paginaActual = 1;
        renderizarTabla();
    }

    function cambiarPagina(delta) {
        const nueva = state.paginacion.paginaActual + delta;
        if (nueva < 1 || nueva > state.paginacion.totalPaginas) return;
        state.paginacion.paginaActual = nueva;
        renderizarTabla();
    }

    function abrirModalProducto() {
        if (!puede('inventario.crear')) {
            toast('No puede crear productos', 'warning');
            return;
        }
        if (!state.categorias.length) {
            toast('Cree una categoría antes de registrar un producto', 'warning');
            return;
        }
        state.productoActual = null;
        state.modoEdicion = false;
        document.getElementById('modal-producto-title').textContent = 'Nuevo producto';
        document.getElementById('form-producto').reset();
        document.getElementById('grupo-stock-inicial').hidden = false;
        document.getElementById('stock').required = true;
        document.getElementById('stock').disabled = false;
        document.getElementById('hint-editar-stock').hidden = true;
        llenarSelectsCategoria();
        ModuleCore.openModal('modal-producto');
    }

    function editarProducto(id) {
        if (!puede('inventario.editar')) return;
        const producto = state.productos.find(p => p.id === id);
        if (!producto) return;
        state.productoActual = producto;
        state.modoEdicion = true;
        llenarSelectsCategoria();
        document.getElementById('modal-producto-title').textContent = `Editar: ${producto.nombre}`;
        document.getElementById('codigo').value = producto.codigo;
        document.getElementById('nombre').value = producto.nombre;
        document.getElementById('categoria').value = producto.categoria;
        document.getElementById('precio').value = producto.precio;
        document.getElementById('stockMinimo').value = producto.stockMinimo;
        document.getElementById('ubicacion').value = producto.ubicacion || '';
        document.getElementById('grupo-stock-inicial').hidden = true;
        document.getElementById('stock').required = false;
        document.getElementById('hint-editar-stock').hidden = false;
        ModuleCore.openModal('modal-producto');
    }

    async function guardarProducto() {
        const form = document.getElementById('form-producto');
        if (!form.checkValidity()) { form.reportValidity(); return; }
        const payload = {
            codigo: document.getElementById('codigo').value.trim(),
            referencia: document.getElementById('codigo').value.trim(),
            nombre: document.getElementById('nombre').value.trim(),
            categoria: document.getElementById('categoria').value,
            precio: parseFloat(document.getElementById('precio').value),
            stock_minimo: parseInt(document.getElementById('stockMinimo').value, 10),
            ubicacion: document.getElementById('ubicacion').value.trim() || null
        };
        if (!state.modoEdicion) {
            payload.stock = parseInt(document.getElementById('stock').value, 10) || 0;
        }
        try {
            if (state.modoEdicion && state.productoActual) {
                await window.apiProductosActualizar(state.productoActual.id, {
                    id_producto: state.productoActual.id,
                    ...payload
                });
                toast('Ficha del producto actualizada', 'success');
            } else {
                await window.apiProductos(false, payload);
                toast('Producto creado', 'success');
            }
            ModuleCore.closeModal('modal-producto');
            await cargarDatos(false);
        } catch (error) {
            toast(error.message || 'No se pudo guardar', 'error');
        }
    }

    function abrirMovimiento(id) {
        if (!puede('inventario.ajustar')) return;
        const producto = state.productos.find(p => p.id === id);
        if (!producto) return;
        state.movProducto = producto;
        document.getElementById('modal-movimiento-title').textContent = 'Movimiento de stock';
        document.getElementById('resumen-movimiento').textContent =
            `${producto.nombre} · Código ${producto.codigo || '—'} · En almacén: ${producto.stock}`;
        document.getElementById('mov-tipo').value = 'ENTRADA';
        document.getElementById('mov-cantidad').value = '1';
        document.getElementById('mov-nueva').value = String(producto.stock);
        document.getElementById('mov-motivo').value = '';
        pintarCamposMovimiento();
        ModuleCore.openModal('modal-movimiento');
    }

    function pintarCamposMovimiento() {
        const tipo = document.getElementById('mov-tipo')?.value;
        const grupoCant = document.getElementById('grupo-mov-cantidad');
        const grupoNueva = document.getElementById('grupo-mov-nueva');
        const esAjuste = tipo === 'AJUSTE';
        if (grupoCant) grupoCant.hidden = esAjuste;
        if (grupoNueva) grupoNueva.hidden = !esAjuste;
        const motivo = document.getElementById('mov-motivo');
        if (motivo && !motivo.value) {
            motivo.placeholder = esAjuste
                ? 'Ej. Inventario físico de septiembre'
                : (tipo === 'SALIDA' ? 'Ej. Filtro dañado' : 'Ej. Compra a proveedor');
        }
    }

    async function guardarMovimiento() {
        const producto = state.movProducto;
        if (!producto) return;
        const tipo = document.getElementById('mov-tipo').value;
        const motivo = document.getElementById('mov-motivo').value.trim();
        if (!motivo) {
            toast('Indique el motivo del movimiento', 'warning');
            return;
        }
        const payload = { id_producto: producto.id, tipo, motivo };
        if (tipo === 'AJUSTE') {
            const nueva = parseInt(document.getElementById('mov-nueva').value, 10);
            if (!Number.isFinite(nueva) || nueva < 0) {
                toast('El conteo no puede ser negativo', 'warning');
                return;
            }
            payload.nueva_cantidad = nueva;
        } else {
            const cantidad = parseInt(document.getElementById('mov-cantidad').value, 10);
            if (!Number.isFinite(cantidad) || cantidad < 1) {
                toast('Indique al menos 1 unidad', 'warning');
                return;
            }
            if (tipo === 'SALIDA' && cantidad > producto.stock) {
                toast(`Solo hay ${producto.stock} unidades de ${producto.nombre}`, 'warning');
                return;
            }
            payload.cantidad = cantidad;
        }
        try {
            await window.apiMovimientoStock(payload);
            ModuleCore.closeModal('modal-movimiento');
            toast('Movimiento registrado', 'success');
            await cargarDatos(false);
        } catch (error) {
            toast(error.message || 'No se pudo registrar el movimiento', 'error');
        }
    }

    async function abrirKardex(id) {
        const producto = state.productos.find(p => p.id === id);
        if (!producto) return;
        document.getElementById('modal-kardex-title').textContent = `Historial · ${producto.nombre}`;
        const tbody = document.querySelector('#tabla-kardex tbody');
        if (tbody) tbody.innerHTML = '<tr><td colspan="6">Cargando...</td></tr>';
        ModuleCore.openModal('modal-kardex');
        try {
            const res = await window.apiStockKardex(id);
            const movs = res.data?.movimientos || [];
            if (!tbody) return;
            tbody.innerHTML = movs.length
                ? movs.map(m => `<tr>
                    <td>${ModuleCore.formatDateTime(m.fecha_hora)}</td>
                    <td>${ModuleCore.badge(m.tipo_movimiento, { ENTRADA: 'bg-success', SALIDA: 'bg-danger', AJUSTE: 'bg-info' })}</td>
                    <td>${m.cantidad != null ? m.cantidad : '—'}</td>
                    <td>${m.cantidad_antes != null ? m.cantidad_antes : '—'}</td>
                    <td>${m.cantidad_despues != null ? m.cantidad_despues : '—'}</td>
                    <td>${escapeHtml(m.motivo || (m.referencia_documento ? 'Doc. ' + m.referencia_documento : '—'))}</td>
                </tr>`).join('')
                : '<tr><td colspan="6" class="text-center">Aún no hay movimientos</td></tr>';
        } catch (error) {
            if (tbody) tbody.innerHTML = `<tr><td colspan="6">${escapeHtml(error.message || 'No se pudo cargar el historial')}</td></tr>`;
        }
    }

    async function guardarCategoria() {
        const nombre = document.getElementById('cat-nombre')?.value.trim();
        if (!nombre) {
            toast('Indique el nombre de la categoría', 'warning');
            return;
        }
        try {
            await window.apiCategoriasCrear({ nombre });
            ModuleCore.closeModal('modal-categoria');
            toast('Categoría creada', 'success');
            await cargarDatos(false);
        } catch (error) {
            toast(error.message || 'No se pudo crear la categoría', 'error');
        }
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => InventarioModule.init());
