/**
 * Órdenes de trabajo: catálogo real, modal usable y flujo hacia facturación.
 */
const ESTADOS_ORDEN = ['Pendiente', 'Diagnóstico', 'En Proceso', 'Pendiente Pago', 'Completada', 'Cancelada'];
const ESTADOS_FACTURABLES = ['Pendiente Pago', 'Completada'];

let appState = {
    ordenes: [],
    clientes: [],
    vehiculos: [],
    mecanicos: [],
    serviciosCatalogo: [],
    ordenActual: null,
    serviciosOrden: [],
    ivaActivo: true,
    ivaPorcentaje: 19,
    filtros: { estado: 'todos', mecanico: 'todos', busqueda: '' },
    paginacion: { paginaActual: 1, itemsPorPagina: 10, totalPaginas: 1 }
};

function puedeEditarPrecio() {
    return !window.MotorSoftGuard || window.MotorSoftGuard.puede('servicios.editar');
}

function puedeAdministrarCatalogo() {
    return !window.MotorSoftGuard
        || window.MotorSoftGuard.puede('servicios.crear')
        || window.MotorSoftGuard.puede('servicios.editar');
}

function puedeEditarOrden() {
    return !window.MotorSoftGuard
        || window.MotorSoftGuard.puede('ordenes.crear')
        || window.MotorSoftGuard.puede('ordenes.agregar_servicios');
}

function puedeFacturarOrden() {
    return !window.MotorSoftGuard || window.MotorSoftGuard.puede('facturas.crear');
}

function escHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function money(n) {
    if (window.ModuleCore?.formatCurrency) return ModuleCore.formatCurrency(n);
    const fmt = window.utils?.formatCurrency;
    return fmt ? fmt(n) : Number(n || 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
}

function unwrap(res) {
    const d = res?.data ?? res;
    if (Array.isArray(d)) return d;
    if (d && typeof d === 'object') {
        if (Array.isArray(d.data)) return d.data;
        if (d.id_cliente || d.id_vehiculo || d.id_usuario || d.id_servicio || d.id_orden) {
            return [d];
        }
    }
    return [];
}

async function safeCall(label, fn) {
    try {
        return await fn();
    } catch (e) {
        console.error('Órdenes: error cargando ' + label, e);
        window.showToast?.(e.message || ('No se pudo cargar ' + label), 'error');
        return { data: [] };
    }
}

function mapCliente(c) {
    return {
        id: String(c.id_cliente ?? c.id ?? ''),
        id_cliente: c.id_cliente ?? c.id,
        nombre: c.nombre || 'Sin nombre',
        cedula: c.documento || '',
        vehiculos: Array.isArray(c.vehiculos) ? c.vehiculos : [],
        ...c
    };
}

function mapVehiculo(v, clienteId) {
    return {
        id: String(v.id_vehiculo ?? v.id ?? ''),
        id_vehiculo: v.id_vehiculo ?? v.id,
        clienteId: String(v.id_cliente ?? clienteId ?? ''),
        placa: v.placa || '',
        tipo: v.tipo || '',
        marca: v.marca || '',
        modelo: v.modelo || '',
        año: v.anio || v.año,
        ...v
    };
}

function fusionarVehiculos(lista) {
    const map = new Map();
    lista.forEach(v => {
        if (v && v.id) map.set(String(v.id), v);
    });
    appState.vehiculos = Array.from(map.values());
}

function mostrarErrores(lista) {
    const box = document.getElementById('orden-form-errores');
    if (!box) return;
    if (!lista.length) {
        box.style.display = 'none';
        box.innerHTML = '';
        return;
    }
    box.style.display = 'block';
    box.innerHTML = '<strong>Revise el formulario:</strong><ul style="margin:0.4rem 0 0;padding-left:1.2rem">' +
        lista.map(e => `<li>${e}</li>`).join('') + '</ul>';
}

function mapOrden(o) {
    const detalles = o.detalles || [];
    const servicios = detalles.map(d => ({
        id: String(d.id_servicio || ''),
        id_servicio: d.id_servicio,
        nombre: d.servicio?.nombre || ('Servicio #' + d.id_servicio),
        precio: Number(d.precio ?? d.subtotal ?? 0),
        cantidad: Number(d.cantidad || 1)
    }));
    const repuestos = (o.repuestos || []).map(r => ({
        id: String(r.id_producto || r.id_items || ''),
        nombre: r.producto || r.nombre || ('Producto #' + (r.id_producto || '')),
        precio: Number(r.precio_unitario ?? r.precio ?? 0),
        cantidad: Number(r.cantidad || 1),
        subtotal: Number(r.subtotal ?? 0)
    }));
    return {
        id: String(o.id_orden),
        id_orden: o.id_orden,
        clienteId: String(o.id_cliente || o.vehiculo?.id_cliente || ''),
        clienteNombre: o.cliente_nombre || o.vehiculo?.cliente_nombre || '—',
        clienteTelefono: o.cliente_telefono || o.vehiculo?.cliente_telefono || '',
        vehiculoId: String(o.id_vehiculo),
        vehiculoPlaca: o.placa || o.vehiculo?.placa || '—',
        vehiculoTipo: o.vehiculo_tipo || o.vehiculo?.tipo || '',
        vehiculoModelo: o.vehiculo_label || [o.vehiculo?.marca, o.vehiculo?.modelo].filter(Boolean).join(' ') || '—',
        fechaCreacion: (o.fecha_ingreso || '').slice(0, 10),
        fechaEntrega: o.fecha_salida ? String(o.fecha_salida).slice(0, 10) : '',
        estado: o.estado,
        mecanicoId: String(o.id_usuario || ''),
        mecanicoNombre: o.mecanico?.nombre || 'Sin asignar',
        servicios,
        repuestos,
        subtotal: Number(o.total_general || o.precio || 0),
        total: Number(o.total_con_repuestos || o.total_general || o.precio || 0),
        notas: o.descripcion || '',
        raw: o
    };
}

function esMecanicoUsuario(u) {
    const rol = (u.rol && (u.rol.nombre || u.rol)) || '';
    return String(rol).toLowerCase().includes('mec') || !!u.es_mecanico;
}

async function cargarCatalogos() {
    const [cliRes, vehRes, usrRes, srvRes] = await Promise.all([
        safeCall('clientes', () => window.apiClientes(true)),
        safeCall('vehículos', () => window.apiVehiculos(true)),
        safeCall('mecánicos', () => window.apiUsuarios(true)),
        safeCall('servicios', () => window.apiServicios({ estado: 'Activo' }))
    ]);
    appState.clientes = unwrap(cliRes).map(mapCliente).filter(c => c.id);
    const desdeClientes = [];
    appState.clientes.forEach(c => {
        (c.vehiculos || []).forEach(v => desdeClientes.push(mapVehiculo(v, c.id)));
    });
    fusionarVehiculos([...desdeClientes, ...unwrap(vehRes).map(v => mapVehiculo(v))]);
    const usuarios = unwrap(usrRes);
    appState.mecanicos = usuarios.filter(esMecanicoUsuario).map(u => ({
        id: String(u.id_usuario ?? u.id ?? ''),
        id_usuario: u.id_usuario ?? u.id,
        nombre: u.nombre,
        ...u
    })).filter(m => m.id);
    if (!appState.mecanicos.length) {
        appState.mecanicos = usuarios.filter(u => String(u.estado || 'Activo') === 'Activo').map(u => ({
            id: String(u.id_usuario ?? u.id ?? ''),
            id_usuario: u.id_usuario ?? u.id,
            nombre: u.nombre,
            ...u
        })).filter(m => m.id);
    }
    appState.serviciosCatalogo = unwrap(srvRes);
    llenarFiltroMecanicos();
    if (document.getElementById('modal-orden-form')?.classList.contains('active')) {
        const clienteActual = document.getElementById('orden-cliente')?.value;
        const vehiculoActual = document.getElementById('orden-vehiculo')?.value;
        const mecanicoActual = document.getElementById('orden-mecanico')?.value;
        cargarOpcionesClientes();
        cargarOpcionesMecanicos();
        if (clienteActual) {
            const sel = document.getElementById('orden-cliente');
            if (sel) sel.value = clienteActual;
            await cargarVehiculosCliente();
            const selVeh = document.getElementById('orden-vehiculo');
            if (selVeh && vehiculoActual) selVeh.value = vehiculoActual;
        }
        if (mecanicoActual) {
            const selMec = document.getElementById('orden-mecanico');
            if (selMec) selMec.value = mecanicoActual;
        }
    }
}

async function cargarDatos() {
    const [ord, cfg] = await Promise.all([
        safeCall('órdenes', () => window.apiOrdenes(true)),
        window.apiConfiguracion().catch(() => ({ data: {} })),
        cargarCatalogos()
    ]);
    appState.ordenes = unwrap(ord).map(mapOrden);
    const mapa = cfg.data?.mapa || cfg.data || {};
    appState.ivaActivo = mapa.iva_activo !== false && mapa.iva_activo !== 0 && mapa.iva_activo !== '0';
    appState.ivaPorcentaje = Number(mapa.iva_porcentaje ?? 19);
    renderizarTabla();
}

function llenarFiltroMecanicos() {
    const sel = document.getElementById('filter-mecanico');
    if (!sel) return;
    const actual = sel.value;
    sel.innerHTML = '<option value="todos">Todos los mecánicos</option>' +
        appState.mecanicos.map(m => `<option value="${m.id}">${m.nombre}</option>`).join('');
    sel.value = actual || 'todos';
}

function setupEventListeners() {
    if (setupEventListeners._bound) return;
    setupEventListeners._bound = true;
    document.getElementById('btn-nueva-orden')?.addEventListener('click', function (e) {
        e.preventDefault();
        openOrdenModal();
    });
    document.getElementById('btn-refresh')?.addEventListener('click', () => cargarDatos());
    document.getElementById('btn-guardar-orden')?.addEventListener('click', guardarOrden);
    document.getElementById('orden-cliente')?.addEventListener('change', cargarVehiculosCliente);
    if (window.ModuleCore) {
        ModuleCore.bindModalClose('modal-orden-form', 'btn-cancelar-orden', 'btn-cerrar-orden');
        ModuleCore.bindModalClose('modal-orden-detalle', 'btn-cerrar-detalle', 'btn-cerrar-detalle-2');
    }
    document.getElementById('filter-estado')?.addEventListener('change', aplicarFiltros);
    document.getElementById('filter-mecanico')?.addEventListener('change', aplicarFiltros);
    document.getElementById('search-orden')?.addEventListener('input', aplicarFiltros);
    document.getElementById('prev-page')?.addEventListener('click', () => cambiarPagina(-1));
    document.getElementById('next-page')?.addEventListener('click', () => cambiarPagina(1));
    document.getElementById('tabla-ordenes')?.addEventListener('click', e => {
        const btnVer = e.target.closest('.btn-ver');
        const btnEditar = e.target.closest('.btn-editar');
        const btnFacturar = e.target.closest('.btn-facturar');
        if (btnVer) verDetalleOrden(btnVer.dataset.id);
        else if (btnEditar) openOrdenModal(btnEditar.dataset.id);
        else if (btnFacturar) generarFactura(btnFacturar.dataset.id);
    });
    document.getElementById('btn-ir-catalogo-desde-orden')?.addEventListener('click', irAlCatalogoServicios);
    document.addEventListener('motorsoft:usuario-actualizado', () => {
        const btnCat = document.getElementById('btn-ir-catalogo-desde-orden');
        if (btnCat) btnCat.hidden = !puedeAdministrarCatalogo();
        const aviso = document.getElementById('servicios-catalogo-vacio');
        if (aviso && !appState.serviciosCatalogo.length) {
            aviso.hidden = false;
        }
        if (document.getElementById('modal-orden-form')?.classList.contains('active')) {
            pintarFilasServicios();
        }
    });
    document.addEventListener('motorsoft:servicios-actualizados', e => {
        const lista = Array.isArray(e.detail) ? e.detail : [];
        appState.serviciosCatalogo = lista.filter(s => String(s.estado || 'Activo') === 'Activo');
        if (document.getElementById('modal-orden-form')?.classList.contains('active')) {
            pintarFilasServicios();
            actualizarTotales();
        }
    });
}

function renderizarTabla() {
    const tbody = document.querySelector('#tabla-ordenes tbody');
    if (!tbody) return;
    const ordenesFiltradas = filtrarOrdenes();
    const inicio = (appState.paginacion.paginaActual - 1) * appState.paginacion.itemsPorPagina;
    const fin = inicio + appState.paginacion.itemsPorPagina;
    const pagina = ordenesFiltradas.slice(inicio, fin);
    appState.paginacion.totalPaginas = Math.max(1, Math.ceil(ordenesFiltradas.length / appState.paginacion.itemsPorPagina));
    if (!pagina.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">No se encontraron órdenes</td></tr>';
    } else {
        tbody.innerHTML = pagina.map(orden => `
            <tr>
                <td><strong>#${orden.id}</strong></td>
                <td>${escHtml(orden.clienteNombre)}</td>
                <td>${escHtml(orden.vehiculoPlaca)}${orden.vehiculoTipo ? ' · ' + escHtml(orden.vehiculoTipo) : ''} - ${escHtml(orden.vehiculoModelo)}</td>
                <td>${escHtml(orden.mecanicoNombre)}</td>
                <td><span class="badge ${obtenerClaseBadge(orden.estado)}">${escHtml(orden.estado)}</span></td>
                <td>${money(orden.total)}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn-icon btn-sm btn-ver" data-id="${orden.id}" title="Ver" type="button"><i class="fas fa-eye"></i></button>
                        ${puedeEditarOrden() ? `<button class="btn-icon btn-sm btn-editar" data-id="${orden.id}" title="Editar" type="button"><i class="fas fa-edit"></i></button>` : ''}
                        ${ESTADOS_FACTURABLES.includes(orden.estado) && puedeFacturarOrden() ? `<button class="btn-icon btn-sm btn-facturar" data-id="${orden.id}" title="Facturar" type="button"><i class="fas fa-file-invoice"></i></button>` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }
    actualizarPaginacion();
}

function filtrarOrdenes() {
    let resultado = [...appState.ordenes];
    if (appState.filtros.estado !== 'todos') resultado = resultado.filter(o => o.estado === appState.filtros.estado);
    if (appState.filtros.mecanico !== 'todos') resultado = resultado.filter(o => o.mecanicoId === appState.filtros.mecanico);
    if (appState.filtros.busqueda) {
        const t = appState.filtros.busqueda.toLowerCase();
        resultado = resultado.filter(o =>
            String(o.id).includes(t) ||
            (o.clienteNombre || '').toLowerCase().includes(t) ||
            (o.vehiculoPlaca || '').toLowerCase().includes(t)
        );
    }
    return resultado;
}

function aplicarFiltros() {
    appState.filtros.estado = document.getElementById('filter-estado')?.value || 'todos';
    appState.filtros.mecanico = document.getElementById('filter-mecanico')?.value || 'todos';
    appState.filtros.busqueda = document.getElementById('search-orden')?.value || '';
    appState.paginacion.paginaActual = 1;
    renderizarTabla();
}

function actualizarPaginacion() {
    const { paginaActual, totalPaginas } = appState.paginacion;
    const span = document.querySelector('.pagination span');
    if (span) span.textContent = `Página ${paginaActual} de ${totalPaginas}`;
    const btnPrev = document.getElementById('prev-page');
    const btnNext = document.getElementById('next-page');
    if (btnPrev) btnPrev.disabled = paginaActual <= 1;
    if (btnNext) btnNext.disabled = paginaActual >= totalPaginas;
}

function cambiarPagina(delta) {
    const n = appState.paginacion.paginaActual + delta;
    if (n < 1 || n > appState.paginacion.totalPaginas) return;
    appState.paginacion.paginaActual = n;
    renderizarTabla();
}

function pintarModalVisible(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.add('active', 'show');
    modal.style.display = 'flex';
    modal.style.opacity = '1';
    modal.style.visibility = 'visible';
}

async function openOrdenModal(id = null) {
    const orden = id ? appState.ordenes.find(o => o.id === String(id)) : null;
    appState.ordenActual = orden || null;
    mostrarErrores([]);
    const titulo = document.getElementById('modal-orden-title');
    if (titulo) titulo.textContent = orden ? `Editar Orden #${orden.id}` : 'Nueva Orden de Trabajo';
    document.getElementById('form-orden')?.reset();
    const selCliente = document.getElementById('orden-cliente');
    const selVehiculo = document.getElementById('orden-vehiculo');
    const selMecanico = document.getElementById('orden-mecanico');
    const selEstado = document.getElementById('orden-estado');
    const fecha = document.getElementById('orden-fecha-entrega');
    const notas = document.getElementById('orden-notas');
    if (selCliente) {
        selCliente.disabled = false;
        selCliente.innerHTML = '<option value="">Cargando clientes...</option>';
    }
    if (selVehiculo) {
        selVehiculo.disabled = false;
        selVehiculo.innerHTML = '<option value="">Seleccione un cliente</option>';
    }
    if (selMecanico) {
        selMecanico.innerHTML = '<option value="">Cargando mecánicos...</option>';
    }
    if (window.ModuleCore) ModuleCore.openModal('modal-orden-form');
    else pintarModalVisible('modal-orden-form');
    await cargarCatalogos();
    cargarOpcionesClientes();
    cargarOpcionesMecanicos();
    if (orden) {
        if (selCliente) {
            selCliente.value = orden.clienteId;
            selCliente.disabled = true;
        }
        await cargarVehiculosCliente();
        if (selVehiculo) {
            selVehiculo.value = orden.vehiculoId;
            selVehiculo.disabled = true;
        }
        if (selMecanico) selMecanico.value = orden.mecanicoId;
        if (selEstado) selEstado.value = ESTADOS_ORDEN.includes(orden.estado) ? orden.estado : 'Pendiente';
        if (fecha) fecha.value = orden.fechaEntrega || '';
        if (notas) notas.value = orden.notas || '';
        appState.serviciosOrden = (orden.servicios || []).map(s => ({
            id: String(s.id_servicio || s.id || ''),
            nombre: s.nombre,
            precio: Number(s.precio || 0),
            cantidad: Number(s.cantidad || 1)
        }));
    } else {
        if (selCliente) selCliente.disabled = false;
        if (selVehiculo) selVehiculo.disabled = false;
        if (selEstado) selEstado.value = 'Pendiente';
        appState.serviciosOrden = [];
        if (selVehiculo) selVehiculo.innerHTML = '<option value="">Seleccione un vehículo</option>';
    }
    pintarFilasServicios();
    actualizarTotales();
}

function cargarOpcionesClientes() {
    const select = document.getElementById('orden-cliente');
    if (!select) return;
    const actual = select.value;
    select.innerHTML = '<option value="">Seleccione un cliente</option>' +
        appState.clientes.map(cliente =>
            `<option value="${cliente.id}">${cliente.nombre}${cliente.cedula ? ' - ' + cliente.cedula : ''}</option>`
        ).join('');
    if (actual && [...select.options].some(o => o.value === actual)) select.value = actual;
    if (!appState.clientes.length) {
        select.innerHTML = '<option value="">No hay clientes en la base de datos</option>';
    }
}

async function cargarVehiculosCliente() {
    const clienteId = document.getElementById('orden-cliente')?.value;
    const select = document.getElementById('orden-vehiculo');
    if (!select) return;
    if (!clienteId) {
        select.innerHTML = '<option value="">Seleccione un vehículo</option>';
        return;
    }
    const bloqueado = !!appState.ordenActual;
    const actual = select.value || (appState.ordenActual ? appState.ordenActual.vehiculoId : '');
    select.innerHTML = '<option value="">Cargando vehículos...</option>';
    try {
        const res = await window.apiVehiculos(true, { id_cliente: clienteId });
        fusionarVehiculos([...appState.vehiculos, ...unwrap(res).map(v => mapVehiculo(v, clienteId))]);
    } catch (e) {
        console.error('Órdenes: vehículos del cliente', e);
    }
    const cli = appState.clientes.find(c => c.id === String(clienteId));
    (cli?.vehiculos || []).forEach(v => fusionarVehiculos([...appState.vehiculos, mapVehiculo(v, clienteId)]));
    const lista = appState.vehiculos.filter(v => String(v.clienteId) === String(clienteId));
    select.innerHTML = '<option value="">Seleccione un vehículo</option>' +
        lista.map(vehiculo =>
            `<option value="${vehiculo.id}">${vehiculo.placa}${vehiculo.tipo ? ' · ' + vehiculo.tipo : ''} - ${vehiculo.marca} ${vehiculo.modelo}</option>`
        ).join('');
    if (!lista.length) {
        select.innerHTML = '<option value="">Este cliente no tiene vehículos</option>';
    } else if (actual && [...select.options].some(o => o.value === actual)) {
        select.value = actual;
    }
    select.disabled = bloqueado;
}

function cargarOpcionesMecanicos() {
    const select = document.getElementById('orden-mecanico');
    if (!select) return;
    const actual = select.value;
    select.innerHTML = '<option value="">Seleccione mecánico</option>' +
        appState.mecanicos.map(m => `<option value="${m.id}">${m.nombre}</option>`).join('');
    if (actual && [...select.options].some(o => o.value === actual)) select.value = actual;
    if (!appState.mecanicos.length) {
        select.innerHTML = '<option value="">No hay mecánicos registrados</option>';
    }
}

function opcionesServiciosHtml(selected) {
    return '<option value="">Seleccione un servicio</option>' +
        appState.serviciosCatalogo.map(s => {
            const sel = String(s.id_servicio) === String(selected) ? ' selected' : '';
            return `<option value="${s.id_servicio}" data-precio="${s.precio}"${sel}>${s.nombre}</option>`;
        }).join('');
}

function irAlCatalogoServicios() {
    window.cerrarModalOrden?.();
    document.querySelector('#modulo-ordenes [data-tab="catalogo"]')?.click();
    return false;
}

function pintarFilasServicios() {
    const lista = document.getElementById('servicios-lista');
    const aviso = document.getElementById('servicios-catalogo-vacio');
    if (aviso) aviso.hidden = appState.serviciosCatalogo.length > 0;
    const btnAdd = document.getElementById('btn-agregar-servicio');
    if (btnAdd) btnAdd.disabled = !appState.serviciosCatalogo.length;
    if (!lista) return;
    if (!appState.serviciosOrden.length) {
        lista.innerHTML = '';
        return;
    }
    const editable = puedeEditarPrecio();
    lista.innerHTML = appState.serviciosOrden.map((s, index) => `
        <div class="servicio-item" data-index="${index}">
            <div class="form-grid">
                <div class="form-group">
                    <label>Servicio</label>
                    <select class="servicio-select" data-index="${index}" required>
                        ${opcionesServiciosHtml(s.id)}
                    </select>
                </div>
                <div class="form-group">
                    <label>Precio ${editable ? '' : '<small class="text-muted">(catálogo)</small>'}</label>
                    <input type="number" class="servicio-precio" data-index="${index}" value="${s.precio || 0}" min="0" step="1000" required ${editable ? '' : 'readonly tabindex="-1"'} title="${editable ? 'Puede ajustar el precio de esta línea' : 'El precio lo define el catálogo. Solo un administrador o gerente puede cambiarlo.'}">
                </div>
                <div class="form-group">
                    <button type="button" class="btn btn-danger btn-sm" onclick="return window.eliminarServicio(${index});"><i class="fas fa-trash"></i></button>
                </div>
            </div>
        </div>
    `).join('');
    lista.querySelectorAll('.servicio-select').forEach(sel => {
        sel.addEventListener('change', function () {
            const idx = Number(this.dataset.index);
            const precio = this.options[this.selectedIndex]?.dataset.precio || 0;
            const input = lista.querySelector(`.servicio-precio[data-index="${idx}"]`);
            if (input) input.value = precio;
            actualizarServicio(idx);
        });
    });
    lista.querySelectorAll('.servicio-precio').forEach(inp => {
        if (!editable) return;
        inp.addEventListener('input', () => actualizarServicio(Number(inp.dataset.index)));
    });
}

function agregarServicio() {
    appState.serviciosOrden.push({ id: '', nombre: '', precio: 0, cantidad: 1 });
    pintarFilasServicios();
    actualizarTotales();
    return false;
}

function actualizarServicio(index) {
    const select = document.querySelector(`.servicio-select[data-index="${index}"]`);
    const precioInput = document.querySelector(`.servicio-precio[data-index="${index}"]`);
    if (!select || !precioInput) return;
    appState.serviciosOrden[index] = {
        id: select.value,
        nombre: select.options[select.selectedIndex]?.text || '',
        precio: parseFloat(precioInput.value) || 0,
        cantidad: 1
    };
    actualizarTotales();
}

function eliminarServicio(index) {
    appState.serviciosOrden.splice(index, 1);
    pintarFilasServicios();
    actualizarTotales();
    return false;
}

function calcIva(subtotal) {
    const iva = appState.ivaActivo ? Math.round(subtotal * (appState.ivaPorcentaje / 100)) : 0;
    return { subtotal, iva, total: subtotal + iva };
}

function actualizarTotales() {
    const subtotal = appState.serviciosOrden.reduce((sum, s) => sum + (Number(s.precio) || 0) * (Number(s.cantidad) || 1), 0);
    const t = calcIva(subtotal);
    const ivaLabel = document.getElementById('orden-iva-label');
    if (ivaLabel) {
        ivaLabel.textContent = appState.ivaActivo
            ? `IVA (${appState.ivaPorcentaje}% configuración del taller):`
            : 'IVA (desactivado en configuración):';
    }
    const elSub = document.getElementById('orden-subtotal');
    const elIva = document.getElementById('orden-iva');
    const elTot = document.getElementById('orden-total');
    if (elSub) elSub.textContent = money(t.subtotal);
    if (elIva) elIva.textContent = money(t.iva);
    if (elTot) elTot.textContent = money(t.total);
}

function leerServiciosDelFormulario() {
    const items = [];
    document.querySelectorAll('#servicios-lista .servicio-item').forEach(row => {
        const select = row.querySelector('.servicio-select');
        const precio = row.querySelector('.servicio-precio');
        items.push({
            id: select?.value || '',
            nombre: select?.options[select.selectedIndex]?.text || '',
            precio: parseFloat(precio?.value || 0),
            cantidad: 1
        });
    });
    appState.serviciosOrden = items;
    return items;
}

async function guardarOrden() {
    leerServiciosDelFormulario();
    const vehiculoId = document.getElementById('orden-vehiculo')?.value;
    const mecanicoId = document.getElementById('orden-mecanico')?.value;
    const estado = document.getElementById('orden-estado')?.value || 'Pendiente';
    const fechaEntrega = document.getElementById('orden-fecha-entrega')?.value || '';
    const notas = document.getElementById('orden-notas')?.value || '';
    const serviciosValidos = appState.serviciosOrden.filter(s => s.id && Number(s.precio) >= 0);
    const errores = [];
    if (!appState.ordenActual && !vehiculoId) errores.push('Seleccione el vehículo del cliente.');
    if (!mecanicoId) errores.push('Asigne un mecánico.');
    if (!serviciosValidos.length) errores.push('Agregue al menos un servicio del catálogo.');
    if (!ESTADOS_ORDEN.includes(estado)) errores.push('Estado no válido.');
    mostrarErrores(errores);
    if (errores.length) {
        window.showToast?.(errores[0], 'error');
        return;
    }
    const payload = {
        id_vehiculo: Number(vehiculoId),
        id_usuario: Number(mecanicoId),
        descripcion: notas,
        estado,
        servicios: serviciosValidos.map(s => ({
            id_servicio: Number(s.id),
            precio: Number(s.precio),
            cantidad: Number(s.cantidad || 1)
        }))
    };
    if (fechaEntrega) payload.fecha_salida = fechaEntrega;
    try {
        if (appState.ordenActual) {
            await window.apiOrdenesActualizar(appState.ordenActual.id_orden, {
                id_orden: appState.ordenActual.id_orden,
                ...payload
            });
            window.showToast?.('Orden actualizada', 'success');
        } else {
            await window.apiOrdenes(false, payload);
            window.showToast?.('Orden creada', 'success');
        }
        if (window.ModuleCore) ModuleCore.closeModal('modal-orden-form');
        else window.cerrarModalOrden?.();
        await cargarDatos();
    } catch (e) {
        mostrarErrores([e.message || 'No se pudo guardar']);
        window.showToast?.(e.message || 'No se pudo guardar', 'error');
    }
}

async function verDetalleOrden(id) {
    let orden = appState.ordenes.find(o => o.id === String(id) || String(o.id_orden) === String(id));
    if (!orden) {
        try {
            const res = await window.apiOrdenes(true, { id });
            const raw = Array.isArray(res?.data) ? res.data[0] : res?.data;
            if (!raw || !raw.id_orden) {
                throw new Error('Orden no encontrada');
            }
            orden = mapOrden(raw);
            if (!appState.ordenes.some(o => o.id === orden.id)) {
                appState.ordenes.unshift(orden);
            }
        } catch (e) {
            window.showToast?.(e.message || 'No se pudo abrir la orden', 'error');
            return;
        }
    }
    const serviciosHTML = (orden.servicios || []).map(s => `<div class="detalle-item"><span>${escHtml(s.nombre)}</span><span>${money((s.precio || 0) * (s.cantidad || 1))}</span></div>`).join('');
    const repuestosHTML = (orden.repuestos || []).map(r => `<div class="detalle-item"><span>${escHtml(r.nombre)} ×${r.cantidad || 1}</span><span>${money(r.subtotal || r.precio)}</span></div>`).join('');
    const linkCliente = orden.clienteId
        ? `<a href="../clientes/index.php?cliente=${encodeURIComponent(orden.clienteId)}">${escHtml(orden.clienteNombre)}</a>`
        : escHtml(orden.clienteNombre);
    const linkVehiculo = orden.vehiculoId
        ? `<a href="../clientes/index.php?vehiculo=${encodeURIComponent(orden.vehiculoId)}">${escHtml(orden.vehiculoPlaca)}${orden.vehiculoTipo ? ' · ' + escHtml(orden.vehiculoTipo) : ''} - ${escHtml(orden.vehiculoModelo)}</a>`
        : `${escHtml(orden.vehiculoPlaca)}${orden.vehiculoTipo ? ' · ' + escHtml(orden.vehiculoTipo) : ''} - ${escHtml(orden.vehiculoModelo)}`;
    const body = document.getElementById('orden-detalle-body');
    const titulo = document.getElementById('modal-orden-detalle-title');
    if (titulo) titulo.textContent = `Orden #${orden.id}`;
    if (body) {
        body.innerHTML = `
            <div class="orden-detalle-grid">
                <div class="detalle-card">
                    <h4>Información</h4>
                    <p><strong>ID:</strong> #${orden.id}</p>
                    <p><strong>Cliente:</strong> ${linkCliente}</p>
                    <p><strong>Vehículo:</strong> ${linkVehiculo}</p>
                    <p><strong>Mecánico:</strong> ${escHtml(orden.mecanicoNombre)}</p>
                    <p><strong>Estado:</strong> ${escHtml(orden.estado)}</p>
                    <p><strong>Ingreso:</strong> ${escHtml(orden.fechaCreacion || '—')}</p>
                    <p><strong>Entrega:</strong> ${escHtml(orden.fechaEntrega || '—')}</p>
                    <p><strong>Total:</strong> ${money(orden.total)}</p>
                    ${orden.notas ? `<p><strong>Notas:</strong> ${escHtml(orden.notas)}</p>` : ''}
                </div>
                <div class="detalle-card">
                    <h4>Servicios</h4>${serviciosHTML || '<p>Sin servicios</p>'}
                    <h4 style="margin-top:1rem">Repuestos</h4>${repuestosHTML || '<p>Sin repuestos cargados por el mecánico</p>'}
                </div>
            </div>
            <div class="detalle-card" style="margin-top:1rem">
                <h4><i class="fas fa-camera"></i> Evidencias</h4>
                <div id="orden-evidencias-lista"><p class="text-muted">Cargando...</p></div>
                <input type="file" id="orden-evidencia-file" accept="image/jpeg,image/png,image/gif,application/pdf" hidden>
                <button type="button" class="btn btn-outline btn-sm" id="btn-subir-evidencia-orden" style="margin-top:0.75rem">
                    <i class="fas fa-upload"></i> Subir foto o PDF
                </button>
            </div>
            <p style="margin-top:1rem;display:flex;gap:0.5rem;flex-wrap:wrap">
                <a class="btn btn-outline" href="../chat/index-trabajadores.php?orden=${encodeURIComponent(orden.id)}"><i class="fas fa-comments"></i> Chat con el cliente</a>
                ${ESTADOS_FACTURABLES.includes(orden.estado) && puedeFacturarOrden() ? `<button type="button" class="btn btn-primary" onclick="window.generarFactura('${orden.id}')"><i class="fas fa-file-invoice"></i> Facturar esta orden</button>` : ''}
            </p>`;
    }
    if (window.ModuleCore) ModuleCore.openModal('modal-orden-detalle');
    else pintarModalVisible('modal-orden-detalle');
    bindEvidenciasOrden(orden.id_orden || orden.id);
}

async function pintarEvidenciasOrden(idOrden, box) {
    if (!box || !idOrden || typeof window.apiAdjuntos !== 'function') return;
    try {
        const res = await window.apiAdjuntos({ entidad_tipo: 'orden', entidad_id: idOrden });
        const lista = Array.isArray(res.data) ? res.data : [];
        box.innerHTML = typeof window.htmlGaleriaEvidencias === 'function'
            ? window.htmlGaleriaEvidencias(lista, 'Sin fotos ni documentos. Suba evidencias de la reparación.')
            : '<p class="text-muted">Sin evidencias.</p>';
    } catch (e) {
        box.innerHTML = '<p class="text-muted">No se pudieron cargar las evidencias.</p>';
    }
}

function bindEvidenciasOrden(idOrden) {
    const box = document.getElementById('orden-evidencias-lista');
    const input = document.getElementById('orden-evidencia-file');
    const btn = document.getElementById('btn-subir-evidencia-orden');
    pintarEvidenciasOrden(idOrden, box);
    btn?.addEventListener('click', () => input?.click());
    input?.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        try {
            await window.apiAdjuntoSubir(file, 'orden', idOrden);
            window.showToast?.('Evidencia cargada', 'success');
            await pintarEvidenciasOrden(idOrden, box);
        } catch (e) {
            window.showToast?.(e.message || 'No se pudo subir', 'error');
        } finally {
            input.value = '';
        }
    });
}

function generarFactura(id) {
    const orden = appState.ordenes.find(o => o.id === String(id));
    const oid = orden ? orden.id_orden : id;
    window.location.href = `../facturacion/index.php?orden=${encodeURIComponent(oid)}`;
}

function obtenerClaseBadge(estado) {
    const e = String(estado || '').toLowerCase();
    if (e.includes('complet')) return 'bg-success';
    if (e.includes('proceso')) return 'bg-warning';
    if (e.includes('pago')) return 'bg-info';
    if (e.includes('cancel')) return 'bg-danger';
    if (e.includes('diagn')) return 'bg-primary';
    return 'bg-secondary';
}

let ordenesBooted = false;
function bootOrdenes() {
    if (ordenesBooted) return;
    ordenesBooted = true;
    setupEventListeners();
    const btnNueva = document.getElementById('btn-nueva-orden');
    if (btnNueva && window.MotorSoftGuard && !window.MotorSoftGuard.puede('ordenes.crear')) {
        btnNueva.hidden = true;
    }
    const btnCat = document.getElementById('btn-ir-catalogo-desde-orden');
    if (btnCat && !puedeAdministrarCatalogo()) {
        btnCat.hidden = true;
    }
    cargarDatos().then(() => {
        const pendiente = window._ordenModalPendiente;
        if (pendiente != null) {
            window._ordenModalPendiente = null;
            openOrdenModal(pendiente === true ? null : pendiente);
            return;
        }
        const params = new URLSearchParams(window.location.search);
        const idOrden = params.get('orden') || params.get('id');
        if (idOrden) verDetalleOrden(idOrden);
    });
}

window.agregarServicio = agregarServicio;
window.eliminarServicio = eliminarServicio;
window.openOrdenModal = openOrdenModal;
window.generarFactura = generarFactura;
window.irAlCatalogoServicios = irAlCatalogoServicios;
window.abrirModalOrden = function (id) {
    openOrdenModal(id || null);
    return false;
};

document.addEventListener('DOMContentLoaded', bootOrdenes);
if (document.readyState !== 'loading') {
    bootOrdenes();
}
