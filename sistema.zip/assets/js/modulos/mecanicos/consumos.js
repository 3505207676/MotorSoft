/**
 * Consumo de repuestos sobre una orden asignada.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;

    const state = {
        ordenes: [],
        orden: null,
        productos: [],
        consumos: [],
        productoId: '',
        busqueda: ''
    };

    function params() {
        return new URLSearchParams(window.location.search);
    }

    function htmlOrdenResumen(o) {
        return (
            '<div class="orden-header">' +
                '<h2>' + Map().esc(o.numero) + '</h2>' +
                '<span class="status-badge status-' + Map().claseEstado(o.estado) + '">' + Map().esc(o.estado) + '</span>' +
            '</div>' +
            '<div class="orden-details">' +
                '<div class="detail-row"><span class="label">Cliente:</span><span class="value">' + Map().esc(o.clienteNombre) + '</span></div>' +
                '<div class="detail-row"><span class="label">Vehículo:</span><span class="value">' + Map().esc(o.vehiculoModelo || o.vehiculoPlaca) + '</span></div>' +
            '</div>'
        );
    }

    function pintarSelector() {
        const box = document.getElementById('orden-info');
        if (!box) return;
        const abiertas = state.ordenes.filter(o => !['Completada', 'Cancelada', 'Pendiente Pago'].includes(o.estado));
        if (!abiertas.length) {
            box.innerHTML = '<div class="empty-state"><i class="fas fa-clipboard-list"></i><p>No tienes órdenes abiertas para cargar repuestos</p></div>';
            return;
        }
        box.innerHTML =
            '<label for="select-orden">Orden de trabajo</label>' +
            '<select id="select-orden" class="form-control">' +
                '<option value="">Selecciona una orden</option>' +
                abiertas.map(o => '<option value="' + Map().esc(o.id) + '">' + Map().esc(o.numero + ' · ' + o.clienteNombre) + '</option>').join('') +
            '</select>';
        const sel = document.getElementById('select-orden');
        sel.addEventListener('change', function () {
            if (this.value) cargarOrden(this.value);
        });
    }

    function pintarConsumos() {
        const box = document.getElementById('consumos-lista');
        if (!box) return;
        if (!state.consumos.length) {
            box.innerHTML = '<p class="text-muted">Aún no hay repuestos en esta orden</p>';
            return;
        }
        box.innerHTML = state.consumos.map(c => (
            '<div class="consumo-item">' +
                '<strong>' + Map().esc(c.producto || c.nombre || 'Producto') + '</strong>' +
                '<span>' + Map().esc(c.referencia || '') + '</span>' +
                '<span>x' + (c.cantidad || 0) + '</span>' +
                '<span>$' + Map().moneda(c.subtotal || 0) + '</span>' +
            '</div>'
        )).join('');
    }

    function productosFiltrados() {
        let lista = state.productos.filter(p => p.cantidad > 0);
        if (state.busqueda) {
            const q = state.busqueda.toLowerCase();
            lista = lista.filter(p =>
                String(p.nombre).toLowerCase().includes(q) ||
                String(p.codigo).toLowerCase().includes(q)
            );
        }
        return lista;
    }

    function pintarFormulario() {
        const form = document.getElementById('form-consumo');
        if (!form || !state.orden) return;
        const pref = params().get('producto') || state.productoId;
        form.innerHTML =
            '<div class="form-group">' +
                '<label for="search-producto">Buscar producto</label>' +
                '<input type="text" id="search-producto" placeholder="Nombre o código">' +
            '</div>' +
            '<div class="form-group">' +
                '<label for="select-producto">Producto</label>' +
                '<select id="select-producto" required>' +
                    '<option value="">Selecciona</option>' +
                    productosFiltrados().map(p => {
                        const sel = String(p.id) === String(pref) ? ' selected' : '';
                        return '<option value="' + Map().esc(p.id) + '"' + sel + '>' + Map().esc(p.nombre + ' · ' + p.codigo + ' (' + p.cantidad + ')') + '</option>';
                    }).join('') +
                '</select>' +
            '</div>' +
            '<div class="form-group">' +
                '<label for="cantidad-consumo">Cantidad</label>' +
                '<input type="number" id="cantidad-consumo" min="1" value="1" required>' +
            '</div>' +
            '<button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Registrar consumo</button>';
        const search = document.getElementById('search-producto');
        if (search) {
            search.value = state.busqueda;
            search.addEventListener('input', function () {
                state.busqueda = this.value.trim();
                state.productoId = document.getElementById('select-producto').value;
                pintarFormulario();
                const next = document.getElementById('search-producto');
                if (next) {
                    next.focus();
                    next.setSelectionRange(next.value.length, next.value.length);
                }
            });
        }
        form.onsubmit = enviar;
    }

    async function cargarOrden(id) {
        try {
            Shell().showLoading('Cargando orden...');
            const [orden, consumos, productos] = await Promise.all([
                window.obtenerOrden(id),
                window.apiConsumosObtener({ id_orden: id }),
                window.obtenerProductos()
            ]);
            state.orden = orden;
            state.consumos = Array.isArray(consumos.data) ? consumos.data : [];
            state.productos = (productos || []).map(window.MecanicoMap.producto).filter(Boolean);
            const box = document.getElementById('orden-info');
            if (box) box.innerHTML = htmlOrdenResumen(orden);
            pintarConsumos();
            pintarFormulario();
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo cargar la orden', 'error');
        } finally {
            Shell().hideLoading();
        }
    }

    async function enviar(e) {
        e.preventDefault();
        if (!state.orden) return;
        const idProducto = document.getElementById('select-producto').value;
        const cantidad = Number(document.getElementById('cantidad-consumo').value) || 0;
        if (!idProducto || cantidad < 1) {
            Shell().showToast('Selecciona producto y cantidad', 'warning');
            return;
        }
        const prod = state.productos.find(p => String(p.id) === String(idProducto));
        const disponible = Number(prod?.cantidad ?? 0);
        if (!prod || cantidad > disponible) {
            Shell().showToast(prod
                ? ('Solo hay ' + disponible + ' unidades de ' + prod.nombre)
                : 'Ese producto no tiene stock', 'warning');
            return;
        }
        try {
            await window.apiConsumosCrear({
                id_orden: state.orden.id_orden || state.orden.id,
                id_producto: idProducto,
                cantidad
            });
            Shell().showToast('Consumo registrado', 'success');
            await cargarOrden(state.orden.id_orden || state.orden.id);
        } catch (err) {
            Shell().showToast(err.message || 'No se pudo registrar el consumo', 'error');
        }
    }

    async function init() {
        const ordenId = params().get('orden') || params().get('id');
        const producto = params().get('producto');
        if (producto) state.productoId = producto;
        if (ordenId) {
            await cargarOrden(ordenId);
            return;
        }
        try {
            const lista = await window.obtenerOrdenes();
            state.ordenes = Array.isArray(lista) ? lista : [];
            pintarSelector();
        } catch (e) {
            const box = document.getElementById('orden-info');
            if (box) box.innerHTML = '<div class="error-state"><p>' + Map().esc(e.message || 'Error cargando órdenes') + '</p></div>';
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoConsumos = { init };
})(window);
