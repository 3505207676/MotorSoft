/**
 * Cromo de la app mecánicos: tema, toasts y overlay de carga.
 */
(function (window) {
    const THEME_KEY = 'tema';

    function temaGuardado() {
        return window.MotorSoftTema
            ? window.MotorSoftTema.leer()
            : (localStorage.getItem(THEME_KEY) === 'dark' ? 'dark' : 'light');
    }

    function aplicarTema(tema) {
        if (window.MotorSoftTema) return window.MotorSoftTema.aplicar(tema);
        const valor = tema === 'dark' ? 'dark' : 'light';
        document.body.setAttribute('data-theme', valor);
        document.documentElement.setAttribute('data-theme', valor);
        localStorage.setItem(THEME_KEY, valor);
        localStorage.setItem('mecanicos-theme', valor);
        const icon = document.getElementById('theme-icon');
        if (icon) {
            icon.className = valor === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        return valor;
    }

    function toggleTema() {
        const nuevo = window.MotorSoftTema
            ? window.MotorSoftTema.toggle()
            : aplicarTema(temaGuardado() === 'dark' ? 'light' : 'dark');
        showToast(nuevo === 'dark' ? 'Modo oscuro activado' : 'Modo claro activado', 'info');
        return nuevo;
    }

    function asegurarToastContainer() {
        let box = document.getElementById('toast-container');
        if (!box) {
            box = document.createElement('div');
            box.id = 'toast-container';
            box.className = 'toast-container';
            document.body.appendChild(box);
        }
        return box;
    }

    function showToast(message, type) {
        const box = asegurarToastContainer();
        const toast = document.createElement('div');
        toast.className = 'toast toast-' + (type || 'info');
        const icon = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        }[type] || 'fas fa-info-circle';
        toast.innerHTML = '<i class="' + icon + '"></i><span></span>';
        toast.querySelector('span').textContent = String(message || '');
        box.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    function showLoading(text) {
        let overlay = document.getElementById('loading-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loading-overlay';
            overlay.className = 'loading-overlay hidden';
            overlay.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i><p id="loading-text">Cargando...</p></div>';
            document.body.appendChild(overlay);
        }
        const label = document.getElementById('loading-text');
        if (label) label.textContent = text || 'Cargando...';
        overlay.classList.remove('hidden');
    }

    function hideLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) overlay.classList.add('hidden');
    }

    function drawer() {
        return document.getElementById('menu-drawer');
    }

    function overlay() {
        return document.getElementById('menu-overlay');
    }

    function menuAbierto() {
        const panel = drawer();
        return !!(panel && panel.classList.contains('is-open'));
    }

    function pintarUsuarioMenu() {
        const sesion = window.MecanicoSesion;
        const u = sesion && typeof sesion.usuario === 'function' ? sesion.usuario() : null;
        const nombre = sesion && typeof sesion.nombre === 'function' ? sesion.nombre() : (u && u.nombre) || 'Mecánico';
        let rol = 'Mecánico';
        if (u && u.rol) {
            rol = typeof u.rol === 'object' ? (u.rol.nombre || 'Mecánico') : String(u.rol);
        }
        const nameEl = document.getElementById('menu-user-name');
        const roleEl = document.getElementById('menu-user-role');
        const av = document.getElementById('menu-avatar');
        if (nameEl) nameEl.textContent = nombre;
        if (roleEl) roleEl.textContent = rol;
        if (av) {
            av.textContent = String(nombre)
                .split(/\s+/)
                .slice(0, 2)
                .map(function (p) { return p.charAt(0).toUpperCase(); })
                .join('') || 'M';
        }
    }

    function abrirMenu() {
        const panel = drawer();
        const fondo = overlay();
        const btn = document.getElementById('btn-menu');
        if (!panel) return;
        pintarUsuarioMenu();
        panel.classList.add('is-open');
        panel.setAttribute('aria-hidden', 'false');
        if (fondo) {
            fondo.hidden = false;
            fondo.classList.add('is-open');
        }
        if (btn) btn.setAttribute('aria-expanded', 'true');
        document.body.classList.add('menu-open');
    }

    function cerrarMenu() {
        const panel = drawer();
        const fondo = overlay();
        const btn = document.getElementById('btn-menu');
        if (panel) {
            panel.classList.remove('is-open');
            panel.setAttribute('aria-hidden', 'true');
        }
        if (fondo) {
            fondo.classList.remove('is-open');
            fondo.hidden = true;
        }
        if (btn) btn.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('menu-open');
    }

    function toggleMenu() {
        if (menuAbierto()) cerrarMenu();
        else abrirMenu();
    }

    async function cerrarSesion() {
        if (!window.confirm('¿Cerrar sesión?')) return;
        cerrarMenu();
        showLoading('Cerrando sesión...');
        try {
            if (typeof window.apiLogout === 'function') {
                await window.apiLogout();
            }
        } catch (e) {
            /* se limpia igual */
        } finally {
            if (window.MotorSoftGuard && typeof window.MotorSoftGuard.limpiar === 'function') {
                window.MotorSoftGuard.limpiar();
            } else {
                localStorage.removeItem('motorsoft_token');
                localStorage.removeItem('motorsoft_usuario');
                localStorage.removeItem('motorsoft_sesion');
            }
            hideLoading();
            window.location.replace('../auth/login.php');
        }
    }

    function initMenu() {
        const btn = document.getElementById('btn-menu');
        const cerrar = document.getElementById('btn-cerrar-menu');
        const fondo = overlay();
        const salir = document.getElementById('btn-cerrar-sesion');
        if (btn && !btn.dataset.bound) {
            btn.dataset.bound = '1';
            btn.addEventListener('click', toggleMenu);
        }
        if (cerrar && !cerrar.dataset.bound) {
            cerrar.dataset.bound = '1';
            cerrar.addEventListener('click', cerrarMenu);
        }
        if (fondo && !fondo.dataset.bound) {
            fondo.dataset.bound = '1';
            fondo.addEventListener('click', cerrarMenu);
        }
        if (salir && !salir.dataset.bound) {
            salir.dataset.bound = '1';
            salir.addEventListener('click', cerrarSesion);
        }
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && menuAbierto()) cerrarMenu();
        });
        pintarUsuarioMenu();
    }

    function init() {
        initMenu();
    }

    document.addEventListener('DOMContentLoaded', init);
    window.MecanicoShell = { init, aplicarTema, toggleTema, showToast, showLoading, hideLoading, abrirMenu, cerrarMenu };
    window.showToast = showToast;
})(window);
