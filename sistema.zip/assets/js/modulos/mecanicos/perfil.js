/**
 * Perfil del mecánico autenticado. Solo campos que existen en la base.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;
    let perfil = null;

    function iniciales(nombre) {
        return String(nombre || 'M')
            .split(/\s+/)
            .slice(0, 2)
            .map(p => p.charAt(0).toUpperCase())
            .join('') || 'M';
    }

    function especialidadTexto(p) {
        const lista = Array.isArray(p.especialidades) ? p.especialidades : [];
        if (!lista.length) return 'Sin especialidad asignada';
        return lista.map(e => e.nombre_especialidad).filter(Boolean).join(', ');
    }

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = (value === 0 || value) ? String(value) : '—';
    }

    function pintar() {
        if (!perfil) return;
        setText('perfil-nombre', perfil.nombre);
        setText('perfil-rol', perfil.rol || 'Mecánico');
        setText('perfil-status', perfil.estado || 'Activo');
        const status = document.getElementById('perfil-status');
        if (status) {
            status.className = 'status-badge status-' + Map().claseEstado(perfil.estado || 'activo');
        }
        setText('info-nombre', perfil.nombre);
        setText('info-telefono', perfil.telefono);
        setText('info-email', perfil.correo);
        setText('info-documento', perfil.documento);
        setText('info-id', String(perfil.id_usuario || ''));
        setText('info-especialidad', especialidadTexto(perfil));
        setText('info-ingreso', Map().fechaLarga(perfil.fecha_ingreso));
        const stats = perfil.estadisticas || {};
        setText('stat-asignadas', Number(stats.ordenes_asignadas ?? stats.total ?? 0));
        setText('stat-activas', Number(stats.ordenes_activas ?? stats.activas ?? 0));
        setText('stat-completadas', Number(stats.ordenes_completadas ?? stats.completadas ?? 0));
        const avatar = document.getElementById('avatar-iniciales');
        if (avatar) avatar.textContent = iniciales(perfil.nombre);
        const formNombre = document.getElementById('edit-nombre');
        const formTel = document.getElementById('edit-telefono');
        const formEmail = document.getElementById('edit-email');
        if (formNombre) formNombre.value = perfil.nombre || '';
        if (formTel) formTel.value = perfil.telefono || '';
        if (formEmail) formEmail.value = perfil.correo || '';
    }

    function abrirModal() {
        const modal = document.getElementById('modal-editar-perfil');
        if (!modal) return;
        pintar();
        modal.classList.remove('hidden');
    }

    function cerrarModal() {
        const modal = document.getElementById('modal-editar-perfil');
        if (modal) modal.classList.add('hidden');
    }

    async function guardar(e) {
        if (e) e.preventDefault();
        try {
            const res = await window.apiMecanicoPerfilActualizar({
                nombre: document.getElementById('edit-nombre').value.trim(),
                telefono: document.getElementById('edit-telefono').value.trim(),
                correo: document.getElementById('edit-email').value.trim()
            });
            perfil = res.data || perfil;
            pintar();
            cerrarModal();
            const local = window.MecanicoSesion.usuario() || {};
            local.nombre = perfil.nombre;
            local.telefono = perfil.telefono;
            local.correo = perfil.correo;
            localStorage.setItem('motorsoft_usuario', JSON.stringify(local));
            Shell().showToast('Perfil actualizado', 'success');
        } catch (err) {
            Shell().showToast(err.message || 'No se pudo guardar el perfil', 'error');
        }
    }

    async function cargar() {
        try {
            const res = await window.apiMecanicoPerfil();
            perfil = res.data || null;
            pintar();
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo cargar el perfil', 'error');
        }
    }

    function init() {
        const editar = document.getElementById('btn-editar-perfil');
        if (editar) editar.addEventListener('click', abrirModal);
        const cerrar = document.getElementById('btn-cerrar-modal');
        const cancelar = document.getElementById('btn-cancelar-edicion');
        if (cerrar) cerrar.addEventListener('click', cerrarModal);
        if (cancelar) cancelar.addEventListener('click', cerrarModal);
        const guardarBtn = document.getElementById('btn-guardar-perfil');
        if (guardarBtn) guardarBtn.addEventListener('click', guardar);
        const form = document.getElementById('form-editar-perfil');
        if (form) form.addEventListener('submit', guardar);
        const modal = document.getElementById('modal-editar-perfil');
        if (modal) {
            modal.addEventListener('click', function (e) {
                if (e.target === modal) cerrarModal();
            });
        }
        cargar();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoPerfil = { init, cargar };
})(window);
