/**
 * Consulta de inventario. El retiro real se registra como consumo de una OT.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;

    const state = { productos: [], filtro: 'todos', busqueda: '' };

    function visibles() {
        let lista = state.productos;
        if (state.busqueda) {
            const q = state.busqueda.toLowerCase();
            lista = lista.filter(p =>
                String(p.nombre).toLowerCase().includes(q) ||
                String(p.codigo).toLowerCase().includes(q)
            );
        }
        if (state.filtro !== 'todos') {
            lista = lista.filter(p => String(p.categoria).toLowerCase() === state.filtro.toLowerCase());
        }
        return lista;
    }

    function estadoStock(p) {
        if (p.cantidad <= p.stock_minimo) return 'critico';
        if (p.cantidad <= p.stock_minimo * 2) return 'bajo';
        return 'normal';
    }

    function pintarFiltros() {
        const box = document.getElementById('categorias-filters');
        if (!box) return;
        const cats = [...new Set(state.productos.map(p => p.categoria).filter(Boolean))];
        box.innerHTML =
            '<button type="button" class="categoria-filter' + (state.filtro === 'todos' ? ' active' : '') + '" data-categoria="todos">Todos (' + state.productos.length + ')</button>' +
            cats.map(cat => {
                const n = state.productos.filter(p => p.categoria === cat).length;
                const active = state.filtro === cat ? ' active' : '';
                return '<button type="button" class="categoria-filter' + active + '" data-categoria="' + Map().esc(cat) + '">' + Map().esc(cat) + ' (' + n + ')</button>';
            }).join('');
    }

    function pintar() {
        const container = document.getElementById('productos-container');
        if (!container) return;
        const lista = visibles();
        if (!lista.length) {
            container.innerHTML = '<div class="empty-state"><i class="fas fa-boxes"></i><h3>No hay productos</h3><p>No se encontraron productos con los criterios actuales</p></div>';
            return;
        }
        const puedeConsumir = window.MecanicoSesion.puede('ordenes.agregar_productos');
        container.innerHTML = lista.map(p => {
            const st = estadoStock(p);
            return (
                '<div class="producto-card stock-' + st + '" data-producto-id="' + Map().esc(p.id) + '">' +
                    '<div class="producto-header">' +
                        '<div class="producto-info">' +
                            '<h3 class="producto-codigo">' + Map().esc(p.codigo) + '</h3>' +
                            '<span class="producto-nombre">' + Map().esc(p.nombre) + '</span>' +
                        '</div>' +
                        '<div class="producto-stock"><span class="stock-badge stock-' + st + '">' + p.cantidad + (st === 'critico' ? ' ⚠' : '') + '</span></div>' +
                    '</div>' +
                    '<div class="producto-body">' +
                        '<div class="producto-details">' +
                            '<div class="detail-item"><i class="fas fa-tag"></i><span>' + Map().esc(p.categoria) + '</span></div>' +
                            '<div class="detail-item"><i class="fas fa-map-marker-alt"></i><span>' + Map().esc(p.ubicacion) + '</span></div>' +
                            '<div class="detail-item"><i class="fas fa-dollar-sign"></i><span>$' + Map().moneda(p.precio) + '</span></div>' +
                        '</div>' +
                        (puedeConsumir
                            ? '<div class="producto-actions"><a class="btn btn-primary btn-sm" href="../consumos/index.php?producto=' + encodeURIComponent(p.id) + '"><i class="fas fa-tools"></i> Usar en orden</a></div>'
                            : '') +
                    '</div>' +
                '</div>'
            );
        }).join('');
    }

    async function cargar() {
        try {
            const raw = await window.obtenerProductos();
            state.productos = (raw || []).map(window.MecanicoMap.producto).filter(Boolean);
            pintarFiltros();
            pintar();
        } catch (e) {
            const container = document.getElementById('productos-container');
            if (container) {
                container.innerHTML = '<div class="error-state"><i class="fas fa-exclamation-triangle"></i><p>' + Map().esc(e.message || 'Error cargando inventario') + '</p></div>';
            }
            Shell().showToast(e.message || 'Error cargando inventario', 'error');
        }
    }

    function init() {
        const search = document.getElementById('search-productos');
        if (search) {
            search.addEventListener('input', function () {
                state.busqueda = this.value.trim();
                pintar();
            });
        }
        const clear = document.getElementById('btn-clear-search');
        if (clear && search) {
            clear.addEventListener('click', function () {
                search.value = '';
                state.busqueda = '';
                pintar();
            });
        }
        document.addEventListener('click', function (e) {
            const btn = e.target.closest('.categoria-filter');
            if (!btn) return;
            state.filtro = btn.dataset.categoria || 'todos';
            pintarFiltros();
            pintar();
        });
        const refresh = document.getElementById('btn-refresh');
        if (refresh) refresh.addEventListener('click', cargar);
        cargar();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoStock = { init, cargar };
})(window);
