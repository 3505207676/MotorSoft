/**
 * Detalle de una orden asignada, con servicios y consumos reales.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;
    let orden = null;
    let productos = [];

    function idDesdeUrl() {
        return new URLSearchParams(window.location.search).get('id') || '';
    }

    function ordenCerrada(o) {
        return ['Completada', 'Cancelada', 'Pendiente Pago'].includes(o && o.estado);
    }

    function pintar(o, consumos) {
        const box = document.getElementById('orden-detalle-container');
        if (!box) return;
        const servicios = o.servicios || [];
        const items = Array.isArray(consumos) ? consumos : [];
        const btnProducto = window.MecanicoSesion && window.MecanicoSesion.puede('ordenes.agregar_productos')
            ? '<button type="button" class="btn btn-primary btn-sm" id="btn-agregar-producto-seccion"><i class="fas fa-plus"></i> Agregar producto</button>'
            : '';
        box.innerHTML =
            '<div class="orden-header">' +
                '<div class="orden-info">' +
                    '<h2>' + Map().esc(o.numero) + '</h2>' +
                    '<span class="status-badge status-' + Map().claseEstado(o.estado) + '">' + Map().esc(o.estado) + '</span>' +
                '</div>' +
                '<div class="orden-fecha"><i class="fas fa-calendar"></i><span>' + Map().esc(Map().fechaLarga(o.fechaCreacion)) + '</span></div>' +
            '</div>' +
            '<div class="orden-content">' +
                '<div class="info-section"><h3><i class="fas fa-user"></i> Cliente</h3>' +
                    '<div class="info-grid">' +
                        '<div class="info-item"><span class="info-label">Nombre</span><span class="info-value">' + Map().esc(o.clienteNombre) + '</span></div>' +
                        '<div class="info-item"><span class="info-label">Teléfono</span><span class="info-value">' + Map().esc(o.clienteTelefono || '—') + '</span></div>' +
                    '</div>' +
                '</div>' +
                '<div class="info-section"><h3><i class="fas ' + Map().iconoVehiculo(o.vehiculoTipo) + '"></i> Vehículo</h3>' +
                    '<div class="info-grid">' +
                        '<div class="info-item"><span class="info-label">Tipo</span><span class="info-value">' + Map().esc(o.vehiculoTipo || '—') + '</span></div>' +
                        '<div class="info-item"><span class="info-label">Vehículo</span><span class="info-value">' + Map().esc(o.vehiculoModelo) + '</span></div>' +
                        '<div class="info-item"><span class="info-label">Placa</span><span class="info-value">' + Map().esc(o.vehiculoPlaca || '—') + '</span></div>' +
                    '</div>' +
                '</div>' +
                '<div class="info-section"><h3><i class="fas fa-align-left"></i> Descripción</h3>' +
                    '<p>' + Map().esc(o.notas || o.descripcion || 'Sin descripción') + '</p>' +
                '</div>' +
                '<div class="info-section"><h3><i class="fas fa-tools"></i> Servicios</h3>' +
                    (servicios.length
                        ? '<ul class="servicios-lista">' + servicios.map(s => '<li>' + Map().esc(s.nombre || 'Servicio') + '</li>').join('') + '</ul>'
                        : '<p class="text-muted">Sin servicios cargados</p>') +
                '</div>' +
                '<div class="info-section">' +
                    '<h3 class="section-title-row"><span><i class="fas fa-boxes"></i> Repuestos</span>' + btnProducto + '</h3>' +
                    (items.length
                        ? '<ul class="repuestos-lista">' + items.map(r => '<li><strong>' + Map().esc(r.producto || 'Producto') + '</strong><div class="info-label">Cantidad ' + (r.cantidad || 0) + (r.referencia ? ' · ' + Map().esc(r.referencia) : '') + '</div></li>').join('') + '</ul>'
                        : '<p class="text-muted">No hay repuestos registrados</p>') +
                '</div>' +
                '<div class="info-section" id="orden-evidencias">' +
                    '<h3 class="section-title-row"><span><i class="fas fa-camera"></i> Evidencias</span>' +
                    '<button type="button" class="btn btn-primary btn-sm" id="btn-subir-evidencia"><i class="fas fa-upload"></i> Subir</button></h3>' +
                    '<div id="lista-evidencias"><p class="text-muted">Cargando...</p></div>' +
                    '<input type="file" id="input-evidencia-orden" accept="image/jpeg,image/png,image/gif,application/pdf" hidden>' +
                '</div>' +
            '</div>';
        const extra = document.getElementById('btn-agregar-producto-seccion');
        if (extra) extra.addEventListener('click', abrirProducto);
        document.getElementById('btn-subir-evidencia')?.addEventListener('click', () => {
            document.getElementById('input-evidencia-orden')?.click();
        });
        document.getElementById('input-evidencia-orden')?.addEventListener('change', subirEvidencia);
        cargarEvidencias(o.id_orden || o.id);
        actualizarAcciones(o);
    }

    function actualizarAcciones(o) {
        const wrap = document.getElementById('orden-actions-container');
        if (wrap) wrap.classList.remove('hidden');
        const iniciar = document.getElementById('btn-iniciar-orden');
        const pausar = document.getElementById('btn-pausar-orden');
        const finalizar = document.getElementById('btn-finalizar-orden');
        const agregar = document.getElementById('btn-agregar-producto');
        const abierta = o.estado === 'Pendiente' || o.estado === 'Diagnóstico';
        const enCurso = o.estado === 'En Proceso' || o.estado === 'En Progreso';
        if (iniciar) iniciar.classList.toggle('hidden', !abierta);
        if (pausar) pausar.classList.toggle('hidden', !enCurso);
        if (finalizar) finalizar.classList.toggle('hidden', !enCurso);
        if (agregar) {
            const puedeProducto = !(window.MecanicoSesion) || window.MecanicoSesion.puede('ordenes.agregar_productos');
            agregar.classList.toggle('hidden', ordenCerrada(o) || !puedeProducto);
        }
    }

    function modalProducto() {
        return document.getElementById('modal-agregar-producto');
    }

    function cerrarProducto() {
        const modal = modalProducto();
        if (modal) modal.classList.add('hidden');
    }

    async function abrirProducto() {
        if (!orden || ordenCerrada(orden)) {
            Shell().showToast('Esta orden ya no admite productos', 'warning');
            return;
        }
        const modal = modalProducto();
        const sel = document.getElementById('producto-orden');
        if (!modal || !sel) {
            window.location.href = '../consumos/index.php?orden=' + encodeURIComponent(idDesdeUrl());
            return;
        }
        sel.innerHTML = '<option value="">Cargando inventario...</option>';
        modal.classList.remove('hidden');
        try {
            const raw = await window.obtenerProductos();
            productos = (raw || []).map(window.MecanicoMap.producto).filter(p => p && p.cantidad > 0);
            if (!productos.length) {
                sel.innerHTML = '<option value="">No hay stock disponible</option>';
                return;
            }
            sel.innerHTML = '<option value="">Selecciona un producto</option>' + productos.map(p => (
                '<option value="' + Map().esc(p.id) + '">' + Map().esc(p.nombre + ' · ' + p.codigo + ' (' + p.cantidad + ')') + '</option>'
            )).join('');
        } catch (e) {
            sel.innerHTML = '<option value="">No se pudo cargar el inventario</option>';
            Shell().showToast(e.message || 'No se pudo cargar el inventario', 'error');
        }
    }

    async function cargarEvidencias(idOrden) {
        const box = document.getElementById('lista-evidencias');
        if (!box || !idOrden || typeof window.apiAdjuntos !== 'function') return;
        try {
            const res = await window.apiAdjuntos({ entidad_tipo: 'orden', entidad_id: idOrden });
            const lista = Array.isArray(res.data) ? res.data : [];
            box.innerHTML = typeof window.htmlGaleriaEvidencias === 'function'
                ? window.htmlGaleriaEvidencias(lista, 'Sin fotos ni documentos. Suba evidencias de la reparación.')
                : '<p class="text-muted">Sin evidencias.</p>';
        } catch (e) {
            box.innerHTML = '<p class="text-muted">No se pudieron cargar las evidencias.</p>';
        }
    }

    async function subirEvidencia() {
        const input = document.getElementById('input-evidencia-orden');
        const file = input?.files?.[0];
        const id = orden && (orden.id_orden || orden.id);
        if (!file || !id) return;
        try {
            await window.apiAdjuntoSubir(file, 'orden', id);
            Shell().showToast('Evidencia cargada', 'success');
            await cargarEvidencias(id);
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo subir', 'error');
        } finally {
            input.value = '';
        }
    }

    async function enviarProducto(e) {
        e.preventDefault();
        if (!orden) return;
        const idProducto = document.getElementById('producto-orden').value;
        const cantidad = Number(document.getElementById('cantidad-orden').value) || 0;
        if (!idProducto || cantidad < 1) {
            Shell().showToast('Selecciona producto y cantidad', 'warning');
            return;
        }
        const prod = productos.find(p => String(p.id) === String(idProducto));
        const disponible = Number(prod?.cantidad ?? 0);
        if (!prod || cantidad > disponible) {
            Shell().showToast(prod
                ? ('Solo hay ' + disponible + ' unidades de ' + prod.nombre)
                : 'Ese producto no tiene stock', 'warning');
            return;
        }
        try {
            await window.apiConsumosCrear({
                id_orden: orden.id_orden || orden.id,
                id_producto: idProducto,
                cantidad
            });
            Shell().showToast('Producto agregado a la orden', 'success');
            cerrarProducto();
            await cargar();
        } catch (err) {
            Shell().showToast(err.message || 'No se pudo agregar el producto', 'error');
        }
    }

    async function cargar() {
        const id = idDesdeUrl();
        const box = document.getElementById('orden-detalle-container');
        if (!id) {
            if (box) box.innerHTML = '<div class="error-state"><p>No se especificó una orden</p></div>';
            return;
        }
        try {
            const [o, consumos] = await Promise.all([
                window.obtenerOrden(id),
                window.apiConsumosObtener({ id_orden: id }).catch(() => ({ data: [] }))
            ]);
            orden = o;
            pintar(o, consumos.data || []);
        } catch (e) {
            if (box) box.innerHTML = '<div class="error-state"><p>' + Map().esc(e.message || 'No se pudo cargar la orden') + '</p></div>';
        }
    }

    async function cambiar(estado, pregunta) {
        if (!orden || (pregunta && !confirm(pregunta))) return;
        try {
            await window.actualizarEstadoOrden(orden.id || orden.id_orden, estado);
            await cargar();
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo actualizar', 'error');
        }
    }

    function init() {
        document.getElementById('btn-iniciar-orden')?.addEventListener('click', () => cambiar('En Proceso', '¿Iniciar esta orden?'));
        document.getElementById('btn-pausar-orden')?.addEventListener('click', () => cambiar('Diagnóstico', '¿Pausar esta orden?'));
        document.getElementById('btn-finalizar-orden')?.addEventListener('click', () => cambiar('Pendiente Pago', '¿Marcar lista para facturar?'));
        document.getElementById('btn-agregar-producto')?.addEventListener('click', abrirProducto);
        document.getElementById('btn-cerrar-producto')?.addEventListener('click', cerrarProducto);
        document.getElementById('btn-cancelar-producto')?.addEventListener('click', cerrarProducto);
        document.getElementById('form-agregar-producto')?.addEventListener('submit', enviarProducto);
        const modal = modalProducto();
        if (modal) {
            modal.addEventListener('click', function (e) {
                if (e.target === modal) cerrarProducto();
            });
        }
        document.getElementById('btn-chat-orden')?.addEventListener('click', () => {
            window.location.href = '../chat/index-mecanicos.php?orden=' + encodeURIComponent(idDesdeUrl());
        });
        document.getElementById('btn-consumos-orden')?.addEventListener('click', () => {
            window.location.href = '../consumos/index.php?orden=' + encodeURIComponent(idDesdeUrl());
        });
        cargar();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoDetalle = { init, cargar };
})(window);
