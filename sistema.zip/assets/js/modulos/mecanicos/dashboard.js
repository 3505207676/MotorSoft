/**
 * Inicio del mecánico: un resumen desde la API, sin datos de prueba.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;

    function setText(id, value) {
        const el = document.getElementById(id);
        if (el) el.textContent = String(value ?? 0);
    }

    function vacio(icono, texto) {
        return '<div class="empty-state"><i class="fas ' + icono + '"></i><p>' + Map().esc(texto) + '</p></div>';
    }

    function etiquetaDia(fecha) {
        const f = String(fecha || '').slice(0, 10);
        if (!f) return '';
        const d = new Date();
        const hoy = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        if (f === hoy) return 'Hoy';
        return f;
    }

    function pintarCitas(citas) {
        const box = document.getElementById('citas-hoy');
        if (!box) return;
        const lista = Array.isArray(citas) ? citas.filter(c => {
            const est = String(c.estado_cita || '').toLowerCase();
            return est !== 'cancelada' && est !== 'completada';
        }) : [];
        if (!lista.length) {
            box.innerHTML = vacio('fa-calendar-check', 'No tienes citas próximas');
            return;
        }
        box.innerHTML = lista.map(c => {
            const id = Number(c.id_cita) || 0;
            const estado = Map().esc(c.estado_cita || '');
            const cuando = [etiquetaDia(c.fecha), c.hora_inicio || c.hora].filter(Boolean).join(' · ');
            const acciones = [];
            if (c.estado_cita === 'Programada') {
                acciones.push('<button type="button" class="btn btn-outline btn-sm" data-cita-accion="confirmar" data-cita-id="' + id + '">Confirmar</button>');
            }
            return (
                '<div class="orden-reciente-card">' +
                    '<div class="orden-reciente-header">' +
                        '<div class="orden-reciente-info">' +
                            '<h4 class="orden-numero">' + Map().esc(cuando || 'Cita') + ' · ' + Map().esc(c.servicio_nombre || c.motivo || 'Servicio') + '</h4>' +
                            '<span class="orden-cliente">' + Map().esc(c.cliente_nombre || 'Cliente') + '</span>' +
                        '</div>' +
                        '<span class="status-badge">' + estado + '</span>' +
                    '</div>' +
                    '<div class="orden-reciente-body">' +
                        '<div class="orden-reciente-details">' +
                            '<span class="vehiculo"><i class="fas ' + Map().iconoVehiculo(c.vehiculo_tipo) + '"></i> ' + Map().esc([c.vehiculo_tipo, c.vehiculo_label || c.placa].filter(Boolean).join(' · ') || '—') + '</span>' +
                        '</div>' +
                        (acciones.length ? '<div class="orden-reciente-actions">' + acciones.join('') + '</div>' : '') +
                    '</div>' +
                '</div>'
            );
        }).join('');
    }

    function pintarOrdenes(ordenes) {
        const box = document.getElementById('ordenes-recientes');
        if (!box) return;
        const lista = (ordenes || []).slice(0, 3);
        if (!lista.length) {
            box.innerHTML = vacio('fa-clipboard-list', 'No hay órdenes asignadas');
            return;
        }
        box.innerHTML = lista.map(raw => {
            const o = Map().orden(raw);
            const id = Map().esc(o.id);
            return (
                '<div class="orden-reciente-card">' +
                    '<div class="orden-reciente-header">' +
                        '<div class="orden-reciente-info">' +
                            '<h4 class="orden-numero">' + Map().esc(o.numero) + '</h4>' +
                            '<span class="orden-cliente">' + Map().esc(o.clienteNombre) + '</span>' +
                        '</div>' +
                        '<span class="status-badge status-' + Map().claseEstado(o.estado) + '">' + Map().esc(o.estado) + '</span>' +
                    '</div>' +
                    '<div class="orden-reciente-body">' +
                        '<div class="orden-reciente-details">' +
                            '<span class="vehiculo"><i class="fas ' + Map().iconoVehiculo(o.vehiculoTipo) + '"></i> ' + Map().esc(Map().etiquetaVehiculo(o)) + '</span>' +
                            '<span class="fecha"><i class="fas fa-calendar"></i> ' + Map().esc(Map().fechaCorta(o.fechaCreacion)) + '</span>' +
                        '</div>' +
                        '<div class="orden-reciente-actions">' +
                            '<a class="btn btn-outline btn-sm" href="../ordenes/orden-detalle.php?id=' + encodeURIComponent(id) + '"><i class="fas fa-eye"></i> Ver</a>' +
                            '<a class="btn btn-primary btn-sm" href="../chat/index-mecanicos.php?orden=' + encodeURIComponent(id) + '"><i class="fas fa-comments"></i> Chat</a>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
        }).join('');
    }

    async function cargar() {
        try {
            Shell().showLoading('Cargando inicio...');
            const res = await window.apiMecanicoDashboard();
            const data = res.data || {};
            const kpis = data.kpis || {};
            setText('kpi-ordenes-asignadas', kpis.ordenes_asignadas);
            setText('kpi-en-progreso', kpis.en_proceso);
            setText('kpi-notificaciones', kpis.chat_no_leidos);
            setText('kpi-stock-critico', kpis.stock_bajo);
            const badgeChat = document.getElementById('chat-badge');
            if (badgeChat) {
                const n = Number(kpis.chat_no_leidos) || 0;
                badgeChat.textContent = n;
                badgeChat.classList.toggle('hidden', n < 1);
            }
            pintarCitas(data.citas_hoy_lista);
            pintarOrdenes(data.ordenes_recientes);
        } catch (e) {
            Shell().showToast(e.message || 'Error cargando el inicio', 'error');
        } finally {
            Shell().hideLoading();
        }
    }

    async function actualizarCita(id, estado) {
        try {
            await window.apiCitasActualizar(id, { estado_cita: estado });
            Shell().showToast('Cita confirmada', 'success');
            await cargar();
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo actualizar la cita', 'error');
        }
    }

    function init() {
        const refresh = document.getElementById('btn-refresh');
        if (refresh) refresh.addEventListener('click', cargar);
        document.addEventListener('click', function (e) {
            const btn = e.target.closest('[data-cita-accion]');
            if (!btn) return;
            const id = Number(btn.dataset.citaId) || 0;
            if (!id) return;
            const estado = btn.dataset.citaAccion === 'confirmar' ? 'Confirmada' : '';
            if (!estado) return;
            actualizarCita(id, estado);
        });
        cargar();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoDashboard = { init, cargar };
})(window);
