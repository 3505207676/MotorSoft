/**
 * Adaptadores de filas de API → vista del mecánico.
 */
(function (window) {
    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function fechaCorta(valor) {
        if (!valor) return '—';
        const d = new Date(String(valor).replace(' ', 'T'));
        if (Number.isNaN(d.getTime())) return String(valor);
        return d.toLocaleDateString('es-CO', { day: 'numeric', month: 'short' });
    }

    function fechaLarga(valor) {
        if (!valor) return '—';
        const d = new Date(String(valor).replace(' ', 'T'));
        if (Number.isNaN(d.getTime())) return String(valor);
        return d.toLocaleDateString('es-CO', { day: 'numeric', month: 'long', year: 'numeric' });
    }

    function claseEstado(estado) {
        return String(estado || 'pendiente').toLowerCase().replace(/\s+/g, '-');
    }

    function orden(o) {
        if (!o) return null;
        if (typeof window.mapOrdenMecanico === 'function') {
            return window.mapOrdenMecanico(o);
        }
        const veh = o.vehiculo || {};
        const detalles = Array.isArray(o.detalles) ? o.detalles : [];
        return {
            id: String(o.id_orden ?? o.id ?? ''),
            id_orden: o.id_orden ?? o.id,
            numero: 'OT #' + (o.id_orden ?? o.id ?? ''),
            clienteNombre: o.cliente_nombre || veh.cliente_nombre || '—',
            vehiculoModelo: o.vehiculo_label || [veh.marca, veh.modelo].filter(Boolean).join(' ') || '—',
            vehiculoPlaca: o.placa || veh.placa || '',
            vehiculoTipo: o.vehiculo_tipo || veh.tipo || '',
            fechaCreacion: o.fecha_ingreso || o.created_at || '',
            estado: o.estado || 'Pendiente',
            descripcion: o.descripcion || '',
            servicios: detalles.map(d => ({
                id: d.id_servicio,
                nombre: (d.servicio && d.servicio.nombre) || d.nombre || ('Servicio #' + (d.id_servicio || '')),
                precio: Number(d.precio ?? d.subtotal ?? 0)
            })),
            raw: o
        };
    }

    function producto(p) {
        if (!p) return null;
        const nested = p.stock && typeof p.stock === 'object' ? p.stock : null;
        const cantidad = Number(p.cantidad ?? (nested && nested.cantidad) ?? 0);
        const minimo = Number(p.stock_minimo ?? (nested && nested.stock_minimo) ?? 0);
        return {
            id: String(p.id_producto ?? p.id ?? ''),
            id_producto: p.id_producto ?? p.id,
            nombre: p.nombre || 'Producto',
            codigo: p.codigo || p.referencia || '—',
            categoria: p.categoria || 'Sin categoría',
            stock: cantidad,
            cantidad,
            stockMinimo: minimo,
            stock_minimo: minimo,
            precio: Number(p.precio ?? p.precio_unitario ?? 0),
            ubicacion: p.ubicacion || '—',
            stock_bajo: !!p.stock_bajo || cantidad <= minimo
        };
    }

    function moneda(n) {
        return Number(n || 0).toLocaleString('es-CO');
    }

    window.MecanicoMap = { esc, fechaCorta, fechaLarga, claseEstado, orden, producto, moneda, iconoVehiculo, etiquetaVehiculo };

    function iconoVehiculo(tipo) {
        return (window.MotorSoftPlaca && MotorSoftPlaca.icono(tipo)) || 'fa-car';
    }

    function etiquetaVehiculo(o) {
        if (!o) return 'Vehículo';
        const bits = [o.vehiculoTipo, o.vehiculoPlaca || o.vehiculoModelo].filter(Boolean);
        return bits.join(' · ') || 'Vehículo';
    }
})(window);
