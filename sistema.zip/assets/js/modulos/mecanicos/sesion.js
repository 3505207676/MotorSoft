/**
 * Identidad del mecánico en sesión. Sin IDs inventados.
 */
(function (window) {
    function usuario() {
        if (window.MotorSoftGuard && typeof window.MotorSoftGuard.usuario === 'function') {
            return window.MotorSoftGuard.usuario();
        }
        try {
            return JSON.parse(localStorage.getItem('motorsoft_usuario') || 'null');
        } catch (e) {
            return null;
        }
    }

    function idUsuario() {
        const u = usuario();
        const id = u && (u.id_usuario || u.id);
        return id ? String(id) : '';
    }

    function nombre() {
        const u = usuario();
        return (u && u.nombre) ? String(u.nombre) : 'Mecánico';
    }

    function puede(slug) {
        return window.MotorSoftGuard && typeof window.MotorSoftGuard.puede === 'function'
            ? window.MotorSoftGuard.puede(slug)
            : false;
    }

    window.MecanicoSesion = { usuario, idUsuario, nombre, puede };
    window.obtenerMecanicoActual = idUsuario;
})(window);
