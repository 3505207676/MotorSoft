/**
 * Órdenes asignadas al mecánico autenticado.
 */
(function (window) {
    const Map = () => window.MecanicoMap;
    const Shell = () => window.MecanicoShell;

    const state = { ordenes: [], filtro: 'todas' };

    const FILTROS = {
        todas: () => true,
        pendiente: o => ['Pendiente', 'Diagnóstico'].includes(o.estado),
        progreso: o => o.estado === 'En Proceso' || o.estado === 'En Progreso',
        finalizado: o => ['Completada', 'Pendiente Pago', 'Cancelada', 'Finalizada'].includes(o.estado)
    };

    function filtradas() {
        const fn = FILTROS[state.filtro] || FILTROS.todas;
        return state.ordenes.filter(fn);
    }

    function htmlAcciones(orden) {
        let html = '';
        if (orden.estado === 'Pendiente' || orden.estado === 'Diagnóstico') {
            html += '<button class="btn btn-success btn-sm" data-accion="iniciar" data-orden-id="' + Map().esc(orden.id) + '"><i class="fas fa-play"></i> Iniciar</button>';
        }
        if (orden.estado === 'En Proceso' || orden.estado === 'En Progreso') {
            html += '<button class="btn btn-warning btn-sm" data-accion="pausar" data-orden-id="' + Map().esc(orden.id) + '"><i class="fas fa-pause"></i> Pausar</button>';
            html += '<button class="btn btn-primary btn-sm" data-accion="finalizar" data-orden-id="' + Map().esc(orden.id) + '"><i class="fas fa-check"></i> Finalizar</button>';
        }
        html += '<a class="btn btn-outline btn-sm" href="orden-detalle.php?id=' + encodeURIComponent(orden.id) + '"><i class="fas fa-eye"></i> Ver</a>';
        html += '<a class="btn btn-outline btn-sm" href="../chat/index-mecanicos.php?orden=' + encodeURIComponent(orden.id) + '"><i class="fas fa-comments"></i> Chat</a>';
        return html;
    }

    function pintar() {
        const container = document.getElementById('ordenes-container');
        const empty = document.getElementById('empty-state');
        const loading = document.getElementById('loading-ordenes');
        if (loading) loading.classList.add('hidden');
        if (!container) return;
        const lista = filtradas();
        if (!lista.length) {
            container.innerHTML = '';
            if (empty) empty.classList.remove('hidden');
            return;
        }
        if (empty) empty.classList.add('hidden');
        container.innerHTML = lista.map(orden => (
            '<div class="orden-card" data-orden-id="' + Map().esc(orden.id) + '">' +
                '<div class="orden-header">' +
                    '<div class="orden-info">' +
                        '<h3 class="orden-numero">' + Map().esc(orden.numero) + '</h3>' +
                        '<span class="orden-cliente">' + Map().esc(orden.clienteNombre) + '</span>' +
                    '</div>' +
                    '<div class="orden-status"><span class="status-badge status-' + Map().claseEstado(orden.estado) + '">' + Map().esc(orden.estado) + '</span></div>' +
                '</div>' +
                '<div class="orden-body">' +
                    '<div class="orden-details">' +
                        '<div class="detail-item"><i class="fas ' + Map().iconoVehiculo(orden.vehiculoTipo) + '"></i><span>' + Map().esc(Map().etiquetaVehiculo(orden) + (orden.vehiculoModelo && orden.vehiculoPlaca ? ' · ' + orden.vehiculoModelo : '')) + '</span></div>' +
                        '<div class="detail-item"><i class="fas fa-calendar"></i><span>' + Map().esc(Map().fechaCorta(orden.fechaCreacion)) + '</span></div>' +
                        '<div class="detail-item"><i class="fas fa-tools"></i><span>' + (orden.servicios || []).length + ' servicios</span></div>' +
                    '</div>' +
                    '<div class="orden-actions">' + htmlAcciones(orden) + '</div>' +
                '</div>' +
            '</div>'
        )).join('');
    }

    function contar() {
        const c = {
            todas: state.ordenes.length,
            pendiente: state.ordenes.filter(FILTROS.pendiente).length,
            progreso: state.ordenes.filter(FILTROS.progreso).length,
            finalizado: state.ordenes.filter(FILTROS.finalizado).length
        };
        Object.keys(c).forEach(k => {
            const el = document.getElementById('count-' + k);
            if (el) el.textContent = c[k];
        });
        const badge = document.getElementById('ordenes-badge');
        if (badge) {
            const n = c.pendiente + c.progreso;
            badge.textContent = n;
            badge.classList.toggle('hidden', n < 1);
        }
    }

    async function cargar() {
        try {
            const loading = document.getElementById('loading-ordenes');
            if (loading) loading.classList.remove('hidden');
            const lista = await window.obtenerOrdenes();
            state.ordenes = Array.isArray(lista) ? lista : [];
            pintar();
            contar();
        } catch (e) {
            const container = document.getElementById('ordenes-container');
            if (container) {
                container.innerHTML = '<div class="error-state"><i class="fas fa-exclamation-triangle"></i><p>' + Map().esc(e.message || 'Error cargando órdenes') + '</p></div>';
            }
            Shell().showToast(e.message || 'Error cargando órdenes', 'error');
        }
    }

    async function cambiarEstado(id, estado, pregunta) {
        if (pregunta && !confirm(pregunta)) return;
        try {
            await window.actualizarEstadoOrden(id, estado);
            await cargar();
        } catch (e) {
            Shell().showToast(e.message || 'No se pudo actualizar la orden', 'error');
        }
    }

    function init() {
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.addEventListener('click', function () {
                state.filtro = this.dataset.filter || 'todas';
                document.querySelectorAll('.filter-tab').forEach(t => t.classList.toggle('active', t === this));
                pintar();
            });
        });
        const refresh = document.getElementById('btn-refresh');
        if (refresh) refresh.addEventListener('click', cargar);
        const emptyRefresh = document.getElementById('btn-refresh-empty');
        if (emptyRefresh) emptyRefresh.addEventListener('click', cargar);
        document.addEventListener('click', function (e) {
            const btn = e.target.closest('[data-accion]');
            if (!btn) return;
            const id = btn.dataset.ordenId;
            if (!id) return;
            if (btn.dataset.accion === 'iniciar') cambiarEstado(id, 'En Proceso', '¿Iniciar esta orden?');
            if (btn.dataset.accion === 'pausar') cambiarEstado(id, 'Diagnóstico', '¿Pausar esta orden?');
            if (btn.dataset.accion === 'finalizar') cambiarEstado(id, 'Pendiente Pago', '¿Marcar la orden lista para facturar?');
        });
        cargar();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
    window.MecanicoOrdenes = { init, cargar };
})(window);
