/**
 * Cliente API para backend PHP - MotorSoft / Taller El Paisa
 * Funciones para llamar a los endpoints del backend (sin mock ni datos locales)
 */

// Obtener base URL desde configuración
const API_BASE = (typeof API !== 'undefined' && API.base) ? API.base : '../../controllers/api';

/**
 * Función genérica para hacer peticiones a la API
 */
async function apiCall(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
    const config = {
        timeout: (typeof CONFIG !== 'undefined' && CONFIG.timeout) ? CONFIG.timeout : 10000,
        cache: 'no-store',
        ...options,
        headers: {
            ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
            'Cache-Control': 'no-cache',
            Pragma: 'no-cache',
            ...(typeof localStorage !== 'undefined' && localStorage.getItem('motorsoft_token')
                ? { Authorization: 'Bearer ' + localStorage.getItem('motorsoft_token') }
                : {}),
            ...(options.headers || {})
        }
    };
    config.cache = options.cache || 'no-store';
    
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
        config.body = JSON.stringify(options.body);
    } else if (options.body) {
        config.body = options.body;
    }
    if (options.body instanceof FormData && config.headers) {
        delete config.headers['Content-Type'];
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), config.timeout);
    const fetchConfig = { ...config };
    delete fetchConfig.timeout;
    
    try {
        const response = await fetch(url, { ...fetchConfig, cache: 'no-store', signal: controller.signal });
        clearTimeout(timeoutId);
        
        const data = await response.json().catch(() => ({}));
        
        if (response.status === 401) {
            if (typeof localStorage !== 'undefined') {
                localStorage.removeItem('motorsoft_token');
                localStorage.removeItem('motorsoft_usuario');
                localStorage.removeItem('motorsoft_cliente');
                localStorage.removeItem('motorsoft_sesion');
            }
            const path = (typeof window !== 'undefined' && window.location.pathname) || '';
            if (!path.includes('/auth/login')) {
                window.location.href = '../auth/login.php';
            }
            throw new Error(data.mensaje || 'Sesión expirada');
        }

        if (!response.ok) {
            throw new Error(data.mensaje || data.error || `Error ${response.status}`);
        }
        
        return data;
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new Error('Tiempo de espera agotado');
        }
        throw error;
    }
}

/**
 * Funciones para Clientes
 */
async function apiClientes(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/clientes/obtener.php${query ? '?' + query : ''}` : '/clientes/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiClientesActualizar(id, data) {
    return apiCall('/clientes/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiClientesEliminar(id) {
    return apiCall('/clientes/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Vehículos
 */
async function apiVehiculos(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/vehiculos/obtener.php${query ? '?' + query : ''}` : '/vehiculos/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiVehiculosActualizar(id, data) {
    return apiCall('/vehiculos/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiVehiculosEliminar(id) {
    return apiCall('/vehiculos/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Órdenes
 */
async function apiOrdenes(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/ordenes/obtener.php${query ? '?' + query : ''}` : '/ordenes/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiOrdenesActualizar(id, data) {
    return apiCall('/ordenes/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiOrdenesEliminar(id) {
    return apiCall('/ordenes/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Productos
 */
async function apiProductos(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/productos/obtener.php${query ? '?' + query : ''}` : '/productos/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiProductosActualizar(id, data) {
    return apiCall('/productos/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiProductosEliminar(id) {
    return apiCall('/productos/eliminar.php', { method: 'POST', body: { id } });
}

async function apiCategorias(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/categorias/obtener.php${query ? '?' + query : ''}`);
}

async function apiCategoriasCrear(data) {
    return apiCall('/categorias/crear.php', { method: 'POST', body: data });
}

/**
 * Funciones para Servicios
 */
async function apiServicios(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/servicios/obtener.php${query ? '?' + query : ''}`);
}

async function apiServiciosCrear(data) {
    return apiCall('/servicios/crear.php', { method: 'POST', body: data });
}

async function apiServiciosActualizar(id, data) {
    return apiCall('/servicios/actualizar.php', {
        method: 'POST',
        body: { id, id_servicio: id, ...data }
    });
}

async function apiServiciosEstado(id, estado) {
    return apiCall('/servicios/cambiar-estado.php', {
        method: 'POST',
        body: { id, id_servicio: id, estado }
    });
}

/**
 * Funciones para Usuarios
 */
async function apiUsuarios(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/usuarios/obtener.php${query ? '?' + query : ''}` : '/usuarios/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiUsuariosActualizar(id, data) {
    return apiCall('/usuarios/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiUsuariosEliminar(id) {
    return apiCall('/usuarios/eliminar.php', { method: 'POST', body: { id } });
}

async function apiUsuariosInvitar(id) {
    return apiCall('/usuarios/invitar.php', { method: 'POST', body: { id, id_usuario: id } });
}

/**
 * Funciones para Facturas
 */
async function apiFacturas(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/facturas/obtener.php${query ? '?' + query : ''}` : '/facturas/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiFacturasActualizar(id, data) {
    return apiCall('/facturas/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiFacturasEliminar(id) {
    return apiCall('/facturas/eliminar.php', { method: 'POST', body: { id } });
}

async function apiVentas(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/ventas/obtener.php${query ? '?' + query : ''}` : '/ventas/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiConfiguracion() {
    return apiCall('/configuracion/obtener.php');
}

async function apiConfiguracionActualizar(data) {
    return apiCall('/configuracion/actualizar.php', { method: 'POST', body: data });
}

async function apiConfiguracionLogoSubir(file) {
    const fd = new FormData();
    fd.append('logo', file);
    return apiCall('/configuracion/logo.php', { method: 'POST', body: fd, timeout: 30000 });
}

async function apiConfiguracionLogoQuitar() {
    return apiCall('/configuracion/logo.php', { method: 'DELETE' });
}

async function apiConfiguracionLogoBlob() {
    const url = `${API_BASE}/configuracion/logo.php`;
    const token = (typeof localStorage !== 'undefined' && localStorage.getItem('motorsoft_token')) || '';
    const response = await fetch(url, {
        headers: token ? { Authorization: 'Bearer ' + token } : {},
        cache: 'no-store'
    });
    if (!response.ok) {
        return null;
    }
    return response.blob();
}

async function apiCorreoProbar(data = {}) {
    return apiCall('/configuracion/probar-correo.php', { method: 'POST', body: data, timeout: 25000 });
}

async function apiConfiguracionBuzon(id) {
    const q = id ? ('?id=' + encodeURIComponent(id)) : '';
    return apiCall('/configuracion/buzon.php' + q);
}

async function apiRoles() {
    return apiCall('/roles/obtener.php');
}

async function apiRolesPermisos(idRol, slugs) {
    return apiCall('/roles/actualizar.php', { method: 'POST', body: { id_rol: idRol, slugs } });
}

async function apiRolesRestaurar(idRol) {
    return apiCall('/roles/restaurar.php', { method: 'POST', body: { id_rol: idRol } });
}

async function apiEspecialidades(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/especialidades/obtener.php${query ? '?' + query : ''}`);
}

async function apiEspecialidadesCrear(data) {
    return apiCall('/especialidades/crear.php', { method: 'POST', body: data });
}

async function apiEspecialidadesActualizar(id, data) {
    return apiCall('/especialidades/actualizar.php', { method: 'POST', body: { id, id_especialidad: id, ...data } });
}

async function apiEspecialidadesEliminar(id) {
    return apiCall('/especialidades/eliminar.php', { method: 'POST', body: { id, id_especialidad: id } });
}

async function apiEspecialidadesAsignar(data) {
    return apiCall('/especialidades/asignar.php', { method: 'POST', body: data });
}

async function apiContratos(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/contratos/obtener.php${query ? '?' + query : ''}`);
}

async function apiContratosCrear(data) {
    return apiCall('/contratos/crear.php', { method: 'POST', body: data });
}

async function apiContratosActualizar(id, data) {
    return apiCall('/contratos/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiContratosEliminar(id) {
    return apiCall('/contratos/eliminar.php', { method: 'POST', body: { id } });
}

async function apiNominas(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/nominas/obtener.php${query ? '?' + query : ''}`);
}

async function apiNominasCrear(data) {
    return apiCall('/nominas/crear.php', { method: 'POST', body: data });
}

async function apiAgenda(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/agenda/obtener.php${query ? '?' + query : ''}`);
}

async function apiAgendaCrear(data) {
    return apiCall('/agenda/crear.php', { method: 'POST', body: data });
}

async function apiAgendaCancelar(id) {
    return apiCall('/agenda/actualizar.php', { method: 'POST', body: { id_horario: id } });
}

async function apiAgendaMecanicos() {
    return apiCall('/agenda/mecanicos.php');
}

async function apiCitas(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/citas/obtener.php${query ? '?' + query : ''}`);
}

async function apiCitasCrear(data) {
    return apiCall('/citas/crear.php', { method: 'POST', body: data });
}

async function apiCitasActualizar(id, data) {
    return apiCall('/citas/actualizar.php', { method: 'POST', body: { id, id_cita: id, ...data } });
}

async function apiCitasConvertir(id) {
    return apiCall('/citas/convertir.php', { method: 'POST', body: { id, id_cita: id } });
}

async function apiCaja() {
    return apiCall('/caja/obtener.php');
}

async function apiCajaActiva() {
    return apiCall('/caja/activa.php');
}

async function apiCajaAbrir(data) {
    return apiCall('/caja/abrir.php', { method: 'POST', body: data });
}

async function apiCajaCerrar(data) {
    return apiCall('/caja/cerrar.php', { method: 'POST', body: data });
}

async function apiCajaTransaccion(data) {
    return apiCall('/caja/transacciones.php', { method: 'POST', body: data });
}

async function apiCuentasCrear(data) {
    return apiCall('/cuentas/crear.php', { method: 'POST', body: data });
}

/**
 * Funciones para Contabilidad
 */
async function apiContabilidad(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/contabilidad/obtener.php${query ? '?' + query : ''}` : '/contabilidad/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

async function apiContabilidadActualizar(id, data) {
    return apiCall('/contabilidad/actualizar.php', { method: 'POST', body: { id, ...data } });
}

async function apiContabilidadEliminar(id) {
    return apiCall('/contabilidad/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones de Autenticación
 */
async function apiLogin(email, password, documento, placa) {
    const body = { password };
    if (email) body.email = email;
    if (documento) body.documento = documento;
    if (placa) body.placa = placa;
    const data = await apiCall('/auth/login.php', { method: 'POST', body });
    if (data && data.data) {
        if (data.data.token) {
            localStorage.setItem('motorsoft_token', data.data.token);
        }
        localStorage.setItem('motorsoft_sesion', JSON.stringify({
            tipo: data.data.tipo,
            rol: data.data.rol,
            redirect: data.data.redirect
        }));
        if (data.data.usuario) {
            localStorage.setItem('motorsoft_usuario', JSON.stringify(data.data.usuario));
        }
        if (data.data.cliente) {
            localStorage.setItem('motorsoft_cliente', JSON.stringify(data.data.cliente));
        }
    }
    return data;
}

async function apiLogout() {
    try {
        return await apiCall('/auth/logout.php', { method: 'POST' });
    } finally {
        localStorage.removeItem('motorsoft_token');
        localStorage.removeItem('motorsoft_usuario');
        localStorage.removeItem('motorsoft_sesion');
        localStorage.removeItem('motorsoft_cliente');
    }
}

async function apiMe() {
    return apiCall('/auth/me.php');
}

async function apiAuditoria(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/auditoria/obtener.php${query ? '?' + query : ''}`);
}

async function apiDashboard(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/dashboard/obtener.php${query ? '?' + query : ''}`);
}

/**
 * Funciones para Stock
 */
async function apiMovimientoStock(data) {
    return apiCall('/stock/movimiento.php', { method: 'POST', body: data });
}

async function apiStockKardex(idProducto) {
    return apiCall('/stock/obtener.php?id_producto=' + encodeURIComponent(idProducto));
}

/**
 * Funciones para Consumos
 */
async function apiConsumosCrear(data) {
    return apiCall('/mecanicos/consumos.php', { method: 'POST', body: data });
}

async function apiConsumosObtener(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/mecanicos/consumos.php${query ? '?' + query : ''}`);
}

async function apiMecanicoDashboard() {
    return apiCall('/mecanicos/dashboard.php');
}

async function apiMecanicoPerfil() {
    return apiCall('/mecanicos/perfil.php');
}

async function apiMecanicoPerfilActualizar(data) {
    return apiCall('/mecanicos/perfil.php', { method: 'POST', body: data });
}

/**
 * Funciones para Chat
 */
function chatQuery(params = {}) {
    const clean = {};
    Object.keys(params || {}).forEach(k => {
        if (params[k] !== undefined && params[k] !== null && params[k] !== '') {
            clean[k] = params[k];
        }
    });
    clean._ = String(Date.now());
    const query = new URLSearchParams(clean).toString();
    return query ? `?${query}` : '';
}

async function apiChatConversaciones(params = {}) {
    return apiCall('/chat/conversaciones.php' + chatQuery(params));
}

async function apiChatContactos(params = {}) {
    return apiCall('/chat/contactos.php' + chatQuery(params));
}

async function apiChatCrearContacto(data) {
    return apiCall('/chat/crear-contacto.php', { method: 'POST', body: data });
}

async function apiChatAbrir(data) {
    return apiCall('/chat/abrir.php', { method: 'POST', body: data });
}

async function apiChatObtener(params = {}) {
    return apiCall('/chat/obtener.php' + chatQuery(params));
}

async function apiChatEnviar(data) {
    return apiCall('/chat/enviar.php', { method: 'POST', body: data });
}

async function apiChatLeer(data = {}) {
    return apiCall('/chat/leer.php', { method: 'POST', body: data });
}

async function apiAdjuntos(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall('/adjuntos/obtener.php' + (query ? '?' + query : ''));
}

async function apiAdjuntoSubir(file, entidadTipo, entidadId) {
    const fd = new FormData();
    fd.append('archivo', file);
    fd.append('entidad_tipo', entidadTipo);
    fd.append('entidad_id', String(entidadId || 0));
    return apiCall('/adjuntos/subir.php', { method: 'POST', body: fd, timeout: 30000 });
}

function urlAdjunto(id) {
    const token = (typeof localStorage !== 'undefined' && localStorage.getItem('motorsoft_token')) || '';
    return `${API_BASE}/adjuntos/ver.php?id=${encodeURIComponent(id)}&token=${encodeURIComponent(token)}`;
}

function htmlGaleriaEvidencias(lista, vacio) {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
    const items = Array.isArray(lista) ? lista : [];
    if (!items.length) {
        return '<p class="text-muted evidencias-vacio">' + esc(vacio || 'Sin fotos ni documentos.') + '</p>';
    }
    return '<div class="evidencias-grid">' + items.map(a => {
        const url = esc(urlAdjunto(a.id_adjunto));
        const nombre = esc(a.nombre_original || 'Archivo');
        if (a.es_imagen) {
            return '<a class="evidencia-item evidencia-img" href="' + url + '" target="_blank" rel="noopener">' +
                '<img src="' + url + '" alt="' + nombre + '"><span>' + nombre + '</span></a>';
        }
        return '<a class="evidencia-item evidencia-file" href="' + url + '" target="_blank" rel="noopener">' +
            '<i class="fas fa-file-pdf"></i><span>' + nombre + '</span></a>';
    }).join('') + '</div>';
}

function htmlAdjuntoMensaje(m, escFn) {
    const esc = typeof escFn === 'function' ? escFn : (s) => String(s ?? '');
    const adj = m && m.adjunto;
    const id = adj?.id_adjunto || m?.id_adjunto;
    if (!id) return `<p>${esc(m?.contenido || '')}</p>`;
    const nombre = adj?.nombre_original || m?.contenido || 'Archivo';
    const url = urlAdjunto(id);
    const img = adj?.es_imagen || /jpe?g|png|gif$/i.test(adj?.extension || '');
    const caption = (m.contenido && m.contenido !== nombre) ? `<p>${esc(m.contenido)}</p>` : '';
    if (img) {
        return `${caption}<button type="button" class="chat-adjunto-img js-visor-archivo" data-src="${esc(url)}" data-nombre="${esc(nombre)}" data-tipo="imagen"><img src="${esc(url)}" alt="${esc(nombre)}"></button>`;
    }
    return `${caption}<button type="button" class="chat-adjunto js-visor-archivo" data-src="${esc(url)}" data-nombre="${esc(nombre)}" data-tipo="archivo"><i class="fas fa-paperclip"></i> ${esc(nombre)}</button>`;
}

function escHtmlVisor(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function asegurarVisorArchivo() {
    let el = document.getElementById('motorsoft-visor');
    if (el) return el;
    if (!document.getElementById('motorsoft-visor-css')) {
        const css = document.createElement('style');
        css.id = 'motorsoft-visor-css';
        css.textContent = [
            '#motorsoft-visor{position:fixed;inset:0;z-index:8000;display:flex;align-items:center;justify-content:center;padding:1.25rem}',
            '#motorsoft-visor[hidden]{display:none!important}',
            '.ms-visor-fondo{position:absolute;inset:0;background:rgba(15,23,42,.78)}',
            '.ms-visor-caja{position:relative;z-index:1;max-width:min(960px,100%);max-height:90vh}',
            '.ms-visor-cuerpo img,.ms-visor-cuerpo iframe{display:block;max-width:100%;max-height:85vh;width:auto;height:auto;margin:0 auto;border:0;border-radius:12px;background:#111;box-shadow:0 20px 50px rgba(0,0,0,.4)}',
            '.ms-visor-cuerpo iframe{width:min(960px,100%);height:min(85vh,720px)}',
            '.ms-visor-cerrar{position:absolute;top:-10px;right:-10px;width:36px;height:36px;border:0;border-radius:50%;background:#fff;color:#111;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,.25);z-index:2}',
            'body.ms-visor-open{overflow:hidden}'
        ].join('');
        document.head.appendChild(css);
    }
    el = document.createElement('div');
    el.id = 'motorsoft-visor';
    el.hidden = true;
    el.innerHTML = '<div class="ms-visor-fondo" data-cerrar="1"></div>' +
        '<div class="ms-visor-caja" role="dialog" aria-modal="true" aria-label="Vista del archivo">' +
        '<button type="button" class="ms-visor-cerrar" data-cerrar="1" aria-label="Cerrar"><i class="fas fa-times"></i></button>' +
        '<div class="ms-visor-cuerpo"></div></div>';
    document.body.appendChild(el);
    el.addEventListener('click', e => {
        if (e.target.closest('[data-cerrar]')) cerrarVisorArchivo();
    });
    return el;
}

function abrirVisorArchivo(src, nombre, tipo) {
    if (!src) return;
    const el = asegurarVisorArchivo();
    const cuerpo = el.querySelector('.ms-visor-cuerpo');
    const seguro = escHtmlVisor(src);
    const alt = escHtmlVisor(nombre || 'Archivo');
    if (tipo === 'archivo') {
        cuerpo.innerHTML = '<iframe src="' + seguro + '" title="' + alt + '"></iframe>';
    } else {
        cuerpo.innerHTML = '<img src="' + seguro + '" alt="' + alt + '">';
    }
    el.hidden = false;
    document.body.classList.add('ms-visor-open');
}

function cerrarVisorArchivo() {
    const el = document.getElementById('motorsoft-visor');
    if (!el) return;
    el.hidden = true;
    const cuerpo = el.querySelector('.ms-visor-cuerpo');
    if (cuerpo) cuerpo.innerHTML = '';
    document.body.classList.remove('ms-visor-open');
}

function initVisorArchivo() {
    if (window.__msVisorBound) return;
    window.__msVisorBound = true;
    document.addEventListener('click', e => {
        const btn = e.target.closest('.js-visor-archivo');
        if (!btn) return;
        e.preventDefault();
        abrirVisorArchivo(btn.getAttribute('data-src'), btn.getAttribute('data-nombre'), btn.getAttribute('data-tipo') || 'imagen');
    });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') cerrarVisorArchivo();
    });
}

if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initVisorArchivo);
    } else {
        initVisorArchivo();
    }
}

async function apiFacturaPdf(id) {
    const url = `${API_BASE}/facturas/pdf.php?id=${encodeURIComponent(id)}`;
    const token = (typeof localStorage !== 'undefined' && localStorage.getItem('motorsoft_token')) || '';
    const response = await fetch(url, {
        headers: token ? { Authorization: 'Bearer ' + token } : {},
        cache: 'no-store'
    });
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.mensaje || 'No se pudo descargar el PDF');
    }
    const blob = await response.blob();
    const href = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = href;
    a.download = `factura-${id}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 1500);
}

async function apiReportes(tipo, params = {}) {
    const query = new URLSearchParams({ tipo: tipo || 'ordenes', ...params }).toString();
    return apiCall('/reportes/obtener.php?' + query);
}

function descargarCsv(nombre, encabezados, filas) {
    const sep = ';';
    const celda = (v) => {
        const s = String(v ?? '');
        if (/[;"\n\r]/.test(s)) {
            return '"' + s.replace(/"/g, '""') + '"';
        }
        return s;
    };
    const lineas = [encabezados.map(celda).join(sep)];
    (filas || []).forEach(fila => {
        lineas.push((Array.isArray(fila) ? fila : []).map(celda).join(sep));
    });
    const blob = new Blob(['\uFEFF' + lineas.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const href = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = href;
    a.download = `${nombre || 'reporte'}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 1500);
}

async function apiWhatsAppProbar() {
    return apiCall('/chat/whatsapp-probar.php', { method: 'POST', timeout: 25000 });
}

async function apiWhatsAppEstado() {
    return apiCall('/chat/whatsapp-probar.php');
}

async function apiWhatsAppSimular(data = {}) {
    return apiCall('/chat/whatsapp-simular.php', { method: 'POST', body: data });
}

/**
 * Funciones de compatibilidad con código existente
 */
function idUsuarioSesion() {
    try {
        const u = JSON.parse(localStorage.getItem('motorsoft_usuario') || 'null');
        if (u && (u.id_usuario || u.id)) return String(u.id_usuario || u.id);
    } catch (e) { /* ignore */ }
    return '';
}

function idClienteSesionNum() {
    try {
        const c = JSON.parse(localStorage.getItem('motorsoft_cliente') || 'null');
        if (c && (c.id_cliente || c.id)) return Number(c.id_cliente || c.id) || 0;
    } catch (e) { /* ignore */ }
    return 0;
}

function chatMensajeEsMio(m) {
    if (!m) return false;
    const tipo = String(m.tipo_emisor || 'Usuario').toLowerCase();
    const emisor = Number(m.emisor_id);
    const yoUsuario = Number(idUsuarioSesion() || 0);
    const yoCliente = idClienteSesionNum();
    if (yoUsuario > 0 && Number.isFinite(emisor) && emisor > 0) {
        return tipo !== 'cliente' && tipo !== 'proveedor' && emisor === yoUsuario;
    }
    if (yoCliente > 0 && Number.isFinite(emisor) && emisor > 0) {
        return tipo === 'cliente' && emisor === yoCliente;
    }
    return !!m.mio;
}

function normalizarEstadoOrden(estado) {
    const mapa = {
        'En Progreso': 'En Proceso',
        'Finalizada': 'Completada',
        'Finalizado': 'Completada'
    };
    return mapa[estado] || estado;
}

function mapOrdenMecanico(o) {
    if (!o) return null;
    if (o.numero && o.clienteNombre && o.fechaCreacion && o.servicios) return o;
    const veh = o.vehiculo || {};
    const detalles = Array.isArray(o.detalles) ? o.detalles : [];
    return {
        id: String(o.id_orden ?? o.id ?? ''),
        id_orden: o.id_orden ?? o.id,
        numero: 'OT #' + (o.id_orden ?? o.id ?? ''),
        clienteNombre: o.cliente_nombre || veh.cliente_nombre || '—',
        clienteTelefono: veh.cliente_telefono || '',
        clienteEmail: veh.cliente_email || '',
        id_cliente: o.id_cliente || veh.id_cliente || 0,
        vehiculoModelo: o.vehiculo_label || [veh.marca, veh.modelo].filter(Boolean).join(' ') || '—',
        vehiculoPlaca: o.placa || veh.placa || '',
        vehiculoTipo: o.vehiculo_tipo || veh.tipo || '',
        fechaCreacion: o.fecha_ingreso || o.created_at || '',
        estado: o.estado,
        servicios: detalles.map(d => ({
            id: d.id_servicio,
            nombre: (d.servicio && d.servicio.nombre) || ('Servicio #' + d.id_servicio),
            precio: Number(d.precio ?? d.subtotal ?? 0),
            descripcion: (d.servicio && d.servicio.descripcion) || ''
        })),
        repuestos: (Array.isArray(o.repuestos) ? o.repuestos : []).map(r => ({
            id: r.id_producto || r.id_items,
            nombre: r.producto || r.nombre || ('Producto #' + (r.id_producto || '')),
            precio: Number(r.precio_unitario ?? r.precio ?? 0),
            cantidad: Number(r.cantidad || 1)
        })),
        notas: o.descripcion || '',
        raw: o
    };
}

async function obtenerOrdenes(mecanicoId) {
    const params = {};
    const raw = mecanicoId != null ? String(mecanicoId) : '';
    const id = /^\d+$/.test(raw) ? raw : idUsuarioSesion();
    if (id) params.mecanico_id = id;
    const data = await apiOrdenes(true, params);
    return (data.data || []).map(mapOrdenMecanico);
}

async function obtenerOrden(ordenId) {
    const data = await apiOrdenes(true, { id: ordenId });
    const item = Array.isArray(data.data) ? data.data[0] : data.data;
    return mapOrdenMecanico(item);
}

async function actualizarEstadoOrden(ordenId, estado, mecanicoId) {
    const data = await apiOrdenesActualizar(ordenId, {
        id_orden: ordenId,
        estado: normalizarEstadoOrden(estado),
        mecanico_id: mecanicoId
    });
    return mapOrdenMecanico(data.data || data) || data.data || null;
}

async function obtenerClientes() {
    const data = await apiClientes(true);
    return data.data || [];
}

async function obtenerVehiculos() {
    const data = await apiVehiculos(true);
    return data.data || [];
}

async function obtenerProductos() {
    const data = await apiProductos(true);
    return data.data || [];
}

async function buscarProductos(query) {
    const data = await apiProductos(true, { busqueda: query });
    return data.data || [];
}

async function obtenerServicios() {
    const data = await apiServicios();
    return data.data || [];
}

async function obtenerConversaciones(mecanicoId) {
    const data = await apiChatObtener({ mecanicoId });
    return data.data || [];
}

async function enviarMensajeChat(conversacionId, texto, mecanicoId) {
    const data = await apiChatEnviar({ conversacionId, texto, mecanicoId });
    return data.data || null;
}

async function obtenerPerfil(mecanicoId) {
    const data = await apiUsuarios({ id: mecanicoId });
    return data.data || null;
}

async function actualizarPerfil(perfilData, mecanicoId) {
    const data = await apiUsuariosActualizar(mecanicoId, perfilData);
    return data.data || null;
}

// Exportar funciones globalmente
if (typeof window !== 'undefined') {
    window.apiCall = apiCall;
    
    // Nuevas funciones API
    window.apiClientes = apiClientes;
    window.apiClientesActualizar = apiClientesActualizar;
    window.apiClientesEliminar = apiClientesEliminar;
    window.apiVehiculos = apiVehiculos;
    window.apiVehiculosActualizar = apiVehiculosActualizar;
    window.apiVehiculosEliminar = apiVehiculosEliminar;
    window.apiOrdenes = apiOrdenes;
    window.apiOrdenesActualizar = apiOrdenesActualizar;
    window.apiOrdenesEliminar = apiOrdenesEliminar;
    window.apiProductos = apiProductos;
    window.apiProductosActualizar = apiProductosActualizar;
    window.apiProductosEliminar = apiProductosEliminar;
    window.apiCategorias = apiCategorias;
    window.apiCategoriasCrear = apiCategoriasCrear;
    window.apiServicios = apiServicios;
    window.apiServiciosCrear = apiServiciosCrear;
    window.apiServiciosActualizar = apiServiciosActualizar;
    window.apiServiciosEstado = apiServiciosEstado;
    window.apiUsuarios = apiUsuarios;
    window.apiUsuariosActualizar = apiUsuariosActualizar;
    window.apiUsuariosEliminar = apiUsuariosEliminar;
    window.apiUsuariosInvitar = apiUsuariosInvitar;
    window.apiFacturas = apiFacturas;
    window.apiFacturasActualizar = apiFacturasActualizar;
    window.apiFacturasEliminar = apiFacturasEliminar;
    window.apiVentas = apiVentas;
    window.apiConfiguracion = apiConfiguracion;
    window.apiConfiguracionActualizar = apiConfiguracionActualizar;
    window.apiConfiguracionLogoSubir = apiConfiguracionLogoSubir;
    window.apiConfiguracionLogoQuitar = apiConfiguracionLogoQuitar;
    window.apiConfiguracionLogoBlob = apiConfiguracionLogoBlob;
    window.apiCorreoProbar = apiCorreoProbar;
    window.apiConfiguracionBuzon = apiConfiguracionBuzon;
    window.apiRoles = apiRoles;
    window.apiRolesPermisos = apiRolesPermisos;
    window.apiRolesRestaurar = apiRolesRestaurar;
    window.apiEspecialidades = apiEspecialidades;
    window.apiEspecialidadesCrear = apiEspecialidadesCrear;
    window.apiEspecialidadesActualizar = apiEspecialidadesActualizar;
    window.apiEspecialidadesEliminar = apiEspecialidadesEliminar;
    window.apiEspecialidadesAsignar = apiEspecialidadesAsignar;
    window.apiContratos = apiContratos;
    window.apiContratosCrear = apiContratosCrear;
    window.apiContratosActualizar = apiContratosActualizar;
    window.apiContratosEliminar = apiContratosEliminar;
    window.apiNominas = apiNominas;
    window.apiNominasCrear = apiNominasCrear;
    window.apiAgenda = apiAgenda;
    window.apiAgendaCrear = apiAgendaCrear;
    window.apiAgendaCancelar = apiAgendaCancelar;
    window.apiAgendaMecanicos = apiAgendaMecanicos;
    window.apiCitas = apiCitas;
    window.apiCitasCrear = apiCitasCrear;
    window.apiCitasActualizar = apiCitasActualizar;
    window.apiCitasConvertir = apiCitasConvertir;
    window.apiCaja = apiCaja;
    window.apiCajaActiva = apiCajaActiva;
    window.apiCajaAbrir = apiCajaAbrir;
    window.apiCajaCerrar = apiCajaCerrar;
    window.apiCajaTransaccion = apiCajaTransaccion;
    window.apiCuentasCrear = apiCuentasCrear;
    window.apiContabilidad = apiContabilidad;
    window.apiContabilidadActualizar = apiContabilidadActualizar;
    window.apiContabilidadEliminar = apiContabilidadEliminar;
    window.apiLogin = apiLogin;
    window.apiLogout = apiLogout;
    window.apiMe = apiMe;
    window.apiAuditoria = apiAuditoria;
    window.apiDashboard = apiDashboard;
    window.apiMecanicoDashboard = apiMecanicoDashboard;
    window.apiMecanicoPerfil = apiMecanicoPerfil;
    window.apiMecanicoPerfilActualizar = apiMecanicoPerfilActualizar;
    window.apiMovimientoStock = apiMovimientoStock;
    window.apiStockKardex = apiStockKardex;
    window.apiConsumosCrear = apiConsumosCrear;
    window.apiConsumosObtener = apiConsumosObtener;
    window.apiChatConversaciones = apiChatConversaciones;
    window.apiChatContactos = apiChatContactos;
    window.apiChatCrearContacto = apiChatCrearContacto;
    window.apiChatAbrir = apiChatAbrir;
    window.apiChatObtener = apiChatObtener;
    window.apiChatEnviar = apiChatEnviar;
    window.apiChatLeer = apiChatLeer;
    window.apiAdjuntos = apiAdjuntos;
    window.apiAdjuntoSubir = apiAdjuntoSubir;
    window.urlAdjunto = urlAdjunto;
    window.htmlAdjuntoMensaje = htmlAdjuntoMensaje;
    window.htmlGaleriaEvidencias = htmlGaleriaEvidencias;
    window.MotorSoftVisor = { abrir: abrirVisorArchivo, cerrar: cerrarVisorArchivo };
    window.apiFacturaPdf = apiFacturaPdf;
    window.apiReportes = apiReportes;
    window.apiWhatsAppProbar = apiWhatsAppProbar;
    window.apiWhatsAppEstado = apiWhatsAppEstado;
    window.apiWhatsAppSimular = apiWhatsAppSimular;
    window.chatMensajeEsMio = chatMensajeEsMio;
    
    // Funciones de compatibilidad
    window.obtenerOrdenes = obtenerOrdenes;
    window.obtenerOrden = obtenerOrden;
    window.actualizarEstadoOrden = actualizarEstadoOrden;
    window.obtenerClientes = obtenerClientes;
    window.obtenerVehiculos = obtenerVehiculos;
    window.obtenerProductos = obtenerProductos;
    window.buscarProductos = buscarProductos;
    window.obtenerServicios = obtenerServicios;
    window.obtenerConversaciones = obtenerConversaciones;
    window.enviarMensajeChat = enviarMensajeChat;
    window.obtenerPerfil = obtenerPerfil;
    window.actualizarPerfil = actualizarPerfil;
    window.mapOrdenMecanico = mapOrdenMecanico;
}
