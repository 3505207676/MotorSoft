/**
 * Validadores para App Mecánicos
 * Funciones de validación para formularios y datos
 */

// ===== VALIDACIONES GENERALES =====

/**
 * Validar que un campo no esté vacío
 */
function validarRequerido(valor, nombreCampo = 'Campo') {
    if (!valor || valor.toString().trim() === '') {
        return {
            valido: false,
            mensaje: `${nombreCampo} es requerido`
        };
    }
    return { valido: true };
}

/**
 * Validar longitud mínima
 */
function validarLongitudMinima(valor, longitud, nombreCampo = 'Campo') {
    if (!valor || valor.toString().length < longitud) {
        return {
            valido: false,
            mensaje: `${nombreCampo} debe tener al menos ${longitud} caracteres`
        };
    }
    return { valido: true };
}

/**
 * Validar longitud máxima
 */
function validarLongitudMaxima(valor, longitud, nombreCampo = 'Campo') {
    if (valor && valor.toString().length > longitud) {
        return {
            valido: false,
            mensaje: `${nombreCampo} no puede tener más de ${longitud} caracteres`
        };
    }
    return { valido: true };
}

/**
 * Validar email
 */
function validarEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        return {
            valido: false,
            mensaje: 'Email no válido'
        };
    }
    return { valido: true };
}

/**
 * Validar teléfono colombiano
 */
function validarTelefono(telefono) {
    const telefonoRegex = /^(\+57|57)?[1-9]\d{9}$/;
    const telefonoLimpio = telefono.replace(/\s/g, '');
    
    if (!telefonoLimpio || !telefonoRegex.test(telefonoLimpio)) {
        return {
            valido: false,
            mensaje: 'Teléfono colombiano no válido'
        };
    }
    return { valido: true };
}

/**
 * Validar número positivo
 */
function validarNumeroPositivo(valor, nombreCampo = 'Número') {
    const numero = parseFloat(valor);
    if (isNaN(numero) || numero <= 0) {
        return {
            valido: false,
            mensaje: `${nombreCampo} debe ser un número positivo`
        };
    }
    return { valido: true };
}

/**
 * Validar número entero positivo
 */
function validarEnteroPositivo(valor, nombreCampo = 'Número') {
    const numero = parseInt(valor);
    if (isNaN(numero) || numero <= 0 || !Number.isInteger(parseFloat(valor))) {
        return {
            valido: false,
            mensaje: `${nombreCampo} debe ser un número entero positivo`
        };
    }
    return { valido: true };
}

// ===== VALIDACIONES ESPECÍFICAS DE ÓRDENES =====

/**
 * Validar estado de orden
 */
function validarEstadoOrden(estado) {
    const estadosValidos = ['Pendiente', 'En Progreso', 'Finalizada', 'Cancelada'];
    if (!estadosValidos.includes(estado)) {
        return {
            valido: false,
            mensaje: `Estado no válido. Debe ser: ${estadosValidos.join(', ')}`
        };
    }
    return { valido: true };
}

/**
 * Validar datos de cliente
 */
function validarCliente(cliente) {
    const errores = [];
    
    // Validar nombre
    const nombreValido = validarRequerido(cliente.nombre, 'Nombre del cliente');
    if (!nombreValido.valido) errores.push(nombreValido.mensaje);
    
    // Validar teléfono
    if (cliente.telefono) {
        const telefonoValido = validarTelefono(cliente.telefono);
        if (!telefonoValido.valido) errores.push(telefonoValido.mensaje);
    }
    
    // Validar email
    if (cliente.email) {
        const emailValido = validarEmail(cliente.email);
        if (!emailValido.valido) errores.push(emailValido.mensaje);
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

/**
 * Validar datos de vehículo
 */
function validarVehiculo(vehiculo) {
    const errores = [];
    
    // Validar placa
    const placaValida = validarRequerido(vehiculo.placa, 'Placa del vehículo');
    if (!placaValida.valido) errores.push(placaValida.mensaje);
    
    // Validar marca
    const marcaValida = validarRequerido(vehiculo.marca, 'Marca del vehículo');
    if (!marcaValida.valido) errores.push(marcaValida.mensaje);
    
    // Validar modelo
    const modeloValido = validarRequerido(vehiculo.modelo, 'Modelo del vehículo');
    if (!modeloValido.valido) errores.push(modeloValido.mensaje);
    
    // Validar año
    if (vehiculo.ano) {
        const anoActual = new Date().getFullYear();
        const ano = parseInt(vehiculo.ano);
        if (isNaN(ano) || ano < 1900 || ano > anoActual + 1) {
            errores.push(`Año debe estar entre 1900 y ${anoActual + 1}`);
        }
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

// ===== VALIDACIONES DE STOCK =====

/**
 * Validar datos de producto
 */
function validarProducto(producto) {
    const errores = [];
    
    // Validar código
    const codigoValido = validarRequerido(producto.codigo, 'Código del producto');
    if (!codigoValido.valido) errores.push(codigoValido.mensaje);
    
    // Validar nombre
    const nombreValido = validarRequerido(producto.nombre, 'Nombre del producto');
    if (!nombreValido.valido) errores.push(nombreValido.mensaje);
    
    // Validar categoría
    const categoriaValida = validarRequerido(producto.categoria, 'Categoría');
    if (!categoriaValida.valido) errores.push(categoriaValida.mensaje);
    
    // Validar precio
    if (producto.precio !== undefined) {
        const precioValido = validarNumeroPositivo(producto.precio, 'Precio');
        if (!precioValido.valido) errores.push(precioValido.mensaje);
    }
    
    // Validar stock
    if (producto.stock !== undefined) {
        const stockValido = validarEnteroPositivo(producto.stock, 'Stock');
        if (!stockValido.valido) errores.push(stockValido.mensaje);
    }
    
    // Validar stock mínimo
    if (producto.stockMinimo !== undefined) {
        const stockMinValido = validarEnteroPositivo(producto.stockMinimo, 'Stock mínimo');
        if (!stockMinValido.valido) errores.push(stockMinValido.mensaje);
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

/**
 * Validar disponibilidad de stock
 */
function validarStockDisponible(productoId, cantidadSolicitada, stockActual) {
    if (cantidadSolicitada > stockActual) {
        return {
            valido: false,
            mensaje: `Stock insuficiente. Disponible: ${stockActual}, Solicitado: ${cantidadSolicitada}`
        };
    }
    return { valido: true };
}

/**
 * Validar movimiento de stock
 */
function validarMovimientoStock(movimiento) {
    const errores = [];
    
    // Validar tipo
    const tiposValidos = ['ENTRADA', 'SALIDA', 'AJUSTE'];
    if (!movimiento.tipo || !tiposValidos.includes(movimiento.tipo)) {
        errores.push(`Tipo de movimiento no válido. Debe ser: ${tiposValidos.join(', ')}`);
    }
    
    // Validar cantidad
    const cantidadValida = validarNumeroPositivo(movimiento.cantidad, 'Cantidad');
    if (!cantidadValida.valido) errores.push(cantidadValida.mensaje);
    
    // Validar motivo
    const motivoValido = validarRequerido(movimiento.motivo, 'Motivo');
    if (!motivoValido.valido) errores.push(motivoValido.mensaje);
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

// ===== VALIDACIONES DE CONSUMOS =====

/**
 * Validar consumo
 */
function validarConsumo(consumo) {
    const errores = [];
    
    // Validar orden
    const ordenValida = validarRequerido(consumo.ordenId, 'ID de orden');
    if (!ordenValida.valido) errores.push(ordenValida.mensaje);
    
    // Validar producto
    const productoValido = validarRequerido(consumo.productoId, 'Producto');
    if (!productoValido.valido) errores.push(productoValido.mensaje);
    
    // Validar cantidad
    const cantidadValida = validarEnteroPositivo(consumo.cantidad, 'Cantidad');
    if (!cantidadValida.valido) errores.push(cantidadValida.mensaje);
    
    // Validar observaciones (opcional pero con longitud máxima)
    if (consumo.observaciones) {
        const obsValida = validarLongitudMaxima(consumo.observaciones, 500, 'Observaciones');
        if (!obsValida.valido) errores.push(obsValida.mensaje);
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

// ===== VALIDACIONES DE CHAT =====

/**
 * Validar mensaje de chat
 */
function validarMensaje(mensaje) {
    const errores = [];
    
    // Validar texto
    const textoValido = validarRequerido(mensaje.texto, 'Mensaje');
    if (!textoValido.valido) errores.push(textoValido.mensaje);
    
    // Validar longitud máxima
    const longitudValida = validarLongitudMaxima(mensaje.texto, 1000, 'Mensaje');
    if (!longitudValida.valido) errores.push(longitudValida.mensaje);
    
    // Validar tipo
    const tiposValidos = ['enviado', 'recibido'];
    if (mensaje.tipo && !tiposValidos.includes(mensaje.tipo)) {
        errores.push(`Tipo de mensaje no válido. Debe ser: ${tiposValidos.join(', ')}`);
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

// ===== VALIDACIONES DE PERFIL =====

/**
 * Validar perfil de mecánico
 */
function validarPerfilMecanico(perfil) {
    const errores = [];
    
    // Validar nombre
    const nombreValido = validarRequerido(perfil.nombre, 'Nombre');
    if (!nombreValido.valido) errores.push(nombreValido.mensaje);
    
    // Validar longitud del nombre
    const nombreLongitud = validarLongitudMaxima(perfil.nombre, 100, 'Nombre');
    if (!nombreLongitud.valido) errores.push(nombreLongitud.valido);
    
    // Validar email si se proporciona
    if (perfil.email) {
        const emailValido = validarEmail(perfil.email);
        if (!emailValido.valido) errores.push(emailValido.mensaje);
    }
    
    // Validar teléfono si se proporciona
    if (perfil.telefono) {
        const telefonoValido = validarTelefono(perfil.telefono);
        if (!telefonoValido.valido) errores.push(telefonoValido.mensaje);
    }
    
    // Validar estado
    if (perfil.estado) {
        const estadosValidos = ['disponible', 'ocupado', 'ausente'];
        if (!estadosValidos.includes(perfil.estado)) {
            errores.push(`Estado no válido. Debe ser: ${estadosValidos.join(', ')}`);
        }
    }
    
    // Validar especialidad si se proporciona
    if (perfil.especialidad) {
        const especialidadValida = validarLongitudMaxima(perfil.especialidad, 100, 'Especialidad');
        if (!especialidadValida.valido) errores.push(especialidadValida.mensaje);
    }
    
    return {
        valido: errores.length === 0,
        mensaje: errores.join(', ')
    };
}

// ===== VALIDACIONES DE FORMULARIOS =====

/**
 * Validar formulario completo
 */
function validarFormulario(formulario, reglas) {
    const errores = {};
    let esValido = true;
    
    Object.keys(reglas).forEach(campo => {
        const valor = formulario[campo];
        const validaciones = reglas[campo];
        
        for (const validacion of validaciones) {
            const resultado = validacion(valor, campo);
            if (!resultado.valido) {
                errores[campo] = resultado.mensaje;
                esValido = false;
                break; // Solo mostrar el primer error por campo
            }
        }
    });
    
    return {
        valido: esValido,
        errores
    };
}

/**
 * Limpiar errores de validación
 */
function limpiarErroresValidacion(contenedor) {
    const elementosError = contenedor.querySelectorAll('.error-message, .field-error');
    elementosError.forEach(elemento => elemento.remove());
    
    const camposConError = contenedor.querySelectorAll('.field-error');
    camposConError.forEach(campo => campo.classList.remove('field-error'));
}

/**
 * Mostrar errores de validación en el DOM
 */
function mostrarErroresValidacion(errores, contenedor) {
    limpiarErroresValidacion(contenedor);
    
    Object.keys(errores).forEach(campo => {
        const elemento = contenedor.querySelector(`[name="${campo}"], #${campo}`);
        if (elemento) {
            // Marcar campo con error
            elemento.classList.add('field-error');
            
            // Crear mensaje de error
            const mensajeError = document.createElement('div');
            mensajeError.className = 'error-message';
            mensajeError.textContent = errores[campo];
            
            // Insertar después del campo
            elemento.parentNode.insertBefore(mensajeError, elemento.nextSibling);
        }
    });
}

// ===== UTILIDADES DE VALIDACIÓN =====

/**
 * Sanitizar entrada de texto
 */
function sanitizarTexto(texto) {
    if (typeof texto !== 'string') return '';
    return texto.trim().replace(/[<>]/g, '');
}

/**
 * Formatear número colombiano
 */
function formatearNumeroColombiano(numero) {
    return new Intl.NumberFormat('es-CO').format(numero);
}

/**
 * Validar formato de fecha
 */
function validarFecha(fecha) {
    const fechaObj = new Date(fecha);
    if (isNaN(fechaObj.getTime())) {
        return {
            valido: false,
            mensaje: 'Fecha no válida'
        };
    }
    return { valido: true };
}

/**
 * Validar rango de fechas
 */
function validarRangoFechas(fechaInicio, fechaFin) {
    const inicio = new Date(fechaInicio);
    const fin = new Date(fechaFin);
    
    if (inicio > fin) {
        return {
            valido: false,
            mensaje: 'La fecha de inicio debe ser anterior a la fecha fin'
        };
    }
    return { valido: true };
}
