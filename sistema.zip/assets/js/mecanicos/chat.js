/**
 * Chat de la app mecánico: mismos hilos reales que el taller
 * (recientes arriba, no leídos visibles, sin simulación).
 */
window.MotorSoftChatScriptCargado = true;

const MecChat = {
    conversaciones: [],
    actual: null,
    mensajes: [],
    filtro: '',
    tipo: '',
    poll: null,
    abriendo: false,
    recien: new Set(),
    idsMensajes: new Set(),
    flashIds: new Set(),
    noLeidos: 0,
    enviando: false,
    cargando: false,
    pollVersion: 0
};

function toast(msg, tipo) {
    if (typeof window.showToast === 'function') window.showToast(msg, tipo);
}

function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function esMio(m) {
    return typeof window.chatMensajeEsMio === 'function' ? window.chatMensajeEsMio(m) : !!m.mio;
}

function idMensaje(m) {
    return Number(m && m.id_mensaje) || 0;
}

function claveConv(c) {
    if (!c) return '';
    return `${c.tipo_contacto || 'Cliente'}:${c.id_contacto || c.id_cliente || 0}:${c.canal || 'Interno'}`;
}

function actividadDe(c) {
    return c?.actividad_at || c?.ultimo?.fecha_hora || '';
}

function ordenarConversaciones(items) {
    return [...items].sort((a, b) => {
        const ua = Number(a.no_leidos) > 0 ? 1 : 0;
        const ub = Number(b.no_leidos) > 0 ? 1 : 0;
        if (ub !== ua) return ub - ua;
        const cmp = String(actividadDe(b)).localeCompare(String(actividadDe(a)));
        if (cmp) return cmp;
        return (Number(b.total_mensajes) || 0) - (Number(a.total_mensajes) || 0);
    });
}

function detectarRecien(anteriores, actuales) {
    const recien = new Set();
    if (!anteriores.length) return recien;
    const prev = new Map(anteriores.map(c => [claveConv(c), Number(c.no_leidos) || 0]));
    actuales.forEach(c => {
        const n = Number(c.no_leidos) || 0;
        if (n > 0 && n > (prev.get(claveConv(c)) || 0)) recien.add(claveConv(c));
    });
    return recien;
}

function preview(texto) {
    const t = String(texto || '').trim();
    return t.length > 48 ? t.slice(0, 48) + '…' : (t || 'Sin mensajes');
}

function previewLinea(c) {
    if (!c?.ultimo?.contenido) return 'Sin mensajes';
    const texto = preview(c.ultimo.contenido);
    return esMio(c.ultimo) ? `Tú: ${texto}` : texto;
}

function horaLista(fecha) {
    if (!fecha) return '';
    const d = new Date(String(fecha).replace(' ', 'T'));
    if (Number.isNaN(d.getTime())) return '';
    const now = new Date();
    const diff = (now.getTime() - d.getTime()) / 1000;
    if (diff < 45) return 'ahora';
    if (diff < 3600) return `hace ${Math.max(1, Math.floor(diff / 60))} min`;
    if (d.toDateString() === now.toDateString()) {
        return d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
    }
    const ayer = new Date(now);
    ayer.setDate(now.getDate() - 1);
    if (d.toDateString() === ayer.toDateString()) return 'ayer';
    return d.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit' });
}

function hora(fecha) {
    if (!fecha) return '';
    const d = new Date(String(fecha).replace(' ', 'T'));
    if (Number.isNaN(d.getTime())) return fecha;
    return d.toLocaleString('es-CO', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
}

function iconoTipo(tipo) {
    if (tipo === 'Proveedor') return 'fa-truck';
    if (tipo === 'Usuario') return 'fa-user-tie';
    return 'fa-user';
}

function etiquetaTipo(tipo) {
    if (tipo === 'Proveedor') return 'Proveedor';
    if (tipo === 'Usuario') return 'Personal';
    return 'Cliente';
}

function firmaLista() {
    const actualKey = claveConv(MecChat.actual);
    const q = MecChat.filtro;
    return MecChat.conversaciones.map(c => {
        const k = claveConv(c);
        return [
            k,
            Number(c.no_leidos) || 0,
            previewLinea(c),
            horaLista(actividadDe(c)),
            MecChat.recien.has(k) ? 1 : 0,
            actualKey === k ? 1 : 0,
            q
        ].join(':');
    }).join('|');
}

function firmaMensajes(lista, flash) {
    const ids = [...(flash || [])].sort().join(',');
    return (lista || []).map(m => `${idMensaje(m)}:${m.contenido || ''}:${esMio(m) ? 1 : 0}`).join('|') + '#' + ids;
}

function esMobile() {
    return window.matchMedia('(max-width: 768px)').matches;
}

function mostrarMovil(panel) {
    const lista = document.getElementById('chat-sidebar');
    const main = document.getElementById('chat-main-panel');
    const back = document.getElementById('btn-volver-chats');
    if (!esMobile()) {
        lista?.classList.remove('hidden');
        main?.classList.remove('hidden');
        back?.classList.add('hidden');
        return;
    }
    const verLista = panel !== 'chat';
    lista?.classList.toggle('hidden', !verLista);
    main?.classList.toggle('hidden', verLista);
    back?.classList.toggle('hidden', verLista);
}

function unwrapChat(res) {
    return res?.data?.conversaciones || [];
}

function payloadConv(c) {
    const body = {
        tipo_contacto: c.tipo_contacto || 'Cliente',
        id_contacto: Number(c.id_contacto || c.id_cliente || 0),
        canal: c.canal || 'Interno'
    };
    if (c.id_conversacion) body.id_conversacion = Number(c.id_conversacion);
    if (body.tipo_contacto === 'Cliente') body.id_cliente = body.id_contacto;
    return body;
}

function puedeEnviar() {
    return !window.MotorSoftGuard || window.MotorSoftGuard.puede('chat.enviar');
}

function aplicarComposer() {
    const ok = puedeEnviar() && !!MecChat.actual && !MecChat.enviando;
    const input = document.getElementById('input-mensaje');
    const btn = document.getElementById('btn-enviar');
    const adj = document.getElementById('btn-adjuntar');
    const nueva = document.getElementById('btn-nueva-conversacion');
    if (input) {
        input.disabled = !ok;
        input.placeholder = !MecChat.actual
            ? 'Seleccione una conversación'
            : (puedeEnviar() ? 'Escribe un mensaje...' : 'No tiene permiso para enviar');
    }
    if (btn) btn.disabled = !ok;
    if (adj) adj.disabled = !ok;
    if (nueva) nueva.hidden = !puedeEnviar();
}

function toggleModal(id, abierto) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.toggle('active', abierto);
    modal.classList.toggle('show', abierto);
    modal.style.display = abierto ? 'flex' : 'none';
}

async function asegurarConversacion() {
    if (!MecChat.actual) return null;
    if (MecChat.actual.id_conversacion || !window.apiChatAbrir) return MecChat.actual;
    const abierta = await window.apiChatAbrir(payloadConv(MecChat.actual));
    MecChat.actual = { ...MecChat.actual, ...(abierta.data || abierta) };
    return MecChat.actual;
}

function pintarBadge() {
    const n = Number(MecChat.noLeidos) || 0;
    const el = document.getElementById('chat-badge');
    if (el) {
        el.textContent = String(n);
        el.classList.toggle('hidden', n < 1);
    }
}

function setChipTipo(tipo) {
    document.querySelectorAll('#chat-filtros-tipo .chat-chip').forEach(btn => {
        btn.classList.toggle('active', (btn.getAttribute('data-tipo') || '') === tipo);
    });
}

async function cargar() {
    if (MecChat.cargando) return;
    MecChat.cargando = true;
    const box = document.getElementById('ordenes-chat-list');
    if (box && !MecChat.conversaciones.length) {
        box.innerHTML = '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i><p>Cargando chats...</p></div>';
    }
    try {
        const params = {};
        if (MecChat.tipo) params.tipo_contacto = MecChat.tipo;
        if (MecChat.filtro) params.q = MecChat.filtro;
        const res = await window.apiChatConversaciones(params);
        const nuevas = ordenarConversaciones(unwrapChat(res));
        MecChat.recien = detectarRecien(MecChat.conversaciones, nuevas);
        MecChat.conversaciones = nuevas;
        MecChat.noLeidos = Number(res.data?.no_leidos || 0);
        if (MecChat.actual) {
            const k = claveConv(MecChat.actual);
            const fresco = MecChat.conversaciones.find(c => claveConv(c) === k);
            if (fresco) MecChat.actual = { ...MecChat.actual, ...fresco };
        }
        const scroll = box ? box.scrollTop : 0;
        pintarLista();
        if (box) box.scrollTop = scroll;
        pintarBadge();
        if (MecChat.recien.size) {
            clearTimeout(cargar._tRecien);
            cargar._tRecien = setTimeout(() => {
                MecChat.recien = new Set();
                pintarLista();
            }, 2500);
        }
    } catch (e) {
        if (box) box.innerHTML = `<p style="padding:1rem">${esc(e.message || 'Error al cargar')}</p>`;
        toast(e.message || 'Error al cargar chat', 'error');
    } finally {
        MecChat.cargando = false;
    }
}

function pintarLista() {
    const box = document.getElementById('ordenes-chat-list');
    if (!box) return false;
    const firma = firmaLista();
    if (box.dataset.firma === firma) return false;
    box.dataset.firma = firma;
    const q = MecChat.filtro;
    const items = MecChat.conversaciones.filter(c => {
        if (!q) return true;
        const blob = `${c.nombre || ''} ${c.documento || ''} ${c.telefono || ''}`.toLowerCase();
        return blob.includes(q);
    });
    if (!items.length) {
        box.innerHTML = '<div class="chat-empty-list"><i class="fas fa-comments"></i><p>No hay conversaciones en este filtro.</p><p>Use + para escribirle a un cliente o al personal.</p></div>';
        return;
    }
    const actualKey = claveConv(MecChat.actual);
    box.innerHTML = items.map(c => {
        const k = claveConv(c);
        const noLeidos = Number(c.no_leidos) || 0;
        const clases = ['orden-chat-item'];
        if (actualKey === k) clases.push('active');
        if (noLeidos > 0) clases.push('no-leido');
        if (MecChat.recien.has(k)) clases.push('recien');
        if (!c.ultimo && !(Number(c.total_mensajes) > 0)) clases.push('sin-actividad');
        const badge = noLeidos > 0
            ? `<span class="orden-badge" title="${noLeidos} sin leer">${noLeidos}</span>`
            : '';
        return `<button type="button" class="${clases.join(' ')}" data-key="${esc(k)}">
            <div class="orden-avatar"><i class="fas ${iconoTipo(c.tipo_contacto)}"></i></div>
            <div class="orden-info">
                <p class="orden-cliente-nombre">${esc(c.nombre)}</p>
                <p class="orden-ultimo-mensaje">${esc(previewLinea(c))}</p>
            </div>
            <div class="orden-meta">
                <span class="orden-hora">${esc(horaLista(actividadDe(c)))}</span>
                <span class="orden-tipo">${esc(etiquetaTipo(c.tipo_contacto))}</span>
                ${badge}
            </div>
        </button>`;
    }).join('');
}

async function abrir(conv) {
    if (!conv || MecChat.abriendo) return;
    MecChat.abriendo = true;
    try {
        let actual = { ...conv };
        if (!actual.id_conversacion && window.apiChatAbrir) {
            try {
                const abierta = await window.apiChatAbrir({
                    tipo_contacto: actual.tipo_contacto || 'Cliente',
                    id_contacto: Number(actual.id_contacto || actual.id_cliente || 0),
                    canal: actual.canal || 'Interno'
                });
                actual = { ...actual, ...(abierta.data || abierta) };
            } catch (e) {
                toast(e.message || 'No se pudo abrir', 'error');
            }
        }
        MecChat.actual = actual;
        document.getElementById('chat-cliente-nombre').textContent = actual.nombre || 'Conversación';
        document.getElementById('chat-vehiculo-info').textContent = [
            etiquetaTipo(actual.tipo_contacto),
            actual.documento,
            actual.telefono
        ].filter(Boolean).join(' · ') || 'Chat interno';
        document.getElementById('chat-input-container')?.classList.remove('hidden');
        aplicarComposer();
        const res = await window.apiChatObtener(payloadConv(actual));
        MecChat.mensajes = Array.isArray(res.data) ? res.data : [];
        MecChat.idsMensajes = new Set(MecChat.mensajes.map(idMensaje).filter(Boolean));
        const box = document.getElementById('mensajes-container');
        if (box) delete box.dataset.ready;
        pintarMensajes();
        pintarLista();
        mostrarMovil('chat');
        arrancarPoll();
        await cargar().catch(() => {});
    } finally {
        MecChat.abriendo = false;
    }
}

async function recargarMensajes() {
    if (!MecChat.actual) return [];
    const previos = new Set(MecChat.idsMensajes);
    const res = await window.apiChatObtener({ ...payloadConv(MecChat.actual), silencioso: 1 });
    const lista = Array.isArray(res.data) ? res.data : [];
    const idsNuevos = lista
        .filter(m => {
            const id = idMensaje(m);
            return id && !previos.has(id) && !esMio(m);
        })
        .map(idMensaje);
    idsNuevos.forEach(id => MecChat.flashIds.add(id));
        MecChat.mensajes = lista;
    MecChat.idsMensajes = new Set(lista.map(idMensaje).filter(Boolean));
    const box = document.getElementById('mensajes-container');
    const firma = firmaMensajes(MecChat.mensajes, MecChat.flashIds);
    if (!box || box.dataset.firma !== firma) {
        pintarMensajes([...MecChat.flashIds]);
    }
    if (idsNuevos.length) {
        clearTimeout(recargarMensajes._flash);
        recargarMensajes._flash = setTimeout(() => {
            MecChat.flashIds = new Set();
            document.querySelectorAll('#mensajes-container .mensaje.recien').forEach(el => el.classList.remove('recien'));
            const el = document.getElementById('mensajes-container');
            if (el) el.dataset.firma = firmaMensajes(MecChat.mensajes, []);
        }, 2800);
    }
    return idsNuevos;
}

function pintarMensajes(idsNuevos = []) {
    const box = document.getElementById('mensajes-container');
    if (!box) return;
    if (!MecChat.actual) {
        box.innerHTML = `<div class="chat-welcome">
            <div class="welcome-icon"><i class="fas fa-comments"></i></div>
            <h3>Bienvenido al Chat</h3>
            <p>Selecciona una conversación para ver los mensajes reales del taller</p>
        </div>`;
        return;
    }
    if (!MecChat.mensajes.length) {
        box.innerHTML = '<div class="chat-welcome"><p>Aún no hay mensajes. Escriba el primero.</p></div>';
        return;
    }
    const primeraVez = box.dataset.ready !== '1';
    const cercaDelFinal = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
    const nuevos = new Set(idsNuevos.map(Number));
    const firma = firmaMensajes(MecChat.mensajes, nuevos);
    if (box.dataset.firma === firma && box.dataset.ready === '1') return;
    box.dataset.firma = firma;
    box.innerHTML = MecChat.mensajes.map(m => `
        <div class="mensaje ${esMio(m) ? 'enviado' : 'recibido'}${nuevos.has(idMensaje(m)) ? ' recien' : ''}">
            <div class="mensaje-contenido">
                <div class="mensaje-texto">${typeof window.htmlAdjuntoMensaje === 'function' ? window.htmlAdjuntoMensaje(m, esc) : `<p>${esc(m.contenido)}</p>`}</div>
                <div class="mensaje-hora">${esc(hora(m.fecha_hora))} · ${esc(m.emisor_nombre || '')}</div>
            </div>
        </div>
    `).join('');
    box.dataset.ready = '1';
    if (primeraVez || cercaDelFinal || idsNuevos.length) {
        box.scrollTop = box.scrollHeight;
    }
}

async function enviar(e) {
    if (e) e.preventDefault();
    const input = document.getElementById('input-mensaje');
    const texto = (input?.value || '').trim();
    if (!texto || !MecChat.actual) return;
    await enviarPayload(texto, 0);
}

async function enviarPayload(texto, idAdjunto) {
    if (!MecChat.actual || MecChat.enviando) return;
    if (!puedeEnviar()) {
        toast('No tiene permiso para enviar mensajes', 'error');
        return;
    }
    MecChat.enviando = true;
    aplicarComposer();
    try {
        const body = payloadConv(MecChat.actual);
        body.contenido = texto || '';
        if (idAdjunto) body.id_adjunto = idAdjunto;
        const res = await window.apiChatEnviar(body);
        const enviado = res.data || {};
        if (enviado.id_conversacion) {
            MecChat.actual = { ...MecChat.actual, id_conversacion: Number(enviado.id_conversacion) };
        }
        const input = document.getElementById('input-mensaje');
        if (input) input.value = '';
        await recargarMensajes();
        await cargar();
    } catch (err) {
        toast(err.message || 'No se pudo enviar', 'error');
    } finally {
        MecChat.enviando = false;
        aplicarComposer();
    }
}

async function adjuntarArchivo(file) {
    if (!MecChat.actual) {
        toast('Seleccione una conversación', 'info');
        return;
    }
    if (String(MecChat.actual.canal || '').toLowerCase() === 'whatsapp') {
        toast('En WhatsApp no se envían archivos. Use el chat interno.', 'info');
        return;
    }
    try {
        await asegurarConversacion();
        const res = await window.apiAdjuntoSubir(file, 'conversacion', MecChat.actual.id_conversacion || 0);
        const id = res.data?.id_adjunto;
        if (!id) throw new Error('No se recibió el archivo');
        const texto = (document.getElementById('input-mensaje')?.value || '').trim();
        await enviarPayload(texto, id);
    } catch (err) {
        toast(err.message || 'No se pudo adjuntar', 'error');
    }
}

async function abrirDesdeOrden(ordenId) {
    if (!ordenId || typeof window.obtenerOrden !== 'function') return;
    try {
        const orden = await window.obtenerOrden(ordenId);
        const idCliente = Number(orden?.id_cliente || orden?.raw?.id_cliente || orden?.raw?.vehiculo?.id_cliente || 0);
        if (idCliente < 1) {
            toast('Esta orden no tiene un cliente asociado', 'error');
            return;
        }
        MecChat.tipo = 'Cliente';
        setChipTipo('Cliente');
        await abrir({
            tipo_contacto: 'Cliente',
            id_contacto: idCliente,
            id_cliente: idCliente,
            canal: 'Interno',
            nombre: orden.clienteNombre || 'Cliente',
            telefono: orden.clienteTelefono || '',
            documento: orden.vehiculoPlaca || ''
        });
    } catch (e) {
        toast(e.message || 'No se pudo abrir el chat de la orden', 'error');
    }
}

async function cargarContactosModal() {
    const tipo = document.getElementById('nueva-conv-tipo')?.value || 'Cliente';
    const q = document.getElementById('nueva-conv-buscar')?.value || '';
    const box = document.getElementById('nueva-conv-lista');
    if (box) box.innerHTML = '<p class="text-muted">Cargando...</p>';
    try {
        const res = await window.apiChatContactos({ tipo_contacto: tipo, q });
        const items = res.data?.contactos || [];
        if (!box) return;
        if (!items.length) {
            box.innerHTML = '<p class="text-muted">No hay contactos de este tipo.</p>';
            return;
        }
        box.innerHTML = items.map(c => `
            <button type="button" class="chat-contacto-item" data-tipo="${esc(c.tipo_contacto)}" data-id="${c.id_contacto}">
                <strong>${esc(c.nombre)}</strong>
                <small>${esc([c.documento, c.telefono].filter(Boolean).join(' · '))}</small>
            </button>
        `).join('');
    } catch (e) {
        if (box) box.innerHTML = `<p>${esc(e.message || 'Error')}</p>`;
    }
}

async function elegirContactoModal(tipo, id) {
    toggleModal('modal-nueva-conversacion', false);
    MecChat.tipo = tipo;
    setChipTipo(tipo);
    await abrir({
        tipo_contacto: tipo,
        id_contacto: Number(id),
        id_cliente: tipo === 'Cliente' ? Number(id) : 0,
        canal: 'Interno',
        nombre: 'Conversación'
    });
    await cargar().catch(() => {});
}

function pintarInfoConversacion() {
    const c = MecChat.actual;
    const box = document.getElementById('info-conv-cuerpo');
    if (!c || !box) return;
    const filas = [
        ['Nombre', c.nombre || '—'],
        ['Tipo', etiquetaTipo(c.tipo_contacto)],
        ['Documento', c.documento || '—'],
        ['Teléfono', c.telefono || '—']
    ];
    box.innerHTML = `<dl class="chat-info-lista">${filas.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`;
}

function arrancarPoll() {
    if (MecChat.poll) clearTimeout(MecChat.poll);
    const version = ++MecChat.pollVersion;

    const tick = async () => {
        try {
            let nuevos = [];
            if (MecChat.actual) nuevos = await recargarMensajes();
            await cargar();
            if (nuevos.length && window.apiChatLeer && MecChat.actual) {
                await window.apiChatLeer(payloadConv(MecChat.actual)).catch(() => {});
            }
        } catch (_) {
            // La siguiente ejecución reintenta; nunca superponer peticiones.
        } finally {
            if (version === MecChat.pollVersion) {
                MecChat.poll = setTimeout(tick, MecChat.actual ? 6000 : 12000);
            }
        }
    };

    MecChat.poll = setTimeout(tick, MecChat.actual ? 6000 : 12000);
}

document.addEventListener('DOMContentLoaded', () => {
    window.MotorSoftChatIniciado = true;
    aplicarComposer();
    document.getElementById('btn-refresh-chats')?.addEventListener('click', () => cargar().catch(() => {}));
    document.getElementById('btn-nueva-conversacion')?.addEventListener('click', () => {
        if (!puedeEnviar()) {
            toast('No tiene permiso para iniciar conversaciones', 'error');
            return;
        }
        toggleModal('modal-nueva-conversacion', true);
        cargarContactosModal();
    });
    document.getElementById('btn-cerrar-nueva-conv')?.addEventListener('click', () => toggleModal('modal-nueva-conversacion', false));
    document.getElementById('modal-nueva-conversacion')?.addEventListener('click', e => {
        if (e.target.id === 'modal-nueva-conversacion') toggleModal('modal-nueva-conversacion', false);
    });
    document.getElementById('nueva-conv-tipo')?.addEventListener('change', cargarContactosModal);
    document.getElementById('nueva-conv-buscar')?.addEventListener('input', () => {
        clearTimeout(cargarContactosModal._t);
        cargarContactosModal._t = setTimeout(cargarContactosModal, 250);
    });
    document.getElementById('nueva-conv-lista')?.addEventListener('click', e => {
        const btn = e.target.closest('.chat-contacto-item');
        if (btn) elegirContactoModal(btn.dataset.tipo, btn.dataset.id);
    });
    document.getElementById('btn-cerrar-info-conv')?.addEventListener('click', () => toggleModal('modal-info-conversacion', false));
    document.getElementById('modal-info-conversacion')?.addEventListener('click', e => {
        if (e.target.id === 'modal-info-conversacion') toggleModal('modal-info-conversacion', false);
    });
    document.getElementById('btn-volver-chats')?.addEventListener('click', () => mostrarMovil('lista'));
    document.getElementById('chat-search-input')?.addEventListener('input', e => {
        MecChat.filtro = e.target.value.trim().toLowerCase();
        pintarLista();
        clearTimeout(cargar._tBuscar);
        cargar._tBuscar = setTimeout(() => cargar().catch(() => {}), 250);
    });
    document.getElementById('ordenes-chat-list')?.addEventListener('click', e => {
        const item = e.target.closest('[data-key]');
        if (!item) return;
        const conv = MecChat.conversaciones.find(c => claveConv(c) === item.dataset.key);
        if (conv) abrir(conv);
    });
    document.getElementById('chat-filtros-tipo')?.addEventListener('click', e => {
        const btn = e.target.closest('[data-tipo]');
        if (!btn) return;
        MecChat.tipo = btn.getAttribute('data-tipo') || '';
        setChipTipo(MecChat.tipo);
        cargar().catch(err => toast(err.message, 'error'));
    });
    document.getElementById('form-mensaje')?.addEventListener('submit', enviar);
    document.getElementById('btn-enviar')?.addEventListener('click', e => {
        e.preventDefault();
        enviar(e);
    });
    document.getElementById('input-mensaje')?.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            enviar(e);
        }
    });
    document.getElementById('btn-info-chat')?.addEventListener('click', () => {
        const c = MecChat.actual;
        if (!c) {
            toast('Seleccione una conversación', 'info');
            return;
        }
        pintarInfoConversacion();
        toggleModal('modal-info-conversacion', true);
    });
    document.getElementById('btn-adjuntar')?.addEventListener('click', () => {
        if (!MecChat.actual) {
            toast('Seleccione una conversación', 'info');
            return;
        }
        let input = document.getElementById('input-adjunto-chat');
        if (!input) {
            input = document.createElement('input');
            input.type = 'file';
            input.id = 'input-adjunto-chat';
            input.accept = 'image/jpeg,image/png,image/gif,application/pdf';
            input.hidden = true;
            input.addEventListener('change', () => {
                const file = input.files && input.files[0];
                if (file) adjuntarArchivo(file);
                input.value = '';
            });
            document.body.appendChild(input);
        }
        input.click();
    });
    mostrarMovil('lista');
    window.addEventListener('resize', () => mostrarMovil(MecChat.actual && esMobile() ? 'chat' : 'lista'));

    cargar().then(async () => {
        const ordenId = new URLSearchParams(window.location.search).get('orden');
        if (ordenId) await abrirDesdeOrden(ordenId);
    }).catch(() => {});

    arrancarPoll();
});
