/**
 * API App Mecánicos - Conectado a backend PHP
 * Wrapper que mantiene la interfaz window.API para compatibilidad con ordenes.js, stock.js, etc.
 */

// Cargar config si existe (debe cargarse antes este script o config.js antes)
const API_BASE = (typeof API_CONFIG !== 'undefined' && API_CONFIG.baseUrl) ? API_CONFIG.baseUrl : '../../controllers/api';

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        console.log(`Toast [${type}]: ${message}`);
        return;
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = { success: 'fas fa-check-circle', error: 'fas fa-exclamation-circle', warning: 'fas fa-exclamation-triangle', info: 'fas fa-info-circle' }[type] || 'fas fa-info-circle';
    toast.innerHTML = `<i class="${icon}"></i><span>${message}</span>`;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toastContainer.contains(toast) && toastContainer.removeChild(toast), 300);
    }, 4000);
}

function obtenerMecanicoActual() {
    try {
        const u = JSON.parse(localStorage.getItem('motorsoft_usuario') || 'null');
        if (u && (u.id_usuario || u.id)) return String(u.id_usuario || u.id);
    } catch (e) { /* ignore */ }
    const stored = localStorage.getItem('mecanico-id');
    if (stored && /^\d+$/.test(stored)) return stored;
    return '';
}

async function fetchOrdenes(mecanicoId) {
    try {
        const id = mecanicoId || obtenerMecanicoActual();
        if (typeof window.obtenerOrdenes === 'function') {
            return await window.obtenerOrdenes(id);
        }
        const qs = id ? `?mecanico_id=${encodeURIComponent(id)}` : '';
        const response = await fetch(`${API_BASE}/ordenes/obtener.php${qs}`);
        const data = await response.json();
        return data.data || data.ordenes || [];
    } catch (error) {
        console.error('Error fetchOrdenes:', error);
        showToast(error.message || 'Error al obtener órdenes', 'error');
        return [];
    }
}

async function fetchOrden(ordenId) {
    try {
        if (typeof window.obtenerOrden === 'function') {
            return await window.obtenerOrden(ordenId);
        }
        const response = await fetch(`${API_BASE}/ordenes/obtener-una.php?id=${encodeURIComponent(ordenId)}`);
        const data = await response.json();
        return data.orden || null;
    } catch (error) {
        console.error('Error fetchOrden:', error);
        showToast(error.message || 'Orden no encontrada', 'error');
        throw error;
    }
}

async function updateOrdenEstado(ordenId, nuevoEstado, mecanicoId) {
    try {
        const idMec = mecanicoId || obtenerMecanicoActual();
        if (typeof window.actualizarEstadoOrden === 'function') {
            const orden = await window.actualizarEstadoOrden(ordenId, nuevoEstado, idMec);
            showToast(`Orden actualizada a: ${nuevoEstado}`, 'success');
            return orden;
        }
        const response = await fetch(`${API_BASE}/ordenes/actualizar-estado.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_orden: ordenId, estado: nuevoEstado, mecanico_id: idMec })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.mensaje || data.message || 'Error al actualizar');
        showToast(`Orden actualizada a: ${nuevoEstado}`, 'success');
        return data.data || data.orden || null;
    } catch (error) {
        console.error('Error updateOrdenEstado:', error);
        showToast(error.message || 'Error al actualizar orden', 'error');
        throw error;
    }
}

async function fetchProductos() {
    try {
        if (typeof window.obtenerProductos === 'function') {
            return await window.obtenerProductos();
        }
        const response = await fetch(`${API_BASE}/productos/obtener.php`);
        const data = await response.json();
        return data.productos || [];
    } catch (error) {
        console.error('Error fetchProductos:', error);
        showToast(error.message || 'Error al obtener productos', 'error');
        return [];
    }
}

async function searchProductos(query) {
    try {
        if (typeof window.buscarProductos === 'function') {
            return await window.buscarProductos(query);
        }
        const response = await fetch(`${API_BASE}/productos/buscar.php?q=${encodeURIComponent(query)}`);
        const data = await response.json();
        return data.productos || [];
    } catch (error) {
        console.error('Error searchProductos:', error);
        return [];
    }
}

async function fetchProducto(productoId) {
    try {
        const productos = await fetchProductos();
        const producto = productos.find(p => p.id === productoId);
        if (!producto) throw new Error('Producto no encontrado');
        return producto;
    } catch (error) {
        console.error('Error fetchProducto:', error);
        throw error;
    }
}

async function createMovimientoStock(productoId, cantidad, tipo, ordenId = null, mecanicoId = 'MEC-001') {
    try {
        const response = await fetch(`${API_BASE}/productos/movimiento-stock.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ producto_id: productoId, cantidad, tipo, orden_id: ordenId, mecanico_id: mecanicoId })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.mensaje || 'Error en movimiento de stock');
        showToast(tipo === 'SALIDA' ? 'Stock retirado' : 'Stock agregado', 'success');
        return data.movimiento || null;
    } catch (error) {
        console.error('Error createMovimientoStock:', error);
        showToast(error.message || 'Error en movimiento de stock', 'error');
        throw error;
    }
}

async function createConsumo(ordenId, productoId, cantidad, observaciones = '', mecanicoId = 'MEC-001') {
    try {
        const response = await fetch(`${API_BASE}/consumos/crear.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orden_id: ordenId, producto_id: productoId, cantidad, observaciones, mecanico_id: mecanicoId })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.mensaje || 'Error al registrar consumo');
        showToast('Consumo registrado correctamente', 'success');
        return data.consumo || null;
    } catch (error) {
        console.error('Error createConsumo:', error);
        showToast(error.message || 'Error al registrar consumo', 'error');
        throw error;
    }
}

async function fetchConsumosOrden(ordenId) {
    try {
        const response = await fetch(`${API_BASE}/consumos/obtener.php?orden_id=${encodeURIComponent(ordenId)}`);
        const data = await response.json();
        return data.consumos || [];
    } catch (error) {
        console.error('Error fetchConsumosOrden:', error);
        return [];
    }
}

async function fetchConversaciones() {
    try {
        if (typeof window.apiChatConversaciones === 'function') {
            const res = await window.apiChatConversaciones({});
            return res.data?.conversaciones || [];
        }
        return [];
    } catch (error) {
        console.error('Error fetchConversaciones:', error);
        return [];
    }
}

async function enviarMensaje(conversacionId, texto) {
    try {
        if (typeof window.apiChatEnviar !== 'function') {
            throw new Error('Chat no disponible');
        }
        const data = await window.apiChatEnviar({
            id_conversacion: conversacionId,
            contenido: texto
        });
        return data.data || data.mensaje || null;
    } catch (error) {
        console.error('Error enviarMensaje:', error);
        showToast(error.message || 'Error al enviar mensaje', 'error');
        throw error;
    }
}

async function fetchCitas(params = {}) {
    try {
        if (typeof window.apiCitas === 'function') {
            const data = await window.apiCitas(params);
            return data.data || [];
        }
        const query = new URLSearchParams(params).toString();
        const response = await fetch(`${API_BASE}/citas/obtener.php${query ? '?' + query : ''}`);
        const data = await response.json();
        return data.data || [];
    } catch (error) {
        console.error('Error fetchCitas:', error);
        showToast(error.message || 'Error al obtener citas', 'error');
        return [];
    }
}

async function actualizarCita(idCita, payload) {
    try {
        if (typeof window.apiCitasActualizar === 'function') {
            const data = await window.apiCitasActualizar(idCita, payload);
            showToast(data.mensaje || 'Cita actualizada', 'success');
            return data.data || null;
        }
        const response = await fetch(`${API_BASE}/citas/actualizar.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_cita: idCita, ...payload })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.mensaje || 'Error al actualizar cita');
        showToast(data.mensaje || 'Cita actualizada', 'success');
        return data.data || null;
    } catch (error) {
        console.error('Error actualizarCita:', error);
        showToast(error.message || 'Error al actualizar cita', 'error');
        throw error;
    }
}

async function fetchPerfil(mecanicoId = 'MEC-001') {
    try {
        if (typeof window.obtenerPerfil === 'function') {
            return await window.obtenerPerfil(mecanicoId);
        }
        const response = await fetch(`${API_BASE}/perfil/obtener.php?mecanico_id=${encodeURIComponent(mecanicoId)}`);
        const data = await response.json();
        return data.perfil || null;
    } catch (error) {
        console.error('Error fetchPerfil:', error);
        return { id: mecanicoId, nombre: 'Mecánico', email: '', telefono: '', especialidad: '', estado: 'disponible' };
    }
}

async function updatePerfil(perfilData, mecanicoId = 'MEC-001') {
    try {
        if (typeof window.actualizarPerfil === 'function') {
            const perfil = await window.actualizarPerfil(perfilData, mecanicoId);
            showToast('Perfil actualizado correctamente', 'success');
            return perfil;
        }
        const response = await fetch(`${API_BASE}/perfil/actualizar.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...perfilData, mecanico_id: mecanicoId })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.mensaje || 'Error al actualizar perfil');
        showToast('Perfil actualizado correctamente', 'success');
        return data.perfil || null;
    } catch (error) {
        console.error('Error updatePerfil:', error);
        showToast(error.message || 'Error al actualizar perfil', 'error');
        throw error;
    }
}

async function initAPI() {
    console.log('API Mecánicos inicializada (backend PHP)');
    document.dispatchEvent(new Event('mecanicos-api-ready'));
}

if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', initAPI);
    window.APIReady = new Promise(resolve => {
        document.addEventListener('mecanicos-api-ready', resolve, { once: true });
    });
    window.API = {
        fetchOrdenes, fetchOrden, updateOrdenEstado,
        fetchProductos, searchProductos, fetchProducto,
        createMovimientoStock, createConsumo, fetchConsumosOrden,
        fetchConversaciones, enviarMensaje,
        fetchPerfil, updatePerfil,
        fetchCitas, actualizarCita,
        obtenerMecanicoActual
    };
    window.showToast = showToast;
    window.obtenerMecanicoActual = obtenerMecanicoActual;
}
