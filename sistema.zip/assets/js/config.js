/**
 * Configuración de API - Taller El Paisa
 * Rutas de endpoints y configuración global
 */

const API = {
    // Base URL para la API
    base: '../../controllers/api',
    
    // Endpoints de módulos
    clientes: {
        obtener: '/clientes/obtener.php',
        crear: '/clientes/crear.php',
        actualizar: '/clientes/actualizar.php',
        eliminar: '/clientes/eliminar.php'
    },
    
    vehiculos: {
        obtener: '/vehiculos/obtener.php',
        crear: '/vehiculos/crear.php',
        actualizar: '/vehiculos/actualizar.php',
        eliminar: '/vehiculos/eliminar.php'
    },
    
    ordenes: {
        obtener: '/ordenes/obtener.php',
        crear: '/ordenes/crear.php',
        actualizar: '/ordenes/actualizar.php',
        actualizarEstado: '/ordenes/actualizar-estado.php',
        detalle: '/ordenes/detalle.php',
        eliminar: '/ordenes/eliminar.php'
    },
    
    productos: {
        obtener: '/productos/obtener.php',
        crear: '/productos/crear.php',
        actualizar: '/productos/actualizar.php',
        eliminar: '/productos/eliminar.php'
    },

    categorias: {
        obtener: '/categorias/obtener.php',
        crear: '/categorias/crear.php',
        eliminar: '/categorias/eliminar.php'
    },
    
    servicios: {
        obtener: '/servicios/obtener.php',
        crear: '/servicios/crear.php',
        actualizar: '/servicios/actualizar.php',
        editar: '/servicios/editar.php',
        cambiarEstado: '/servicios/cambiar-estado.php'
    },

    especialidades: {
        obtener: '/especialidades/obtener.php',
        crear: '/especialidades/crear.php',
        actualizar: '/especialidades/actualizar.php',
        eliminar: '/especialidades/eliminar.php',
        asignar: '/especialidades/asignar.php'
    },

    roles: {
        obtener: '/roles/obtener.php',
        actualizar: '/roles/actualizar.php',
        restaurar: '/roles/restaurar.php'
    },
    
    usuarios: {
        obtener: '/usuarios/obtener.php',
        crear: '/usuarios/crear.php',
        actualizar: '/usuarios/actualizar.php',
        eliminar: '/usuarios/eliminar.php',
        asignarRol: '/usuarios/asignar-rol.php'
    },
    
    auth: {
        login: '/auth/login.php',
        logout: '/auth/logout.php',
        me: '/auth/me.php',
        register: '/auth/register.php',
        recuperar: '/auth/recuperar.php',
        resetPassword: '/auth/reset-password.php'
    },
    
    stock: {
        obtener: '/stock/obtener.php',
        movimiento: '/stock/movimiento.php'
    },
    
    consumos: {
        crear: '/consumos/crear.php',
        obtener: '/consumos/obtener.php'
    },
    
    chat: {
        conversaciones: '/chat/conversaciones.php',
        obtener: '/chat/obtener.php',
        enviar: '/chat/enviar.php',
        leer: '/chat/leer.php'
    },

    facturas: {
        obtener: '/facturas/obtener.php',
        crear: '/facturas/crear.php',
        actualizar: '/facturas/actualizar.php',
        eliminar: '/facturas/eliminar.php'
    },

    ventas: {
        obtener: '/ventas/obtener.php',
        crear: '/ventas/crear.php'
    },

    configuracion: {
        obtener: '/configuracion/obtener.php',
        actualizar: '/configuracion/actualizar.php'
    },

    contabilidad: {
        obtener: '/contabilidad/obtener.php',
        crear: '/contabilidad/crear.php',
        actualizar: '/contabilidad/actualizar.php',
        eliminar: '/contabilidad/eliminar.php'
    },

    citas: {
        obtener: '/citas/obtener.php',
        crear: '/citas/crear.php',
        actualizar: '/citas/actualizar.php',
        convertir: '/citas/convertir.php'
    },

    agenda: {
        obtener: '/agenda/obtener.php',
        crear: '/agenda/crear.php',
        actualizar: '/agenda/actualizar.php',
        mecanicos: '/agenda/mecanicos.php'
    },

    auditoria: {
        obtener: '/auditoria/obtener.php'
    },

    ventas: {
        obtener: '/ventas/obtener.php',
        crear: '/ventas/crear.php'
    },

    contratos: {
        obtener: '/contratos/obtener.php',
        crear: '/contratos/crear.php',
        actualizar: '/contratos/actualizar.php',
        eliminar: '/contratos/eliminar.php'
    },

    nominas: {
        obtener: '/nominas/obtener.php',
        crear: '/nominas/crear.php'
    }
};

// Configuración de la aplicación
const CONFIG = {
    // Paginación
    defaultPageSize: 10,
    maxPageSize: 100,
    
    // Tiempos de espera (ms)
    timeout: 10000,
    debounceDelay: 300,
    
    // Formatos
    formatos: {
        fecha: 'YYYY-MM-DD',
        fechaHora: 'YYYY-MM-DD HH:mm:ss',
        moneda: 'COP',
        decimales: 0
    },
    
    // Estados de órdenes
    estadosOrden: ['Pendiente', 'Diagnóstico', 'En Proceso', 'Pendiente Pago', 'Completada', 'Cancelada'],
    
    // Roles de usuarios
    roles: ['Administrador', 'Mecánico', 'Recepcionista'],
    
    // Categorías de productos
    categorias: ['Aceites', 'Filtros', 'Frenos', 'Suspensión', 'Motor', 'Eléctrico', 'Otros'],
    
    // Tipos de vehículo
    tiposVehiculo: ['Automóvil', 'Moto', 'Camioneta', 'Camión', 'Otro'],
    
    // Colores de estados
    coloresEstado: {
        'Pendiente': '#ffc107',
        'Diagnóstico': '#17a2b8',
        'En Proceso': '#007bff',
        'Pendiente Pago': '#fd7e14',
        'Completada': '#28a745',
        'Cancelada': '#dc3545'
    }
};

// Compatibilidad con estructura previa
const APP_CONFIG = {
    apiBaseUrl: API.base,
    timeout: CONFIG.timeout,
    endpoints: {
        // Autenticación
        login: API.auth.login,
        logout: API.auth.logout,
        verificarSesion: '/auth/verificar.php',

        // Órdenes
        ordenesObtener: API.ordenes.obtener,
        ordenesCrear: API.ordenes.crear,
        ordenesActualizar: API.ordenes.actualizar,
        ordenesEliminar: API.ordenes.eliminar,

        // Clientes
        clientesObtener: API.clientes.obtener,
        clientesCrear: API.clientes.crear,

        // Vehículos
        vehiculosObtener: API.vehiculos.obtener,

        // Productos
        productosObtener: API.productos.obtener,
        categoriasObtener: API.categorias.obtener,

        // Servicios
        serviciosObtener: API.servicios.obtener
    }
};

const API_CONFIG = {
    baseUrl: API.base,
    timeout: CONFIG.timeout,
    retryAttempts: 3,
    endpoints: {
        auth: API.auth,
        ordenes: API.ordenes,
        clientes: API.clientes,
        vehiculos: API.vehiculos,
        productos: API.productos,
        categorias: API.categorias,
        servicios: API.servicios,
        usuarios: API.usuarios,
        chat: API.chat,
        stock: API.stock,
        consumos: API.consumos,
        facturas: API.facturas,
        ventas: API.ventas,
        configuracion: API.configuracion
    }
};

// Exportar para uso global
if (typeof window !== 'undefined') {
    window.API = API;
    window.CONFIG = CONFIG;
    window.APP_CONFIG = APP_CONFIG;
    window.API_CONFIG = API_CONFIG;
}
