/**
 * Utilidades para modales
 */

/**
 * Crea un modal dinámicamente
 * @param {string} id - ID del modal
 * @param {string} title - Título del modal
 * @param {string} content - Contenido HTML del modal
 * @param {Function} onConfirm - Callback al confirmar
 * @returns {HTMLElement} - Elemento del modal
 */
export function createModal(id, title, content, onConfirm = null) {
    // Verificar si ya existe el modal
    let modal = document.getElementById(id);
    
    if (!modal) {
        // Crear estructura del modal
        modal = document.createElement('div');
        modal.id = id;
        modal.className = 'modal';
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="btn-close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-outline btn-cancel">Cancelar</button>
                    <button class="btn btn-primary btn-confirm">Confirmar</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Eventos para cerrar el modal
        const btnClose = modal.querySelector('.btn-close');
        const btnCancel = modal.querySelector('.btn-cancel');
        
        btnClose.addEventListener('click', () => {
            modal.classList.remove('active');
        });
        
        btnCancel.addEventListener('click', () => {
            modal.classList.remove('active');
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
        
        // Evento para confirmar acción
        const btnConfirm = modal.querySelector('.btn-confirm');
        if (onConfirm && btnConfirm) {
            btnConfirm.addEventListener('click', () => {
                onConfirm();
                modal.classList.remove('active');
            });
        }
    }
    
    // Mostrar modal
    modal.classList.add('active');
    
    return modal;
}

/**
 * Crea un modal de confirmación
 * @param {string} title - Título del modal
 * @param {string} message - Mensaje de confirmación
 * @param {Function} onConfirm - Callback al confirmar
 * @returns {HTMLElement} - Elemento del modal
 */
export function confirmAction(title, message, onConfirm) {
    return createModal(
        'modal-confirm',
        title,
        `<p>${message}</p>`,
        onConfirm
    );
}

/**
 * Crea un modal de alerta
 * @param {string} title - Título del modal
 * @param {string} message - Mensaje de alerta
 */
export function showAlert(title, message) {
    const modal = createModal(
        'modal-alert',
        title,
        `<p>${message}</p>`
    );
    
    // Cambiar botones para alerta
    const footer = modal.querySelector('.modal-footer');
    footer.innerHTML = `
        <button class="btn btn-primary btn-close-alert">Aceptar</button>
    `;
    
    const btnCloseAlert = modal.querySelector('.btn-close-alert');
    btnCloseAlert.addEventListener('click', () => {
        modal.classList.remove('active');
    });
}

/**
 * Abre un modal existente por su ID
 * @param {string} id - ID del modal
 */
export function openModal(id) {
    document.getElementById(id)?.classList.add('active');
}

/**
 * Cierra un modal existente por su ID
 * @param {string} id - ID del modal
 */
export function closeModal(id) {
    document.getElementById(id)?.classList.remove('active');
}

/**
 * Vincula botones para cerrar un modal
 * @param {string} modalId - ID del modal
 * @param {...string} btnIds - IDs de los botones que cierran el modal
 */
export function bindModalClose(modalId, ...btnIds) {
    btnIds.forEach(bid => {
        document.getElementById(bid)?.addEventListener('click', () => closeModal(modalId));
    });
    const modal = document.getElementById(modalId);
    modal?.addEventListener('click', e => {
        if (e.target === modal) closeModal(modalId);
    });
}
