/**
 * Tema único para bienvenida, cliente, taller y mecánicos.
 * Clave canónica: localStorage.tema (light|dark).
 * También sincroniza las claves viejas theme y mecanicos-theme.
 */
(function (window) {
    var KEY = 'tema';
    var LEGACY = ['theme', 'mecanicos-theme'];
    var SELECTOR = '#theme-toggle, #btn-theme, #btn-toggle-tema';

    function normalizar(valor) {
        if (valor === 'auto') {
            return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        return valor === 'dark' ? 'dark' : 'light';
    }

    function leer() {
        try {
            var t = localStorage.getItem(KEY);
            if (t === 'dark' || t === 'light' || t === 'auto') return normalizar(t);
            for (var i = 0; i < LEGACY.length; i++) {
                var v = localStorage.getItem(LEGACY[i]);
                if (v === 'dark' || v === 'light' || v === 'auto') return normalizar(v);
            }
        } catch (e) {}
        return 'light';
    }

    function pintarIconos(valor) {
        var cls = valor === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        document.querySelectorAll('#theme-toggle i, #btn-theme i, #theme-icon, #icon-tema').forEach(function (icon) {
            icon.className = cls;
        });
    }

    function aplicar(tema) {
        var valor = normalizar(tema);
        var root = document.documentElement;
        root.setAttribute('data-theme', valor);
        root.style.colorScheme = valor;
        root.classList.toggle('dark-theme', valor === 'dark');
        if (document.body) {
            document.body.setAttribute('data-theme', valor);
            document.body.classList.toggle('dark-theme', valor === 'dark');
        }
        try {
            localStorage.setItem(KEY, valor);
            localStorage.setItem('theme', valor);
            localStorage.setItem('mecanicos-theme', valor);
        } catch (e) {}
        pintarIconos(valor);
        return valor;
    }

    function toggle() {
        return aplicar(leer() === 'dark' ? 'light' : 'dark');
    }

    function init() {
        aplicar(leer());
        if (window.__motorsoftTemaBound) return;
        window.__motorsoftTemaBound = true;
        document.addEventListener('click', function (e) {
            var btn = e.target.closest(SELECTOR);
            if (!btn) return;
            e.preventDefault();
            toggle();
        });
    }

    window.MotorSoftTema = { leer: leer, aplicar: aplicar, toggle: toggle, init: init };
    window.aplicarTema = aplicar;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})(window);
