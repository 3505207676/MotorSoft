/**
 * Helpers de UI reutilizables
 * MotorSoft - Taller El Paisa
 */

/**
 * Función debounce para retrasar ejecución
 * @param {Function} fn - Función a ejecutar
 * @param {number} wait - Tiempo de espera en ms
 * @returns {Function} - Función con debounce
 */
export function debounce(fn, wait = 300) {
    let t;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn(...args), wait);
    };
}

/**
 * Genera el siguiente ID para una colección
 * @param {Array} collection - Colección de datos
 * @param {string} field - Campo del ID
 * @returns {number} - Siguiente ID
 */
export function nextId(collection, field = 'id') {
    if (!collection?.length) return 1;
    return Math.max(...collection.map(i => Number(i[field]) || 0)) + 1;
}

/**
 * Genera un badge HTML según el estado
 * @param {string} estado - Estado a mostrar
 * @param {Object} map - Mapa personalizado de clases
 * @returns {string} - HTML del badge
 */
export function badge(estado, map = {}) {
    const defaults = {
        Activo: 'bg-success', Inactivo: 'bg-secondary', Vigente: 'bg-success',
        Pendiente: 'bg-warning', Pagada: 'bg-success', Anulada: 'bg-danger',
        Programada: 'bg-primary', Confirmada: 'bg-success', Cancelada: 'bg-danger',
        Completada: 'bg-success', 'En Proceso': 'bg-info', Disponible: 'bg-success',
        Ocupado: 'bg-warning', Cerrada: 'bg-secondary', Activa: 'bg-success',
        Ingreso: 'bg-success', Egreso: 'bg-danger', CREATE: 'bg-success',
        UPDATE: 'bg-info', DELETE: 'bg-danger'
    };
    const cls = map[estado] || defaults[estado] || 'bg-primary';
    return `<span class="badge ${cls}">${estado}</span>`;
}

/**
 * Inicializa tabs en un contenedor
 * @param {string} containerSelector - Selector del contenedor
 * @param {Function} onChange - Callback al cambiar tab
 */
export function initTabs(containerSelector, onChange) {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    const tabs = container.querySelectorAll('[data-tab]');
    const panels = container.querySelectorAll('[data-panel]');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const id = tab.dataset.tab;
            tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === id));
            panels.forEach(p => p.classList.toggle('active', p.dataset.panel === id));
            if (onChange) onChange(id);
        });
    });
}

/**
 * Pagina un array de items
 * @param {Array} items - Items a paginar
 * @param {number} page - Página actual
 * @param {number} perPage - Items por página
 * @returns {Object} - Objeto con items paginados y metadata
 */
export function paginate(items, page, perPage) {
    const total = items.length;
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    const current = Math.min(Math.max(1, page), totalPages);
    const start = (current - 1) * perPage;
    return { items: items.slice(start, start + perPage), page: current, totalPages, total };
}

/**
 * Vincula controles de paginación
 * @param {HTMLElement} prevBtn - Botón anterior
 * @param {HTMLElement} nextBtn - Botón siguiente
 * @param {HTMLElement} labelEl - Elemento de etiqueta
 * @param {Object} state - Estado de paginación
 * @param {Function} renderFn - Función de renderizado
 * @returns {Function} - Función de actualización
 */
export function bindPagination(prevBtn, nextBtn, labelEl, state, renderFn) {
    const update = () => {
        if (labelEl) labelEl.textContent = `Página ${state.page} de ${state.totalPages}`;
        if (prevBtn) prevBtn.disabled = state.page <= 1;
        if (nextBtn) nextBtn.disabled = state.page >= state.totalPages;
        renderFn();
    };
    prevBtn?.addEventListener('click', () => { if (state.page > 1) { state.page--; update(); } });
    nextBtn?.addEventListener('click', () => { if (state.page < state.totalPages) { state.page++; update(); } });
    return update;
}

/**
 * Genera fila vacía para tablas
 * @param {number} cols - Número de columnas
 * @param {string} msg - Mensaje a mostrar
 * @returns {string} - HTML de la fila vacía
 */
export function emptyRow(cols, msg = 'Sin registros') {
    return `<tr><td colspan="${cols}" class="text-center text-muted">${msg}</td></tr>`;
}

/**
 * Genera botones de acción para tablas
 * @param {string|number} id - ID del item
 * @param {Object} options - Opciones de visibilidad
 * @returns {string} - HTML de los botones
 */
export function actionButtons(id, { view = true, edit = true, del = true } = {}) {
    return `<div class="table-actions">
        ${view ? `<button class="btn-icon btn-sm btn-view" data-id="${id}" title="Ver"><i class="fas fa-eye"></i></button>` : ''}
        ${edit ? `<button class="btn-icon btn-sm btn-edit" data-id="${id}" title="Editar"><i class="fas fa-edit"></i></button>` : ''}
        ${del ? `<button class="btn-icon btn-sm btn-delete" data-id="${id}" title="Eliminar"><i class="fas fa-trash"></i></button>` : ''}
    </div>`;
}

/**
 * Objeto con todos los helpers (para compatibilidad)
 */
export const uiHelpers = {
    debounce,
    nextId,
    badge,
    initTabs,
    paginate,
    bindPagination,
    emptyRow,
    actionButtons
};
