/**
 * Utilidades de validación para formularios
 * MotorSoft - Taller El Paisa
 */

/**
 * Valida formato de email
 * @param {string} email - Email a validar
 * @returns {boolean} - true si es válido
 */
export function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(String(email).toLowerCase());
}

/**
 * Valida teléfono colombiano (fijo o móvil)
 * Formatos aceptados: 3001234567, 300 123 4567, 300-123-4567, +57 300 123 4567
 * @param {string} phone - Teléfono a validar
 * @returns {boolean} - true si es válido
 */
export function validatePhone(phone) {
    const regex = /^(\+57|57)?[\s-]?([36]\d{2}|[1-8]\d{2})[\s-]?(\d{3})[\s-]?(\d{4})$/;
    return regex.test(String(phone).replace(/\s+/g, ' '));
}

/**
 * Valida que sea un número positivo
 * @param {string|number} value - Valor a validar
 * @returns {boolean} - true si es número positivo
 */
export function validatePositiveNumber(value) {
    const num = parseFloat(value);
    return !isNaN(num) && num > 0;
}

/**
 * Valida que sea un número entero positivo
 * @param {string|number} value - Valor a validar
 * @returns {boolean} - true si es entero positivo
 */
export function validatePositiveInteger(value) {
    const num = parseInt(value, 10);
    return !isNaN(num) && num > 0 && Number.isInteger(num);
}

/**
 * Valida longitud mínima de texto
 * @param {string} text - Texto a validar
 * @param {number} minLength - Longitud mínima requerida
 * @returns {boolean} - true si cumple longitud mínima
 */
export function validateMinLength(text, minLength) {
    return String(text).trim().length >= minLength;
}

/**
 * Valida longitud máxima de texto
 * @param {string} text - Texto a validar
 * @param {number} maxLength - Longitud máxima permitida
 * @returns {boolean} - true si no excede longitud máxima
 */
export function validateMaxLength(text, maxLength) {
    return String(text).trim().length <= maxLength;
}

/**
 * Valida rango de longitud de texto
 * @param {string} text - Texto a validar
 * @param {number} min - Longitud mínima
 * @param {number} max - Longitud máxima
 * @returns {boolean} - true si está en el rango
 */
export function validateLengthRange(text, min, max) {
    const length = String(text).trim().length;
    return length >= min && length <= max;
}

/**
 * Valida formato de placa vehicular colombiana
 * Formatos: ABC123 (carro), ABC12D (moto)
 */
export function validateVehiclePlate(plate) {
    const p = String(plate || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    return /^[A-Z]{3}[0-9]{3}$/.test(p) || /^[A-Z]{3}[0-9]{2}[A-Z]$/.test(p);
}

/**
 * Valida formato de cédula colombiana
 * @param {string} cedula - Cédula a validar
 * @returns {boolean} - true si es válida
 */
export function validateCedula(cedula) {
    const regex = /^\d{6,10}$/;
    return regex.test(String(cedula).replace(/\D/g, ''));
}

/**
 * Valida formato de NIT colombiano
 * @param {string} nit - NIT a validar
 * @returns {boolean} - true si es válido
 */
export function validateNit(nit) {
    const regex = /^\d{9,10}-?\d$/;
    return regex.test(String(nit).replace(/\s/g, ''));
}

/**
 * Valida que un campo no esté vacío
 * @param {string} value - Valor a validar
 * @returns {boolean} - true si no está vacío
 */
export function validateRequired(value) {
    return String(value).trim().length > 0;
}

/**
 * Valida formato de fecha (YYYY-MM-DD o DD/MM/YYYY)
 * @param {string} date - Fecha a validar
 * @returns {boolean} - true si es válida
 */
export function validateDate(date) {
    const regex1 = /^\d{4}-\d{2}-\d{2}$/; // YYYY-MM-DD
    const regex2 = /^\d{2}\/\d{2}\/\d{4}$/; // DD/MM/YYYY
    if (!regex1.test(date) && !regex2.test(date)) return false;
    
    const dateObj = new Date(date);
    return dateObj instanceof Date && !isNaN(dateObj);
}

/**
 * Valida rango numérico
 * @param {number} value - Valor a validar
 * @param {number} min - Valor mínimo
 * @param {number} max - Valor máximo
 * @returns {boolean} - true si está en el rango
 */
export function validateRange(value, min, max) {
    const num = parseFloat(value);
    return !isNaN(num) && num >= min && num <= max;
}

/**
 * Valida formato de URL
 * @param {string} url - URL a validar
 * @returns {boolean} - true si es válida
 */
export function validateUrl(url) {
    try {
        new URL(url);
        return true;
    } catch {
        return false;
    }
}

/**
 * Objeto con todas las validaciones (para compatibilidad)
 */
export const validators = {
    email: validateEmail,
    phone: validatePhone,
    positiveNumber: validatePositiveNumber,
    positiveInteger: validatePositiveInteger,
    minLength: validateMinLength,
    maxLength: validateMaxLength,
    lengthRange: validateLengthRange,
    vehiclePlate: validateVehiclePlate,
    cedula: validateCedula,
    nit: validateNit,
    required: validateRequired,
    date: validateDate,
    range: validateRange,
    url: validateUrl
};

/**
 * Clase para validar formularios completos
 */
export class FormValidator {
    constructor(formElement) {
        this.form = formElement;
        this.errors = {};
    }

    /**
     * Valida un campo individual
     * @param {HTMLElement} field - Campo a validar
     * @param {Object} rules - Reglas de validación
     * @returns {boolean} - true si es válido
     */
    validateField(field, rules) {
        const value = field.value;
        const fieldName = field.name || field.id;
        
        // Limpiar errores previos
        this.clearFieldError(field);
        
        // Validar cada regla
        for (const [rule, param] of Object.entries(rules)) {
            let isValid = true;
            let errorMessage = '';
            
            switch (rule) {
                case 'required':
                    isValid = validateRequired(value);
                    errorMessage = 'Este campo es obligatorio';
                    break;
                case 'email':
                    isValid = validateEmail(value);
                    errorMessage = 'Email inválido';
                    break;
                case 'phone':
                    isValid = validatePhone(value);
                    errorMessage = 'Teléfono inválido';
                    break;
                case 'minLength':
                    isValid = validateMinLength(value, param);
                    errorMessage = `Mínimo ${param} caracteres`;
                    break;
                case 'maxLength':
                    isValid = validateMaxLength(value, param);
                    errorMessage = `Máximo ${param} caracteres`;
                    break;
                case 'positiveNumber':
                    isValid = validatePositiveNumber(value);
                    errorMessage = 'Debe ser un número positivo';
                    break;
                case 'vehiclePlate':
                    isValid = validateVehiclePlate(value);
                    errorMessage = 'Placa inválida. Carro: ABC123. Moto: ABC12D';
                    break;
                case 'cedula':
                    isValid = validateCedula(value);
                    errorMessage = 'Cédula inválida';
                    break;
                case 'date':
                    isValid = validateDate(value);
                    errorMessage = 'Fecha inválida';
                    break;
            }
            
            if (!isValid) {
                this.showFieldError(field, errorMessage);
                this.errors[fieldName] = errorMessage;
                return false;
            }
        }
        
        return true;
    }

    /**
     * Muestra error en un campo
     * @param {HTMLElement} field - Campo con error
     * @param {string} message - Mensaje de error
     */
    showFieldError(field, message) {
        field.classList.add('error');
        
        // Crear elemento de error si no existe
        let errorElement = field.parentElement.querySelector('.error-message');
        if (!errorElement) {
            errorElement = document.createElement('span');
            errorElement.className = 'error-message';
            field.parentElement.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
    }

    /**
     * Limpia error de un campo
     * @param {HTMLElement} field - Campo a limpiar
     */
    clearFieldError(field) {
        field.classList.remove('error');
        const errorElement = field.parentElement.querySelector('.error-message');
        if (errorElement) {
            errorElement.remove();
        }
        
        const fieldName = field.name || field.id;
        delete this.errors[fieldName];
    }

    /**
     * Valida todo el formulario
     * @param {Object} validationRules - Reglas de validación por campo
     * @returns {boolean} - true si todo es válido
     */
    validateForm(validationRules) {
        this.errors = {};
        let isValid = true;
        
        for (const [fieldName, rules] of Object.entries(validationRules)) {
            const field = this.form.querySelector(`[name="${fieldName}"], #${fieldName}`);
            if (field && !this.validateField(field, rules)) {
                isValid = false;
            }
        }
        
        return isValid;
    }

    /**
     * Obtiene todos los errores
     * @returns {Object} - Objeto con errores por campo
     */
    getErrors() {
        return this.errors;
    }
}
