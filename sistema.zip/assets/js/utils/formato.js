/**
 * Utilidades de formato para datos
 * MotorSoft - Taller El Paisa
 */

/**
 * Formatea un valor como moneda colombiana
 * @param {number} amount - Valor a formatear
 * @returns {string} - Valor formateado como moneda
 */
export function formatCurrency(amount) {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0
    }).format(amount);
}

/**
 * Formatea una fecha
 * @param {Date|string} date - Fecha a formatear
 * @returns {string} - Fecha formateada
 */
export function formatDate(date) {
    if (!(date instanceof Date)) {
        date = new Date(date);
    }
    
    return new Intl.DateTimeFormat('es-CO', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    }).format(date);
}

/**
 * Formatea fecha y hora
 * @param {Date|string} value - Fecha a formatear
 * @returns {string} - Fecha y hora formateada
 */
export function formatDateTime(value) {
    if (!value) return '—';
    const d = new Date(value);
    return new Intl.DateTimeFormat('es-CO', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    }).format(d);
}

/**
 * Genera un ID único
 * @returns {string} - ID único
 */
export function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Objeto con todas las funciones de formato (para compatibilidad)
 */
export const formatUtils = {
    formatCurrency,
    formatDate,
    formatDateTime,
    generateId
};
