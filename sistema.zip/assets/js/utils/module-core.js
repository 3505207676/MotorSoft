/**
 * Utilidades compartidas para módulos del panel de trabajadores
 * MotorSoft - Taller El Paisa
 */
const ModuleCore = {
    debounce(fn, wait = 300) {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), wait);
        };
    },

    formatCurrency(amount) {
        return window.utils?.formatCurrency(amount) ??
            new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(amount || 0);
    },

    formatDate(value) {
        if (!value) return '—';
        const d = value instanceof Date ? value : new Date(value);
        if (Number.isNaN(d.getTime())) return String(value);
        return window.utils?.formatDate(d) ??
            new Intl.DateTimeFormat('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(d);
    },

    formatDateTime(value) {
        if (!value) return '—';
        const d = new Date(value);
        return new Intl.DateTimeFormat('es-CO', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        }).format(d);
    },

    nextId(collection, field = 'id') {
        if (!collection?.length) return 1;
        return Math.max(...collection.map(i => Number(i[field]) || 0)) + 1;
    },

    badge(estado, map = {}) {
        const defaults = {
            Activo: 'bg-success', Inactivo: 'bg-secondary', Vigente: 'bg-success',
            Pendiente: 'bg-warning', Pagada: 'bg-success', Anulada: 'bg-danger',
            Programada: 'bg-primary', Confirmada: 'bg-success', Cancelada: 'bg-danger',
            Completada: 'bg-success', 'En Proceso': 'bg-info', Disponible: 'bg-success',
            Ocupado: 'bg-warning', Cerrada: 'bg-secondary', Activa: 'bg-success',
            Ingreso: 'bg-success', Egreso: 'bg-danger', CREATE: 'bg-success',
            UPDATE: 'bg-info', DELETE: 'bg-danger'
        };
        const cls = map[estado] || defaults[estado] || 'bg-primary';
        return `<span class="badge ${cls}">${estado}</span>`;
    },

    initTabs(containerSelector, onChange) {
        const container = document.querySelector(containerSelector);
        if (!container) return;

        const tabs = container.querySelectorAll('[data-tab]');
        const panels = container.querySelectorAll('[data-panel]');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const id = tab.dataset.tab;
                tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === id));
                panels.forEach(p => p.classList.toggle('active', p.dataset.panel === id));
                if (onChange) onChange(id);
            });
        });
    },

    paginate(items, page, perPage) {
        const total = items.length;
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        const current = Math.min(Math.max(1, page), totalPages);
        const start = (current - 1) * perPage;
        return { items: items.slice(start, start + perPage), page: current, totalPages, total };
    },

    bindPagination(prevBtn, nextBtn, labelEl, state, renderFn) {
        const update = () => {
            if (labelEl) labelEl.textContent = `Página ${state.page} de ${state.totalPages}`;
            if (prevBtn) prevBtn.disabled = state.page <= 1;
            if (nextBtn) nextBtn.disabled = state.page >= state.totalPages;
            renderFn();
        };
        prevBtn?.addEventListener('click', () => { if (state.page > 1) { state.page--; update(); } });
        nextBtn?.addEventListener('click', () => { if (state.page < state.totalPages) { state.page++; update(); } });
        return update;
    },

    openModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.add('active', 'show');
    },

    closeModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('active', 'show');
    },

    bindModalClose(modalId, ...btnIds) {
        btnIds.forEach(bid => {
            document.getElementById(bid)?.addEventListener('click', () => this.closeModal(modalId));
        });
        const modal = document.getElementById(modalId);
        modal?.addEventListener('click', e => {
            if (e.target === modal) this.closeModal(modalId);
        });
    },

    confirm(title, message, onConfirm) {
        if (window.confirmAction) {
            window.confirmAction(title, message, onConfirm);
        } else if (confirm(message)) {
            onConfirm();
        }
    },

    toast(msg, type = 'info') {
        window.showToast?.(msg, type);
    },

    emptyRow(cols, msg = 'Sin registros') {
        return `<tr><td colspan="${cols}" class="text-center text-muted">${msg}</td></tr>`;
    },

    actionButtons(id, { view = true, edit = true, del = true } = {}) {
        return `<div class="table-actions">
            ${view ? `<button class="btn-icon btn-sm btn-view" data-id="${id}" title="Ver"><i class="fas fa-eye"></i></button>` : ''}
            ${edit ? `<button class="btn-icon btn-sm btn-edit" data-id="${id}" title="Editar"><i class="fas fa-edit"></i></button>` : ''}
            ${del ? `<button class="btn-icon btn-sm btn-delete" data-id="${id}" title="Eliminar"><i class="fas fa-trash"></i></button>` : ''}
        </div>`;
    }
};

window.ModuleCore = ModuleCore;
