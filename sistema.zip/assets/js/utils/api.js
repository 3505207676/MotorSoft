/**
 * Cliente API para backend PHP - MotorSoft / Taller El Paisa
 * Funciones para llamar a los endpoints del backend
 */

// Obtener base URL desde configuración
const API_BASE = (typeof API !== 'undefined' && API.base) ? API.base : '../../controllers/api';

/**
 * Función genérica para hacer peticiones a la API
 * @param {string} endpoint - Endpoint de la API
 * @param {Object} options - Opciones de fetch
 * @returns {Promise} - Respuesta de la API
 */
export async function apiCall(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;
    const config = {
        timeout: (typeof CONFIG !== 'undefined' && CONFIG.timeout) ? CONFIG.timeout : 10000,
        cache: 'no-store',
        ...options,
        headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            Pragma: 'no-cache',
            ...(typeof localStorage !== 'undefined' && localStorage.getItem('motorsoft_token')
                ? { Authorization: 'Bearer ' + localStorage.getItem('motorsoft_token') }
                : {}),
            ...(options.headers || {})
        }
    };
    config.cache = options.cache || 'no-store';
    
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
        config.body = JSON.stringify(options.body);
    } else if (options.body) {
        config.body = options.body;
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), config.timeout);
    const fetchConfig = { ...config };
    delete fetchConfig.timeout;
    
    try {
        const response = await fetch(url, { ...fetchConfig, cache: 'no-store', signal: controller.signal });
        clearTimeout(timeoutId);
        
        const data = await response.json().catch(() => ({}));
        
        if (response.status === 401) {
            if (typeof localStorage !== 'undefined') {
                localStorage.removeItem('motorsoft_token');
                localStorage.removeItem('motorsoft_usuario');
                localStorage.removeItem('motorsoft_cliente');
                localStorage.removeItem('motorsoft_sesion');
            }
            const path = (typeof window !== 'undefined' && window.location.pathname) || '';
            if (!path.includes('/auth/login')) {
                window.location.href = '../auth/login.php';
            }
            throw new Error(data.mensaje || 'Sesión expirada');
        }

        if (!response.ok) {
            throw new Error(data.mensaje || data.error || `Error ${response.status}`);
        }
        
        return data;
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new Error('Tiempo de espera agotado');
        }
        throw error;
    }
}

/**
 * Funciones para Clientes
 */
export async function apiClientes(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/clientes/obtener.php${query ? '?' + query : ''}` : '/clientes/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiClientesActualizar(id, data) {
    return apiCall('/clientes/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiClientesEliminar(id) {
    return apiCall('/clientes/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Vehículos
 */
export async function apiVehiculos(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/vehiculos/obtener.php${query ? '?' + query : ''}` : '/vehiculos/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiVehiculosActualizar(id, data) {
    return apiCall('/vehiculos/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiVehiculosEliminar(id) {
    return apiCall('/vehiculos/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Órdenes
 */
export async function apiOrdenes(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/ordenes/obtener.php${query ? '?' + query : ''}` : '/ordenes/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiOrdenesActualizar(id, data) {
    return apiCall('/ordenes/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiOrdenesEliminar(id) {
    return apiCall('/ordenes/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Productos
 */
export async function apiProductos(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/productos/obtener.php${query ? '?' + query : ''}` : '/productos/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiProductosActualizar(id, data) {
    return apiCall('/productos/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiProductosEliminar(id) {
    return apiCall('/productos/eliminar.php', { method: 'POST', body: { id } });
}

export async function apiCategorias(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/categorias/obtener.php${query ? '?' + query : ''}`);
}

export async function apiCategoriasCrear(data) {
    return apiCall('/categorias/crear.php', { method: 'POST', body: data });
}

/**
 * Funciones para Servicios
 */
export async function apiServicios(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/servicios/obtener.php${query ? '?' + query : ''}`);
}

/**
 * Funciones para Usuarios
 */
export async function apiUsuarios(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/usuarios/obtener.php${query ? '?' + query : ''}` : '/usuarios/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiUsuariosActualizar(id, data) {
    return apiCall('/usuarios/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiUsuariosEliminar(id) {
    return apiCall('/usuarios/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones para Facturas
 */
export async function apiFacturas(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/facturas/obtener.php${query ? '?' + query : ''}` : '/facturas/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiFacturasActualizar(id, data) {
    return apiCall('/facturas/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiFacturasEliminar(id) {
    return apiCall('/facturas/eliminar.php', { method: 'POST', body: { id } });
}

export async function apiVentas(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/ventas/obtener.php${query ? '?' + query : ''}` : '/ventas/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiConfiguracion() {
    return apiCall('/configuracion/obtener.php');
}

export async function apiConfiguracionActualizar(data) {
    return apiCall('/configuracion/actualizar.php', { method: 'POST', body: data });
}

export async function apiRoles() {
    return apiCall('/roles/obtener.php');
}

export async function apiCaja() {
    return apiCall('/caja/obtener.php');
}

export async function apiCajaActiva() {
    return apiCall('/caja/activa.php');
}

export async function apiCajaAbrir(data) {
    return apiCall('/caja/abrir.php', { method: 'POST', body: data });
}

export async function apiCajaCerrar(data) {
    return apiCall('/caja/cerrar.php', { method: 'POST', body: data });
}

export async function apiCajaTransaccion(data) {
    return apiCall('/caja/transacciones.php', { method: 'POST', body: data });
}

export async function apiCuentasCrear(data) {
    return apiCall('/cuentas/crear.php', { method: 'POST', body: data });
}

/**
 * Funciones para Contabilidad
 */
export async function apiContabilidad(obtener = {}, params = {}) {
    const query = new URLSearchParams(params).toString();
    const endpoint = obtener ? `/contabilidad/obtener.php${query ? '?' + query : ''}` : '/contabilidad/crear.php';
    return apiCall(endpoint, obtener ? {} : { method: 'POST', body: params });
}

export async function apiContabilidadActualizar(id, data) {
    return apiCall('/contabilidad/actualizar.php', { method: 'POST', body: { id, ...data } });
}

export async function apiContabilidadEliminar(id) {
    return apiCall('/contabilidad/eliminar.php', { method: 'POST', body: { id } });
}

/**
 * Funciones de Autenticación
 */
export async function apiLogin(email, password, documento, placa) {
    const body = { password };
    if (email) body.email = email;
    if (documento) body.documento = documento;
    if (placa) body.placa = placa;
    const data = await apiCall('/auth/login.php', { method: 'POST', body });
    if (data && data.data) {
        if (data.data.token) {
            localStorage.setItem('motorsoft_token', data.data.token);
        }
        localStorage.setItem('motorsoft_sesion', JSON.stringify({
            tipo: data.data.tipo,
            rol: data.data.rol,
            redirect: data.data.redirect
        }));
        if (data.data.usuario) {
            localStorage.setItem('motorsoft_usuario', JSON.stringify(data.data.usuario));
        }
        if (data.data.cliente) {
            localStorage.setItem('motorsoft_cliente', JSON.stringify(data.data.cliente));
        }
    }
    return data;
}

export async function apiLogout() {
    try {
        return await apiCall('/auth/logout.php', { method: 'POST' });
    } finally {
        localStorage.removeItem('motorsoft_token');
        localStorage.removeItem('motorsoft_usuario');
    }
}

export async function apiMe() {
    return apiCall('/auth/me.php', { method: 'GET' });
}

/**
 * Funciones para Stock
 */
export async function apiMovimientoStock(data) {
    return apiCall('/stock/movimiento.php', { method: 'POST', body: data });
}

/**
 * Funciones para Consumos
 */
export async function apiConsumosCrear(data) {
    return apiCall('/consumos/crear.php', { method: 'POST', body: data });
}

export async function apiConsumosObtener(params = {}) {
    const query = new URLSearchParams(params).toString();
    return apiCall(`/consumos/obtener.php${query ? '?' + query : ''}`);
}

/**
 * Funciones para Chat
 */
function chatQuery(params = {}) {
    const clean = {};
    Object.keys(params || {}).forEach(k => {
        if (params[k] !== undefined && params[k] !== null && params[k] !== '') {
            clean[k] = params[k];
        }
    });
    clean._ = String(Date.now());
    const query = new URLSearchParams(clean).toString();
    return query ? `?${query}` : '';
}

export async function apiChatConversaciones(params = {}) {
    return apiCall('/chat/conversaciones.php' + chatQuery(params));
}

export async function apiChatContactos(params = {}) {
    return apiCall('/chat/contactos.php' + chatQuery(params));
}

export async function apiChatCrearContacto(data) {
    return apiCall('/chat/crear-contacto.php', { method: 'POST', body: data });
}

export async function apiChatAbrir(data) {
    return apiCall('/chat/abrir.php', { method: 'POST', body: data });
}

export async function apiChatObtener(params = {}) {
    return apiCall('/chat/obtener.php' + chatQuery(params));
}

export async function apiChatEnviar(data) {
    return apiCall('/chat/enviar.php', { method: 'POST', body: data });
}

export async function apiChatLeer(data = {}) {
    return apiCall('/chat/leer.php', { method: 'POST', body: data });
}

export async function apiWhatsAppProbar() {
    return apiCall('/chat/whatsapp-probar.php', { method: 'POST' });
}

/**
 * Funciones de compatibilidad con código existente
 */
export async function obtenerOrdenes(mecanicoId) {
    const data = await apiOrdenes(true, { mecanicoId });
    return data.data || [];
}

export async function obtenerOrden(ordenId) {
    const data = await apiOrdenes(true, { id: ordenId });
    return data.data || null;
}

export async function actualizarEstadoOrden(ordenId, estado, mecanicoId) {
    const data = await apiOrdenesActualizar(ordenId, { estado, mecanico_id: mecanicoId });
    return data.data || null;
}

export async function obtenerClientes() {
    const data = await apiClientes(true);
    return data.data || [];
}

export async function obtenerVehiculos() {
    const data = await apiVehiculos(true);
    return data.data || [];
}

export async function obtenerProductos() {
    const data = await apiProductos(true);
    return data.data || [];
}

export async function buscarProductos(query) {
    const data = await apiProductos(true, { busqueda: query });
    return data.data || [];
}

export async function obtenerServicios() {
    const data = await apiServicios();
    return data.data || [];
}

export async function obtenerConversaciones(mecanicoId) {
    const data = await apiChatObtener({ mecanicoId });
    return data.data || [];
}

export async function enviarMensajeChat(conversacionId, texto, mecanicoId) {
    const data = await apiChatEnviar({ conversacionId, texto, mecanicoId });
    return data.data || null;
}

export async function obtenerPerfil(mecanicoId) {
    const data = await apiUsuarios({ id: mecanicoId });
    return data.data || null;
}

export async function actualizarPerfil(perfilData, mecanicoId) {
    const data = await apiUsuariosActualizar(mecanicoId, perfilData);
    return data.data || null;
}
