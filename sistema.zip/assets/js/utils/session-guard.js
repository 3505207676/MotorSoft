/**
 * Exige sesión activa según el panel.
 * Sin token o con tipo incorrecto → login.
 */
(function (window) {
    var LOGIN = '../auth/login.php';

    function leerSesion() {
        try {
            return JSON.parse(localStorage.getItem('motorsoft_sesion') || 'null');
        } catch (e) {
            return null;
        }
    }

    function limpiar() {
        localStorage.removeItem('motorsoft_token');
        localStorage.removeItem('motorsoft_usuario');
        localStorage.removeItem('motorsoft_cliente');
        localStorage.removeItem('motorsoft_sesion');
    }

    function irLogin() {
        limpiar();
        window.location.replace(LOGIN);
    }

    function sinTildes(texto) {
        return String(texto || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }

    function nombreRolDe(usuario) {
        if (!usuario) return '';
        if (usuario.rol && typeof usuario.rol === 'object') {
            return usuario.rol.nombre || '';
        }
        return usuario.rol || '';
    }

    function esMecanico(sesion, usuario) {
        var u = usuario || leerUsuario();
        var s = sesion || leerSesion();
        if (u && u.es_mecanico === true) return true;
        if (s && s.es_mecanico === true) return true;
        var rol = (s && s.rol) || nombreRolDe(u);
        return sinTildes(rol).indexOf('mecanic') !== -1;
    }

    function exigir(panel) {
        var token = localStorage.getItem('motorsoft_token');
        var sesion = leerSesion();

        if (!token || !sesion || !sesion.tipo) {
            irLogin();
            return false;
        }

        if (panel === 'trabajadores') {
            if (sesion.tipo !== 'usuario') {
                irLogin();
                return false;
            }
            if (esMecanico(sesion)) {
                window.location.replace('../dashboard/index-mecanicos.php');
                return false;
            }
            return true;
        }

        if (panel === 'mecanicos') {
            if (sesion.tipo !== 'usuario') {
                irLogin();
                return false;
            }
            if (!esMecanico(sesion)) {
                window.location.replace('../dashboard/index-trabajadores.php');
                return false;
            }
            return true;
        }

        if (panel === 'cliente') {
            if (sesion.tipo !== 'cliente') {
                irLogin();
                return false;
            }
            return true;
        }

        irLogin();
        return false;
    }

    function leerUsuario() {
        try {
            return JSON.parse(localStorage.getItem('motorsoft_usuario') || 'null');
        } catch (e) {
            return null;
        }
    }

    function slugsDe(usuario) {
        var u = usuario || leerUsuario();
        if (!u) return [];
        if (Array.isArray(u.permisos)) return u.permisos;
        if (u.rol && Array.isArray(u.rol.permisos)) {
            return u.rol.permisos.map(function (p) { return p.slug; });
        }
        return [];
    }

    function puede(slug, usuario) {
        var u = usuario || leerUsuario();
        if (!u) return false;
        if (u.es_admin) return true;
        var rol = (u.rol && u.rol.nombre) ? u.rol.nombre : (u.rol || '');
        if (String(rol).toLowerCase().indexOf('admin') !== -1) return true;
        return slugsDe(u).indexOf(slug) !== -1;
    }

    function puedeAlguno(lista, usuario) {
        return (lista || []).some(function (slug) { return puede(slug, usuario); });
    }

    window.MotorSoftGuard = {
        exigir: exigir,
        limpiar: limpiar,
        puede: puede,
        puedeAlguno: puedeAlguno,
        slugs: slugsDe,
        usuario: leerUsuario,
        esMecanico: esMecanico
    };
})(window);
