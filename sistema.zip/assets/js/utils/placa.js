/**
 * Placas colombianas: carro ABC123, moto ABC12D.
 */
(function (window) {
    const TIPOS = ['Moto', 'Automóvil', 'Camioneta', 'Camión', 'Otro'];

    function normalizar(placa) {
        return String(placa || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    }

    function validar(placa) {
        const p = normalizar(placa);
        return /^[A-Z]{3}[0-9]{3}$/.test(p) || /^[A-Z]{3}[0-9]{2}[A-Z]$/.test(p);
    }

    function esMoto(placa) {
        return /^[A-Z]{3}[0-9]{2}[A-Z]$/.test(normalizar(placa));
    }

    function inferirTipo(placa) {
        return esMoto(placa) ? 'Moto' : 'Automóvil';
    }

    function icono(tipo) {
        const t = String(tipo || '').toLowerCase();
        if (t.indexOf('moto') === 0) return 'fa-motorcycle';
        if (t.indexOf('cami') === 0 && t.indexOf('camioneta') === -1) return 'fa-truck';
        if (t.indexOf('camioneta') === 0) return 'fa-car-side';
        return 'fa-car';
    }

    window.MotorSoftPlaca = {
        TIPOS,
        normalizar,
        validar,
        esMoto,
        inferirTipo,
        icono
    };
})(window);
