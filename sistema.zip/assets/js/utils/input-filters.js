/**
 * Filtros de teclado: no letras en campos numéricos, no números en campos de texto.
 */
(function () {
    const FILTROS = {
        digits: /[^\d]/g,
        letters: /[^A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]/g,
        plate: /[^A-Za-z0-9]/g,
        alnum: /[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9\s]/g
    };

    function aplicarValor(input, tipo) {
        let valor = input.value;
        if (tipo === 'digits') valor = valor.replace(FILTROS.digits, '');
        if (tipo === 'letters') valor = valor.replace(FILTROS.letters, '');
        if (tipo === 'plate') valor = valor.replace(FILTROS.plate, '').toUpperCase();
        if (tipo === 'alnum') valor = valor.replace(FILTROS.alnum, '');
        if (input.value !== valor) {
            input.value = valor;
        }
    }

    function tipoDe(input) {
        return input.getAttribute('data-filter') || '';
    }

    document.addEventListener('input', function (e) {
        const el = e.target;
        if (!el || el.tagName !== 'INPUT') return;
        const tipo = tipoDe(el);
        if (!tipo) return;
        aplicarValor(el, tipo);
    });

    document.addEventListener('paste', function (e) {
        const el = e.target;
        if (!el || el.tagName !== 'INPUT') return;
        const tipo = tipoDe(el);
        if (!tipo) return;
        setTimeout(function () { aplicarValor(el, tipo); }, 0);
    });

    window.MotorSoftFiltros = { aplicarValor, tipoDe };
})();
