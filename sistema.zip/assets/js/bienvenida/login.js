/**
 * Funcionalidad para el formulario de login|
 */

document.addEventListener('DOMContentLoaded', function() {
    inicializarMenu();
    inicializarLogin();
    inicializarRecuperacion();
    inicializarRecordarDatos();
});

function inicializarMenu() {
    const btn = document.getElementById('nav-toggle');
    const nav = document.getElementById('site-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', () => {
        const open = nav.classList.toggle('is-open');
        btn.setAttribute('aria-expanded', String(open));
        const icon = btn.querySelector('i');
        if (icon) icon.className = open ? 'fas fa-times' : 'fas fa-bars';
    });
}

function inicializarLogin() {
    const formularioLogin = document.getElementById('form-login');
    
    if (formularioLogin) {
        formularioLogin.addEventListener('submit', function(event) {
            event.preventDefault();
            procesarLogin();
        });
        
        // Limpiar errores al escribir
        const inputs = formularioLogin.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                limpiarError(this);
            });
            
            // Validación en tiempo real
            input.addEventListener('blur', function() {
                validarCampo(this);
            });
        });
    } else {
        console.error('No se encontró el formulario de login con ID form-login');
    }
}

function inicializarRecuperacion() {
    const btnRecuperar = document.getElementById('recuperar-password');
    const modalRecuperar = document.getElementById('modal-recuperar');
    const btnCerrarModal = document.getElementById('cerrar-modal');
    const formRecuperar = document.getElementById('form-recuperar');
    
    if (btnRecuperar) {
        btnRecuperar.addEventListener('click', function(e) {
            e.preventDefault();
            mostrarModalRecuperacion();
        });
    }
    
    if (btnCerrarModal) {
        btnCerrarModal.addEventListener('click', cerrarModalRecuperacion);
    }
    
    if (modalRecuperar) {
        modalRecuperar.addEventListener('click', function(e) {
            if (e.target === modalRecuperar) {
                cerrarModalRecuperacion();
            }
        });
    }
    
    if (formRecuperar) {
        formRecuperar.addEventListener('submit', function(e) {
            e.preventDefault();
            procesarRecuperacion();
        });
    }
}

function inicializarRecordarDatos() {
    const checkboxRecordar = document.getElementById('recordar');
    if (checkboxRecordar) {
        // Cargar datos guardados
        cargarDatosGuardados();
        
        checkboxRecordar.addEventListener('change', function() {
            if (this.checked) {
                guardarDatos();
            } else {
                eliminarDatosGuardados();
            }
        });
    }
}

function procesarLogin() {
    const placa = document.getElementById('placa').value.trim().toUpperCase();
    const documento = document.getElementById('documento').value.trim();
    const password = document.getElementById('password').value;
    const btnLogin = document.querySelector('.btn-login');

    limpiarErrores();

    if (!documento) {
        mostrarError('documento', 'Ingresa tu documento (solo números)');
        return;
    }
    if (!/^\d{6,15}$/.test(documento)) {
        mostrarError('documento', 'El documento solo admite números (6 a 15 dígitos)');
        return;
    }
    if (placa && !validarFormatoPlaca(placa)) {
        mostrarError('placa', 'Placa inválida. Carro: ABC123. Moto: ABC12D');
        return;
    }

    const esCliente = placa.length > 0;
    if (!esCliente && !password) {
        mostrarError('password', 'La contraseña es obligatoria para personal del taller');
        return;
    }
    if (!esCliente && password.length < 6) {
        mostrarError('password', 'La contraseña debe tener al menos 6 caracteres');
        return;
    }

    mostrarLoading(btnLogin, true);

    const apiBase = (typeof API !== 'undefined' && API.base)
        ? API.base
        : '../../controllers/api';

    fetch(apiBase + '/auth/login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            documento: documento,
            password: password,
            placa: placa
        })
    })
        .then(function (res) {
            return res.json().then(function (data) {
                return { ok: res.ok, data: data };
            });
        })
        .then(function (resultado) {
            if (!resultado.ok || !resultado.data.success) {
                throw new Error(resultado.data.mensaje || 'Credenciales inválidas');
            }

            const payload = resultado.data.data || {};
            if (payload.token) {
                localStorage.setItem('motorsoft_token', payload.token);
            }
            localStorage.setItem('motorsoft_sesion', JSON.stringify({
                tipo: payload.tipo,
                rol: payload.rol,
                es_mecanico: !!payload.es_mecanico,
                redirect: payload.redirect
            }));
            if (payload.usuario) {
                localStorage.setItem('motorsoft_usuario', JSON.stringify(payload.usuario));
            }
            if (payload.cliente) {
                localStorage.setItem('motorsoft_cliente', JSON.stringify(payload.cliente));
            }

            const checkboxRecordar = document.getElementById('recordar');
            if (checkboxRecordar && checkboxRecordar.checked) {
                guardarDatos();
            }

            const destino = payload.redirect || destinoSegunRol(payload);
            const etiqueta = payload.tipo === 'cliente'
                ? 'cliente'
                : ('rol ' + (payload.rol || 'trabajador'));
            mostrarMensajeGeneral('Bienvenido (' + etiqueta + '). Redirigiendo...', 'exito');

            setTimeout(function () {
                window.location.href = destino;
            }, 700);
        })
        .catch(function (err) {
            mostrarMensajeGeneral(err.message || 'No se pudo iniciar sesión', 'error');
        })
        .finally(function () {
            mostrarLoading(btnLogin, false);
        });
}

function destinoSegunRol(payload) {
    if (payload.tipo === 'cliente') {
        return '../cliente/P_Inicio.php';
    }
    if (payload.es_mecanico) {
        return '../dashboard/index-mecanicos.php';
    }
    const rol = String(payload.rol || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');
    if (rol.indexOf('mecanic') !== -1) {
        return '../dashboard/index-mecanicos.php';
    }
    return '../dashboard/index-trabajadores.php';
}

function apiBase() {
    return (typeof API !== 'undefined' && API.base)
        ? API.base
        : '../../controllers/api';
}

function procesarRecuperacion() {
    const documento = document.getElementById('documento-recuperar').value.trim();
    const email = document.getElementById('email-recuperar').value.trim();
    const btnRecuperar = document.querySelector('.btn-recuperar');

    limpiarErrores();

    if (!documento) {
        mostrarError('documento-recuperar', 'Ingresa tu documento de identidad');
        return;
    }
    if (!/^\d{6,15}$/.test(documento)) {
        mostrarError('documento-recuperar', 'El documento solo admite números (6 a 15 dígitos)');
        return;
    }
    if (!email || !validarEmail(email)) {
        mostrarError('email-recuperar', 'Ingresa un correo electrónico válido');
        return;
    }

    mostrarLoading(btnRecuperar, true);

    fetch(apiBase() + '/auth/recuperar.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            documento: documento,
            email: email
        })
    })
        .then(function (res) {
            return res.text().then(function (text) {
                var data = {};
                try {
                    data = text ? JSON.parse(text) : {};
                } catch (e) {
                    data = { success: false, mensaje: 'No se pudo procesar la respuesta del servidor' };
                }
                return { ok: res.ok, data: data };
            });
        })
        .then(function (resultado) {
            if (!resultado.ok || !resultado.data.success) {
                throw new Error(resultado.data.mensaje || 'No se pudo enviar el enlace');
            }
            ocultarAlertaRecuperar();
            cerrarModalRecuperacion();
            mostrarMensajeGeneral('Si los datos coinciden, enviamos un enlace a su correo. Revise también spam.', 'exito');
        })
        .catch(function (err) {
            mostrarAlertaRecuperar(err.message || 'No se pudo enviar el enlace', 'error');
        })
        .finally(function () {
            mostrarLoading(btnRecuperar, false);
        });
}

function mostrarModalRecuperacion() {
    const modal = document.getElementById('modal-recuperar');
    if (modal) {
        modal.classList.add('mostrar');
        document.body.style.overflow = 'hidden';
        ocultarAlertaRecuperar();
        const primerInput = modal.querySelector('input');
        if (primerInput) {
            setTimeout(() => primerInput.focus(), 300);
        }
    }
}

function cerrarModalRecuperacion() {
    const modal = document.getElementById('modal-recuperar');
    if (modal) {
        modal.classList.remove('mostrar');
        document.body.style.overflow = '';
        
        // Limpiar formulario
        const form = document.getElementById('form-recuperar');
        if (form) {
            form.reset();
            limpiarErrores();
        }
        ocultarAlertaRecuperar();
    }
}

function mostrarLoading(boton, mostrar) {
    if (mostrar) {
        boton.classList.add('loading');
        boton.disabled = true;
    } else {
        boton.classList.remove('loading');
        boton.disabled = false;
    }
}

function validarCampo(campo) {
    const valor = campo.value.trim();
    const id = campo.id;
    
    if (!valor) return;
    
    switch (id) {
        case 'placa':
            if (!validarFormatoPlaca(valor)) {
                mostrarError(id, 'Formato de placa inválido. Carro: ABC123. Moto: ABC12D');
            }
            break;
        case 'documento':
            if (!validarFormatoDocumento(valor)) {
                mostrarError(id, 'Formato de documento inválido. Ej: 1234567890');
            }
            break;
        case 'documento-recuperar':
            if (!validarFormatoDocumento(valor)) {
                mostrarError(id, 'Formato de documento inválido. Ej: 1000000001');
            }
            break;
        case 'email-recuperar':
            if (!validarEmail(valor)) {
                mostrarError(id, 'Ingresa un correo electrónico válido');
            }
            break;
    }
}

function validarFormatoPlaca(placa) {
    if (window.MotorSoftPlaca && typeof window.MotorSoftPlaca.validar === 'function') {
        return window.MotorSoftPlaca.validar(placa);
    }
    const p = String(placa || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    return /^[A-Z]{3}[0-9]{3}$/.test(p) || /^[A-Z]{3}[0-9]{2}[A-Z]$/.test(p);
}

function validarFormatoDocumento(documento) {
    return /^[0-9]{6,15}$/.test(documento);
}

function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function guardarDatos() {
    const placa = document.getElementById('placa').value.trim();
    const documento = document.getElementById('documento').value.trim();
    if (documento) {
        localStorage.setItem('taller_el_paisa_datos', JSON.stringify({
            placa: placa,
            documento: documento,
            timestamp: new Date().getTime()
        }));
    }
}

function cargarDatosGuardados() {
    const datosGuardados = localStorage.getItem('taller_el_paisa_datos');
    if (datosGuardados) {
        try {
            const datos = JSON.parse(datosGuardados);
            if (datos.placa) {
                document.getElementById('placa').value = datos.placa;
            }
            if (datos.documento) {
                document.getElementById('documento').value = datos.documento;
            }
            // Marcar checkbox
            const checkbox = document.getElementById('recordar');
            if (checkbox) {
                checkbox.checked = true;
            }
        } catch (e) {
            console.error('Error al cargar datos guardados:', e);
        }
    }
}

function eliminarDatosGuardados() {
    localStorage.removeItem('taller_el_paisa_datos');
}

/**
 * Muestra un mensaje de error debajo del campo específico
 */
function mostrarError(idCampo, mensaje) {
    const campo = document.getElementById(idCampo);
    const inputGroup = campo.closest('.input-group');
    
    if (inputGroup) {
        inputGroup.classList.add('error');
        
        // Eliminar mensaje de error anterior si existe
        const mensajeAnterior = inputGroup.querySelector('.mensaje-error');
        if (mensajeAnterior) {
            mensajeAnterior.remove();
        }
        
        // Crear y añadir nuevo mensaje de error
        const mensajeError = document.createElement('p');
        mensajeError.classList.add('mensaje-error');
        mensajeError.textContent = mensaje;
        
        // Insertar después del input
        inputGroup.appendChild(mensajeError);
        
        // Enfocar el campo
        campo.focus();
    }
}

/**
 * Limpia el error de un campo específico
 */
function limpiarError(campo) {
    const inputGroup = campo.closest('.input-group');
    if (inputGroup) {
        inputGroup.classList.remove('error');
        const mensajeError = inputGroup.querySelector('.mensaje-error');
        if (mensajeError) {
            mensajeError.remove();
        }
    }
}

/**
 * Limpia todos los errores del formulario
 */
function limpiarErrores() {
    const errores = document.querySelectorAll('.mensaje-error');
    errores.forEach(error => error.remove());
    
    const inputGroups = document.querySelectorAll('.input-group.error');
    inputGroups.forEach(group => group.classList.remove('error'));
}

function mostrarAlertaRecuperar(mensaje, tipo) {
    const el = document.getElementById('alerta-recuperar');
    if (!el) {
        mostrarMensajeGeneral(mensaje, tipo);
        return;
    }
    el.hidden = false;
    el.classList.toggle('exito', tipo === 'exito');
    el.textContent = mensaje;
}

function ocultarAlertaRecuperar() {
    const el = document.getElementById('alerta-recuperar');
    if (!el) return;
    el.hidden = true;
    el.textContent = '';
    el.classList.remove('exito');
}

/**
 * Muestra un mensaje general en el formulario
 */
function mostrarMensajeGeneral(mensaje, tipo = 'error') {
    const modal = document.getElementById('modal-recuperar');
    const enModal = modal && modal.classList.contains('mostrar');
    const formulario = enModal
        ? document.getElementById('form-recuperar')
        : document.getElementById('form-login');

    if (!formulario) {
        return;
    }

    const mensajeAnterior = document.querySelector('.mensaje-general:not(#alerta-recuperar)');
    if (mensajeAnterior) {
        mensajeAnterior.remove();
    }

    const mensajeGeneral = document.createElement('div');
    mensajeGeneral.classList.add('mensaje-general');
    if (tipo === 'exito') {
        mensajeGeneral.classList.add('exito');
    }
    mensajeGeneral.textContent = mensaje;
    formulario.insertBefore(mensajeGeneral, formulario.firstChild);

    setTimeout(() => {
        mensajeGeneral.classList.add('desvanecer');
        setTimeout(() => {
            mensajeGeneral.remove();
        }, 500);
    }, 5000);
}