document.addEventListener('DOMContentLoaded', () => {
  inicializarMenu();
  inicializarHeroTitulos();
  activarAcordeon();
  activarReveladoScroll();
  activarContadores();
  activarScrollSuave();
  inicializarTestimonios();
  inicializarFiltrosServicios();
});

function activarAcordeon() {
  const items = document.querySelectorAll('[data-accordion]');
  items.forEach((item) => {
    const btn = item.querySelector('.faq-q, .pregunta-titulo');
    if (!btn) return;
    btn.addEventListener('click', () => {
      items.forEach((i) => i !== item && i.classList.remove('abierta'));
      item.classList.toggle('abierta');
    });
  });
}

function activarReveladoScroll() {
  const elementos = document.querySelectorAll('[data-reveal]');
  if (!elementos.length) return;
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('mostrar');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });
  elementos.forEach((el) => obs.observe(el));
}

function activarContadores() {
  const contadores = document.querySelectorAll('[data-counter]');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        contar(entry.target);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });
  contadores.forEach((c) => obs.observe(c));
}

function contar(el) {
  const objetivo = parseFloat(el.getAttribute('data-target')) || 0;
  const numEl = el.querySelector('.num');
  if (!numEl) return;
  const esDecimal = !Number.isInteger(objetivo);
  const duracion = 1400;
  const inicio = performance.now();

  function frame(t) {
    const p = Math.min((t - inicio) / duracion, 1);
    const valor = objetivo * (1 - Math.pow(1 - p, 3));
    numEl.textContent = esDecimal ? valor.toFixed(1) : Math.round(valor);
    if (p < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

function activarScrollSuave() {
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', (e) => {
      const href = a.getAttribute('href');
      if (href && href.length > 1) {
        e.preventDefault();
        const nav = document.getElementById('site-nav');
        const toggle = document.getElementById('nav-toggle');
        nav?.classList.remove('is-open');
        toggle?.setAttribute('aria-expanded', 'false');
        const navIcon = toggle?.querySelector('i');
        if (navIcon) navIcon.className = 'fas fa-bars';
        const destino = document.querySelector(href);
        destino?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
}

function inicializarMenu() {
  const btn = document.getElementById('nav-toggle');
  const nav = document.getElementById('site-nav');
  if (!btn || !nav) return;
  btn.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    btn.setAttribute('aria-expanded', String(open));
    const icon = btn.querySelector('i');
    if (icon) icon.className = open ? 'fas fa-times' : 'fas fa-bars';
  });
}

function inicializarTestimonios() {
  const testimonios = document.querySelectorAll('.quote, .testimonio');
  const dots = document.querySelectorAll('.dot');
  const prevBtn = document.querySelector('.quote-prev, .testimonio-prev');
  const nextBtn = document.querySelector('.quote-next, .testimonio-next');
  if (!testimonios.length) return;

  let currentSlide = 0;

  function mostrar(index) {
    testimonios.forEach((el, i) => {
      el.classList.toggle('is-active', i === index);
      el.classList.toggle('active', i === index);
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === index);
      dot.classList.toggle('active', i === index);
    });
  }

  nextBtn?.addEventListener('click', () => {
    currentSlide = (currentSlide + 1) % testimonios.length;
    mostrar(currentSlide);
  });
  prevBtn?.addEventListener('click', () => {
    currentSlide = (currentSlide - 1 + testimonios.length) % testimonios.length;
    mostrar(currentSlide);
  });
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      currentSlide = Number(dot.dataset.slide || index);
      mostrar(currentSlide);
    });
  });
  setInterval(() => {
    currentSlide = (currentSlide + 1) % testimonios.length;
    mostrar(currentSlide);
  }, 6000);
}

function inicializarHeroTitulos() {
  const titulo = document.getElementById('hero-title');
  const lead = document.getElementById('hero-lead');
  const dotsWrap = document.getElementById('hero-dots');
  if (!titulo) return;

  const frases = [
    {
      titulo: 'Consulta el estado de tu vehículo',
      lead: 'Información en tiempo real, atención personalizada y servicio técnico de confianza.',
    },
    {
      titulo: 'Tu carro, siempre bajo control',
      lead: 'Revisa avances, repuestos y costos desde el celular, cuando quieras.',
    },
    {
      titulo: 'Sabes en qué va tu reparación',
      lead: 'Sin llamadas de más: el taller te mantiene al día, paso a paso.',
    },
    {
      titulo: 'Mecánica clara, sin sorpresas',
      lead: 'Diagnóstico honesto, tiempos definidos y un equipo que te explica el trabajo.',
    },
    {
      titulo: 'Servicio de confianza en Cumaribo',
      lead: 'Más de 12 años cuidando vehículos con calidad y trato cercano.',
    },
  ];

  let indice = 0;
  const reducirMovimiento = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const duracionFade = reducirMovimiento ? 0 : 650;

  const pintarDots = () => {
    if (!dotsWrap) return;
    if (!dotsWrap.childElementCount) {
      dotsWrap.innerHTML = frases.map((_, i) => (
        `<button type="button" class="hero-dot" data-slide="${i}" aria-label="Frase ${i + 1}"></button>`
      )).join('');
      dotsWrap.querySelectorAll('.hero-dot').forEach((dot) => {
        dot.addEventListener('click', () => mostrar(Number(dot.dataset.slide)));
      });
    }
    dotsWrap.querySelectorAll('.hero-dot').forEach((dot, i) => {
      dot.classList.toggle('is-active', i === indice);
    });
  };

  const mostrar = (siguiente) => {
    if (siguiente === indice) return;
    indice = (siguiente + frases.length) % frases.length;
    const aplicar = () => {
      titulo.textContent = frases[indice].titulo;
      if (lead) lead.textContent = frases[indice].lead;
      titulo.classList.remove('is-out');
      lead?.classList.remove('is-out');
      pintarDots();
    };
    if (!duracionFade) {
      aplicar();
      return;
    }
    titulo.classList.add('is-out');
    lead?.classList.add('is-out');
    window.setTimeout(aplicar, duracionFade);
  };

  pintarDots();
  if (reducirMovimiento) return;
  window.setInterval(() => mostrar(indice + 1), 9000);
}

function inicializarFiltrosServicios() {
  const filtros = document.querySelectorAll('.chip[data-filtro], .filtro-btn');
  const servicios = document.querySelectorAll('.service-card, .card-servicio');

  filtros.forEach((filtro) => {
    filtro.addEventListener('click', () => {
      const categoria = filtro.getAttribute('data-filtro');
      filtros.forEach((f) => {
        f.classList.remove('is-active', 'active');
      });
      filtro.classList.add('is-active', 'active');
      servicios.forEach((servicio) => {
        const cat = servicio.getAttribute('data-categoria');
        const mostrar = categoria === 'todos' || cat === categoria;
        servicio.style.display = mostrar ? '' : 'none';
      });
    });
  });
}
