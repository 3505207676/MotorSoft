// Interactividad para las páginas de servicios

document.addEventListener('DOMContentLoaded', () => {
  inicializarAnimaciones();
  inicializarTooltips();
});

// Animaciones de entrada
function inicializarAnimaciones() {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  // Observar elementos que necesitan animación
  const elementosAnimables = document.querySelectorAll('.servicio-info, .servicio-caracteristicas, .servicio-proceso');
  
  elementosAnimables.forEach(elemento => {
    elemento.style.opacity = '0';
    elemento.style.transform = 'translateY(30px)';
    elemento.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(elemento);
  });

  // Animación escalonada para características
  const caracteristicas = document.querySelectorAll('.caracteristica');
  caracteristicas.forEach((caracteristica, index) => {
    caracteristica.style.animationDelay = `${index * 0.1}s`;
    caracteristica.style.animation = 'fadeInUp 0.5s ease forwards';
  });

  // Animación escalonada para pasos del proceso
  const pasos = document.querySelectorAll('.step');
  pasos.forEach((paso, index) => {
    paso.style.animationDelay = `${index * 0.2}s`;
    paso.style.animation = 'fadeInUp 0.6s ease forwards';
  });
}

// Tooltips para precios
function inicializarTooltips() {
  const precios = document.querySelectorAll('.precio-item');
  
  precios.forEach(precio => {
    precio.addEventListener('mouseenter', () => {
      const tooltip = document.createElement('div');
      tooltip.className = 'precio-tooltip';
      tooltip.textContent = 'Precio base - puede variar según el vehículo';
      tooltip.style.cssText = `
        position: absolute;
        background: var(--gris-oscuro);
        color: #fff;
        padding: 0.5rem;
        border-radius: 5px;
        font-size: 0.8rem;
        z-index: 1000;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.3s ease;
      `;
      
      document.body.appendChild(tooltip);
      
      const rect = precio.getBoundingClientRect();
      tooltip.style.left = rect.left + 'px';
      tooltip.style.top = (rect.top - tooltip.offsetHeight - 5) + 'px';
      
      setTimeout(() => {
        tooltip.style.opacity = '1';
      }, 10);
    });
    
    precio.addEventListener('mouseleave', () => {
      const tooltip = document.querySelector('.precio-tooltip');
      if (tooltip) {
        tooltip.remove();
      }
    });
  });
}

// Efectos de hover mejorados
document.addEventListener('DOMContentLoaded', () => {
  const botones = document.querySelectorAll('.btn-volver, .btn-contacto');
  
  botones.forEach(boton => {
    boton.addEventListener('mouseenter', () => {
      boton.style.transform = 'translateY(-3px) scale(1.05)';
    });
    
    boton.addEventListener('mouseleave', () => {
      boton.style.transform = 'translateY(0) scale(1)';
    });
  });
  
  // Efecto de pulso en números de pasos
  const numerosPasos = document.querySelectorAll('.step-number');
  numerosPasos.forEach(numero => {
    numero.addEventListener('mouseenter', () => {
      numero.style.animation = 'pulse 0.6s ease';
    });
  });
});

// CSS para animaciones
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
  }
`;
document.head.appendChild(style);
