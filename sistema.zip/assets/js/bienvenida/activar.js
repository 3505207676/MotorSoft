/**
 * Define la contraseña con el token del correo (invitación o recuperación).
 */
document.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token') || '';
    const hidden = document.getElementById('token-activar');
    if (hidden) hidden.value = token;
    const msg = document.getElementById('activar-mensaje');
    if (!token) {
        if (msg) msg.textContent = 'Este enlace no es válido. Solicite uno nuevo desde el inicio de sesión.';
        const btn = document.getElementById('btn-activar');
        if (btn) btn.disabled = true;
        document.getElementById('password-activar')?.setAttribute('disabled', 'disabled');
        document.getElementById('password-confirm-activar')?.setAttribute('disabled', 'disabled');
    }
    document.getElementById('form-activar')?.addEventListener('submit', (e) => {
        e.preventDefault();
        guardar();
    });
});

function apiBase() {
    return (typeof API !== 'undefined' && API.base)
        ? API.base
        : '../../controllers/api';
}

function guardar() {
    const token = document.getElementById('token-activar')?.value || '';
    const password = document.getElementById('password-activar')?.value || '';
    const confirm = document.getElementById('password-confirm-activar')?.value || '';
    const msg = document.getElementById('activar-mensaje');
    const btn = document.getElementById('btn-activar');
    if (msg) msg.textContent = '';
    if (!token) {
        if (msg) msg.textContent = 'Falta el token del enlace.';
        return;
    }
    if (password.length < 6) {
        if (msg) msg.textContent = 'La contraseña debe tener al menos 6 caracteres.';
        return;
    }
    if (password !== confirm) {
        if (msg) msg.textContent = 'Las contraseñas no coinciden.';
        return;
    }
    if (btn) btn.disabled = true;
    fetch(apiBase() + '/auth/reset-password.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password, password_confirm: confirm })
    })
        .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
        .then((resultado) => {
            if (!resultado.ok || !resultado.data.success) {
                throw new Error(resultado.data.mensaje || 'No se pudo guardar la contraseña');
            }
            if (msg) msg.textContent = 'Contraseña guardada. Ya puede iniciar sesión.';
            setTimeout(() => { window.location.href = 'login.php'; }, 1200);
        })
        .catch((err) => {
            if (msg) msg.textContent = err.message || 'No se pudo guardar la contraseña';
        })
        .finally(() => {
            if (btn) btn.disabled = false;
        });
}
