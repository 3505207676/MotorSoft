/**
 * Capa de datos del panel: API primero, con copia local de respaldo.
 */
const MotorStore = {
    PREFIX: 'motorsoft_',

    _load(key) {
        try {
            const raw = localStorage.getItem(this.PREFIX + key);
            return raw ? JSON.parse(raw) : null;
        } catch { return null; }
    },

    _save(key, data) {
        localStorage.setItem(this.PREFIX + key, JSON.stringify(data));
        return data;
    },

    async list(key, apiFetcher) {
        if (typeof apiFetcher === 'function') {
            const res = await apiFetcher();
            const data = res?.data ?? res;
            if (Array.isArray(data)) {
                this._save(key, data);
                return data;
            }
            return [];
        }
        return this._load(key) || [];
    },

    async saveItem(key, item, idField, apiSaver) {
        const collection = await this.list(key);
        const id = item[idField];
        const idx = collection.findIndex(r => Number(r[idField]) === Number(id));

        if (typeof apiSaver === 'function') {
            const res = await apiSaver(item, idx >= 0);
            if (res?.data) item = res.data;
        }

        if (idx >= 0) collection[idx] = { ...collection[idx], ...item };
        else {
            if (!item[idField]) item[idField] = ModuleCore.nextId(collection, idField);
            collection.push(item);
        }
        this._save(key, collection);
        this._logAudit(idx >= 0 ? 'UPDATE' : 'CREATE', key, item[idField]);
        return item;
    },

    async removeItem(key, id, idField, apiDeleter) {
        let collection = await this.list(key);
        if (typeof apiDeleter === 'function') {
            await apiDeleter(id);
        }
        collection = collection.filter(r => Number(r[idField]) !== Number(id));
        this._save(key, collection);
        this._logAudit('DELETE', key, id);
        return true;
    },

    _logAudit(accion, tabla, registro_id) {
        const logs = this._load('logs_auditoria') || [];
        logs.unshift({
            id_log: ModuleCore.nextId(logs, 'id_log'),
            id_usuario: 1,
            usuario_nombre: 'Sistema',
            accion,
            tabla_afectada: tabla,
            registro_id,
            fecha: new Date().toISOString(),
            ip_address: '127.0.0.1'
        });
        this._save('logs_auditoria', logs.slice(0, 500));
    },

    getCliente(id) {
        return (this._load('clientes') || []).find(c => Number(c.id_cliente) === Number(id));
    },

    getVehiculosByCliente(idCliente) {
        return (this._load('vehiculos') || []).filter(v => Number(v.id_cliente) === Number(idCliente));
    },

    getUsuario(id) {
        return (this._load('usuarios') || []).find(u => u.id_usuario === id);
    },

    getConcepto(id) {
        return (this._load('conceptos_financieros') || []).find(c => c.id_concepto === id);
    },

    getCuenta(id) {
        return (this._load('cuentas') || []).find(c => c.id_cuenta === id);
    },

    apiClientes: {
        list: () => typeof apiClientes === 'function' ? apiClientes(true) : null,
        save: (d, isEdit) => isEdit ? apiClientesActualizar(d.id_cliente, d) : apiClientes(false, d),
        remove: id => apiClientesEliminar(id)
    },
    apiVehiculos: {
        list: () => typeof apiVehiculos === 'function' ? apiVehiculos(true) : null,
        save: (d, isEdit) => isEdit ? apiVehiculosActualizar(d.id_vehiculo, d) : apiVehiculos(false, d),
        remove: id => apiVehiculosEliminar(id)
    },
    apiFacturas: {
        list: () => typeof apiFacturas === 'function' ? apiFacturas(true) : null,
        save: (d, isEdit) => isEdit ? apiFacturasActualizar(d.id_factura, d) : apiFacturas(false, d),
        remove: id => apiFacturasEliminar(id)
    },
    apiVentas: {
        list: () => typeof apiVentas === 'function' ? apiVentas(true) : null,
        save: d => apiVentas(false, d)
    },
    apiProductos: {
        list: () => typeof apiProductos === 'function' ? apiProductos(true) : null
    },
    apiConfiguracion: {
        get: () => typeof apiConfiguracion === 'function' ? apiConfiguracion() : null,
        save: d => apiConfiguracionActualizar(d)
    },
    apiContabilidad: {
        list: () => typeof apiContabilidad === 'function' ? apiContabilidad(true) : null
    }
};

window.MotorStore = MotorStore;
