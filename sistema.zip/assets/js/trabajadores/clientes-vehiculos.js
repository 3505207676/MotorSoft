/**
 * Módulo unificado Clientes y Vehículos
 * Alineado a tablas Clientes y Vehiculo (db_taller.sql)
 */
const ClientesVehiculosModule = (() => {
    const state = {
        tab: 'clientes',
        clientes: [],
        vehiculos: [],
        editCliente: null,
        editVehiculo: null,
        pagClientes: { page: 1, perPage: 8, totalPages: 1 },
        pagVehiculos: { page: 1, perPage: 8, totalPages: 1 },
        filtros: { clienteEstado: 'todos', vehiculoEstado: 'todos', busqueda: '' }
    };

    async function init() {
        await loadData();
        ModuleCore.initTabs('#modulo-clientes-vehiculos', id => { state.tab = id; });
        bindEvents();
        renderClientes();
        renderVehiculos();
        populateClienteSelect();
        abrirDesdeQuery();
    }

    async function loadData() {
        try {
            state.clientes = await MotorStore.list('clientes', MotorStore.apiClientes.list);
            state.vehiculos = await MotorStore.list('vehiculos', MotorStore.apiVehiculos.list);
        } catch (e) {
            state.clientes = [];
            state.vehiculos = [];
            ModuleCore.toast(e.message || 'No se pudieron cargar clientes/vehículos', 'error');
        }
    }

    function bindEvents() {
        document.getElementById('btn-nuevo-cliente')?.addEventListener('click', () => openClienteModal());
        document.getElementById('btn-nuevo-vehiculo')?.addEventListener('click', () => openVehiculoModal());
        document.getElementById('btn-refresh-cv')?.addEventListener('click', async () => {
            await loadData();
            renderClientes();
            renderVehiculos();
            populateClienteSelect();
            ModuleCore.toast('Datos actualizados', 'success');
        });
        document.getElementById('filter-cliente-estado')?.addEventListener('change', e => {
            state.filtros.clienteEstado = e.target.value;
            state.pagClientes.page = 1;
            renderClientes();
        });
        document.getElementById('filter-vehiculo-estado')?.addEventListener('change', e => {
            state.filtros.vehiculoEstado = e.target.value;
            state.pagVehiculos.page = 1;
            renderVehiculos();
        });
        document.getElementById('search-cv')?.addEventListener('input', ModuleCore.debounce(e => {
            state.filtros.busqueda = e.target.value.trim().toLowerCase();
            state.pagClientes.page = 1;
            state.pagVehiculos.page = 1;
            renderClientes();
            renderVehiculos();
        }));

        ModuleCore.bindModalClose('modal-cliente', 'btn-cancelar-cliente', 'btn-cerrar-cliente');
        ModuleCore.bindModalClose('modal-vehiculo', 'btn-cancelar-vehiculo', 'btn-cerrar-vehiculo');
        document.getElementById('btn-guardar-cliente')?.addEventListener('click', saveCliente);
        document.getElementById('btn-guardar-vehiculo')?.addEventListener('click', saveVehiculo);
        const formVeh = document.getElementById('form-vehiculo');
        formVeh?.placa?.addEventListener('blur', () => {
            if (!window.MotorSoftPlaca || !formVeh.tipo) return;
            if (formVeh.tipo.dataset.auto !== '1') return;
            formVeh.tipo.value = MotorSoftPlaca.inferirTipo(formVeh.placa.value);
        });
        formVeh?.tipo?.addEventListener('change', () => {
            formVeh.tipo.dataset.auto = '0';
        });

        document.getElementById('tabla-clientes')?.addEventListener('click', onClienteTableClick);
        document.getElementById('tabla-vehiculos')?.addEventListener('click', onVehiculoTableClick);

        ModuleCore.bindPagination(
            document.getElementById('prev-clientes'),
            document.getElementById('next-clientes'),
            document.getElementById('pag-clientes-label'),
            state.pagClientes,
            renderClientes
        );
        ModuleCore.bindPagination(
            document.getElementById('prev-vehiculos'),
            document.getElementById('next-vehiculos'),
            document.getElementById('pag-vehiculos-label'),
            state.pagVehiculos,
            renderVehiculos
        );
    }

    function activarTab(id) {
        const container = document.getElementById('modulo-clientes-vehiculos');
        if (!container) return;
        container.querySelectorAll('[data-tab]').forEach(t => t.classList.toggle('active', t.dataset.tab === id));
        container.querySelectorAll('[data-panel]').forEach(p => p.classList.toggle('active', p.dataset.panel === id));
        state.tab = id;
    }

    function abrirDesdeQuery() {
        const params = new URLSearchParams(location.search);
        const idCli = params.get('cliente');
        const idVeh = params.get('vehiculo');
        const hash = (location.hash || '').replace('#', '');
        if (idVeh || hash === 'vehiculos') {
            activarTab('vehiculos');
            const v = idVeh ? state.vehiculos.find(x => mismoId(x.id_vehiculo, idVeh)) : null;
            if (v) {
                state.filtros.busqueda = String(v.placa || '').toLowerCase();
                const search = document.getElementById('search-cv');
                if (search) search.value = v.placa || '';
                renderVehiculos();
                showVehiculoDetail(v);
            }
            return;
        }
        if (idCli) {
            activarTab('clientes');
            const c = state.clientes.find(x => mismoId(x.id_cliente, idCli));
            if (c) {
                state.filtros.busqueda = String(c.nombre || c.documento || '').toLowerCase();
                const search = document.getElementById('search-cv');
                if (search) search.value = c.nombre || c.documento || '';
                renderClientes();
                showClienteDetail(c);
            }
        }
    }

    function filteredClientes() {
        return state.clientes.filter(c => {
            if (state.filtros.clienteEstado !== 'todos' && c.estado !== state.filtros.clienteEstado) return false;
            if (state.filtros.busqueda) {
                const q = state.filtros.busqueda;
                return [c.nombre, c.documento, c.email, c.telefono].some(v => String(v || '').toLowerCase().includes(q));
            }
            return true;
        });
    }

    function filteredVehiculos() {
        return state.vehiculos.filter(v => {
            if (state.filtros.vehiculoEstado !== 'todos' && v.estado !== state.filtros.vehiculoEstado) return false;
            if (state.filtros.busqueda) {
                const q = state.filtros.busqueda;
                const cliente = MotorStore.getCliente(v.id_cliente);
                return [v.placa, v.tipo, v.marca, v.modelo, cliente?.nombre].some(x => String(x || '').toLowerCase().includes(q));
            }
            return true;
        });
    }

    function renderClientes() {
        const tbody = document.querySelector('#tabla-clientes tbody');
        if (!tbody) return;
        const filtered = filteredClientes();
        const { items, totalPages } = ModuleCore.paginate(filtered, state.pagClientes.page, state.pagClientes.perPage);
        state.pagClientes.totalPages = totalPages;

        document.getElementById('kpi-clientes').textContent = state.clientes.filter(c => c.estado === 'Activo').length;
        document.getElementById('kpi-vehiculos-total').textContent = state.vehiculos.length;

        if (!items.length) {
            tbody.innerHTML = ModuleCore.emptyRow(8);
            return;
        }

        tbody.innerHTML = items.map(c => {
            const nVeh = state.vehiculos.filter(v => mismoId(v.id_cliente, c.id_cliente)).length;
            return `<tr>
                <td><strong>${esc(c.nombre)}</strong></td>
                <td>${esc(c.documento)}</td>
                <td>${esc(c.email || '—')}</td>
                <td>${esc(c.telefono)}</td>
                <td>${esc(c.preferencia_contacto || '—')}</td>
                <td>${ModuleCore.badge(c.estado)}</td>
                <td><span class="linked-badge"><i class="fas fa-car"></i> ${nVeh}</span></td>
                <td>${ModuleCore.actionButtons(c.id_cliente)}</td>
            </tr>`;
        }).join('');
    }

    function renderVehiculos() {
        const tbody = document.querySelector('#tabla-vehiculos tbody');
        if (!tbody) return;
        const filtered = filteredVehiculos();
        const { items, totalPages } = ModuleCore.paginate(filtered, state.pagVehiculos.page, state.pagVehiculos.perPage);
        state.pagVehiculos.totalPages = totalPages;

        if (!items.length) {
                tbody.innerHTML = ModuleCore.emptyRow(6);
            return;
        }

        tbody.innerHTML = items.map(v => {
            const cliente = MotorStore.getCliente(v.id_cliente);
            const icono = (window.MotorSoftPlaca && window.MotorSoftPlaca.icono(v.tipo)) || 'fa-car';
            return `<tr>
                <td><strong>${esc(v.placa)}</strong></td>
                <td><i class="fas ${icono}"></i> ${esc(v.tipo || 'Automóvil')}</td>
                <td>${esc(v.marca)} ${esc(v.modelo)} (${esc(v.anio || '—')})</td>
                <td>${esc(cliente?.nombre || '—')}</td>
                <td>${ModuleCore.badge(v.estado)}</td>
                <td>${ModuleCore.actionButtons(v.id_vehiculo)}</td>
            </tr>`;
        }).join('');
    }

    function populateClienteSelect(selected) {
        const sel = document.getElementById('veh-id-cliente');
        if (!sel) return;
        sel.innerHTML = '<option value="">Seleccione cliente...</option>' +
            state.clientes.filter(c => c.estado === 'Activo').map(c =>
                `<option value="${c.id_cliente}" ${selected == c.id_cliente ? 'selected' : ''}>${c.nombre} (${c.documento})</option>`
            ).join('');
    }

    function openClienteModal(cliente = null) {
        state.editCliente = cliente;
        document.getElementById('modal-cliente-title').textContent = cliente ? 'Editar Cliente' : 'Nuevo Cliente';
        const f = document.getElementById('form-cliente');
        f.reset();
        if (cliente) {
            f.nombre.value = cliente.nombre;
            f.documento.value = cliente.documento;
            f.email.value = cliente.email || '';
            f.telefono.value = cliente.telefono;
            f.preferencia_contacto.value = cliente.preferencia_contacto || 'WhatsApp';
            f.estado.value = cliente.estado;
        }
        ModuleCore.openModal('modal-cliente');
    }

    function openVehiculoModal(vehiculo = null) {
        state.editVehiculo = vehiculo;
        populateClienteSelect(vehiculo?.id_cliente);
        document.getElementById('modal-vehiculo-title').textContent = vehiculo ? `Editar: ${vehiculo.placa}` : 'Nuevo Vehículo';
        const f = document.getElementById('form-vehiculo');
        f.reset();
        f.tipo.dataset.auto = '1';
        if (vehiculo) {
            f.placa.value = vehiculo.placa;
            f.tipo.value = vehiculo.tipo || (window.MotorSoftPlaca ? MotorSoftPlaca.inferirTipo(vehiculo.placa) : 'Automóvil');
            f.tipo.dataset.auto = '0';
            f.marca.value = vehiculo.marca;
            f.modelo.value = vehiculo.modelo;
            f.anio.value = vehiculo.anio || '';
            f.estado.value = vehiculo.estado;
            f.id_cliente.value = vehiculo.id_cliente;
        }
        ModuleCore.openModal('modal-vehiculo');
    }

    async function saveCliente() {
        const f = document.getElementById('form-cliente');
        if (!f.checkValidity()) { f.reportValidity(); return; }
        const data = {
            id_cliente: state.editCliente?.id_cliente,
            nombre: f.nombre.value.trim(),
            documento: f.documento.value.trim(),
            email: f.email.value.trim(),
            telefono: f.telefono.value.trim(),
            preferencia_contacto: f.preferencia_contacto.value,
            estado: f.estado.value
        };
        try {
            await MotorStore.saveItem('clientes', data, 'id_cliente', (item, isEdit) =>
                isEdit ? MotorStore.apiClientes.save(item, true) : MotorStore.apiClientes.save(item, false)
            );
            await loadData();
            renderClientes();
            populateClienteSelect();
            ModuleCore.closeModal('modal-cliente');
            ModuleCore.toast('Cliente guardado', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo guardar el cliente', 'error');
        }
    }

    async function saveVehiculo() {
        const f = document.getElementById('form-vehiculo');
        if (!f.checkValidity()) { f.reportValidity(); return; }
        const placa = f.placa.value.trim().toUpperCase();
        if (window.MotorSoftPlaca && !MotorSoftPlaca.validar(placa)) {
            ModuleCore.toast('Placa inválida. Carro: ABC123. Moto: ABC12D', 'error');
            return;
        }
        const data = {
            id_vehiculo: state.editVehiculo?.id_vehiculo,
            id_cliente: parseInt(f.id_cliente.value, 10),
            placa,
            tipo: f.tipo.value,
            marca: f.marca.value.trim(),
            modelo: f.modelo.value.trim(),
            anio: parseInt(f.anio.value, 10) || null,
            estado: f.estado.value
        };
        try {
            await MotorStore.saveItem('vehiculos', data, 'id_vehiculo', (item, isEdit) =>
                isEdit ? MotorStore.apiVehiculos.save(item, true) : MotorStore.apiVehiculos.save(item, false)
            );
            await loadData();
            renderVehiculos();
            renderClientes();
            ModuleCore.closeModal('modal-vehiculo');
            ModuleCore.toast('Vehículo guardado', 'success');
        } catch (e) {
            ModuleCore.toast(e.message || 'No se pudo guardar el vehículo', 'error');
        }
    }

    function onClienteTableClick(e) {
        const btn = e.target.closest('.btn-view, .btn-edit, .btn-delete');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const cliente = state.clientes.find(c => mismoId(c.id_cliente, id));
        if (!cliente) return;
        if (btn.classList.contains('btn-view')) showClienteDetail(cliente);
        else if (btn.classList.contains('btn-edit')) openClienteModal(cliente);
        else if (btn.classList.contains('btn-delete')) {
            ModuleCore.confirm('Eliminar cliente', `¿Eliminar a ${cliente.nombre}?`, async () => {
                try {
                    await MotorStore.removeItem('clientes', id, 'id_cliente', MotorStore.apiClientes.remove);
                    await loadData();
                    renderClientes();
                    populateClienteSelect();
                    ModuleCore.toast('Cliente eliminado', 'success');
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo eliminar el cliente', 'error');
                }
            });
        }
    }

    function onVehiculoTableClick(e) {
        const btn = e.target.closest('.btn-view, .btn-edit, .btn-delete');
        if (!btn) return;
        const id = parseInt(btn.dataset.id, 10);
        const vehiculo = state.vehiculos.find(v => mismoId(v.id_vehiculo, id));
        if (!vehiculo) return;
        if (btn.classList.contains('btn-view')) showVehiculoDetail(vehiculo);
        else if (btn.classList.contains('btn-edit')) openVehiculoModal(vehiculo);
        else if (btn.classList.contains('btn-delete')) {
            ModuleCore.confirm('Eliminar vehículo', `¿Eliminar placa ${vehiculo.placa}?`, async () => {
                try {
                    await MotorStore.removeItem('vehiculos', id, 'id_vehiculo', MotorStore.apiVehiculos.remove);
                    await loadData();
                    renderVehiculos();
                    renderClientes();
                    ModuleCore.toast('Vehículo eliminado', 'success');
                } catch (err) {
                    ModuleCore.toast(err.message || 'No se pudo eliminar el vehículo', 'error');
                }
            });
        }
    }

    function showClienteDetail(cliente) {
        const vehiculos = state.vehiculos.filter(v => mismoId(v.id_cliente, cliente.id_cliente));
        const vehList = vehiculos.length
            ? vehiculos.map(v => `<span class="linked-badge"><i class="fas ${(window.MotorSoftPlaca && MotorSoftPlaca.icono(v.tipo)) || 'fa-car'}"></i> ${esc(v.tipo || '')} ${esc(v.placa)} — ${esc(v.marca)} ${esc(v.modelo)}</span>`).join(' ')
            : '<span class="text-muted">Sin vehículos registrados</span>';

        window.createModal?.('modal-detalle', `Cliente: ${esc(cliente.nombre)}`, `
            <div class="detail-grid">
                <div class="detail-item"><label>Documento</label><p>${esc(cliente.documento)}</p></div>
                <div class="detail-item"><label>Email</label><p>${esc(cliente.email || '—')}</p></div>
                <div class="detail-item"><label>Teléfono</label><p>${esc(cliente.telefono)}</p></div>
                <div class="detail-item"><label>Contacto preferido</label><p>${esc(cliente.preferencia_contacto || '—')}</p></div>
                <div class="detail-item"><label>Estado</label><p>${ModuleCore.badge(cliente.estado)}</p></div>
            </div>
            <h4 style="margin:1.25rem 0 0.75rem"><i class="fas fa-car"></i> Vehículos (${vehiculos.length})</h4>
            <div style="display:flex;flex-wrap:wrap;gap:0.5rem">${vehList}</div>
        `);
    }

    function showVehiculoDetail(v) {
        const cliente = MotorStore.getCliente(v.id_cliente);
        window.createModal?.('modal-detalle', `Vehículo: ${esc(v.placa)}`, `
            <div class="detail-grid">
                <div class="detail-item"><label>Placa</label><p>${esc(v.placa)}</p></div>
                <div class="detail-item"><label>Tipo</label><p>${esc(v.tipo || 'Automóvil')}</p></div>
                <div class="detail-item"><label>Marca / Modelo</label><p>${esc(v.marca)} ${esc(v.modelo)}</p></div>
                <div class="detail-item"><label>Año</label><p>${esc(v.anio || '—')}</p></div>
                <div class="detail-item"><label>Propietario</label><p>${esc(cliente?.nombre || '—')}</p></div>
                <div class="detail-item"><label>Estado</label><p>${ModuleCore.badge(v.estado)}</p></div>
            </div>
        `);
    }

    function mismoId(a, b) {
        return Number(a) === Number(b);
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => ClientesVehiculosModule.init());
