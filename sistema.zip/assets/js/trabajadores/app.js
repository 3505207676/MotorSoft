/**
 * Script principal para la aplicación de trabajadores
 * Taller El Paisa - Panel de Control
 */

// Inicialización de la aplicación
document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    initThemeToggle();
    initModals();
    initToasts();
});

// Control del sidebar
function initSidebar() {
    const toggleBtn = document.getElementById('toggle-sidebar');
    const floatingToggle = document.getElementById('floating-toggle');
    const appContainer = document.querySelector('.app-container');
    
    // Función para alternar el sidebar
    const toggleSidebar = () => {
        appContainer.classList.toggle('sidebar-collapsed');
    };
    
    // Botón dentro del sidebar
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleSidebar);
    }
    
    // Botón flotante (visible cuando sidebar está colapsado)
    if (floatingToggle) {
        floatingToggle.addEventListener('click', toggleSidebar);
    }
    
    // Manejo responsive del sidebar
    if (window.innerWidth < 768) {
        appContainer.classList.add('sidebar-collapsed');
    }
    
    window.addEventListener('resize', () => {
        if (window.innerWidth < 768) {
            appContainer.classList.add('sidebar-collapsed');
        }
    });
}

// Control del tema (claro/oscuro)
function initThemeToggle() {
    const themeOptions = document.querySelectorAll('.theme-option');
    const actual = window.MotorSoftTema ? window.MotorSoftTema.leer() : (localStorage.getItem('tema') || localStorage.getItem('theme') || 'light');
    const resuelto = actual === 'dark' ? 'dark' : 'light';
    if (window.MotorSoftTema) {
        window.MotorSoftTema.aplicar(resuelto);
    }

    if (themeOptions.length > 0) {
        themeOptions.forEach(option => {
            option.classList.toggle('active', option.dataset.theme === resuelto);
            option.addEventListener('click', () => {
                const theme = option.dataset.theme;
                themeOptions.forEach(opt => opt.classList.remove('active'));
                option.classList.add('active');
                if (window.MotorSoftTema) {
                    window.MotorSoftTema.aplicar(theme);
                }
            });
        });
    }
}

// Actualizar icono del toggle de tema
function updateThemeIcon(isDark) {
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        const icon = themeToggle.querySelector('i');
        if (isDark) {
            icon.className = 'fas fa-sun';
        } else {
            icon.className = 'fas fa-moon';
        }
    }
}

// Inicialización de modales
function initModals() {
    // Modal de configuración
    const btnConfig = document.getElementById('btn-configuracion');
    const modalConfig = document.getElementById('modal-configuracion');
    
    if (btnConfig && modalConfig) {
        btnConfig.addEventListener('click', () => {
            modalConfig.classList.add('active');
        });
        
        // Cerrar modal con botón
        const btnClose = modalConfig.querySelector('.btn-close');
        if (btnClose) {
            btnClose.addEventListener('click', () => {
                modalConfig.classList.remove('active');
            });
        }
        
        // Cerrar modal con botón cancelar
        const btnCancel = modalConfig.querySelector('.btn-outline');
        if (btnCancel) {
            btnCancel.addEventListener('click', () => {
                modalConfig.classList.remove('active');
            });
        }
        
        // Cerrar modal al hacer clic fuera
        modalConfig.addEventListener('click', (e) => {
            if (e.target === modalConfig) {
                modalConfig.classList.remove('active');
            }
        });
    }
    
    window.createModal = function(id, title, content, onConfirm = null) {
        const existente = document.getElementById(id);
        if (existente) existente.remove();

        const modal = document.createElement('div');
        modal.id = id;
        modal.className = 'modal';
        const pie = onConfirm
            ? `<div class="modal-footer">
                    <button type="button" class="btn btn-outline btn-cancel">Cancelar</button>
                    <button type="button" class="btn btn-primary btn-confirm">Confirmar</button>
               </div>`
            : `<div class="modal-footer">
                    <button type="button" class="btn btn-primary btn-cancel">Cerrar</button>
               </div>`;
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button type="button" class="btn-close" aria-label="Cerrar">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                ${pie}
            </div>
        `;
        document.body.appendChild(modal);

        const cerrar = () => {
            modal.classList.remove('active', 'show');
            modal.style.display = 'none';
        };
        modal.querySelector('.btn-close')?.addEventListener('click', cerrar);
        modal.querySelector('.btn-cancel')?.addEventListener('click', cerrar);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) cerrar();
        });
        const btnConfirm = modal.querySelector('.btn-confirm');
        if (onConfirm && btnConfirm) {
            btnConfirm.addEventListener('click', () => {
                onConfirm();
                cerrar();
            });
        }

        modal.classList.add('active', 'show');
        modal.style.display = 'flex';
        return modal;
    };
    
    // Función para crear modales de confirmación
    window.confirmAction = function(title, message, onConfirm) {
        return createModal(
            'modal-confirm',
            title,
            `<p>${message}</p>`,
            onConfirm
        );
    };
    
    // Función para crear modales de alerta
    window.showAlert = function(title, message) {
        const modal = createModal(
            'modal-alert',
            title,
            `<p>${message}</p>`
        );
        
        // Cambiar botones para alerta
        const footer = modal.querySelector('.modal-footer');
        footer.innerHTML = `
            <button class="btn btn-primary btn-close-alert">Aceptar</button>
        `;
        
        const btnCloseAlert = modal.querySelector('.btn-close-alert');
        btnCloseAlert.addEventListener('click', () => {
            modal.classList.remove('active');
        });
    };
}

function initToasts() {
    window.showToast = function(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas ${getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Contenedor de toasts
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.appendChild(toast);
        
        // Animación de entrada
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // Cerrar toast
        const closeBtn = toast.querySelector('.toast-close');
        closeBtn.addEventListener('click', () => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        });
        
        // Auto cerrar
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, duration);
    };
    
    function getToastIcon(type) {
        switch (type) {
            case 'success': return 'fa-check-circle';
            case 'warning': return 'fa-exclamation-triangle';
            case 'error': return 'fa-times-circle';
            default: return 'fa-info-circle';
        }
    }
}

// Utilidades generales
const utils = {
    // Formatear moneda
    formatCurrency: (amount) => {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            minimumFractionDigits: 0
        }).format(amount);
    },
    
    // Formatear fecha
    formatDate: (date) => {
        if (!(date instanceof Date)) {
            date = new Date(date);
        }
        
        return new Intl.DateTimeFormat('es-CO', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        }).format(date);
    },
    
    // Validar email
    validateEmail: (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },
    
    // Validar teléfono colombiano
    validatePhone: (phone) => {
        const re = /^(\+57|57)?[ -]*(3\d{2})[ -]*(\d{3})[ -]*(\d{4})$/;
        return re.test(phone);
    },
    
    // Generar ID único
    generateId: () => {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
};

// Exportar utilidades para uso global
window.utils = utils;