/**
 * Navegación lateral del panel de trabajadores.
 * Pinta nombre y rol desde la sesión real (API /auth/me).
 */
function nombreRolSidebar(usuario) {
    if (!usuario) return '';
    if (usuario.rol && typeof usuario.rol === 'object') {
        return usuario.rol.nombre || '';
    }
    return usuario.rol || '';
}

function pintarSidebarUsuario(usuario) {
    const nameEl = document.getElementById('sidebar-user-name');
    const roleEl = document.getElementById('sidebar-user-role');
    if (!usuario || !nameEl) return;
    nameEl.textContent = usuario.nombre || 'Usuario';
    if (roleEl) roleEl.textContent = nombreRolSidebar(usuario) || 'Sin rol';
}

function filtrarSidebarPorPermisos(usuario) {
    const nav = document.querySelector('.sidebar-nav ul');
    if (!nav || !usuario) return;
    nav.querySelectorAll('a[data-permiso]').forEach((link) => {
        const raw = link.getAttribute('data-permiso') || '';
        const slugs = raw.split('|').map((s) => s.trim()).filter(Boolean);
        const ok = slugs.length === 0
            || (window.MotorSoftGuard && window.MotorSoftGuard.puedeAlguno
                ? window.MotorSoftGuard.puedeAlguno(slugs, usuario)
                : true);
        const item = link.closest('li');
        if (item) item.hidden = !ok;
    });
}

function redirigirSiPaginaProhibida(usuario) {
    if (!usuario || !window.MotorSoftGuard?.puede) return;
    const path = window.location.pathname;
    const reglas = [
        { test: /\/usuarios\//, slugs: ['usuarios.ver'] },
        { test: /\/contabilidad\//, slugs: ['contabilidad.ver'] },
        { test: /\/reportes\//, slugs: ['reportes.ordenes', 'reportes.nomina'] },
        { test: /\/auditoria\//, slugs: ['auditoria.ver'] },
        { test: /\/configuracion\//, slugs: ['configuracion.ver', 'configuracion.editar'] },
        { test: /\/inventario\//, slugs: ['inventario.ver'] },
        { test: /\/facturacion\//, slugs: ['facturas.ver'] },
        { test: /\/clientes\//, slugs: ['clientes.ver'] },
        { test: /\/ordenes\//, slugs: ['ordenes.ver'] },
        { test: /\/agenda\//, slugs: ['agenda.ver'] },
        { test: /\/chat\//, slugs: ['chat.ver'] },
    ];
    const regla = reglas.find((r) => r.test.test(path));
    if (!regla) return;
    const ok = window.MotorSoftGuard.puedeAlguno
        ? window.MotorSoftGuard.puedeAlguno(regla.slugs, usuario)
        : regla.slugs.some((slug) => window.MotorSoftGuard.puede(slug, usuario));
    if (!ok) {
        window.location.replace('../dashboard/index-trabajadores.php');
    }
}

async function cerrarSesionOficina(e) {
    e.preventDefault();
    if (!window.confirm('¿Cerrar sesión?')) return;
    try {
        if (typeof window.apiLogout === 'function') {
            await window.apiLogout();
        }
    } catch (err) {
        /* se limpia igual */
    }
    if (window.MotorSoftGuard && typeof window.MotorSoftGuard.limpiar === 'function') {
        window.MotorSoftGuard.limpiar();
    } else {
        localStorage.removeItem('motorsoft_token');
        localStorage.removeItem('motorsoft_usuario');
        localStorage.removeItem('motorsoft_sesion');
        localStorage.removeItem('motorsoft_cliente');
    }
    window.location.replace('../auth/login.php');
}

function enlazarCerrarSesion() {
    const salir = document.getElementById('btn-cerrar-sesion-oficina')
        || document.querySelector('.sidebar-footer .btn-salir');
    if (!salir || salir.dataset.bound === '1') return;
    salir.dataset.bound = '1';
    salir.addEventListener('click', cerrarSesionOficina);
}

async function cargarUsuarioSidebar() {
    const nameEl = document.getElementById('sidebar-user-name');
    const roleEl = document.getElementById('sidebar-user-role');
    if (!nameEl) return;

    try {
        const cache = JSON.parse(localStorage.getItem('motorsoft_usuario') || 'null');
        if (cache && cache.nombre) {
            pintarSidebarUsuario(cache);
            filtrarSidebarPorPermisos(cache);
        }
    } catch (e) {
        /* cache inválido */
    }

    if (typeof window.apiMe !== 'function') {
        return;
    }

    try {
        const res = await window.apiMe();
        const usuario = res.data?.usuario;
        if (!usuario) {
            return;
        }
        pintarSidebarUsuario(usuario);
        filtrarSidebarPorPermisos(usuario);
        redirigirSiPaginaProhibida(usuario);
        localStorage.setItem('motorsoft_usuario', JSON.stringify(usuario));
        const sesion = JSON.parse(localStorage.getItem('motorsoft_sesion') || 'null') || {};
        sesion.rol = nombreRolSidebar(usuario);
        sesion.tipo = sesion.tipo || 'usuario';
        localStorage.setItem('motorsoft_sesion', JSON.stringify(sesion));
        document.dispatchEvent(new CustomEvent('motorsoft:usuario-actualizado', { detail: usuario }));
    } catch (e) {
        if (roleEl && !roleEl.textContent) {
            roleEl.textContent = 'Sin sesión';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.sidebar-nav ul');
    if (nav) {
        const path = window.location.pathname;
        nav.querySelectorAll('a[href]').forEach((link) => {
            const href = link.getAttribute('href') || '';
            if (href.includes('.html')) {
                link.setAttribute('href', href.replace(/\.html/g, '.php'));
            }
        });
        if (path.includes('/clientes/') || path.includes('/vehiculos/')) {
            nav.querySelectorAll('a').forEach((a) => a.classList.remove('active'));
            const clientes = nav.querySelector('a[href*="clientes"]');
            if (clientes) clientes.classList.add('active');
        }
    }
    enlazarCerrarSesion();
    cargarUsuarioSidebar();
    cargarBadgeChat();
});

async function cargarBadgeChat() {
    if (typeof window.apiChatConversaciones !== 'function') return;
    try {
        const res = await window.apiChatConversaciones();
        const n = Number(res.data?.no_leidos || 0);
        document.querySelectorAll('#badge-chat-sidebar, #badge-chat-top, #btn-mensajes .notification-badge').forEach(el => {
            if (!el) return;
            el.textContent = String(n);
            el.hidden = n <= 0;
        });
    } catch (e) { /* silencioso */ }
}

window.pintarSidebarUsuario = pintarSidebarUsuario;
window.cargarUsuarioSidebar = cargarUsuarioSidebar;
