/**
 * Campana del personal: alertas reales de stock, citas, facturas y chat.
 */
(function (window, document) {
    const ICONOS = {
        stock: 'fa-boxes',
        citas: 'fa-calendar-day',
        facturas: 'fa-file-invoice-dollar',
        chat: 'fa-comments'
    };

    let items = [];
    let panel = null;
    let abierto = false;
    let timer = null;

    function esMecanico() {
        return /index-mecanicos|\/stock\/index\.php|\/consumos\/|\/perfil\/index-mecanicos/.test(location.pathname);
    }

    function boton() {
        return document.getElementById('btn-notificaciones') || document.getElementById('btn-notifications');
    }

    function badgeEl(btn) {
        return (btn && btn.querySelector('.notification-badge')) || document.getElementById('notification-count');
    }

    function hrefDe(n) {
        if (!esMecanico()) return n.href || '#';
        if (n.tipo === 'chat') return '../chat/index-mecanicos.php';
        if (n.tipo === 'stock') return '../stock/index.php';
        if (n.tipo === 'citas') return '../dashboard/index-mecanicos.php#citas-hoy';
        return n.href || '#';
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function pintarBadge() {
        const btn = boton();
        if (!btn) return;
        const n = items.length;
        const badge = badgeEl(btn);
        if (!badge) return;
        badge.textContent = String(n);
        badge.hidden = n <= 0;
        badge.classList.toggle('hidden', n <= 0);
    }

    function asegurarPanel() {
        if (panel) return panel;
        panel = document.createElement('div');
        panel.id = 'motorsoft-notif-panel';
        panel.className = 'notif-panel';
        panel.hidden = true;
        panel.setAttribute('role', 'dialog');
        panel.setAttribute('aria-label', 'Alertas del taller');
        document.body.appendChild(panel);
        return panel;
    }

    function render() {
        const el = asegurarPanel();
        if (!items.length) {
            el.innerHTML = '<div class="notif-head">Alertas del taller</div>' +
                '<p class="notif-empty">No hay alertas del taller en este momento.</p>';
            return;
        }
        el.innerHTML = '<div class="notif-head">Alertas del taller</div><ul class="notif-list">' +
            items.map(n => {
                const icon = ICONOS[n.tipo] || 'fa-bell';
                return '<li><a href="' + esc(hrefDe(n)) + '">' +
                    '<i class="fas ' + icon + '"></i><span>' + esc(n.texto) + '</span></a></li>';
            }).join('') + '</ul>';
    }

    function posicionar() {
        const btn = boton();
        const el = asegurarPanel();
        if (!btn) return;
        const r = btn.getBoundingClientRect();
        el.style.top = (r.bottom + 8) + 'px';
        el.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
        el.style.left = 'auto';
    }

    function abrir() {
        render();
        posicionar();
        asegurarPanel().hidden = false;
        abierto = true;
    }

    function cerrar() {
        if (panel) panel.hidden = true;
        abierto = false;
    }

    function toggle(e) {
        e.preventDefault();
        e.stopPropagation();
        if (abierto) cerrar();
        else abrir();
    }

    function aplicar(lista) {
        items = Array.isArray(lista) ? lista : [];
        pintarBadge();
        if (abierto) render();
    }

    async function cargar() {
        if (typeof window.apiDashboard !== 'function') return;
        try {
            const res = await window.apiDashboard({ alertas: '1' });
            aplicar((res.data || {}).notificaciones || []);
        } catch (err) {
            aplicar([]);
        }
    }

    function init() {
        const btn = boton();
        if (!btn || btn.dataset.notifBound === '1') return;
        btn.dataset.notifBound = '1';
        btn.addEventListener('click', toggle);
        document.addEventListener('click', e => {
            if (!abierto) return;
            if (panel && panel.contains(e.target)) return;
            if (btn.contains(e.target)) return;
            cerrar();
        });
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') cerrar();
        });
        window.addEventListener('resize', () => {
            if (abierto) posicionar();
        });
        cargar();
        if (timer) clearInterval(timer);
        timer = setInterval(cargar, 60000);
    }

    document.addEventListener('DOMContentLoaded', init);
    window.MotorSoftNotificaciones = { recargar: cargar, aplicar, cerrar };
})(window, document);
