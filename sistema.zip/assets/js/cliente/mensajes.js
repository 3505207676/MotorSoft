/**
 * Chat del portal cliente: un hilo real con el taller.
 */
const CliChat = {
    mensajes: [],
    poll: null,
    enviando: false,
    firma: '',
};

function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
    }[c]));
}

function esMio(m) {
    if (m && typeof m.mio === 'boolean') return m.mio;
    const tipo = String(m?.tipo_emisor || '').toLowerCase();
    let yoCliente = 0;
    try {
        const c = JSON.parse(localStorage.getItem('motorsoft_cliente') || 'null');
        yoCliente = Number(c?.id_cliente || c?.id || 0);
    } catch (e) {
        yoCliente = 0;
    }
    if (yoCliente > 0) {
        return tipo === 'cliente' && Number(m.emisor_id) === yoCliente;
    }
    return typeof window.chatMensajeEsMio === 'function' ? window.chatMensajeEsMio(m) : false;
}

function parseFecha(valor) {
    if (!valor) return null;
    const raw = String(valor).trim();
    const d = new Date(raw.includes('T') ? raw : raw.replace(' ', 'T'));
    return Number.isNaN(d.getTime()) ? null : d;
}

function horaCorta(valor) {
    const d = parseFecha(valor);
    if (!d) return '';
    return d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
}

function claveDia(valor) {
    const d = parseFecha(valor);
    if (!d) return '';
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function etiquetaDia(valor) {
    const d = parseFecha(valor);
    if (!d) return '';
    const hoy = new Date();
    const ayer = new Date();
    ayer.setDate(hoy.getDate() - 1);
    if (d.toDateString() === hoy.toDateString()) return 'Hoy';
    if (d.toDateString() === ayer.toDateString()) return 'Ayer';
    return d.toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'short' });
}

function unwrapLista(res) {
    if (Array.isArray(res?.data)) return res.data;
    if (Array.isArray(res?.data?.mensajes)) return res.data.mensajes;
    return [];
}

function aviso(texto) {
    const el = document.getElementById('cli-chat-aviso');
    if (!el) return;
    el.textContent = texto || '';
    el.hidden = !texto;
}

function firmaDe(lista) {
    return lista.map(m => `${m.id_mensaje || ''}:${m.estado || ''}:${m.contenido || ''}:${m.id_adjunto || ''}`).join('|');
}

function pintarEstado(lista) {
    const status = document.getElementById('cli-chat-status');
    if (!status) return;
    const ultimo = lista[lista.length - 1];
    if (!ultimo) {
        status.textContent = 'Aún no hay mensajes. Escribe al taller.';
        return;
    }
    const hora = horaCorta(ultimo.fecha_hora);
    status.textContent = esMio(ultimo)
        ? (hora ? `Último mensaje enviado a las ${hora}` : 'Mensaje enviado')
        : (hora ? `Última respuesta a las ${hora}` : 'El taller te respondió');
}

function pintar() {
    const box = document.getElementById('cli-chat-thread');
    if (!box) return;
    const lista = CliChat.mensajes;
    const firma = firmaDe(lista);
    const cercaDelFinal = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    const primera = box.dataset.ready !== '1';
    if (firma === CliChat.firma && box.dataset.ready === '1') return;
    CliChat.firma = firma;

    if (!lista.length) {
        box.innerHTML = `
            <div class="cli-chat-empty">
                <i class="fas fa-comments"></i>
                <h3>Habla con el taller</h3>
                <p>Pregunta por tu vehículo, una cita o una factura. El personal te responde aquí.</p>
            </div>`;
        box.dataset.ready = '1';
        pintarEstado(lista);
        return;
    }

    let dia = '';
    box.innerHTML = lista.map(m => {
        const actual = claveDia(m.fecha_hora);
        let chip = '';
        if (actual && actual !== dia) {
            dia = actual;
            chip = `<div class="cli-chat-day"><span>${esc(etiquetaDia(m.fecha_hora))}</span></div>`;
        }
        const mio = esMio(m);
        return `${chip}
            <article class="cli-chat-msg ${mio ? 'is-mine' : 'is-theirs'}">
                <div class="cli-chat-bubble">
                    ${mio ? '' : `<span class="cli-chat-from">${esc(m.emisor_nombre || 'Taller')}</span>`}
                    ${typeof window.htmlAdjuntoMensaje === 'function' ? window.htmlAdjuntoMensaje(m, esc) : `<p>${esc(m.contenido)}</p>`}
                    <time>${esc(horaCorta(m.fecha_hora))}</time>
                </div>
            </article>`;
    }).join('');
    box.dataset.ready = '1';
    pintarEstado(lista);
    if (primera || cercaDelFinal) {
        box.scrollTop = box.scrollHeight;
    }
}

async function marcarLeidos() {
    if (typeof window.apiChatLeer !== 'function') return;
    try {
        await window.apiChatLeer();
        window.actualizarBadgeMensajes?.(0);
    } catch (e) {
        /* silencioso */
    }
}

async function cargarMensajes(silencioso = false) {
    try {
        const res = await window.apiChatObtener(silencioso ? { silencioso: 1 } : {});
        CliChat.mensajes = unwrapLista(res);
        pintar();
        const hayNuevos = CliChat.mensajes.some(m => !esMio(m) && String(m.estado || '').toLowerCase() !== 'leido');
        if (hayNuevos) await marcarLeidos();
        else window.actualizarBadgeMensajes?.(0);
    } catch (e) {
        if (!silencioso) {
            const box = document.getElementById('cli-chat-thread');
            if (box && !CliChat.mensajes.length) {
                box.innerHTML = `<div class="cli-chat-empty"><p>${esc(e.message || 'No se pudieron cargar los mensajes')}</p></div>`;
            }
        }
    }
}

async function enviar(e) {
    e.preventDefault();
    const input = document.getElementById('cli-chat-input');
    const btn = document.getElementById('cli-chat-enviar');
    const texto = (input?.value || '').trim();
    if (!texto || CliChat.enviando) return;
    await despacharMensaje(texto, 0);
}

async function despacharMensaje(texto, idAdjunto) {
    const input = document.getElementById('cli-chat-input');
    const btn = document.getElementById('cli-chat-enviar');
    if (CliChat.enviando) return;
    CliChat.enviando = true;
    aviso('');
    if (btn) btn.disabled = true;
    try {
        const body = { contenido: texto || '' };
        if (idAdjunto) body.id_adjunto = idAdjunto;
        await window.apiChatEnviar(body);
        if (input) input.value = '';
        await cargarMensajes();
        const box = document.getElementById('cli-chat-thread');
        if (box) box.scrollTop = box.scrollHeight;
    } catch (err) {
        aviso(err.message || 'No se pudo enviar el mensaje');
    } finally {
        CliChat.enviando = false;
        if (btn) btn.disabled = false;
        input?.focus();
    }
}

async function adjuntarCliente() {
    const input = document.getElementById('cli-chat-archivo');
    const file = input?.files?.[0];
    if (!file) return;
    aviso('');
    try {
        let conv = CliChat.mensajes[0]?.id_conversacion || 0;
        if (conv < 1 && typeof window.apiChatAbrir === 'function') {
            const abierta = await window.apiChatAbrir({});
            conv = Number(abierta.data?.id_conversacion || abierta.id_conversacion || 0);
        }
        const res = await window.apiAdjuntoSubir(file, 'conversacion', conv);
        const id = res.data?.id_adjunto;
        if (!id) throw new Error('No se recibió el archivo');
        const texto = (document.getElementById('cli-chat-input')?.value || '').trim();
        await despacharMensaje(texto, id);
    } catch (err) {
        aviso(err.message || 'No se pudo adjuntar');
    } finally {
        input.value = '';
    }
}

function arrancarPoll() {
    if (CliChat.poll) clearInterval(CliChat.poll);
    CliChat.poll = setInterval(() => cargarMensajes(true).catch(() => {}), 5000);
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('cli-chat-form')?.addEventListener('submit', enviar);
    document.getElementById('cli-chat-adjuntar')?.addEventListener('click', () => {
        document.getElementById('cli-chat-archivo')?.click();
    });
    document.getElementById('cli-chat-archivo')?.addEventListener('change', adjuntarCliente);
    cargarMensajes();
    arrancarPoll();
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) return;
        cargarMensajes(true).catch(() => {});
    });
});
