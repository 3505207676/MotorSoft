/**
 * Catálogo de servicios y agendamiento desde el portal del cliente.
 */
const iconosPorTipo = {
    mantenimiento: 'fas fa-oil-can',
    diagnostico: 'fas fa-laptop',
    suspension: 'fas fa-car-side',
    frenos: 'fas fa-car-crash',
    electrico: 'fas fa-bolt',
    motor: 'fas fa-cog',
    reparacion: 'fas fa-tools'
};

let serviciosDisponibles = [];
let serviciosFiltrados = [];
let vehiculosCliente = [];
let citasCliente = [];
let vistaActual = 'tarjetas';
let servicioSeleccionado = null;

function hoyISO() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function unwrap(res) {
    return Array.isArray(res?.data) ? res.data : [];
}

function moneda(n) {
    return Number(n || 0).toLocaleString('es-CO');
}

function iconoServicio(tipo) {
    const clave = String(tipo || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return iconosPorTipo[clave] || 'fas fa-cogs';
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-vista-tarjetas')?.addEventListener('click', () => cambiarVista('tarjetas'));
    document.getElementById('btn-vista-tabla')?.addEventListener('click', () => cambiarVista('tabla'));
    document.getElementById('buscar-servicio')?.addEventListener('input', filtrarServicios);
    document.getElementById('filtro-categoria')?.addEventListener('change', filtrarServicios);
    document.getElementById('filtro-precio')?.addEventListener('change', filtrarServicios);
    document.getElementById('cerrar-modal-agendar')?.addEventListener('click', cerrarModalAgendar);
    document.getElementById('cancelar-modal-agendar')?.addEventListener('click', cerrarModalAgendar);
    document.getElementById('agendar-fecha')?.addEventListener('change', () => cargarHorarios());
    document.getElementById('form-agendar')?.addEventListener('submit', confirmarCita);
    document.getElementById('lista-mis-citas')?.addEventListener('click', onCitaClienteClick);
    const fecha = document.getElementById('agendar-fecha');
    if (fecha) fecha.min = hoyISO();
    cargarPreferenciaVista();
    cargarDatos();
});

async function cargarDatos() {
    try {
        const [servRes, vehRes, citasRes] = await Promise.all([
            window.apiServicios({ estado: 'Activo' }),
            window.apiVehiculos(true),
            window.apiCitas()
        ]);
        serviciosDisponibles = unwrap(servRes);
        vehiculosCliente = unwrap(vehRes);
        citasCliente = unwrap(citasRes);
        llenarFiltroCategoria();
        filtrarServicios();
        pintarCitasCliente();
    } catch (e) {
        mostrarNotificacion(e.message || 'No se pudieron cargar los servicios', true);
        const grid = document.getElementById('vista-tarjetas-servicios');
        if (grid) grid.innerHTML = `<p style="text-align:center;padding:2rem">${e.message || 'Error al cargar'}</p>`;
    }
}

function llenarFiltroCategoria() {
    const select = document.getElementById('filtro-categoria');
    if (!select) return;
    const tipos = [...new Set(serviciosDisponibles.map(s => s.tipo).filter(Boolean))];
    const actual = select.value;
    select.innerHTML = '<option value="">Todas las categorías</option>' +
        tipos.map(t => `<option value="${t}">${t}</option>`).join('');
    if (actual) select.value = actual;
}

function filtrarServicios() {
    const texto = (document.getElementById('buscar-servicio')?.value || '').toLowerCase();
    const categoria = document.getElementById('filtro-categoria')?.value || '';
    const precio = document.getElementById('filtro-precio')?.value || '';
    serviciosFiltrados = serviciosDisponibles.filter(s => {
        const nombre = String(s.nombre || '').toLowerCase();
        const desc = String(s.descripcion || '').toLowerCase();
        const coincideTexto = !texto || nombre.includes(texto) || desc.includes(texto);
        const coincideCat = !categoria || String(s.tipo || '') === categoria;
        const p = Number(s.precio || 0);
        let coincidePrecio = true;
        if (precio === '0-50000') coincidePrecio = p <= 50000;
        else if (precio === '50000-100000') coincidePrecio = p > 50000 && p <= 100000;
        else if (precio === '100000-200000') coincidePrecio = p > 100000 && p <= 200000;
        else if (precio === '200000+') coincidePrecio = p > 200000;
        return coincideTexto && coincideCat && coincidePrecio;
    });
    cargarServicios();
}

function cambiarVista(nuevaVista) {
    vistaActual = nuevaVista;
    document.querySelectorAll('.btn-vista').forEach(btn => btn.classList.remove('activo'));
    document.getElementById(`btn-vista-${nuevaVista}`)?.classList.add('activo');
    const vistaTarjetas = document.getElementById('vista-tarjetas-servicios');
    const vistaTabla = document.getElementById('vista-tabla-servicios');
    if (nuevaVista === 'tarjetas') {
        if (vistaTarjetas) vistaTarjetas.style.display = '';
        if (vistaTabla) vistaTabla.style.display = 'none';
    } else {
        if (vistaTarjetas) vistaTarjetas.style.display = 'none';
        if (vistaTabla) vistaTabla.style.display = 'block';
    }
    localStorage.setItem('vistaPreferidaServicios', nuevaVista);
    cargarServicios();
}

function cargarPreferenciaVista() {
    cambiarVista(localStorage.getItem('vistaPreferidaServicios') || 'tarjetas');
}

function cargarServicios() {
    if (vistaActual === 'tarjetas') cargarServiciosTarjetas();
    else cargarServiciosTabla();
}

function vacioServicios() {
    return `
        <div class="empty-state" style="padding:1.25rem">
            <p>No se encontraron servicios. Prueba con otro filtro o vuelve más tarde.</p>
        </div>`;
}

function cargarServiciosTarjetas() {
    const contenedor = document.getElementById('vista-tarjetas-servicios');
    if (!contenedor) return;
    if (!serviciosFiltrados.length) {
        contenedor.innerHTML = vacioServicios();
        return;
    }
    contenedor.innerHTML = serviciosFiltrados.map((s) => `
        <article class="servicio-card">
            <div class="card-top">
                <div class="tarjeta-icon"><i class="${iconoServicio(s.tipo)}"></i></div>
                <span class="categoria">${s.tipo || 'Servicio'}</span>
            </div>
            <h3>${s.nombre}</h3>
            <p>${s.descripcion || 'Consulte con el taller para más detalles.'}</p>
            <div class="servicio-footer">
                <div class="precio">$${moneda(s.precio)}</div>
                <button class="btn-solicitar" data-id="${s.id_servicio}" type="button">
                    Agendar
                </button>
            </div>
        </article>
    `).join('');
    contenedor.querySelectorAll('.btn-solicitar').forEach(btn => {
        btn.addEventListener('click', () => abrirModalAgendar(parseInt(btn.dataset.id, 10)));
    });
}

function cargarServiciosTabla() {
    const contenedor = document.getElementById('vista-tabla-servicios');
    if (!contenedor) return;
    if (!serviciosFiltrados.length) {
        contenedor.innerHTML = vacioServicios();
        return;
    }
    contenedor.innerHTML = `
        <div class="tabla-container">
            <table>
                <thead>
                    <tr>
                        <th>Servicio</th>
                        <th>Categoría</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    ${serviciosFiltrados.map(s => `
                        <tr>
                            <td><strong>${s.nombre}</strong></td>
                            <td>${s.tipo || '—'}</td>
                            <td>${s.descripcion || '—'}</td>
                            <td>$${moneda(s.precio)}</td>
                            <td>
                                <button class="btn-solicitar" data-id="${s.id_servicio}">
                                    <i class="fas fa-calendar-plus"></i> Agendar
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>`;
    contenedor.querySelectorAll('.btn-solicitar').forEach(btn => {
        btn.addEventListener('click', () => abrirModalAgendar(parseInt(btn.dataset.id, 10)));
    });
}

function escHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

function pintarCitasCliente() {
    const box = document.getElementById('lista-mis-citas');
    if (!box) return;
    const hoy = hoyISO();
    const activas = citasCliente.filter(c => {
        const est = String(c.estado_cita || '').toLowerCase();
        const fecha = String(c.fecha || '').slice(0, 10);
        return est !== 'cancelada' && est !== 'completada' && (!fecha || fecha >= hoy);
    });
    const enTaller = citasCliente.filter(c => Number(c.id_orden) > 0 && String(c.fecha || '').slice(0, 10) >= hoy);
    if (!activas.length && !enTaller.length) {
        box.innerHTML = '<p>No tienes citas programadas. Elige un servicio y aparta un horario.</p>';
        return;
    }
    const bloqueActivas = activas.map(c => `
        <div class="cita-info" style="margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--borde,#e2e8f0)">
            <h3>${escHtml(c.servicio_nombre || 'Servicio')}</h3>
            <p><strong>Fecha:</strong> ${escHtml(c.fecha || '—')} ${escHtml(c.hora_inicio || '')}</p>
            <p><strong>Vehículo:</strong> ${escHtml(c.vehiculo_label || c.vehiculo_placa || '—')}</p>
            <p><strong>Mecánico:</strong> ${escHtml(c.mecanico_nombre || '—')}</p>
            <p><strong>Estado:</strong> ${escHtml(c.estado_cita)}</p>
            <button type="button" class="btn-detalle btn-cancelar-cita" data-id="${c.id_cita}">Cancelar cita</button>
        </div>
    `).join('');
    const bloqueOt = enTaller.map(c => `
        <div class="cita-info" style="margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--borde,#e2e8f0)">
            <h3>${escHtml(c.servicio_nombre || 'Servicio')}</h3>
            <p>El taller ya recibió el vehículo y abrió la orden <strong>#${escHtml(c.id_orden)}</strong>.</p>
            <p><strong>Vehículo:</strong> ${escHtml(c.vehiculo_label || c.vehiculo_placa || '—')}</p>
            <a class="btn-detalle" href="P_Reparaciones.php">Ver reparación</a>
        </div>
    `).join('');
    box.innerHTML = bloqueActivas + bloqueOt;
}

async function onCitaClienteClick(e) {
    const btn = e.target.closest('.btn-cancelar-cita');
    if (!btn) return;
    const id = parseInt(btn.dataset.id, 10);
    if (!id || !confirm('¿Cancelar esta cita?')) return;
    try {
        await window.apiCitasActualizar(id, { estado_cita: 'Cancelada' });
        mostrarNotificacion('Cita cancelada');
        await cargarDatos();
    } catch (err) {
        mostrarNotificacion(err.message || 'No se pudo cancelar', true);
    }
}

function abrirModalAgendar(idServicio) {
    servicioSeleccionado = serviciosDisponibles.find(s => Number(s.id_servicio) === Number(idServicio));
    if (!servicioSeleccionado) {
        mostrarNotificacion('Servicio no encontrado', true);
        return;
    }
    document.getElementById('agendar-id-servicio').value = servicioSeleccionado.id_servicio;
    document.getElementById('agendar-servicio-nombre').value = `${servicioSeleccionado.nombre} — $${moneda(servicioSeleccionado.precio)}`;
    document.getElementById('agendar-motivo').value = '';
    document.getElementById('agendar-errores').style.display = 'none';
    const selVeh = document.getElementById('agendar-vehiculo');
    if (!vehiculosCliente.length) {
        mostrarNotificacion('Pida en recepción que registren su vehículo antes de agendar.', true);
        return;
    }
    selVeh.innerHTML = vehiculosCliente.map(v =>
        `<option value="${v.id_vehiculo}">${escHtml(v.placa)} — ${escHtml(v.marca || '')} ${escHtml(v.modelo || '')}</option>`
    ).join('');
    const fecha = document.getElementById('agendar-fecha');
    fecha.value = hoyISO();
    cargarHorarios();
    const modal = document.getElementById('modal-agendar');
    modal.style.display = 'flex';
}

function cerrarModalAgendar() {
    const modal = document.getElementById('modal-agendar');
    if (modal) modal.style.display = 'none';
}

async function cargarHorarios() {
    const fecha = document.getElementById('agendar-fecha')?.value;
    const sel = document.getElementById('agendar-horario');
    if (!sel) return;
    if (!fecha) {
        sel.innerHTML = '<option value="">Elija una fecha</option>';
        return;
    }
    sel.innerHTML = '<option value="">Cargando horarios...</option>';
    try {
        const res = await window.apiAgenda({ fecha });
        const slots = unwrap(res);
        if (!slots.length) {
            sel.innerHTML = '<option value="">No hay cupos ese día</option>';
            return;
        }
        sel.innerHTML = '<option value="">Seleccione horario...</option>' + slots.map(h =>
            `<option value="${h.id_horario}">${escHtml(h.hora_inicio)} — ${escHtml(h.mecanico_nombre || 'Mecánico')} (${h.cupos_libres ?? 0} cupos)</option>`
        ).join('');
    } catch (e) {
        sel.innerHTML = `<option value="">${e.message || 'No se pudieron cargar horarios'}</option>`;
    }
}

async function confirmarCita(e) {
    e.preventDefault();
    const box = document.getElementById('agendar-errores');
    const idServicio = parseInt(document.getElementById('agendar-id-servicio').value, 10) || 0;
    const idVehiculo = parseInt(document.getElementById('agendar-vehiculo').value, 10) || 0;
    const idHorario = parseInt(document.getElementById('agendar-horario').value, 10) || 0;
    const motivo = (document.getElementById('agendar-motivo').value || '').trim();
    const errores = [];
    if (!idServicio) errores.push('Seleccione un servicio.');
    if (!idVehiculo) errores.push('Seleccione un vehículo. Si no aparece ninguno, pida en recepción que lo registren.');
    if (!idHorario) errores.push('Seleccione un horario disponible.');
    if (errores.length) {
        box.style.display = 'block';
        box.innerHTML = errores.map(x => `<div>${x}</div>`).join('');
        return;
    }
    try {
        await window.apiCitasCrear({
            id_servicio: idServicio,
            id_vehiculo: idVehiculo,
            id_horario: idHorario,
            motivo
        });
        cerrarModalAgendar();
        mostrarNotificacion('Cita agendada. Te esperamos en el taller.');
        await cargarDatos();
    } catch (err) {
        box.style.display = 'block';
        box.innerHTML = err.message || 'No se pudo agendar la cita';
    }
}

function mostrarNotificacion(mensaje, error = false) {
    const notificacion = document.createElement('div');
    notificacion.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 2000;
        background: ${error ? '#b91c1c' : 'linear-gradient(45deg, #16a34a, #4caf50)'};
        color: white; padding: 1rem 1.5rem; border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15); max-width: 320px;`;
    notificacion.innerHTML = `<i class="fas ${error ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i> ${mensaje}`;
    document.body.appendChild(notificacion);
    setTimeout(() => notificacion.remove(), 3500);
}

window.solicitarServicio = abrirModalAgendar;
