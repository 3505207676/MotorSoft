document.addEventListener('DOMContentLoaded', () => {
    cargarInicio();
    document.querySelector('.btn-refresh')?.addEventListener('click', cargarInicio);
    document.querySelector('.cita-box')?.addEventListener('click', onCitaInicioClick);
});

function unwrap(res) {
    return Array.isArray(res?.data) ? res.data : (res?.data ? [res.data] : []);
}

function hoyISO() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function fmtFechaCorta(iso) {
    const raw = String(iso || '').slice(0, 10);
    if (!raw) return '—';
    const d = new Date(`${raw}T12:00:00`);
    if (Number.isNaN(d.getTime())) return raw;
    const months = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function setKpi(selNumero, valor, selDesc, desc) {
    const n = document.querySelector(selNumero);
    if (n) n.textContent = valor;
    const d = document.querySelector(selDesc);
    if (d) d.textContent = desc;
}

async function cargarInicio() {
    const cli = JSON.parse(localStorage.getItem('motorsoft_cliente') || 'null');
    if (cli?.nombre) {
        const n1 = document.getElementById('nombre-cliente');
        const n2 = document.getElementById('user-name');
        if (n1) n1.textContent = cli.nombre;
        if (n2) n2.textContent = cli.nombre;
    }
    try {
        const [vehRes, ordRes, citasRes, chatRes, facRes] = await Promise.all([
            window.apiVehiculos(true),
            window.apiOrdenes(true),
            window.apiCitas(),
            window.apiChatConversaciones().catch(() => ({ data: { conversaciones: [], no_leidos: 0 } })),
            window.apiFacturas(true).catch(() => ({ data: [] }))
        ]);
        const vehiculos = unwrap(vehRes);
        const ordenes = unwrap(ordRes);
        const citas = unwrap(citasRes);
        const facturas = unwrap(facRes);
        const noLeidos = Number(chatRes.data?.no_leidos || 0);
        const mensajes = unwrap({ data: chatRes.data?.conversaciones?.[0] ? null : [] });
        const msgs = Array.isArray(chatRes.data?.conversaciones)
            ? []
            : [];

        const activas = ordenes.filter(o => !['Completada', 'Cancelada'].includes(o.estado));
        setKpi('.tarjeta-vehiculos .numero, .tarjeta-vehiculos p.numero', String(vehiculos.length), '.tarjeta-vehiculos .descripcion', `${vehiculos.length} vehículo(s) en el sistema`);
        setKpi('.tarjeta-reparacion .numero, .tarjeta-reparacion p.numero', String(activas.length), '.tarjeta-reparacion .descripcion', `${activas.length} orden(es) en curso`);
        setKpi('.tarjeta-mensajes .numero, .tarjeta-mensajes p.numero', String(noLeidos), '.tarjeta-mensajes .descripcion', `${noLeidos} mensaje(s) sin leer`);

        const ultima = ordenes[0];
        const visita = document.querySelector('.tarjeta-visita .fecha');
        const visitaDesc = document.querySelector('.tarjeta-visita .descripcion');
        if (visita) visita.textContent = ultima ? fmtFechaCorta(ultima.fecha_ingreso) : 'Sin visitas';
        if (visitaDesc) visitaDesc.textContent = ultima ? (ultima.estado || '') : 'Aún no hay órdenes';

        pintarProximaCita(citas);
        pintarEstadoVehiculo(activas, vehiculos);
        await pintarMensajesRecientes();
        pintarAlertas(vehiculos, activas);
        pintarResumen(ordenes, facturas);
        window.actualizarBadgeMensajes?.(noLeidos);
    } catch (e) {
        console.warn(e);
    }
}

function pintarProximaCita(citas) {
    const hoy = hoyISO();
    const siguiente = (citas || [])
        .filter(c => {
            const est = String(c.estado_cita || '').toLowerCase();
            return est !== 'cancelada' && est !== 'completada' && (c.fecha || '') >= hoy;
        })
        .sort((a, b) => String(a.fecha + a.hora_inicio).localeCompare(String(b.fecha + b.hora_inicio)))[0];
    const badge = document.querySelector('.proxima-cita .status-badge');
    const box = document.querySelector('.cita-box');
    if (!box) return;
    if (!siguiente) {
        if (badge) {
            badge.textContent = 'Sin cita';
            badge.className = 'status-badge';
        }
        box.innerHTML = '<div class="empty-state"><p>No tienes una cita programada.</p><a href="P_Servicios.php" class="btn-detalle">Agendar un servicio</a></div>';
        return;
    }
    if (badge) {
        badge.textContent = siguiente.estado_cita || 'Programada';
        badge.className = 'status-badge status-confirmada';
    }
    box.innerHTML = `
        <div class="info-grid">
            <div class="info-item"><span class="info-label">Servicio</span><span class="info-value">${siguiente.servicio_nombre || '—'}</span></div>
            <div class="info-item"><span class="info-label">Fecha</span><span class="info-value">${fmtFechaCorta(siguiente.fecha)} · ${siguiente.hora_inicio || ''}</span></div>
            <div class="info-item"><span class="info-label">Vehículo</span><span class="info-value">${siguiente.vehiculo_label || siguiente.vehiculo_placa || '—'}</span></div>
            <div class="info-item"><span class="info-label">Mecánico</span><span class="info-value">${siguiente.mecanico_nombre || '—'}</span></div>
        </div>
        <div class="form-actions">
            <a href="P_Servicios.php" class="btn-detalle">Ver en Servicios</a>
            <button type="button" class="btn-detalle btn-cancelar-cita" data-id="${siguiente.id_cita}">Cancelar cita</button>
        </div>
    `;
}

async function onCitaInicioClick(e) {
    const btn = e.target.closest('.btn-cancelar-cita');
    if (!btn) return;
    const id = parseInt(btn.dataset.id, 10);
    if (!id || !confirm('¿Cancelar esta cita?')) return;
    try {
        await window.apiCitasActualizar(id, { estado_cita: 'Cancelada' });
        await cargarInicio();
    } catch (err) {
        alert(err.message || 'No se pudo cancelar la cita');
    }
}

function pintarEstadoVehiculo(activas, vehiculos) {
    const box = document.querySelector('.estado-box');
    if (!box) return;
    const ot = activas[0];
    if (!ot) {
        box.innerHTML = '<div class="empty-state"><p>No tienes vehículos en reparación actualmente.</p><a href="P_Servicios.php" class="btn-detalle">Solicitar un servicio</a></div>';
        return;
    }
    box.innerHTML = `
        <div class="info-grid">
            <div class="info-item"><span class="info-label">Vehículo</span><span class="info-value">${ot.vehiculo_label || ot.placa || '—'}</span></div>
            <div class="info-item"><span class="info-label">Placa</span><span class="info-value">${ot.placa || '—'}</span></div>
            <div class="info-item"><span class="info-label">Estado</span><span class="info-value">${ot.estado}</span></div>
        </div>
        <div class="form-actions"><a href="P_Reparaciones.php${ot.placa ? '?placa=' + encodeURIComponent(ot.placa) : (ot.id_orden ? '?orden=' + encodeURIComponent(ot.id_orden) : '')}" class="btn-detalle">Ver orden</a></div>
    `;
}

async function pintarMensajesRecientes() {
    const lista = document.querySelector('.mensajes-recientes ul');
    if (!lista) return;
    try {
        const res = await window.apiChatObtener();
        const msgs = Array.isArray(res.data) ? res.data.slice(-3).reverse() : [];
        if (!msgs.length) {
            lista.innerHTML = '<li>No hay mensajes recientes.</li>';
            return;
        }
        lista.innerHTML = msgs.map(m => `<li><strong>${m.emisor_nombre || 'Taller'}:</strong> ${m.contenido} <span class="fecha">${(m.fecha_hora || '').slice(0, 16)}</span></li>`).join('');
    } catch (e) {
        lista.innerHTML = '<li>No se pudieron cargar los mensajes.</li>';
    }
}

function pintarAlertas(vehiculos, activas) {
    const section = document.querySelector('.alertas');
    if (!section) return;
    if (!activas.length) {
        section.hidden = true;
        return;
    }
    section.hidden = false;
    section.innerHTML = `<h2><i class="fas fa-exclamation-triangle"></i> Recomendaciones</h2>
        <p>Tienes ${activas.length} orden(es) en el taller. Revisa el detalle en Reparaciones.</p>`;
}

function pintarResumen(ordenes, facturas) {
    const stats = document.querySelectorAll('.grafico-stats .stat-number');
    if (stats[0]) stats[0].textContent = String(ordenes.length);
    if (stats[1]) {
        const total = facturas.filter(f => String(f.estado).toLowerCase() === 'pagada')
            .reduce((s, f) => s + Number(f.total || 0), 0);
        stats[1].textContent = total.toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
    }
    const labels = document.querySelectorAll('.grafico-stats .stat-label');
    if (labels[0]) labels[0].textContent = 'Órdenes registradas';
    if (labels[1]) labels[1].textContent = 'Total facturado';
}
