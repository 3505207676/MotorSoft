document.addEventListener('DOMContentLoaded', () => {
    const contenedor = document.querySelector('.reparaciones-en-curso');
    const histTarjetas = document.getElementById('vista-tarjetas-historial');
    const histTbody = document.querySelector('#vista-tabla-historial tbody');

    document.getElementById('btn-vista-tarjetas-historial')?.addEventListener('click', () => cambiar('tarjetas'));
    document.getElementById('btn-vista-tabla-historial')?.addEventListener('click', () => cambiar('tabla'));

    function cambiar(tipo) {
        localStorage.setItem('vistaHistorialPreferida', tipo);
        const tarjetas = document.getElementById('vista-tarjetas-historial');
        const tabla = document.getElementById('vista-tabla-historial');
        if (tipo === 'tarjetas') {
            tarjetas.style.display = 'grid';
            tabla.style.display = 'none';
            document.getElementById('btn-vista-tarjetas-historial')?.classList.add('activo');
            document.getElementById('btn-vista-tabla-historial')?.classList.remove('activo');
        } else {
            tarjetas.style.display = 'none';
            tabla.style.display = 'block';
            document.getElementById('btn-vista-tarjetas-historial')?.classList.remove('activo');
            document.getElementById('btn-vista-tabla-historial')?.classList.add('activo');
        }
    }

    function idOrden(o) {
        return o.id_orden || o.id;
    }

    function servicios(o) {
        return (o.detalles || []).map(d => d.servicio?.nombre || 'Servicio').join(', ') || (o.descripcion || '—');
    }

    function galeria(o) {
        const lista = o.adjuntos || [];
        if (typeof window.htmlGaleriaEvidencias === 'function') {
            return window.htmlGaleriaEvidencias(lista, 'Aún no hay fotos de esta reparación.');
        }
        return lista.length
            ? `<p>${lista.length} archivo(s)</p>`
            : '<p class="evidencias-vacio">Aún no hay fotos de esta reparación.</p>';
    }

    function card(o) {
        return `<article class="reparacion-card">
            <div class="card-top">
                <div class="tarjeta-icon"><i class="fas fa-tools"></i></div>
                <div>
                    <h3>${o.vehiculo_label || o.placa || 'Vehículo'}</h3>
                    <p class="card-sub">${o.placa || 'Sin placa'}</p>
                </div>
                <span class="status-badge">${o.estado || '—'}</span>
            </div>
            <div class="info-grid">
                <div class="info-item"><span class="info-label">Servicio</span><span class="info-value">${servicios(o)}</span></div>
                <div class="info-item"><span class="info-label">Ingreso</span><span class="info-value">${String(o.fecha_ingreso || '').slice(0, 10) || '—'}</span></div>
            </div>
            <div class="evidencias-bloque">
                <span class="info-label">Evidencias</span>
                ${galeria(o)}
            </div>
        </article>`;
    }

    async function conAdjuntos(ordenes) {
        return Promise.all(ordenes.map(async o => {
            try {
                const r = await window.apiAdjuntos({ entidad_tipo: 'orden', entidad_id: idOrden(o) });
                return { ...o, adjuntos: Array.isArray(r.data) ? r.data : [] };
            } catch (e) {
                return { ...o, adjuntos: [] };
            }
        }));
    }

    const placaFiltro = String(new URLSearchParams(window.location.search).get('placa') || '').trim().toUpperCase();
    const ordenFiltro = String(new URLSearchParams(window.location.search).get('orden') || '').trim();

    function dePlaca(lista) {
        let out = lista;
        if (placaFiltro) {
            out = out.filter(o => String(o.placa || '').trim().toUpperCase() === placaFiltro);
        }
        if (ordenFiltro) {
            out = out.filter(o => String(o.id_orden || o.id) === ordenFiltro);
        }
        return out;
    }

    window.apiOrdenes(true).then(async res => {
        const ordenes = Array.isArray(res.data) ? res.data : [];
        const conFotos = await conAdjuntos(ordenes);
        const enCurso = dePlaca(conFotos.filter(o => !['Completada', 'Cancelada'].includes(o.estado)));
        const historial = dePlaca(conFotos.filter(o => ['Completada', 'Cancelada'].includes(o.estado)));
        const vacioCurso = placaFiltro
            ? `<p>No hay reparaciones en curso para ${placaFiltro}.</p>`
            : '<p>No hay reparaciones en curso.</p>';
        const vacioHist = placaFiltro
            ? `<p>Sin historial para ${placaFiltro}.</p>`
            : '<p>Sin historial.</p>';
        if (contenedor) contenedor.innerHTML = enCurso.length ? enCurso.map(card).join('') : vacioCurso;
        if (histTarjetas) histTarjetas.innerHTML = historial.length ? historial.map(card).join('') : vacioHist;
        if (histTbody) {
            histTbody.innerHTML = historial.length
                ? historial.map(o => `<tr>
                    <td>${o.vehiculo_label || '—'}</td>
                    <td>${o.placa || '—'}</td>
                    <td>${servicios(o)}</td>
                    <td>${String(o.fecha_ingreso || '').slice(0, 10)}</td>
                    <td>${o.estado}</td>
                    <td>${(o.adjuntos || []).length ? (o.adjuntos.length + ' archivo(s)') : 'Sin evidencias'}</td>
                </tr>`).join('')
                : `<tr><td colspan="6">${placaFiltro ? 'Sin historial para ' + placaFiltro : 'Sin historial.'}</td></tr>`;
        }
        cambiar(localStorage.getItem('vistaHistorialPreferida') || 'tarjetas');
    }).catch(e => {
        if (contenedor) contenedor.innerHTML = `<p>${e.message || 'No se pudieron cargar las órdenes'}</p>`;
    });
});
