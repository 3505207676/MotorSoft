/**
 * Perfil del cliente: datos reales, foto, tema y avisos.
 */
document.addEventListener('DOMContentLoaded', function () {
    const formProfile = document.getElementById('form-profile');
    const btnEditProfile = document.getElementById('btn-edit-profile');
    const btnCancelEdit = document.getElementById('btn-cancel-edit');
    const btnSaveProfile = document.getElementById('btn-save-profile');
    const btnChangeAvatar = document.getElementById('btn-change-avatar');
    const inputAvatar = document.getElementById('input-avatar');
    const darkThemeToggle = document.getElementById('dark-theme');
    const avisosToggle = document.getElementById('pref-avisos');

    const inputNombre = document.getElementById('nombre');
    const inputDocumento = document.getElementById('documento');
    const inputTelefono = document.getElementById('telefono');
    const inputEmail = document.getElementById('email');
    const inputPreferencia = document.getElementById('preferencia_contacto');
    const inputFechaRegistro = document.getElementById('fecha_registro');
    const errorTelefono = document.getElementById('error-telefono');
    const errorEmail = document.getElementById('error-email');

    let userData = {};
    let clienteId = 0;

    initProfile();

    function claveAvisos() {
        return 'motorsoft_cli_avisos';
    }

    function initProfile() {
        loadUserData();
        loadVehicles();
        setupEventListeners();
        if (darkThemeToggle) {
            darkThemeToggle.checked = document.documentElement.getAttribute('data-theme') === 'dark';
        }
        if (avisosToggle) {
            avisosToggle.checked = localStorage.getItem(claveAvisos()) !== '0';
        }
    }

    function loadVehicles() {
        const box = document.getElementById('perfil-vehiculos');
        if (!box || typeof window.apiVehiculos !== 'function') return;
        window.apiVehiculos(true).then(res => {
            const list = Array.isArray(res.data) ? res.data : [];
            if (!list.length) {
                box.innerHTML = '<p>No hay vehículos registrados.</p>';
                return;
            }
            box.innerHTML = list.map(v => {
                const titulo = [v.marca, v.modelo, v.anio || v.año].filter(Boolean).join(' ') || 'Vehículo';
                return '<div class="vehicle-item"><div class="vehicle-icon"><i class="fas fa-car"></i></div>' +
                    '<div class="vehicle-info"><h4>' + titulo + '</h4><p>Placa: ' + (v.placa || '—') + '</p></div></div>';
            }).join('');
        }).catch(() => {
            box.innerHTML = '<p>No se pudieron cargar los vehículos.</p>';
        });
    }

    function loadUserData() {
        const cached = JSON.parse(localStorage.getItem('motorsoft_cliente') || '{}');
        pintarCliente(cached);
        window.apiClientes(true).then(res => {
            const c = res.data && !Array.isArray(res.data) ? res.data : (Array.isArray(res.data) ? res.data[0] : null);
            if (!c) return;
            pintarCliente(c);
            localStorage.setItem('motorsoft_cliente', JSON.stringify(c));
        }).catch(() => {});
    }

    function pintarAvatar(c) {
        const av = document.getElementById('perfil-avatar');
        const menu = document.getElementById('menu-avatar');
        const id = c?.avatar?.id_adjunto;
        const url = id && typeof window.urlAdjunto === 'function' ? window.urlAdjunto(id) : '';
        const iniciales = String(c?.nombre || 'C').split(/\s+/).slice(0, 2).map(p => p.charAt(0).toUpperCase()).join('') || 'C';
        [av, menu].forEach(el => {
            if (!el) return;
            if (url) {
                el.innerHTML = '<img src="' + url + '" alt="">';
                el.classList.add('has-photo');
            } else {
                el.textContent = iniciales;
                el.classList.remove('has-photo');
            }
        });
    }

    function pintarCliente(c) {
        if (!c) return;
        clienteId = Number(c.id_cliente || c.id || 0);
        if (inputNombre) inputNombre.value = c.nombre || '';
        if (inputDocumento) inputDocumento.value = c.documento || '';
        if (inputTelefono) inputTelefono.value = c.telefono || '';
        if (inputEmail) inputEmail.value = c.email || '';
        if (inputPreferencia) {
            const pref = c.preferencia_contacto || 'WhatsApp';
            inputPreferencia.value = ['WhatsApp', 'Llamada', 'Email'].includes(pref) ? pref : 'WhatsApp';
        }
        if (inputFechaRegistro) inputFechaRegistro.value = (c.created_at || '').slice(0, 10);
        const titulo = document.getElementById('perfil-nombre');
        if (titulo) titulo.textContent = c.nombre || 'Cliente';
        const userNameElement = document.getElementById('user-name');
        if (userNameElement) userNameElement.textContent = c.nombre || 'Cliente';
        const menuName = document.getElementById('menu-user-name');
        if (menuName) menuName.textContent = c.nombre || 'Cliente';
        pintarAvatar(c);
        userData = {
            telefono: inputTelefono.value,
            email: inputEmail.value,
            preferencia_contacto: inputPreferencia ? inputPreferencia.value : ''
        };
    }

    function setupEventListeners() {
        btnEditProfile?.addEventListener('click', enableProfileEditing);
        btnCancelEdit?.addEventListener('click', cancelProfileEditing);
        formProfile?.addEventListener('submit', saveProfileChanges);
        btnChangeAvatar?.addEventListener('click', () => inputAvatar?.click());
        inputAvatar?.addEventListener('change', subirAvatar);
        darkThemeToggle?.addEventListener('change', toggleDarkTheme);
        avisosToggle?.addEventListener('change', guardarAvisos);
        inputTelefono?.addEventListener('input', validatePhone);
        inputEmail?.addEventListener('input', validateEmail);
    }

    function enableProfileEditing() {
        userData = {
            telefono: inputTelefono.value,
            email: inputEmail.value,
            preferencia_contacto: inputPreferencia.value
        };
        inputTelefono.disabled = false;
        inputEmail.disabled = false;
        inputPreferencia.disabled = false;
        btnCancelEdit.style.display = 'inline-flex';
        btnSaveProfile.style.display = 'inline-flex';
        btnEditProfile.style.display = 'none';
        inputTelefono.focus();
        showToast('info', 'Modo edición', 'Puede cambiar teléfono, correo y forma de contacto');
    }

    function cancelProfileEditing() {
        inputTelefono.value = userData.telefono;
        inputEmail.value = userData.email;
        inputPreferencia.value = userData.preferencia_contacto;
        inputTelefono.disabled = true;
        inputEmail.disabled = true;
        inputPreferencia.disabled = true;
        btnCancelEdit.style.display = 'none';
        btnSaveProfile.style.display = 'none';
        btnEditProfile.style.display = 'inline-flex';
        errorTelefono.textContent = '';
        errorEmail.textContent = '';
        showToast('info', 'Edición cancelada', 'No se guardaron cambios');
    }

    async function saveProfileChanges(e) {
        e.preventDefault();
        if (!validatePhone() || !validateEmail()) {
            showToast('error', 'Revise los datos', 'Corrija el teléfono o el correo');
            return;
        }
        try {
            const res = await window.apiClientesActualizar(0, {
                telefono: inputTelefono.value,
                email: inputEmail.value,
                preferencia_contacto: inputPreferencia.value
            });
            const c = res.data || {};
            pintarCliente(c);
            localStorage.setItem('motorsoft_cliente', JSON.stringify(c));
            inputTelefono.disabled = true;
            inputEmail.disabled = true;
            inputPreferencia.disabled = true;
            btnCancelEdit.style.display = 'none';
            btnSaveProfile.style.display = 'none';
            btnEditProfile.style.display = 'inline-flex';
            showToast('success', 'Perfil actualizado', 'Sus datos quedaron guardados');
        } catch (err) {
            showToast('error', 'Error', err.message || 'No se pudo guardar');
        }
    }

    async function subirAvatar() {
        const file = inputAvatar?.files?.[0];
        if (!file) return;
        if (file.size > 5 * 1024 * 1024) {
            showToast('error', 'Archivo grande', 'La foto no puede superar 5 MB');
            inputAvatar.value = '';
            return;
        }
        try {
            btnChangeAvatar.disabled = true;
            const res = await window.apiAdjuntoSubir(file, 'cliente', clienteId || 0);
            const adj = res.data || {};
            const cached = JSON.parse(localStorage.getItem('motorsoft_cliente') || '{}');
            cached.avatar = adj;
            localStorage.setItem('motorsoft_cliente', JSON.stringify(cached));
            pintarAvatar(cached);
            showToast('success', 'Foto actualizada', 'Su foto de perfil ya está visible');
        } catch (err) {
            showToast('error', 'No se subió', err.message || 'Intente con JPG o PNG');
        } finally {
            btnChangeAvatar.disabled = false;
            inputAvatar.value = '';
        }
    }

    function toggleDarkTheme() {
        const nuevo = darkThemeToggle.checked ? 'dark' : 'light';
        if (window.MotorSoftTema) window.MotorSoftTema.aplicar(nuevo);
        else if (typeof aplicarTema === 'function') aplicarTema(nuevo);
        showToast('success', 'Tema', nuevo === 'dark' ? 'Tema oscuro activado' : 'Tema claro activado');
    }

    function guardarAvisos() {
        localStorage.setItem(claveAvisos(), avisosToggle.checked ? '1' : '0');
        window.aplicarPreferenciaAvisosCliente?.();
        showToast('success', 'Avisos', avisosToggle.checked
            ? 'Verá el número de mensajes nuevos en el menú'
            : 'Se ocultaron los avisos de mensajes en el menú');
    }

    function validatePhone() {
        const phone = inputTelefono.value.trim();
        if (!phone) {
            errorTelefono.textContent = 'El teléfono es obligatorio';
            return false;
        }
        if (!/^3[0-9]{9}$/.test(phone)) {
            errorTelefono.textContent = 'Celular colombiano de 10 dígitos que empiece en 3';
            return false;
        }
        errorTelefono.textContent = '';
        return true;
    }

    function validateEmail() {
        const email = inputEmail.value.trim();
        if (!email) {
            errorEmail.textContent = 'El correo es obligatorio';
            return false;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            errorEmail.textContent = 'Ingrese un correo válido';
            return false;
        }
        errorEmail.textContent = '';
        return true;
    }

    function showToast(type, title, message) {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) return;
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle', warning: 'fa-exclamation-triangle' };
        toast.innerHTML = `<div class="toast-icon"><i class="fas ${icons[type] || icons.info}"></i></div>
            <div class="toast-content"><div class="toast-title">${title}</div><div class="toast-message">${message}</div></div>
            <button class="toast-close" type="button"><i class="fas fa-times"></i></button>`;
        toastContainer.appendChild(toast);
        toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());
        setTimeout(() => toast.remove(), 3000);
    }
});
