// Archivo: main.js - Funcionalidades comunes para todas las páginas de la plataforma de usuario

document.addEventListener('DOMContentLoaded', () => {
    inicializarUsuario();
    inicializarSidebar();
    inicializarMenuCliente();
    inicializarFecha();
    inicializarLogout();
    cargarBadgeMensajesCliente();
});

function aplicarTema(tema) {
    if (window.MotorSoftTema) return window.MotorSoftTema.aplicar(tema);
    const valor = tema === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', valor);
    if (document.body) {
        document.body.setAttribute('data-theme', valor);
        document.body.classList.toggle('dark-theme', valor === 'dark');
    }
    localStorage.setItem('tema', valor);
}

// Función para inicializar la barra lateral
function inicializarSidebar() {
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const contenido = document.querySelector('.contenido');
    
    // Cargar estado guardado de la barra lateral
    const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (sidebarCollapsed) {
        sidebar?.classList.add('collapsed');
        contenido?.classList.add('expanded');
    }
    
    // Agregar evento para colapsar/expandir la barra lateral
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            contenido.classList.toggle('expanded');
            
            // Guardar estado
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem('sidebarCollapsed', isCollapsed);
        });
    }
}

// Función para inicializar la fecha actual
function inicializarFecha() {
    const fechaElement = document.getElementById('fecha-actual');
    if (fechaElement) {
        const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const fechaActual = new Date().toLocaleDateString('es-ES', opciones);
        fechaElement.textContent = fechaActual.charAt(0).toUpperCase() + fechaActual.slice(1);
    }
}

function clienteActual() {
    try {
        return JSON.parse(localStorage.getItem('motorsoft_cliente') || 'null');
    } catch (e) {
        return null;
    }
}

function inicialesDe(nombre) {
    return String(nombre || 'C')
        .split(/\s+/)
        .slice(0, 2)
        .map(p => p.charAt(0).toUpperCase())
        .join('') || 'C';
}

function pintarMenuUsuario(nombreUsuario) {
    const nameEl = document.getElementById('menu-user-name');
    const av = document.getElementById('menu-avatar');
    if (nameEl) nameEl.textContent = nombreUsuario;
    if (!av) return;
    const cliente = clienteActual();
    const id = cliente?.avatar?.id_adjunto;
    if (id && typeof window.urlAdjunto === 'function') {
        av.innerHTML = '<img src="' + window.urlAdjunto(id) + '" alt="">';
        av.classList.add('has-photo');
        return;
    }
    av.textContent = inicialesDe(nombreUsuario);
    av.classList.remove('has-photo');
}

function avisosClienteActivos() {
    return localStorage.getItem('motorsoft_cli_avisos') !== '0';
}

function aplicarPreferenciaAvisosCliente() {
    if (avisosClienteActivos()) return;
    document.querySelectorAll('.notification-badge').forEach(el => {
        el.hidden = true;
        el.style.display = 'none';
    });
}

function inicializarUsuario() {
    const cliente = clienteActual();
    const nombreUsuario = cliente?.nombre || localStorage.getItem('nombreUsuario') || 'Cliente';

    if (!document.title.includes('|')) {
        document.title = `${document.title} | ${nombreUsuario}`;
    }

    const userNameElement = document.getElementById('user-name');
    if (userNameElement) userNameElement.textContent = nombreUsuario;

    const nombreClienteElement = document.getElementById('nombre-cliente');
    if (nombreClienteElement) nombreClienteElement.textContent = nombreUsuario;

    pintarMenuUsuario(nombreUsuario);
}

function drawer() {
    return document.getElementById('menu-drawer');
}

function overlayMenu() {
    return document.getElementById('menu-overlay');
}

function menuAbierto() {
    return !!drawer()?.classList.contains('is-open');
}

function esEscritorioCliente() {
    return window.matchMedia('(min-width: 1024px)').matches;
}

function sincronizarShellCliente() {
    if (!esEscritorioCliente()) return;
    cerrarMenuCliente();
    drawer()?.setAttribute('aria-hidden', 'false');
}

function abrirMenuCliente() {
    if (esEscritorioCliente()) return;
    const panel = drawer();
    const fondo = overlayMenu();
    const btn = document.getElementById('btn-menu');
    if (!panel) return;
    pintarMenuUsuario(document.getElementById('menu-user-name')?.textContent || clienteActual()?.nombre || 'Cliente');
    panel.classList.add('is-open');
    panel.setAttribute('aria-hidden', 'false');
    if (fondo) {
        fondo.hidden = false;
        fondo.classList.add('is-open');
    }
    if (btn) btn.setAttribute('aria-expanded', 'true');
    document.body.classList.add('menu-open');
}

function cerrarMenuCliente() {
    const panel = drawer();
    const fondo = overlayMenu();
    const btn = document.getElementById('btn-menu');
    if (panel) {
        panel.classList.remove('is-open');
        panel.setAttribute('aria-hidden', 'true');
    }
    if (fondo) {
        fondo.classList.remove('is-open');
        fondo.hidden = true;
    }
    if (btn) btn.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
}

function inicializarMenuCliente() {
    const btn = document.getElementById('btn-menu');
    const cerrar = document.getElementById('btn-cerrar-menu');
    const fondo = overlayMenu();
    const salir = document.getElementById('btn-cerrar-sesion');
    btn?.addEventListener('click', () => (menuAbierto() ? cerrarMenuCliente() : abrirMenuCliente()));
    cerrar?.addEventListener('click', cerrarMenuCliente);
    fondo?.addEventListener('click', cerrarMenuCliente);
    salir?.addEventListener('click', cerrarSesionCliente);
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && menuAbierto()) cerrarMenuCliente();
    });
    sincronizarShellCliente();
    window.matchMedia('(min-width: 1024px)').addEventListener('change', sincronizarShellCliente);
}

async function cerrarSesionCliente() {
    if (!window.confirm('¿Cerrar sesión?')) return;
    cerrarMenuCliente();
    try {
        if (typeof window.apiLogout === 'function') {
            await window.apiLogout();
        }
    } catch (err) {
        localStorage.removeItem('motorsoft_token');
        localStorage.removeItem('motorsoft_usuario');
        localStorage.removeItem('motorsoft_sesion');
        localStorage.removeItem('motorsoft_cliente');
    }
    if (window.MotorSoftGuard?.limpiar) window.MotorSoftGuard.limpiar();
    window.location.replace('../auth/login.php');
}

function inicializarLogout() {
    document.querySelectorAll('a.logout').forEach(link => {
        link.addEventListener('click', async (e) => {
            e.preventDefault();
            await cerrarSesionCliente();
        });
    });
}

// Función para inicializar animaciones
function inicializarAnimaciones() {
    // Animación para la barra superior
    const topbar = document.querySelector('.topbar');
    if (topbar) {
        topbar.classList.add('animated', 'fadeInDown');
    }
    
    // Animación para la barra lateral
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.add('animated', 'slideInLeft');
    }
    
    // Animación para el contenido principal
    const contenido = document.querySelector('.contenido');
    if (contenido) {
        contenido.classList.add('animated', 'fadeIn');
    }
    
    // Animación para las tarjetas con efecto escalonado
    const tarjetas = document.querySelectorAll('.tarjeta, .card');
    if (tarjetas.length > 0) {
        tarjetas.forEach((tarjeta, index) => {
            setTimeout(() => {
                tarjeta.classList.add('animated', 'fadeInUp');
            }, 100 * index);
        });
    }
}

function actualizarBadgeMensajes(n) {
    if (!avisosClienteActivos()) {
        aplicarPreferenciaAvisosCliente();
        return;
    }
    const valor = Number(n || 0);
    document.querySelectorAll('.notification-badge').forEach(el => {
        el.textContent = String(valor);
        el.hidden = valor <= 0;
        if (valor <= 0) el.style.display = 'none';
        else el.style.display = '';
    });
}

async function cargarBadgeMensajesCliente() {
    if (typeof window.apiChatConversaciones !== 'function') return;
    try {
        const res = await window.apiChatConversaciones();
        actualizarBadgeMensajes(res.data?.no_leidos || 0);
    } catch (e) {
        actualizarBadgeMensajes(0);
    }
}

window.actualizarBadgeMensajes = actualizarBadgeMensajes;
window.cargarBadgeMensajesCliente = cargarBadgeMensajesCliente;
window.aplicarPreferenciaAvisosCliente = aplicarPreferenciaAvisosCliente;
