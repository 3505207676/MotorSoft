let facturasDisponibles = [];
let facturasFiltradas = [];

document.addEventListener('DOMContentLoaded', async function () {
  configurarEventos();
  try {
    const res = await window.apiFacturas(true);
    facturasDisponibles = (Array.isArray(res.data) ? res.data : []).map(mapFactura);
  } catch (e) {
    mostrarNotificacionUI(e.message || 'No se pudieron cargar las facturas', 'error');
    facturasDisponibles = [];
  }
  filtrarFacturas();
});

function mapFactura(f) {
  const items = (f.detalles || []).map(d => ({
    descripcion: d.descripcion || d.nombre || d.producto || 'Ítem',
    cantidad: Number(d.cantidad || 1),
    precio: Number(d.precio_unitario ?? d.precio ?? d.subtotal ?? 0)
  }));
  const placa = f.vehiculo_placa || f.vehiculo?.placa || f.vehiculo?.vehiculo_label || '';
  return {
    id: f.id_factura,
    numero: f.numero,
    fecha: (f.fecha_emision || '').slice(0, 10),
    vehiculo: placa || '—',
    concepto: f.tipo_factura || 'Factura',
    total: Number(f.total || 0),
    estado: String(f.estado || '').toLowerCase(),
    detalle: {
      cliente: f.cliente || f.cliente_obj?.nombre || '',
      nit: f.cliente_obj?.documento || '',
      direccion: '',
      items,
      notas: ''
    },
    raw: f
  };
}

function configurarEventos() {
  document.getElementById('buscar-factura')?.addEventListener('input', filtrarFacturas);
  document.getElementById('filtro-estado')?.addEventListener('change', filtrarFacturas);
  document.getElementById('filtro-fecha')?.addEventListener('change', filtrarFacturas);
  document.getElementById('btn-cerrar')?.addEventListener('click', cerrarModalFactura);
  document.getElementById('cerrar-modal-factura')?.addEventListener('click', cerrarModalFactura);
  window.addEventListener('click', (e) => {
    if (e.target.classList && e.target.classList.contains('modal')) cerrarModalFactura();
  });
}

function filtrarFacturas() {
  const texto = (document.getElementById('buscar-factura')?.value || '').toLowerCase();
  const estado = document.getElementById('filtro-estado')?.value || '';
  const tiempo = document.getElementById('filtro-fecha')?.value || '';
  const hoy = new Date();
  facturasFiltradas = facturasDisponibles.filter((f) => {
    const coincideTexto = (f.numero || '').toLowerCase().includes(texto) || (f.concepto || '').toLowerCase().includes(texto);
    const coincideEstado = !estado || f.estado === estado.toLowerCase();
    let coincideFecha = true;
    if (tiempo && f.fecha) {
      const fecha = new Date(f.fecha);
      if (tiempo === 'mes') coincideFecha = fecha.getMonth() === hoy.getMonth() && fecha.getFullYear() === hoy.getFullYear();
      else if (tiempo === 'anio') coincideFecha = fecha.getFullYear() === hoy.getFullYear();
    }
    return coincideTexto && coincideEstado && coincideFecha;
  });
  renderTablaFacturas();
}

function renderTablaFacturas() {
  const tbody = document.getElementById('tbody-facturas');
  if (!tbody) return;
  if (!facturasFiltradas.length) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:1.5rem;">No se encontraron facturas</td></tr>`;
    return;
  }
  tbody.innerHTML = facturasFiltradas.map((f) => {
    const estadoClase = f.estado === 'pagada' ? 'estado-pagada' : f.estado === 'pendiente' ? 'estado-pendiente' : 'estado-anulada';
    return `<tr>
      <td>${f.numero}</td>
      <td>${formatearFechaCorta(f.fecha)}</td>
      <td>${f.vehiculo}</td>
      <td>${f.concepto}</td>
      <td>${formatearCOP(f.total)}</td>
      <td><span class="estado-badge ${estadoClase}">${capitalizar(f.estado)}</span></td>
      <td><button class="btn-accion-factura" onclick="previsualizarFactura('${f.numero}')"><i class="fas fa-eye"></i></button></td>
    </tr>`;
  }).join('');
}

function previsualizarFactura(numero) {
  const factura = facturasDisponibles.find((x) => x.numero === numero);
  if (!factura) return;
  document.getElementById('modal-numero').textContent = factura.numero;
  document.getElementById('modal-fecha').textContent = formatearFechaLarga(factura.fecha);
  document.getElementById('modal-estado').textContent = capitalizar(factura.estado);
  document.getElementById('modal-contenido-factura').innerHTML = construirContenidoFactura(factura);
  const modal = document.getElementById('modal-ver-factura');
  modal.classList.remove('oculto');
  modal.style.display = 'flex';
  const btnDescargar = document.getElementById('btn-descargar-pdf');
  if (btnDescargar) {
    btnDescargar.onclick = async () => {
      try {
        await window.apiFacturaPdf(factura.id);
      } catch (e) {
        mostrarNotificacionUI(e.message || 'No se pudo descargar el PDF');
      }
    };
  }
}

function cerrarModalFactura() {
  const modal = document.getElementById('modal-ver-factura');
  if (!modal) return;
  modal.classList.add('oculto');
  modal.style.display = 'none';
}

function construirContenidoFactura(f) {
  const items = f.detalle.items.length ? f.detalle.items : [{ descripcion: f.concepto, cantidad: 1, precio: f.total }];
  const filas = items.map(it => `<tr>
    <td>${it.descripcion}</td>
    <td style="text-align:center;">${it.cantidad}</td>
    <td style="text-align:right;">${formatearCOP(it.precio)}</td>
    <td style="text-align:right;">${formatearCOP(it.precio * it.cantidad)}</td>
  </tr>`).join('');
  return `
    <div class="fila">
      <div><strong>Cliente:</strong> ${f.detalle.cliente}<br/><strong>Documento:</strong> ${f.detalle.nit}</div>
      <div><strong>Tipo:</strong> ${f.concepto}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;background:white;">
      <thead><tr style="background:#eee;"><th>Descripción</th><th>Cant.</th><th>Precio</th><th>Subtotal</th></tr></thead>
      <tbody>${filas}</tbody>
    </table>
    <div style="text-align:right;margin-top:1rem;">
      <div><strong>Subtotal:</strong> ${formatearCOP(f.raw?.subtotal ?? f.total)}</div>
      <div><strong>IVA:</strong> ${formatearCOP(f.raw?.IVA ?? f.raw?.iva ?? 0)}</div>
      <div><strong>Total:</strong> ${formatearCOP(f.total)}</div>
    </div>`;
}

function formatearCOP(valor) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor || 0);
}
function formatearFechaCorta(fechaStr) {
  if (!fechaStr) return '—';
  const d = new Date(fechaStr);
  if (Number.isNaN(d.getTime())) return fechaStr;
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}
function formatearFechaLarga(fechaStr) {
  if (!fechaStr) return '—';
  const d = new Date(fechaStr);
  if (Number.isNaN(d.getTime())) return fechaStr;
  return d.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
}
function capitalizar(txt) {
  return String(txt || '').charAt(0).toUpperCase() + String(txt || '').slice(1);
}
function mostrarNotificacionUI(mensaje) {
  const n = document.createElement('div');
  n.className = 'notificacion-exito';
  n.textContent = mensaje;
  document.body.appendChild(n);
  setTimeout(() => n.remove(), 2500);
}
window.previsualizarFactura = previsualizarFactura;
