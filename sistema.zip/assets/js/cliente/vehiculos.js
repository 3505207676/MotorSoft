document.addEventListener('DOMContentLoaded', () => {
    const btnVistaTarjetas = document.getElementById('btn-vista-tarjetas');
    const btnVistaTabla = document.getElementById('btn-vista-tabla');
    const vistaTarjetas = document.getElementById('vista-tarjetas');
    const vistaTabla = document.getElementById('vista-tabla');
    let vehiculos = [];
    let ordenes = [];

    function cambiarVista(tipo) {
        localStorage.setItem('vistaVehiculosPreferida', tipo);
        if (tipo === 'tarjetas') {
            vistaTarjetas.style.display = 'grid';
            vistaTabla.style.display = 'none';
            btnVistaTarjetas?.classList.add('activo');
            btnVistaTabla?.classList.remove('activo');
        } else {
            vistaTarjetas.style.display = 'none';
            vistaTabla.style.display = 'block';
            btnVistaTarjetas?.classList.remove('activo');
            btnVistaTabla?.classList.add('activo');
        }
    }

    function estadoVehiculo(v) {
        const ot = ordenes.find(o => Number(o.id_vehiculo) === Number(v.id_vehiculo) && !['Completada', 'Cancelada'].includes(o.estado));
        return ot ? ot.estado : (v.estado || 'Activo');
    }

    function ultimoServicio(v) {
        const ot = ordenes.filter(o => Number(o.id_vehiculo) === Number(v.id_vehiculo))[0];
        return ot ? String(ot.fecha_ingreso || '').slice(0, 10) : 'Sin servicios';
    }

    function esc(s) {
        return String(s ?? '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    function enlaceHistorial(v) {
        const placa = encodeURIComponent(v.placa || '');
        return `P_Reparaciones.php?placa=${placa}`;
    }

    function pintar() {
        if (vistaTarjetas) {
            if (!vehiculos.length) {
                vistaTarjetas.innerHTML = '<p>No tienes vehículos registrados. El taller los asocia cuando ingresas el primero.</p>';
            } else {
                vistaTarjetas.innerHTML = vehiculos.map(v => `
                    <article class="tarjeta-vehiculo">
                        <div class="card-top">
                            <div class="tarjeta-icon"><i class="fas ${(window.MotorSoftPlaca && MotorSoftPlaca.icono(v.tipo)) || 'fa-car'}"></i></div>
                            <div>
                                <h3>${esc(v.marca || '')} ${esc(v.modelo || '')}</h3>
                                <p class="card-sub">${esc([v.tipo, v.placa].filter(Boolean).join(' · ') || 'Sin placa')}</p>
                            </div>
                            <span class="status-badge">${esc(estadoVehiculo(v))}</span>
                        </div>
                        <div class="info-grid">
                            <div class="info-item"><span class="info-label">Año</span><span class="info-value">${esc(v.anio || v.año || '—')}</span></div>
                            <div class="info-item"><span class="info-label">Último servicio</span><span class="info-value">${esc(ultimoServicio(v))}</span></div>
                        </div>
                        <div class="form-actions">
                            <a class="btn-detalle" href="${enlaceHistorial(v)}">Ver historial</a>
                        </div>
                    </article>
                `).join('');
            }
        }
        const tbody = document.querySelector('.tabla-vehiculos tbody');
        if (tbody) {
            tbody.innerHTML = vehiculos.length
                ? vehiculos.map(v => `<tr>
                    <td>${esc(v.marca || '')} ${esc(v.modelo || '')}</td>
                    <td>${esc(v.tipo || '')}</td>
                    <td>${esc(v.placa || '')}</td>
                    <td>${esc(ultimoServicio(v))}</td>
                    <td>${esc(estadoVehiculo(v))}</td>
                    <td><a class="btn-detalle" href="${enlaceHistorial(v)}">Ver historial</a></td>
                </tr>`).join('')
                : '<tr><td colspan="6">No tienes vehículos registrados. El taller los asocia cuando ingresas el primero.</td></tr>';
        }
    }

    btnVistaTarjetas?.addEventListener('click', () => cambiarVista('tarjetas'));
    btnVistaTabla?.addEventListener('click', () => cambiarVista('tabla'));
    cambiarVista(localStorage.getItem('vistaVehiculosPreferida') || 'tarjetas');

    Promise.all([window.apiVehiculos(true), window.apiOrdenes(true).catch(() => ({ data: [] }))])
        .then(([vehRes, ordRes]) => {
            vehiculos = Array.isArray(vehRes.data) ? vehRes.data : [];
            ordenes = Array.isArray(ordRes.data) ? ordRes.data : [];
            pintar();
        })
        .catch(e => {
            if (vistaTarjetas) vistaTarjetas.innerHTML = `<p>${e.message || 'No se pudieron cargar los vehículos'}</p>`;
        });
});
