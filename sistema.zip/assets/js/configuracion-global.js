/**
 * Sistema de Configuración Global - MotorSoft
 * Accesible desde todas las páginas de la aplicación
 */

class ConfiguracionGlobal {
    constructor() {
        this.configuracion = {};
        this.modal = null;
        this.init();
    }

    async init() {
        await this.cargarConfiguracion();
        this.crearModal();
        this.configurarEventListeners();
    }

    /**
     * Carga configuración desde backend
     */
    async cargarConfiguracion() {
        try {
            // Simulado - se puede implementar endpoint específico
            this.configuracion = {
                nombre_taller: 'Taller El Paisa',
                direccion: 'Calle Principal #123',
                telefono: '3001234567',
                email: 'contacto@tallerpaisa.com',
                iva_porcentaje: 19,
                moneda: 'COP',
                horario_trabajo: 'Lunes a Viernes 8:00 - 17:00',
                notificaciones_email: true,
                tema: 'light',
                idioma: 'es',
                formato_fecha: 'DD/MM/YYYY',
                backup_automatico: true,
                frecuencia_backup: 'diario'
            };
        } catch (error) {
            console.error('Error cargando configuración:', error);
            this.configuracion = {};
        }
    }

    /**
     * Crea el modal de configuración
     */
    crearModal() {
        const modalHTML = `
            <div class="modal" id="modal-configuracion-global">
                <div class="modal-content modal-lg">
                    <div class="modal-header">
                        <h3><i class="fas fa-cog"></i> Configuración del Sistema</h3>
                        <button class="btn-close" onclick="configGlobal.cerrarModal()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="config-tabs">
                            <div class="tab-nav">
                                <button class="tab-btn active" data-tab="general">
                                    <i class="fas fa-cogs"></i> General
                                </button>
                                <button class="tab-btn" data-tab="taller">
                                    <i class="fas fa-tools"></i> Taller
                                </button>
                                <button class="tab-btn" data-tab="facturacion">
                                    <i class="fas fa-file-invoice"></i> Facturación
                                </button>
                                <button class="tab-btn" data-tab="notificaciones">
                                    <i class="fas fa-bell"></i> Notificaciones
                                </button>
                                <button class="tab-btn" data-tab="sistema">
                                    <i class="fas fa-server"></i> Sistema
                                </button>
                            </div>
                            
                            <div class="tab-content">
                                <!-- Tab General -->
                                <div class="tab-pane active" id="tab-general">
                                    <div class="form-grid">
                                        <div class="form-group">
                                            <label>Nombre del Sistema</label>
                                            <input type="text" id="config-nombre-sistema" value="${this.configuracion.nombre_taller || ''}">
                                        </div>
                                        <div class="form-group">
                                            <label>Tema</label>
                                            <select id="config-tema">
                                                <option value="light" ${this.configuracion.tema === 'light' ? 'selected' : ''}>Claro</option>
                                                <option value="dark" ${this.configuracion.tema === 'dark' ? 'selected' : ''}>Oscuro</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Idioma</label>
                                            <select id="config-idioma">
                                                <option value="es" ${this.configuracion.idioma === 'es' ? 'selected' : ''}>Español</option>
                                                <option value="en" ${this.configuracion.idioma === 'en' ? 'selected' : ''}>English</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Formato de Fecha</label>
                                            <select id="config-formato-fecha">
                                                <option value="DD/MM/YYYY" ${this.configuracion.formato_fecha === 'DD/MM/YYYY' ? 'selected' : ''}>DD/MM/YYYY</option>
                                                <option value="MM/DD/YYYY" ${this.configuracion.formato_fecha === 'MM/DD/YYYY' ? 'selected' : ''}>MM/DD/YYYY</option>
                                                <option value="YYYY-MM-DD" ${this.configuracion.formato_fecha === 'YYYY-MM-DD' ? 'selected' : ''}>YYYY-MM-DD</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tab Taller -->
                                <div class="tab-pane" id="tab-taller">
                                    <div class="form-grid">
                                        <div class="form-group">
                                            <label>Nombre del Taller</label>
                                            <input type="text" id="config-nombre-taller" value="${this.configuracion.nombre_taller || ''}">
                                        </div>
                                        <div class="form-group">
                                            <label>Dirección</label>
                                            <input type="text" id="config-direccion" value="${this.configuracion.direccion || ''}">
                                        </div>
                                        <div class="form-group">
                                            <label>Teléfono</label>
                                            <input type="tel" id="config-telefono" value="${this.configuracion.telefono || ''}">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" id="config-email" value="${this.configuracion.email || ''}">
                                        </div>
                                        <div class="form-group full-width">
                                            <label>Horario de Trabajo</label>
                                            <input type="text" id="config-horario" value="${this.configuracion.horario_trabajo || ''}">
                                        </div>
                                    </div>
                                </div>

                                <!-- Tab Facturación -->
                                <div class="tab-pane" id="tab-facturacion">
                                    <div class="form-grid">
                                        <div class="form-group">
                                            <label>Porcentaje de IVA (%)</label>
                                            <input type="number" id="config-iva" value="${this.configuracion.iva_porcentaje || 19}" min="0" max="100">
                                        </div>
                                        <div class="form-group">
                                            <label>Moneda</label>
                                            <select id="config-moneda">
                                                <option value="COP" ${this.configuracion.moneda === 'COP' ? 'selected' : ''}>Peso Colombiano (COP)</option>
                                                <option value="USD" ${this.configuracion.moneda === 'USD' ? 'selected' : ''}>Dólar (USD)</option>
                                                <option value="EUR" ${this.configuracion.moneda === 'EUR' ? 'selected' : ''}>Euro (EUR)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tab Notificaciones -->
                                <div class="tab-pane" id="tab-notificaciones">
                                    <div class="form-grid">
                                        <div class="form-group">
                                            <label class="checkbox-label">
                                                <input type="checkbox" id="config-notificaciones-email" ${this.configuracion.notificaciones_email ? 'checked' : ''}>
                                                <span>Enviar notificaciones por email</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tab Sistema -->
                                <div class="tab-pane" id="tab-sistema">
                                    <div class="form-grid">
                                        <div class="form-group">
                                            <label class="checkbox-label">
                                                <input type="checkbox" id="config-backup-automatico" ${this.configuracion.backup_automatico ? 'checked' : ''}>
                                                <span>Backup automático</span>
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <label>Frecuencia de Backup</label>
                                            <select id="config-frecuencia-backup">
                                                <option value="diario" ${this.configuracion.frecuencia_backup === 'diario' ? 'selected' : ''}>Diario</option>
                                                <option value="semanal" ${this.configuracion.frecuencia_backup === 'semanal' ? 'selected' : ''}>Semanal</option>
                                                <option value="mensual" ${this.configuracion.frecuencia_backup === 'mensual' ? 'selected' : ''}>Mensual</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline" onclick="configGlobal.cerrarModal()">Cancelar</button>
                        <button type="button" class="btn btn-danger" onclick="configGlobal.restaurarDefecto()">Restaurar por Defecto</button>
                        <button type="button" class="btn btn-primary" onclick="configGlobal.guardarConfiguracion()">Guardar Cambios</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        this.modal = document.getElementById('modal-configuracion-global');
    }

    /**
     * Configura event listeners
     */
    configurarEventListeners() {
        // Botones de configuración en todas las páginas
        document.addEventListener('click', (e) => {
            if (e.target.id === 'btn-configuracion' || e.target.closest('#btn-configuracion')) {
                this.abrirModal();
            }
        });

        // Tabs
        this.modal.addEventListener('click', (e) => {
            if (e.target.classList.contains('tab-btn')) {
                this.cambiarTab(e.target.dataset.tab);
            }
        });

        // Aplicar tema inmediatamente
        const temaSelect = document.getElementById('config-tema');
        if (temaSelect) {
            temaSelect.addEventListener('change', (e) => {
                this.aplicarTema(e.target.value);
            });
        }
    }

    /**
     * Abre el modal de configuración
     */
    abrirModal() {
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    /**
     * Cierra el modal de configuración
     */
    cerrarModal() {
        this.modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    /**
     * Cambia de tab
     */
    cambiarTab(tabId) {
        // Actualizar botones
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

        // Actualizar contenido
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        document.getElementById(`tab-${tabId}`).classList.add('active');
    }

    /**
     * Aplica tema
     */
    aplicarTema(tema) {
        if (window.MotorSoftTema) {
            window.MotorSoftTema.aplicar(tema);
            return;
        }
        document.body.setAttribute('data-theme', tema);
        localStorage.setItem('tema', tema);
        const iconoTema = document.querySelector('#theme-toggle i, #btn-toggle-tema i');
        if (iconoTema) {
            iconoTema.className = tema === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    /**
     * Guarda configuración
     */
    async guardarConfiguracion() {
        try {
            // Recopilar datos del formulario
            const nuevaConfig = {
                nombre_taller: document.getElementById('config-nombre-taller')?.value || '',
                direccion: document.getElementById('config-direccion')?.value || '',
                telefono: document.getElementById('config-telefono')?.value || '',
                email: document.getElementById('config-email')?.value || '',
                iva_porcentaje: parseFloat(document.getElementById('config-iva')?.value) || 19,
                moneda: document.getElementById('config-moneda')?.value || 'COP',
                horario_trabajo: document.getElementById('config-horario')?.value || '',
                notificaciones_email: document.getElementById('config-notificaciones-email')?.checked || false,
                tema: document.getElementById('config-tema')?.value || 'light',
                idioma: document.getElementById('config-idioma')?.value || 'es',
                formato_fecha: document.getElementById('config-formato-fecha')?.value || 'DD/MM/YYYY',
                backup_automatico: document.getElementById('config-backup-automatico')?.checked || false,
                frecuencia_backup: document.getElementById('config-frecuencia-backup')?.value || 'diario'
            };

            // Aquí se enviaría al backend
            // await apiCall('/configuracion/guardar', { method: 'POST', body: nuevaConfig });

            // Actualizar configuración local
            this.configuracion = { ...this.configuracion, ...nuevaConfig };

            // Aplicar cambios inmediatos
            this.aplicarTema(nuevaConfig.tema);

            // Mostrar éxito
            window.showToast('Configuración guardada exitosamente', 'success');
            this.cerrarModal();

        } catch (error) {
            console.error('Error guardando configuración:', error);
            window.showToast('Error guardando configuración', 'error');
        }
    }

    /**
     * Restaura configuración por defecto
     */
    async restaurarDefecto() {
        if (!confirm('¿Está seguro de que desea restaurar la configuración por defecto? Esta acción no se puede deshacer.')) {
            return;
        }

        try {
            // Valores por defecto
            const defecto = {
                nombre_taller: 'Taller El Paisa',
                direccion: '',
                telefono: '',
                email: '',
                iva_porcentaje: 19,
                moneda: 'COP',
                horario_trabajo: 'Lunes a Viernes 8:00 - 17:00',
                notificaciones_email: true,
                tema: 'light',
                idioma: 'es',
                formato_fecha: 'DD/MM/YYYY',
                backup_automatico: true,
                frecuencia_backup: 'diario'
            };

            // Actualizar formulario
            Object.keys(defecto).forEach(key => {
                const element = document.getElementById(`config-${key.replace('_', '-')}`);
                if (element) {
                    if (element.type === 'checkbox') {
                        element.checked = defecto[key];
                    } else {
                        element.value = defecto[key];
                    }
                }
            });

            window.showToast('Valores por defecto cargados. Haga clic en "Guardar Cambios" para aplicar.', 'info');

        } catch (error) {
            console.error('Error restaurando configuración:', error);
            window.showToast('Error restaurando configuración', 'error');
        }
    }

    /**
     * Obtiene un valor de configuración
     */
    get(key) {
        return this.configuracion[key];
    }

    /**
     * Actualiza un valor de configuración
     */
    set(key, value) {
        this.configuracion[key] = value;
    }
}

// Instancia global
let configGlobal;

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    configGlobal = new ConfiguracionGlobal();
});

// Exportar para uso global
if (typeof window !== 'undefined') {
    window.ConfiguracionGlobal = ConfiguracionGlobal;
    window.configGlobal = configGlobal;
}
