/**
 * Componentes Reutilizables - MotorSoft
 * Componentes UI flexibles y reutilizables para toda la aplicación
 */

class ComponentesUI {
    /**
     * Crea un modal reutilizable
     */
    static crearModal(options = {}) {
        const defaults = {
            id: 'modal-' + Date.now(),
            title: 'Modal',
            size: 'medium', // small, medium, large, full
            closable: true,
            backdrop: true,
            keyboard: true
        };

        const config = { ...defaults, ...options };

        const modalHTML = `
            <div class="modal ${config.backdrop ? 'modal-backdrop' : ''}" id="${config.id}">
                <div class="modal-content modal-${config.size}">
                    <div class="modal-header">
                        <h3>${config.title}</h3>
                        ${config.closable ? `<button class="btn-close" onclick="ComponentesUI.cerrarModal('${config.id}')"><i class="fas fa-times"></i></button>` : ''}
                    </div>
                    <div class="modal-body">
                        ${config.content || ''}
                    </div>
                    ${config.footer ? `<div class="modal-footer">${config.footer}</div>` : ''}
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        const modal = document.getElementById(config.id);
        
        // Event listeners
        if (config.backdrop) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.cerrarModal(config.id);
                }
            });
        }

        if (config.keyboard) {
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.classList.contains('active')) {
                    this.cerrarModal(config.id);
                }
            });
        }

        return modal;
    }

    /**
     * Abre un modal
     */
    static abrirModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            return modal;
        }
        return null;
    }

    /**
     * Cierra un modal
     */
    static cerrarModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
            
            // Disparar evento de cierre
            const event = new CustomEvent('modalCerrado', { detail: { modalId } });
            modal.dispatchEvent(event);
        }
    }

    /**
     * Crea una notificación toast
     */
    static crearToast(options = {}) {
        const defaults = {
            message: 'Notificación',
            type: 'info', // success, error, warning, info
            duration: 5000,
            closable: true,
            position: 'top-right' // top-left, top-right, bottom-left, bottom-right, center
        };

        const config = { ...defaults, ...options };

        const toastHTML = `
            <div class="toast toast-${config.type} toast-${config.position}" data-toast-id="${Date.now()}">
                <div class="toast-content">
                    <div class="toast-icon">
                        <i class="fas ${this.getIconoToast(config.type)}"></i>
                    </div>
                    <div class="toast-message">${config.message}</div>
                    ${config.closable ? '<button class="toast-close" onclick="this.parentElement.parentElement.remove()"><i class="fas fa-times"></i></button>' : ''}
                </div>
                <div class="toast-progress"></div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', toastHTML);
        
        const toast = document.querySelector(`[data-toast-id="${Date.now()}"]`);
        
        // Auto cerrar
        if (config.duration > 0) {
            setTimeout(() => {
                toast.classList.add('toast-hiding');
                setTimeout(() => toast.remove(), 300);
            }, config.duration);
        }

        // Animación de progreso
        if (config.duration > 0) {
            const progressBar = toast.querySelector('.toast-progress');
            progressBar.style.animation = `toastProgress ${config.duration}ms linear`;
        }

        return toast;
    }

    /**
     * Obtiene el icono según el tipo de toast
     */
    static getIconoToast(type) {
        const iconos = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return iconos[type] || iconos.info;
    }

    /**
     * Crea una tabla reutilizable
     */
    static crearTabla(options = {}) {
        const defaults = {
            id: 'tabla-' + Date.now(),
            columns: [],
            data: [],
            paginable: true,
            searchable: true,
            selectable: false,
            acciones: [],
            emptyMessage: 'No hay datos disponibles',
            pageSize: 10
        };

        const config = { ...defaults, ...options };

        let tablaHTML = `
            <div class="tabla-container" id="${config.id}">
                ${config.searchable ? `
                    <div class="tabla-search">
                        <div class="search-input">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Buscar..." class="tabla-search-input">
                        </div>
                        <div class="tabla-actions">
                            ${config.acciones.map(accion => `
                                <button class="btn btn-sm ${accion.class || 'btn-outline'}" onclick="${accion.onclick}">
                                    <i class="fas ${accion.icon}"></i> ${accion.text}
                                </button>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                <div class="tabla-wrapper">
                    <table class="tabla">
                        <thead>
                            <tr>
                                ${config.columns.map(col => `
                                    <th class="${col.sortable ? 'sortable' : ''}" data-column="${col.key}">
                                        ${col.title}
                                        ${col.sortable ? '<i class="fas fa-sort"></i>' : ''}
                                    </th>
                                `).join('')}
                                ${config.acciones.length > 0 ? '<th>Acciones</th>' : ''}
                            </tr>
                        </thead>
                        <tbody>
                            ${config.data.length === 0 ? `
                                <tr>
                                    <td colspan="${config.columns.length + (config.acciones.length > 0 ? 1 : 0)}" class="tabla-empty">
                                        <div class="tabla-empty-content">
                                            <i class="fas fa-inbox"></i>
                                            <p>${config.emptyMessage}</p>
                                        </div>
                                    </td>
                                </tr>
                            ` : ''}
                            ${config.data.map(row => `
                                <tr class="${config.selectable ? 'selectable' : ''}" data-id="${row.id || ''}">
                                    ${config.columns.map(col => `
                                        <td>${this.formatearCelda(row[col.key], col)}</td>
                                    `).join('')}
                                    ${config.acciones.length > 0 ? `
                                        <td class="tabla-acciones">
                                            <div class="acciones-dropdown">
                                                <button class="btn btn-sm btn-outline acciones-toggle">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <div class="acciones-menu">
                                                    ${config.acciones.map(accion => `
                                                        <button class="accion-item" onclick="${accion.onclick.replace('{id}', row.id)}">
                                                            <i class="fas ${accion.icon}"></i> ${accion.text}
                                                        </button>
                                                    `).join('')}
                                                </div>
                                            </div>
                                        </td>
                                    ` : ''}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
                ${config.paginable && config.data.length > config.pageSize ? `
                    <div class="tabla-pagination">
                        <div class="pagination-info">
                            Mostrando 1-${Math.min(config.pageSize, config.data.length)} de ${config.data.length} resultados
                        </div>
                        <div class="pagination-controls">
                            <button class="btn btn-sm btn-outline" disabled>
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <span class="pagination-pages">1</span>
                            <button class="btn btn-sm btn-outline" disabled>
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                ` : ''}
            </div>
        `;

        return tablaHTML;
    }

    /**
     * Formatea una celda de tabla según el tipo
     */
    static formatearCelda(value, column) {
        if (column.type === 'currency') {
            return new Intl.NumberFormat('es-CO', {
                style: 'currency',
                currency: 'COP'
            }).format(value || 0);
        }

        if (column.type === 'date') {
            return new Date(value).toLocaleDateString('es-CO');
        }

        if (column.type === 'badge') {
            return `<span class="badge badge-${column.color || 'primary'}">${value}</span>`;
        }

        if (column.type === 'status') {
            const colores = {
                'Activo': 'success',
                'Inactivo': 'danger',
                'Pendiente': 'warning',
                'Completada': 'success',
                'Cancelada': 'danger'
            };
            return `<span class="badge badge-${colores[value] || 'secondary'}">${value}</span>`;
        }

        return value || '';
    }

    /**
     * Crea un formulario reutilizable
     */
    static crearFormulario(options = {}) {
        const defaults = {
            id: 'form-' + Date.now(),
            fields: [],
            data: {},
            submitText: 'Guardar',
            cancelText: 'Cancelar',
            onSubmit: null,
            onCancel: null
        };

        const config = { ...defaults, ...options };

        let formHTML = `
            <form class="form-reutilizable" id="${config.id}">
                <div class="form-grid">
                    ${config.fields.map(field => this.crearCampo(field, config.data[field.name])).join('')}
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-outline" onclick="ComponentesUI.cancelarFormulario('${config.id}')">${config.cancelText}</button>
                    <button type="submit" class="btn btn-primary">${config.submitText}</button>
                </div>
            </form>
        `;

        return formHTML;
    }

    /**
     * Crea un campo de formulario
     */
    static crearCampo(field, value = '') {
        const fieldValue = value || field.default || '';
        
        switch (field.type) {
            case 'text':
            case 'email':
            case 'tel':
            case 'number':
            case 'date':
                return `
                    <div class="form-group ${field.fullWidth ? 'full-width' : ''}">
                        <label for="${field.name}">${field.label}${field.required ? ' *' : ''}</label>
                        <input type="${field.type}" id="${field.name}" name="${field.name}" 
                               value="${fieldValue}" ${field.required ? 'required' : ''}
                               placeholder="${field.placeholder || ''}" ${field.attributes || ''}>
                        ${field.help ? `<small class="form-help">${field.help}</small>` : ''}
                    </div>
                `;

            case 'select':
                return `
                    <div class="form-group ${field.fullWidth ? 'full-width' : ''}">
                        <label for="${field.name}">${field.label}${field.required ? ' *' : ''}</label>
                        <select id="${field.name}" name="${field.name}" ${field.required ? 'required' : ''}>
                            <option value="">${field.placeholder || 'Seleccione...'}</option>
                            ${field.options.map(opt => `
                                <option value="${opt.value}" ${opt.value === fieldValue ? 'selected' : ''}>${opt.label}</option>
                            `).join('')}
                        </select>
                        ${field.help ? `<small class="form-help">${field.help}</small>` : ''}
                    </div>
                `;

            case 'textarea':
                return `
                    <div class="form-group full-width">
                        <label for="${field.name}">${field.label}${field.required ? ' *' : ''}</label>
                        <textarea id="${field.name}" name="${field.name}" rows="${field.rows || 3}"
                                  placeholder="${field.placeholder || ''}" ${field.required ? 'required' : ''}>${fieldValue}</textarea>
                        ${field.help ? `<small class="form-help">${field.help}</small>` : ''}
                    </div>
                `;

            case 'checkbox':
                return `
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" id="${field.name}" name="${field.name}" 
                                   ${fieldValue ? 'checked' : ''}>
                            <span>${field.label}</span>
                        </label>
                        ${field.help ? `<small class="form-help">${field.help}</small>` : ''}
                    </div>
                `;

            default:
                return '';
        }
    }

    /**
     * Valida un formulario
     */
    static validarFormulario(formId, rules = {}) {
        const form = document.getElementById(formId);
        const formData = new FormData(form);
        const errors = {};

        for (const [field, rule] of Object.entries(rules)) {
            const value = formData.get(field);
            
            if (rule.required && !value) {
                errors[field] = 'Este campo es requerido';
                continue;
            }

            if (rule.type === 'email' && value && !this.validarEmail(value)) {
                errors[field] = 'Email inválido';
            }

            if (rule.type === 'tel' && value && !this.validarTelefono(value)) {
                errors[field] = 'Teléfono inválido';
            }

            if (rule.min && value && value.length < rule.min) {
                errors[field] = `Mínimo ${rule.min} caracteres`;
            }

            if (rule.max && value && value.length > rule.max) {
                errors[field] = `Máximo ${rule.max} caracteres`;
            }
        }

        this.mostrarErroresFormulario(formId, errors);
        return Object.keys(errors).length === 0;
    }

    /**
     * Muestra errores de formulario
     */
    static mostrarErroresFormulario(formId, errors) {
        const form = document.getElementById(formId);
        
        // Limpiar errores anteriores
        form.querySelectorAll('.error-message').forEach(el => el.remove());
        form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));

        // Mostrar nuevos errores
        for (const [field, message] of Object.entries(errors)) {
            const input = form.querySelector(`[name="${field}"]`);
            if (input) {
                input.classList.add('error');
                const errorDiv = document.createElement('div');
                errorDiv.className = 'error-message';
                errorDiv.textContent = message;
                input.parentNode.appendChild(errorDiv);
            }
        }
    }

    /**
     * Valida email
     */
    static validarEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    /**
     * Valida teléfono
     */
    static validarTelefono(telefono) {
        const re = /^[0-9\s\-\(\)]+$/;
        return re.test(telefono) && telefono.replace(/\D/g, '').length >= 7;
    }

    /**
     * Cancela formulario
     */
    static cancelarFormulario(formId) {
        const form = document.getElementById(formId);
        form.reset();
        
        // Limpiar errores
        form.querySelectorAll('.error-message').forEach(el => el.remove());
        form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
    }

    /**
     * Crea un loading spinner
     */
    static crearLoading(size = 'medium') {
        const tamaños = {
            small: '16px',
            medium: '24px',
            large: '32px'
        };

        return `
            <div class="loading-spinner loading-${size}">
                <div class="spinner" style="width: ${tamaños[size]}; height: ${tamaños[size]};">
                    <div class="bounce1"></div>
                    <div class="bounce2"></div>
                    <div class="bounce3"></div>
                </div>
            </div>
        `;
    }

    /**
     * Muestra u oculta loading en un elemento
     */
    static toggleLoading(elementId, show = true) {
        const element = document.getElementById(elementId);
        if (!element) return;

        if (show) {
            element.classList.add('loading');
            element.style.position = 'relative';
            element.style.pointerEvents = 'none';
            
            const loading = document.createElement('div');
            loading.className = 'loading-overlay';
            loading.innerHTML = this.crearLoading();
            element.appendChild(loading);
        } else {
            element.classList.remove('loading');
            element.style.position = '';
            element.style.pointerEvents = '';
            
            const overlay = element.querySelector('.loading-overlay');
            if (overlay) overlay.remove();
        }
    }
}

// Exportar para uso global
if (typeof window !== 'undefined') {
    window.ComponentesUI = ComponentesUI;
}
