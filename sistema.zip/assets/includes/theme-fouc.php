<script>
(function () {
  try {
    var t = localStorage.getItem('tema') || localStorage.getItem('theme') || localStorage.getItem('mecanicos-theme') || 'light';
    if (t === 'auto') t = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    t = t === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', t);
    document.documentElement.style.colorScheme = t;
    document.documentElement.classList.toggle('dark-theme', t === 'dark');
  } catch (e) {}
})();
</script>
