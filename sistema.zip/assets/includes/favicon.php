    <link rel="icon" type="image/png" href="../../assets/images/logo-taller.png">
    <link rel="icon" type="image/svg+xml" href="../../assets/images/logo-taller.svg">
    <link rel="apple-touch-icon" href="../../assets/images/logo-taller.png">
