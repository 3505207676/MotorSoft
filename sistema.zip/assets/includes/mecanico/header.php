<?php
if (!isset($title)) $title = 'App Mecánicos - Taller El Paisa';
if (!isset($show_back)) $show_back = false;
if (!isset($show_menu)) $show_menu = true;
if (!isset($show_notifications)) $show_notifications = true;
if (!isset($show_refresh)) $show_refresh = false;
if (!isset($page_title)) $page_title = 'App Mecánicos';
if (!isset($active_module)) $active_module = 'dashboard';
$mec_css = '20260915logo1';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#2563eb">
    <title><?php echo htmlspecialchars($title); ?></title>
    <?php require_once __DIR__ . '/../theme-fouc.php'; ?>
    <?php require __DIR__ . '/../favicon.php'; ?>
    <link rel="manifest" href="../../assets/js/mecanicos/manifest.json">
    <link rel="stylesheet" href="../../assets/css/main-mecanicos.css?v=<?php echo $mec_css; ?>">
    <link rel="stylesheet" href="../../assets/css/mobile-mecanicos.css?v=<?php echo $mec_css; ?>">
    <link rel="stylesheet" href="../../assets/css/layout-mecanicos.css?v=<?php echo $mec_css; ?>">
    
    <!-- Font Awesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="page-<?php echo htmlspecialchars($active_module ?? 'dashboard'); ?>">
    <div class="menu-overlay" id="menu-overlay" hidden></div>
    <aside class="menu-drawer" id="menu-drawer" aria-hidden="true" aria-label="Menú de la aplicación">
        <div class="menu-drawer-header">
            <div class="menu-drawer-identity">
                <div class="menu-brand marca-taller">
                    <img src="../../assets/images/logo-taller.png" width="40" height="40" alt="Taller El Paisa">
                    <div class="menu-user-text">
                        <strong>Taller El Paisa</strong>
                        <span>App mecánicos</span>
                    </div>
                </div>
                <div class="menu-user">
                    <div class="menu-avatar" id="menu-avatar">M</div>
                    <div class="menu-user-text">
                        <strong id="menu-user-name">Mecánico</strong>
                        <span id="menu-user-role">Taller El Paisa</span>
                    </div>
                </div>
            </div>
            <button type="button" class="btn-icon" id="btn-cerrar-menu" aria-label="Cerrar menú">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="menu-drawer-nav">
            <a href="../dashboard/index-mecanicos.php" class="menu-link <?php echo $active_module === 'dashboard' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i><span>Inicio</span>
            </a>
            <a href="../ordenes/index-mecanicos.php" class="menu-link <?php echo $active_module === 'ordenes' ? 'active' : ''; ?>">
                <i class="fas fa-clipboard-list"></i><span>Órdenes</span>
            </a>
            <a href="../stock/index.php" class="menu-link <?php echo $active_module === 'stock' ? 'active' : ''; ?>">
                <i class="fas fa-boxes"></i><span>Stock</span>
            </a>
            <a href="../consumos/index.php" class="menu-link <?php echo $active_module === 'consumos' ? 'active' : ''; ?>">
                <i class="fas fa-tools"></i><span>Consumos</span>
            </a>
            <a href="../chat/index-mecanicos.php" class="menu-link <?php echo $active_module === 'chat' ? 'active' : ''; ?>">
                <i class="fas fa-comments"></i><span>Chat</span>
            </a>
            <a href="../perfil/index-mecanicos.php" class="menu-link <?php echo $active_module === 'perfil' ? 'active' : ''; ?>">
                <i class="fas fa-user"></i><span>Perfil</span>
            </a>
        </nav>
        <div class="menu-drawer-footer">
            <button type="button" class="menu-link menu-link-logout" id="btn-cerrar-sesion">
                <i class="fas fa-sign-out-alt"></i><span>Cerrar sesión</span>
            </button>
        </div>
    </aside>
    <div class="app-container">
        <header class="app-header">
            <div class="header-content">
                <div class="header-left">
                    <button class="btn-icon" id="btn-menu" type="button" aria-label="Menú" aria-controls="menu-drawer" aria-expanded="false">
                        <i class="fas fa-bars"></i>
                    </button>
                    <?php if ($show_back): ?>
                    <button class="btn-icon" onclick="window.history.back()" aria-label="Volver">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <?php endif; ?>
                    <h1 class="app-title"><img class="header-logo" src="../../assets/images/logo-taller.png" width="28" height="28" alt=""> <?php echo htmlspecialchars($page_title); ?></h1>
                </div>
                <div class="header-right">
                    <?php if ($show_notifications): ?>
                    <button class="btn-icon" id="btn-notifications" aria-label="Notificaciones">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge hidden" id="notification-count">0</span>
                    </button>
                    <?php endif; ?>
                    <?php if ($show_refresh): ?>
                    <button class="btn-icon" id="btn-refresh" aria-label="Actualizar">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <?php endif; ?>
                    <button class="btn-icon" id="btn-theme" aria-label="Cambiar tema">
                        <i class="fas fa-moon" id="theme-icon"></i>
                    </button>
                </div>
            </div>
        </header>
