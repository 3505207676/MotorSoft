<?php
if (!isset($active_module)) $active_module = 'dashboard';
?>
        <!-- Navegación Principal -->
        <nav class="main-nav" id="main-nav">
            <div class="nav-items">
                <a href="../dashboard/index-mecanicos.php" class="nav-item <?php echo $active_module === 'dashboard' ? 'active' : ''; ?>" data-module="dashboard">
                    <i class="fas fa-home"></i>
                    <span>Inicio</span>
                </a>
                <a href="../ordenes/index-mecanicos.php" class="nav-item <?php echo $active_module === 'ordenes' ? 'active' : ''; ?>" data-module="ordenes">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Órdenes</span>
                    <span class="nav-badge hidden" id="ordenes-badge">0</span>
                </a>
                <a href="../stock/index.php" class="nav-item <?php echo $active_module === 'stock' ? 'active' : ''; ?>" data-module="stock">
                    <i class="fas fa-boxes"></i>
                    <span>Stock</span>
                </a>
                <a href="../consumos/index.php" class="nav-item <?php echo $active_module === 'consumos' ? 'active' : ''; ?>" data-module="consumos">
                    <i class="fas fa-tools"></i>
                    <span>Consumos</span>
                </a>
                <a href="../chat/index-mecanicos.php" class="nav-item <?php echo $active_module === 'chat' ? 'active' : ''; ?>" data-module="chat">
                    <i class="fas fa-comments"></i>
                    <span>Chat</span>
                    <span class="nav-badge hidden" id="chat-badge">0</span>
                </a>
                <a href="../perfil/index-mecanicos.php" class="nav-item <?php echo $active_module === 'perfil' ? 'active' : ''; ?>" data-module="perfil">
                    <i class="fas fa-user"></i>
                    <span>Perfil</span>
                </a>
            </div>
        </nav>
