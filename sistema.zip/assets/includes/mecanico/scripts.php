<?php
$mec_js = '20260915placa1';
?>
    <script src="../../assets/js/utils/theme.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/utils/session-guard.js?v=<?php echo $mec_js; ?>"></script>
    <script>MotorSoftGuard.exigir('mecanicos');</script>
    <script src="../../assets/js/config.js"></script>
    <script src="../../assets/js/utils/placa.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/api.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/trabajadores/notificaciones.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/modulos/mecanicos/shell.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/modulos/mecanicos/sesion.js?v=<?php echo $mec_js; ?>"></script>
    <script src="../../assets/js/modulos/mecanicos/mapeos.js?v=<?php echo $mec_js; ?>"></script>
