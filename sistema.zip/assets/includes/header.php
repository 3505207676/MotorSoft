<?php
/**
 * Header global para todas las páginas
 * @param string $title Título de la página
 * @param array $css_files Array de archivos CSS adicionales (opcional)
 */
if (!isset($title)) $title = 'Taller El Paisa';
if (!isset($css_files)) $css_files = [];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?></title>
    <?php require __DIR__ . '/favicon.php'; ?>
    <?php require_once __DIR__ . '/theme-fouc.php'; ?>
    <link rel="stylesheet" href="../../assets/css/main-trabajadores.css?v=20260915logo1">
    <link rel="stylesheet" href="../../assets/css/componentes.css?v=20260915notif1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <?php foreach ($css_files as $css): ?>
        <link rel="stylesheet" href="../../assets/css/<?php echo htmlspecialchars($css); ?>">
    <?php endforeach; ?>
</head>
<body>
    <div class="app-container">
        <!-- Botón flotante para reabrir sidebar (visible cuando está colapsado) -->
        <button id="floating-toggle" class="floating-toggle">
            <i class="fas fa-bars"></i>
        </button>
