<?php
if (!isset($active_page)) $active_page = 'inicio';
?>
    <!-- 🔹 BARRA LATERAL -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <h2 class="marca-taller"><img src="../../assets/images/logo-taller.png" width="36" height="36" alt=""> Taller El Paisa</h2>
        <button id="sidebar-toggle" class="sidebar-toggle">
          <i class="fas fa-bars"></i>
        </button>
      </div>
      <nav>
        <ul>
          <li><a href="../cliente/P_Inicio.php" class="<?php echo $active_page === 'inicio' ? 'activo' : ''; ?>">
            <i class="fas fa-home"></i> Inicio
          </a></li>
          <li><a href="../cliente/P_MisVehiculos.php" class="<?php echo $active_page === 'vehiculos' ? 'activo' : ''; ?>">
            <i class="fas fa-car"></i> Mis Vehículos
          </a></li>
          <li><a href="../cliente/P_Reparaciones.php" class="<?php echo $active_page === 'reparaciones' ? 'activo' : ''; ?>">
            <i class="fas fa-tools"></i> Reparaciones
          </a></li>
          <li><a href="../cliente/P_Servicios.php" class="<?php echo $active_page === 'servicios' ? 'activo' : ''; ?>">
            <i class="fas fa-cogs"></i> Servicios
          </a></li>
          <li><a href="../cliente/P_Mensajes.php" class="<?php echo $active_page === 'mensajes' ? 'activo' : ''; ?>">
            <i class="fas fa-envelope"></i> Mensajes
            <span class="notification-badge">0</span>
          </a></li>
          <li><a href="../cliente/P_Facturas.php" class="<?php echo $active_page === 'facturas' ? 'activo' : ''; ?>">
            <i class="fas fa-file-invoice"></i> Facturas
          </a></li>
          <li><a href="#" class="logout">
            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
          </a></li>
        </ul>
      </nav>
    </aside>
