<?php
if (!isset($title)) $title = 'Cliente | Taller El Paisa';
if (!isset($page_title)) $page_title = 'Portal cliente';
if (!isset($active_page)) $active_page = 'inicio';
if (!isset($page_scripts)) $page_scripts = [];
if (is_string($page_scripts)) $page_scripts = [$page_scripts];
$cli_css = '20260915logo1';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <meta name="theme-color" content="#ff9800">
  <title><?php echo htmlspecialchars($title); ?></title>
  <?php require __DIR__ . '/../favicon.php'; ?>
  <?php require_once __DIR__ . '/../theme-fouc.php'; ?>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../../assets/css/panel_cliente.css?v=<?php echo $cli_css; ?>">
  <link rel="stylesheet" href="../../assets/css/layout-cliente.css?v=<?php echo $cli_css; ?>">
  <script src="../../assets/js/utils/session-guard.js?v=20260915mecrol1"></script>
  <script>MotorSoftGuard.exigir('cliente');</script>
</head>
<body class="cliente-app page-<?php echo htmlspecialchars($active_page); ?>">
  <div class="menu-overlay" id="menu-overlay" hidden></div>
  <aside class="menu-drawer" id="menu-drawer" aria-hidden="true" aria-label="Menú del portal">
    <div class="menu-drawer-header">
      <div class="menu-header-copy">
        <div class="menu-brand">
          <img class="menu-brand-mark" src="../../assets/images/logo-taller.png" width="40" height="40" alt="Taller El Paisa">
          <div class="menu-brand-text">
            <strong>Taller El Paisa</strong>
            <span>Portal del cliente</span>
          </div>
        </div>
        <div class="menu-user">
          <div class="menu-avatar" id="menu-avatar"><i class="fas fa-user"></i></div>
          <div class="menu-user-text">
            <strong id="menu-user-name">Cliente</strong>
            <span>Cliente</span>
          </div>
        </div>
      </div>
      <button type="button" class="btn-icon" id="btn-cerrar-menu" aria-label="Cerrar menú">
        <i class="fas fa-times"></i>
      </button>
    </div>
    <nav class="menu-drawer-nav">
      <a href="../cliente/P_Inicio.php" class="menu-link <?php echo $active_page === 'inicio' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i><span>Inicio</span>
      </a>
      <a href="../cliente/P_MisVehiculos.php" class="menu-link <?php echo $active_page === 'vehiculos' ? 'active' : ''; ?>">
        <i class="fas fa-car"></i><span>Mis vehículos</span>
      </a>
      <a href="../cliente/P_Reparaciones.php" class="menu-link <?php echo $active_page === 'reparaciones' ? 'active' : ''; ?>">
        <i class="fas fa-tools"></i><span>Reparaciones</span>
      </a>
      <a href="../cliente/P_Servicios.php" class="menu-link <?php echo $active_page === 'servicios' ? 'active' : ''; ?>">
        <i class="fas fa-cogs"></i><span>Servicios</span>
      </a>
      <a href="../cliente/P_Mensajes.php" class="menu-link <?php echo $active_page === 'mensajes' ? 'active' : ''; ?>">
        <i class="fas fa-envelope"></i><span>Mensajes</span>
        <span class="notification-badge" hidden>0</span>
      </a>
      <a href="../cliente/P_Facturas.php" class="menu-link <?php echo $active_page === 'facturas' ? 'active' : ''; ?>">
        <i class="fas fa-file-invoice"></i><span>Facturas</span>
      </a>
      <a href="../cliente/perfil.php" class="menu-link <?php echo $active_page === 'perfil' ? 'active' : ''; ?>">
        <i class="fas fa-user-circle"></i><span>Mi perfil</span>
      </a>
    </nav>
    <div class="menu-drawer-footer">
      <button type="button" class="menu-link menu-link-logout" id="btn-cerrar-sesion">
        <i class="fas fa-sign-out-alt"></i><span>Cerrar sesión</span>
      </button>
    </div>
  </aside>

  <div class="app-container">
    <header class="app-header">
      <div class="header-content">
        <div class="header-left">
          <button class="btn-icon" id="btn-menu" type="button" aria-label="Menú" aria-controls="menu-drawer" aria-expanded="false">
            <i class="fas fa-bars"></i>
          </button>
          <h1 class="app-title"><img class="header-logo" src="../../assets/images/logo-taller.png" width="28" height="28" alt=""> <?php echo htmlspecialchars($page_title); ?></h1>
        </div>
        <div class="header-right">
          <button class="btn-icon" id="theme-toggle" type="button" title="Cambiar tema" aria-label="Cambiar tema">
            <i class="fas fa-moon"></i>
          </button>
        </div>
      </div>
    </header>
