<?php
if (!isset($active_page)) $active_page = 'inicio';
?>
    <nav class="main-nav" id="main-nav">
      <div class="nav-items">
        <a href="../cliente/P_Inicio.php" class="nav-item <?php echo $active_page === 'inicio' ? 'active' : ''; ?>">
          <i class="fas fa-home"></i><span>Inicio</span>
        </a>
        <a href="../cliente/P_MisVehiculos.php" class="nav-item <?php echo $active_page === 'vehiculos' ? 'active' : ''; ?>">
          <i class="fas fa-car"></i><span>Vehículos</span>
        </a>
        <a href="../cliente/P_Reparaciones.php" class="nav-item <?php echo $active_page === 'reparaciones' ? 'active' : ''; ?>">
          <i class="fas fa-tools"></i><span>Órdenes</span>
        </a>
        <a href="../cliente/P_Servicios.php" class="nav-item <?php echo $active_page === 'servicios' ? 'active' : ''; ?>">
          <i class="fas fa-cogs"></i><span>Servicios</span>
        </a>
        <a href="../cliente/P_Mensajes.php" class="nav-item <?php echo $active_page === 'mensajes' ? 'active' : ''; ?>">
          <i class="fas fa-envelope"></i><span>Chat</span>
          <span class="nav-badge notification-badge" hidden>0</span>
        </a>
        <a href="../cliente/perfil.php" class="nav-item <?php echo $active_page === 'perfil' ? 'active' : ''; ?>">
          <i class="fas fa-user"></i><span>Perfil</span>
        </a>
      </div>
    </nav>
