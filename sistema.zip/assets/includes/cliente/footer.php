<?php
if (!isset($page_scripts)) $page_scripts = [];
if (is_string($page_scripts)) $page_scripts = [$page_scripts];
$cli_js = '20260915placa1';
?>
    <div class="toast-container" id="toast-container"></div>
  </div>
  <script src="../../assets/js/utils/theme.js?v=<?php echo $cli_js; ?>"></script>
  <script src="../../assets/js/config.js"></script>
  <script src="../../assets/js/utils/placa.js?v=<?php echo $cli_js; ?>"></script>
  <script src="../../assets/js/api.js?v=<?php echo $cli_js; ?>"></script>
  <script src="../../assets/js/cliente/main.js?v=<?php echo $cli_js; ?>"></script>
  <?php foreach ($page_scripts as $src): ?>
  <script src="../../assets/js/cliente/<?php echo htmlspecialchars($src); ?>?v=<?php echo $cli_js; ?>"></script>
  <?php endforeach; ?>
</body>
</html>
