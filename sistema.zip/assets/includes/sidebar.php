<?php
/**
 * Sidebar de navegación para trabajadores
 * @param string $active_page Página activa (dashboard, clientes, ordenes, inventario, facturacion, usuarios, contabilidad, agenda, auditoria, chat)
 */
if (!isset($active_page)) $active_page = 'dashboard';
?>
        <!-- Sidebar / Menú lateral -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo marca-taller">
                    <img src="../../assets/images/logo-taller.png" width="42" height="42" alt="Taller El Paisa">
                    <h1>Taller El Paisa</h1>
                </div>
                <button id="toggle-sidebar" class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <div class="user-info">
                <div class="user-avatar">
                    <img src="../../assets/images/avatar-default.svg" alt="Avatar de usuario">
                </div>
                <div class="user-details">
                    <h3 id="sidebar-user-name">Cargando...</h3>
                    <span class="user-role" id="sidebar-user-role"></span>
                </div>
            </div>

            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="../dashboard/index-trabajadores.php" <?php echo $active_page === 'dashboard' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Panel Principal</span>
                        </a>
                    </li>
                    <li>
                        <a href="../clientes/index.php" data-permiso="clientes.ver" <?php echo $active_page === 'clientes' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-address-book"></i>
                            <span>Clientes y Vehículos</span>
                        </a>
                    </li>
                    <li>
                        <a href="../ordenes/index-trabajadores.php" data-permiso="ordenes.ver" <?php echo $active_page === 'ordenes' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-clipboard-list"></i>
                            <span>Órdenes</span>
                        </a>
                    </li>
                    <li>
                        <a href="../inventario/index.php" data-permiso="inventario.ver" <?php echo $active_page === 'inventario' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-boxes"></i>
                            <span>Inventario</span>
                        </a>
                    </li>
                    <li>
                        <a href="../facturacion/index.php" data-permiso="facturas.ver" <?php echo $active_page === 'facturacion' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-file-invoice-dollar"></i>
                            <span>Facturación</span>
                        </a>
                    </li>
                    <li>
                        <a href="../usuarios/index.php" data-permiso="usuarios.ver" <?php echo $active_page === 'usuarios' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-users"></i>
                            <span>Usuarios</span>
                        </a>
                    </li>
                    <li>
                        <a href="../contabilidad/index.php" data-permiso="contabilidad.ver" <?php echo $active_page === 'contabilidad' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-calculator"></i>
                            <span>Contabilidad</span>
                        </a>
                    </li>
                    <li>
                        <a href="../agenda/index.php" data-permiso="agenda.ver" <?php echo $active_page === 'agenda' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-calendar-alt"></i>
                            <span>Agenda y Citas</span>
                        </a>
                    </li>
                    <li>
                        <a href="../reportes/index.php" data-permiso="reportes.ordenes|reportes.nomina" <?php echo $active_page === 'reportes' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-chart-bar"></i>
                            <span>Reportes</span>
                        </a>
                    </li>
                    <li>
                        <a href="../auditoria/index.php" data-permiso="auditoria.ver" <?php echo $active_page === 'auditoria' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-shield-alt"></i>
                            <span>Auditoría</span>
                        </a>
                    </li>
                    <li>
                        <a href="../chat/index-trabajadores.php" data-permiso="chat.ver" <?php echo $active_page === 'chat' ? 'class="active"' : ''; ?>>
                            <i class="fas fa-comments"></i>
                            <span>Chat</span>
                            <span class="notification-badge" id="badge-chat-sidebar" hidden>0</span>
                        </a>
                    </li>
                    <li class="separator"></li>
                    <li>
                    <a href="../configuracion/index.php" data-permiso="configuracion.ver|configuracion.editar" <?php echo $active_page === 'configuracion' ? 'class="active"' : ''; ?> id="btn-configuracion">
                            <i class="fas fa-cog"></i>
                            <span>Configuración</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="../auth/login.php" class="btn-salir" id="btn-cerrar-sesion-oficina">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Cerrar Sesión</span>
                </a>
            </div>
        </aside>
