<?php
// Scripts globales compartidos por todos los módulos
?>
    <script src="../../assets/js/utils/theme.js?v=20260915chat2"></script>
    <script src="../../assets/js/utils/session-guard.js?v=20260915mecrol1"></script>
    <script>MotorSoftGuard.exigir('trabajadores');</script>
    <script src="../../assets/js/config.js"></script>
    <script src="../../assets/js/utils/input-filters.js"></script>
    <script src="../../assets/js/utils/placa.js?v=20260915placa1"></script>
    <script src="../../assets/js/api.js?v=20260915placa1"></script>
    <script src="../../assets/js/trabajadores/app.js?v=20260915ot2"></script>
    <script src="../../assets/js/trabajadores/notificaciones.js?v=20260915int1"></script>
    <script src="../../assets/js/trabajadores/module-core.js?v=20260915ot2"></script>
    <script src="../../assets/js/trabajadores/data-store.js?v=20260915cerca1"></script>
    <script src="../../assets/js/trabajadores/sidebar-nav.js?v=20260915precio1"></script>
</body>
</html>
